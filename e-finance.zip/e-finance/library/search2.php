<?
require_once 'connectionmysql.php';
Connected();
$term = trim(strip_tags($_GET['term']));//retrieve the search term that autocomplete sends
$send = trim(strip_tags($_GET['send']));//retrieve the search term that autocomplete sends


$qstring = "SELECT items.id as item_id, items.piece_id, items.unit_id, items.name, items.code, items.pcs, items.pcsname, items.icategory_id, items.saleprice, items.buyprice, items.minstock, items.isupdate, items.stock, pieces.id, pieces.name as satuan  FROM items LEFT JOIN pieces ON (items.piece_id = pieces.id) WHERE items.unit_id = '".$send."' AND items.icategory_id = '2' AND items.name LIKE '%".$term."%'";
$result = mysql_query($qstring);//query the database for entries containing the term

while ($row = mysql_fetch_array($result,MYSQL_ASSOC))//loop through the retrieved values
{
		$row['item_id']=(int)$row['item_id'];
		$row['value']=htmlentities(stripslashes($row['name']));
		$row['buyprice']=htmlentities(stripslashes($row['buyprice']));
		$row['saleprice']=htmlentities(stripslashes($row['saleprice']));
		$row['stock']=htmlentities(stripslashes($row['stock']));
		$row['disc']=(int)$row['saleprice']*10/100;
		$row['salemindisc']=(int)$row['saleprice']-($row['saleprice']*10/100);
		$row['satuan']=htmlentities(stripslashes($row['satuan']));
		
		
		
		$row_set[] = $row;//build an array
}
echo json_encode($row_set);//format the array into json data


?>