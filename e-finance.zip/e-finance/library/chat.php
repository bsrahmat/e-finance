<?
require_once 'connectionmysql.php';

Connected();

if ($_GET['action'] == "chatheartbeat") { chatHeartbeat(); } 
if ($_GET['action'] == "sendchat") { sendChat(); } 
if ($_GET['action'] == "closechat") { closeChat(); } 
if ($_GET['action'] == "startchatsession") { startChatSession(); } 

if (!isset($_SESSION['chatHistory'])) {
	$_SESSION['chatHistory'] = array();	
}

if (!isset($_SESSION['openChatBoxes'])) {
	$_SESSION['openChatBoxes'] = array();	
}

function chatHeartbeat() {
	
	$sql = "select * from tbl_chat where (tbl_chat.chat_to = '".mysql_real_escape_string($_SESSION['simonev_username'])."' AND tbl_chat.chat_recd = 0) order by tbl_chat.chat_kode ASC";
	$query = mysql_query($sql);
	$items = '';

	$chatBoxes = array();

	while ($chat = mysql_fetch_array($query)) {

		if (!isset($_SESSION['openChatBoxes'][$chat['chat_from']]) && isset($_SESSION['chatHistory'][$chat['chat_from']])) {
			$items = $_SESSION['chatHistory'][$chat['chat_from']];
		}

		$chat['chat_message'] = sanitize($chat['chat_message']);

		$items .= <<<EOD
					   {
			"s": "0",
			"f": "{$chat['chat_from']}",
			"m": "{$chat['chat_message']}"
	   },
EOD;

	if (!isset($_SESSION['chatHistory'][$chat['chat_from']])) {
		$_SESSION['chatHistory'][$chat['chat_from']] = '';
	}

	$_SESSION['chatHistory'][$chat['chat_from']] .= <<<EOD
						   {
			"s": "0",
			"f": "{$chat['chat_from']}",
			"m": "{$chat['chat_message']}"
	   },
EOD;
		
		unset($_SESSION['tsChatBoxes'][$chat['chat_from']]);
		$_SESSION['openChatBoxes'][$chat['chat_from']] = $chat['chat_sent'];
	}

	if (!empty($_SESSION['openChatBoxes'])) {
	foreach ($_SESSION['openChatBoxes'] as $chatbox => $time) {
		if (!isset($_SESSION['tsChatBoxes'][$chatbox])) {
			$now = time()-strtotime($time);
			$time = date('g:iA M dS', strtotime($time));

			$chat_message = "Sent at $time";
			if ($now > 180) {
				$items .= <<<EOD
{
"s": "2",
"f": "$chatbox",
"m": "{$chat_message}"
},
EOD;

	if (!isset($_SESSION['chatHistory'][$chatbox])) {
		$_SESSION['chatHistory'][$chatbox] = '';
	}

	$_SESSION['chatHistory'][$chatbox] .= <<<EOD
		{
"s": "2",
"f": "$chatbox",
"m": "{$chat_message}"
},
EOD;
			$_SESSION['tsChatBoxes'][$chatbox] = 1;
		}
		}
	}
}

	$sql = "update tbl_chat set chat_recd = 1 where tbl_chat.chat_to = '".mysql_real_escape_string($_SESSION['simonev_username'])."' and chat_recd = 0";
	$query = mysql_query($sql);

	if ($items != '') {
		$items = substr($items, 0, -1);
	}
header('Content-type: application/json');
?>
{
		"items": [
			<?php echo $items;?>
        ]
}

<?php
			exit(0);
}

function chatBoxSession($chatbox) {
	
	$items = '';
	
	if (isset($_SESSION['chatHistory'][$chatbox])) {
		$items = $_SESSION['chatHistory'][$chatbox];
	}

	return $items;
}

function startChatSession() {
	$items = '';
	if (!empty($_SESSION['openChatBoxes'])) {
		foreach ($_SESSION['openChatBoxes'] as $chatbox => $void) {
			$items .= chatBoxSession($chatbox);
		}
	}


	if ($items != '') {
		$items = substr($items, 0, -1);
	}

header('Content-type: application/json');
?>
{
		"username": "<?php echo $_SESSION['simonev_username'];?>",
		"items": [
			<?php echo $items;?>
        ]
}

<?php


	exit(0);
}

function sendChat() {
	$chat_from = $_SESSION['simonev_username'];
	$chat_to = $_POST['chat_to'];
	$chat_message = $_POST['chat_message'];

	$_SESSION['openChatBoxes'][$_POST['chat_to']] = date('Y-m-d H:i:s', time());
	
	$chat_messagesan = sanitize($chat_message);

	if (!isset($_SESSION['chatHistory'][$_POST['chat_to']])) {
		$_SESSION['chatHistory'][$_POST['chat_to']] = '';
	}

	$_SESSION['chatHistory'][$_POST['chat_to']] .= <<<EOD
					   {
			"s": "1",
			"f": "{$chat_to}",
			"m": "{$chat_messagesan}"
	   },
EOD;


	unset($_SESSION['tsChatBoxes'][$_POST['chat_to']]);

	$sql = "insert into tbl_chat (tbl_chat.chat_from,tbl_chat.chat_to,chat_message,chat_sent) values ('".mysql_real_escape_string($chat_from)."', '".mysql_real_escape_string($chat_to)."','".mysql_real_escape_string($chat_message)."',NOW())";
	$query = mysql_query($sql);
	echo "1";
	exit(0);
}

function closeChat() {

	unset($_SESSION['openChatBoxes'][$_POST['chatbox']]);
	
	echo "1";
	exit(0);
}

function sanitize($text) {
	$text = htmlspecialchars($text, ENT_QUOTES);
	$text = str_replace("\n\r","\n",$text);
	$text = str_replace("\r\n","\n",$text);
	$text = str_replace("\n","<br>",$text);
	return $text;
}
