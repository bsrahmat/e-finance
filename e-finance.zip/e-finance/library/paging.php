<?php
// rodentzoft 
// datadunia.cb@gmail.com
// class universal pagination free v2
// update 20102011
// changelog :
// 1. removed -> embbeded -> css,class,href,div,ul,a,extra parameter each tag, long way
// 2. easy -> output to array or public class variabel, install
// 3. less -> variabel input
class pagination{

        public  $currentPage=1;    
        public  $total= 1;    
        public  $limit=10;    
        public  $rangenum=5;    
        public  $baseLink='#';    

public function getHalaman(){

		$currentPage	= $this->currentPage;
		$total			= $this->total;
		$limit			= $this->limit;
		$baseLink		= $this->baseLink;
		$rangenum		= $this->rangenum;
		//output ( on v2.1 will deprecated )
		$PageFirst;		$LinkFirst;
		$PageLast;		$LinkLast;
		$PageNumber;	$LinkNumber;// output array
		$PagePrev;		$LinkPrev;
		$PageNext;		$LinkNext;
		$PageTotal;
		// array output
		$Output;

		if($total<=0) $total = 1;
		
		if(!$total OR !$baseLink){
			return false;
		}
		if(!$currentPage){
			$this->currentPage	= 1;
			$currentPage		= 1;
		}

		$totalPages = ceil($total/$limit);

		$min = ($currentPage - $rangenum < $totalPages && $currentPage- $rangenum > 0) ? $currentPage - $rangenum : 1;
		$max = ($currentPage + $rangenum > $totalPages) ? $totalPages : $currentPage + $rangenum;

		$this->PageFirst	= 1;
		$this->LinkFirst	= $this->baseLink.'1';

			for($i=$min;$i<=$max;$i++){
				$this->PageNumber[]				= $i;
				$this->LinkNumber[]				= $this->baseLink."$i";
			}

		$this->PageLast			= $totalPages;
		$this->LinkLast			= $this->baseLink.$totalPages;

		$this->PagePrev		= ($currentPage - 1 > 0 )			? ($currentPage - 1): $currentPage ;
		$this->LinkPrev		= $this->baseLink.$this->PagePrev;
		$this->PageNext		= ($currentPage + 1 <= $totalPages)	? ($currentPage + 1): $currentPage ;
		$this->LinkNext		= $this->baseLink.$this->PageNext;
		$this->Output['total']['all']	= $total;
		$this->Output['total']['page']	= $totalPages;
		$this->Output['total']['string']	= $totalPages;

				$this->Output['page']['first']	= $this->PageFirst;
				$this->Output['link']['first']	= $this->LinkFirst;
				$this->Output['page']['last']	= $this->PageLast;
				$this->Output['link']['last']	= $this->LinkLast;
				$this->Output['Page']['number']	= $this->PageNumber;
				$this->Output['link']['number']	= $this->LinkNumber;
				$this->Output['page']['prev']	= $this->PagePrev;
				$this->Output['link']['prev']	= $this->LinkPrev;
				$this->Output['page']['next']	= $this->PageNext;
				$this->Output['link']['next']	= $this->LinkNext;

		return  $this->Output;
	} 
}
?>