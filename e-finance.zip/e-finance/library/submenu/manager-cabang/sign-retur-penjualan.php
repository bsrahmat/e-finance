
<?php
/////// konfigurasi
///// query untuk paging

if(file_exists('../../connectionmysql.php')) {
	require_once '../../connectionmysql.php';
	Connected();
	$path = '../../../';
} else $path = '../../';

$perm = array();
$perm = getPermissions('4');
if(file_exists('../../error-menu.php')) if($perm[-1]=='1') { require_once '../../error-menu.php'; die; }
$IDmodul= $_SESSION['galaxy_unit'];
	
if($IDmodul=='none') $IDmodul = '-1';

//BAGIAN INPUTAN PENCARIAN
//Fungsi STRIPSTRING berfungsi hanya karakter a-z, A-Z, dan angka 0-9 yang diperbolehkan.
$get_search = '';
$search = '';
$search_name = 'Pencarian...';

if(isset($_GET['search'])) {
	$_GET['search'] = stripInput($_GET['search']);
	$search_name = $_GET['search'];
	
	if($_GET['search'] || $_GET['search'] != 'Pencarian...' || $_GET['search'] != '') {
		$search = "AND LOWER(sreturs.retnom) LIKE '%".strtolower($_GET['search'])."%' OR LOWER(fakturs.faknom) LIKE '%".strtolower($_GET['search'])."%'";
		$get_search = '&search='.strtolower($_GET['search']);
	}
}
$qry_count = '';
if($_SESSION['galaxy_type']=='0')
 $qry_count = "SELECT sreturs.id, sreturs.faktur_id, sreturs.retdate, sreturs.retnom, sreturs.unitid, sreturs.isclosed, sreturs.isacc, sreturs.isok, sreturs.ispost, sreturs.issign, fakturs.id, fakturs.sj_id, fakturs.fakdate, fakturs.faknom, fakturs.unitid, fakturs.tempodate, fakturs.ispost, fakturs.post, fakturs.isclosed FROM sreturs LEFT JOIN fakturs ON (sreturs.faktur_id = fakturs.id) WHERE sreturs.isacc = '1' AND sreturs.unitid != '10' ".$search;
else
 $qry_count = "SELECT sreturs.id, sreturs.faktur_id, sreturs.retdate, sreturs.retnom, sreturs.unitid, sreturs.isclosed, sreturs.isacc, sreturs.isok, sreturs.ispost, sreturs.issign, fakturs.id, fakturs.sj_id, fakturs.fakdate, fakturs.faknom, fakturs.unitid, fakturs.tempodate, fakturs.ispost, fakturs.post, fakturs.isclosed FROM sreturs LEFT JOIN fakturs ON (sreturs.faktur_id = fakturs.id)  WHERE sreturs.isacc = '1' AND sreturs.unitid != '10' AND sreturs.unitid = '".$_SESSION['galaxy_unit']."' ".$search;

$rs_count = mysql_query($qry_count);
$count  = mysql_num_rows($rs_count);

// variabel paging
$page  = (isset($_GET['p']))?( (is_numeric($_GET['p']))?( $page = $_GET['p']): $page = 1 ): $page = 1;
$limit = 20;
$start = $limit * ($page - 1);

$pager = new pagination();
$pager->currentPage 	= $page;
$pager->total			= $count;
$pager->limit			= $limit;
$pager->baseLink		= 'library/submenu/manager-cabang/sign-retur-penjualan?p=';
$pager->getHalaman(); 
/// output variabel paging
$selPrev = ($page==$pager->PagePrev )?"-selected":'';
$PevLink = 'link="'. $pager->LinkPrev.$get_search.'"';

$selNext	= ($page==$pager->PageNext )?"-selected":'';
$NextLink	= 'link="'. $pager->LinkNext.$get_search.'"';

//query untuk isi
$qry_sreturs = '';
if($_SESSION['galaxy_type']=='0')
 $qry_sreturs = "SELECT sreturs.id, sreturs.faktur_id, sreturs.retdate, sreturs.retnom, sreturs.unitid, sreturs.isclosed, sreturs.isacc, sreturs.isok, sreturs.ispost, sreturs.issign, fakturs.id, fakturs.sj_id, fakturs.fakdate, fakturs.faknom, fakturs.unitid, fakturs.tempodate, fakturs.ispost, fakturs.post, fakturs.isclosed FROM sreturs LEFT JOIN fakturs ON (sreturs.faktur_id = fakturs.id)  WHERE sreturs.isacc = '1' AND sreturs.unitid != '10' ".$search." order by sreturs.id DESC limit $limit offset $start;";
else
 $qry_sreturs = "SELECT sreturs.id, sreturs.faktur_id, sreturs.retdate, sreturs.retnom, sreturs.unitid, sreturs.isclosed, sreturs.isacc, sreturs.isok, sreturs.ispost, sreturs.issign, fakturs.id, fakturs.sj_id, fakturs.fakdate, fakturs.faknom, fakturs.unitid, fakturs.tempodate, fakturs.ispost, fakturs.post, fakturs.isclosed FROM sreturs LEFT JOIN fakturs ON (sreturs.faktur_id = fakturs.id)  WHERE sreturs.isacc = '1' AND sreturs.unitid != '10' AND sreturs.unitid = '".$_SESSION['galaxy_unit']."' ".$search." order by sreturs.id DESC limit $limit offset $start;";

$rs_sreturs = mysql_query($qry_sreturs);

/////////////// ending konfigurasi
////////////// process

?>

                   <div class="sub-content-title">Retur Penjualan</div>
                    
<div class="cboxtable">
                    	<div class="sub-content-bar">
                            <div class="search-button" link="library/submenu/manager-cabang/sign-retur-penjualan"><img src="images/cari.png" /></div>
                            <input class="search-input" type="text" value="<? echo $search_name ?>"  />
                            <div class="search-text">No. Faktur / No Retur : </div>

                        </div>
                      	<div class="ctabletitle">Data Retur Penjualan</div>
						<table class="ctable">
                        <tr class="ctableheader">
                            <td width="6%">No</td>
                            <td width="18%">No. Retur</td>
                            <td width="18%">No. Faktur</td>
                            <td width="9%">Tanggal</td>
                            <td>Customers</td>
                            <td>Sales</td>
                            <td width="10%">Status</td>
                            <td align="center" width="1%">Act</td>
                        </tr>
                        <?php
							$no= $start+1;
							$bg = '';
							$status = '';
							while($rows_sreturs=mysql_fetch_array($rs_sreturs)) {
								$rows_sj=mysql_fetch_array(mysql_query("select * from fakturs LEFT JOIN sjs ON (fakturs.sj_id = sjs.id) LEFT JOIN spbs ON (sjs.spb_id = spbs.id) where fakturs.id = '".$rows_sreturs['faktur_id']."';"));
								$rows_sale=mysql_fetch_array(mysql_query("select * from sales where id = '".$rows_sj['sale_id']."';"));
								$rows_cus=mysql_fetch_array(mysql_query("select * from customers where id = '".$rows_sj['customer_id']."';"));
							if($rows_sreturs[9] == NULL) { $bg = 'style="background-color:#FFCC99; color:#000"';}
							if($rows_sreturs[9] == '1') { $bg = 'style="background-color:#93C194; color:#000"';}
							
							if($rows_sreturs[9] == NULL) { $status = 'BELUM';}
							if($rows_sreturs[9] == '1') { $status = 'SETUJU';}
						?>
                        <tr <? echo $bg ?>>
                            <td align="right"><? echo $no ?></td>
                            <td class="ltext"><? echo $rows_sreturs['retnom'] ?></td>
                            <td class="ltext"><? echo $rows_sreturs['faknom'] ?></td>
                            <td><? echo cDate2($rows_sreturs['retdate']) ?></td>                            
                            <td class="ltext"><? echo $rows_cus['name'] ?></td>
                            <td class="ltext"><? echo $rows_sale['name'] ?></td>
                            <td><b><? echo $status ?></b></td>
                            <td>
                            	<div class="cactions one">                                
                                <div class="cview" title="Detail" link="library/submenu/manager-cabang/detail/sign-retur-penjualan?<? echo $rows_sreturs[0] ?>&p=<? echo $page ?>"></div>
                                
                               
                            	</div>
                            </td>
                        </tr>
						<?php
						$no++;
							}
						?>
                        </table>
						</div>
                        <div class="ctablefooter">
                        
                        	                
                        	<ul class="paginationbox">
                            <li><div class="pagination-button<?php echo $selPrev?>" <?php echo $PevLink?>>Sebelumnya</div></li>
    
                            <?php
                            for ($numPage=0;$numPage<count($pager->PageNumber);$numPage++){
							$selNnum	= ($page==$pager->PageNumber[$numPage] )?"-selected":'';
							$link		= 'link="'.$pager->LinkNumber[$numPage].$get_search.'"';
							echo	'<li><div class="pagination-button'. $selNnum .'" '.$link.'>'.$pager->PageNumber[$numPage].'</div></li>';
                            }
                            ?>
                            <li><div class="pagination-button<?php echo $selNext?>" <?php echo $NextLink?>>Selanjutnya</div></li>
                            </ul>
                        
                        </div>
                      
                    <input name="p" type="hidden" value="<? echo $page ?>" />
                    





