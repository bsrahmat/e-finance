<script type="text/javascript">
 $(document).ready(function(){
   $(".ctable tr").mouseover(function(){$(this).addClass("over");}).mouseout(function(){$(this).removeClass("over");});
   $(".ctable tr:even").addClass("alt");
 });
 </script>
<?php
if(file_exists('../../../connectionmysql.php')) {
	require_once '../../../connectionmysql.php';
	Connected();
}
$perm = array();
$perm = getPermissions('2');
if(file_exists('../../error-menu.php')) if($perm[-1]=='1') { require_once '../../error-menu.php'; die; }
$page  = (isset($_GET['p']))?( (is_numeric($_GET['p']))?( $page = $_GET['p']): $page = 1 ): $page = 1;
$qry_trprequests = '';

$qry_trprequests = "select * from trprequests JOIN units ON (trprequests.unit_id = units.id) where trprequests.id = '".$_GET['gid']."';";
$rs_trprequests = mysql_query($qry_trprequests);
$rows_trprequests=mysql_fetch_array($rs_trprequests);
/////////////// ending konfigurasi
////////////// process

$qry_isi = "SELECT * FROM trprdetails WHERE trprequest_id = '".$_GET['gid']."';";
$rs_isi = mysql_query($qry_isi);
$cnt_isi = mysql_num_rows($rs_isi);


?>

                   <div class="sub-content-title">Permintaan Pembelian</div>
				   <div class="cboxtable">
                    <div style="float: right; width: auto; padding: 2px 0; "><label style="width: 115px; color: black;"><input style="float: left; margin-right: 4px;" type="checkbox" name="show-hide" value="1" checked/>Show/Hide</label></div> 
					<script type="text/javascript">
                            $("input[name='show-hide']").unbind('click').click(function() { 
                                if($(this).attr('checked')==true) {
								$("div[class^='show-body']").slideToggle("normal");
                                $("div[class^='show-body']").show();
                                } else
								$("div[class^='show-body']").slideToggle("normal");
                                $("div[class^='show-body']").hide();
                            }) 
					</script>                   
                    	<div class="sub-content-bar">
                          <div class="show-hide">
                          <div class="show-body">
                          <table class="show-table">
                          <tr>
                          <td width="18%" align="right">No. Permintaan</td>
                          <td width="5%" align="center">:</td>
                          <td align="left"><? echo $rows_trprequests['prnom'] ?></td>
                          </tr>
                          <tr>
                          <td align="right">Tanggal</td>
                          <td align="center">:</td>
                          <td align="left"><? echo cDate2($rows_trprequests['prdate']) ?></td>
                          </tr>
                          <tr>
                          <td align="right">Cabang Peminta</td>
                          <td align="center">:</td>
                          <td align="left"><? echo $rows_trprequests['name'] ?></td>
                          </tr>
                          <tr>
                          <td align="right">Nama Peminta</td>
                          <td align="center">:</td>
                          <td align="left"><? echo $rows_trprequests['prname'] ?></td>
                          </tr>
                          
                          </table>
                          </div>
                          <div class="popup-footer">
                            <div link="library/submenu/manager-cabang/pemeriksaan-pb" class="button-back">Kembali</div>
                            
                           
                            
                            	<? if($rows_trprequests['gmsign']=='' && $cnt_isi>0) { ?>
                                <div link="modul/manager-cabang/pemeriksaan-pb?<? echo $rows_trprequests[0] ?>" title="Setuju" mode="7" type="popup" class="acc-button">Setuju</div>
                                <? } else { ?>
                            	<div class="disabled-acc-button">Setuju</div>
                            	<? } ?>
                                <? if($rows_trprequests['gmsign']=='' && $cnt_isi>0) { ?>
                                <div link="modul/manager-cabang/pemeriksaan-pb?<? echo $rows_trprequests[0] ?>" title="Tolak" mode="8" type="popup" class="hold-button">Tolak</div>
                                <? } else { ?>
                            	<div class="disabled-hold-button">Tolak</div>
                            	<? } ?>
                            
                            
                          </div>
                          </div>
                        </div>
                      	<div class="ctabletitle">Daftar Permintaan Pembelian</div>
						<table class="ctable">
                        <tr class="ctableheader">
                            <td width="6%">No</td>
                            <td>Nama Barang</td>
                            <td width="15%">Satuan</td>
                            <td width="9%">Qty</td>
                            <? if($rows_trprequests['gmsign']=='2' || $rows_trprequests['gmsign']=='') { ?>
                            <td width="9%">Stock</td>
                            <? } ?>
                            <td width="10%">W.Butuh</td>
                            
                        </tr>
                        <?php
							$qry_trprdetails = "select * from trprdetails JOIN items ON (trprdetails.item_id = items.id) where trprequest_id = '".$_GET['gid']."';";
							$rs_trprdetails = mysql_query($qry_trprdetails);
							$no= 1;
							while($rows_trprdetails=mysql_fetch_array($rs_trprdetails)) {
								$rows_satuan=mysql_fetch_array(mysql_query("select * from pieces where id = '".$rows_trprdetails['piece_id']."';"));
							
						?>
                        <tr>
                            <td align="right"><? echo $no ?></td>
                            <td class="ltext"><? echo $rows_trprdetails['name'] ?></td>
                            <td><? echo $rows_satuan['name'] ?></td>                            
                            <td align="right"><? echo cFormat($rows_trprdetails['qty'],false) ?></td>
                            <? if($rows_trprequests['gmsign']=='2' || $rows_trprequests['gmsign']=='') { ?>
                            <td align="right"><? echo cFormat($rows_trprdetails['stock'],true) ?></td>
                            <? } ?>
                            <td><? echo cDate2($rows_trprdetails['timereq']) ?></td>
                            
                        </tr>
						<?php
						$no++;
							}
						?>
                        </table>
						</div>
                        <div class="ctablefooter">
							
                        
                        </div>   
                    <input name="p" type="hidden" value="<? echo $page ?>" />