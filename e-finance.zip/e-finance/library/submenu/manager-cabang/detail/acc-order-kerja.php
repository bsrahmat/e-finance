<script type="text/javascript">
 $(document).ready(function(){
   $(".ctable tr").mouseover(function(){$(this).addClass("over");}).mouseout(function(){$(this).removeClass("over");});
   $(".ctable tr:even").addClass("alt");
 });
 </script>
<?php
if(file_exists('../../../connectionmysql.php')) {
	require_once '../../../connectionmysql.php';
	Connected();
}
$perm = array();
$perm = getPermissions('3');
if(file_exists('../../error-menu.php')) if($perm[-1]=='1') { require_once '../../error-menu.php'; die; }
$page  = (isset($_GET['p']))?( (is_numeric($_GET['p']))?( $page = $_GET['p']): $page = 1 ): $page = 1;
$qry_worders = '';

$qry_worders = "SELECT worders.id, worders.wodate, worders.wonom, worders.unit_id, worders.isclosed, worders.supplier_id, worders.gmsign, worders.id, units.id, units.gmanager_id, units.name, units.code, units.address, units.phone, units.fax, units.headsale_id, units.rek, units.rekname, units.pusat, units.ismanu, suppliers.id, suppliers.name, suppliers.code, suppliers.address, suppliers.city, suppliers.phone, suppliers.fax, suppliers.upname, suppliers.issubkon FROM worders LEFT JOIN units ON (worders.unit_id = units.id) LEFT JOIN suppliers ON (worders.supplier_id = suppliers.id) where worders.id = '".$_GET['gid']."';";
$rs_worders = mysql_query($qry_worders);
$rows_worders=mysql_fetch_array($rs_worders);
/////////////// ending konfigurasi
////////////// process

?>

                   <div class="sub-content-title">Order Kerja</div>
				   <div class="cboxtable">    
                   <div style="float: right; width: auto; padding: 2px 0; "><label style="width: 115px; color: black;"><input style="float: left; margin-right: 4px;" type="checkbox" name="show-hide" value="1" checked/>Show/Hide</label></div> 
					<script type="text/javascript">
                            $("input[name='show-hide']").unbind('click').click(function() { 
                                if($(this).attr('checked')==true) {
								$("div[class^='show-body']").slideToggle("normal");
                                $("div[class^='show-body']").show();
                                } else
								$("div[class^='show-body']").slideToggle("normal");
                                $("div[class^='show-body']").hide();
                            }) 
					</script>               
                    	<div class="sub-content-bar">
                          <div class="show-hide">
                          <div class="show-body">
                          <table class="show-table">
                          <tr>
                          <td width="18%" align="right">No. Order Kerja</td>
                          <td width="5%" align="center">:</td>
                          <td align="left"><? echo $rows_worders['wonom'] ?></td>
                          </tr>
                          <tr>
                          <td align="right">Tanggal</td>
                          <td align="center">:</td>
                          <td align="left"><? echo cDate2($rows_worders['wodate']) ?></td>
                          </tr>
                          <tr>
                          <td align="right">Cabang Peminta</td>
                          <td align="center">:</td>
                          <td align="left"><? echo $rows_worders[10] ?></td>
                          </tr>
                          <tr>
                          <td align="right">Pelaksana</td>
                          <td align="center">:</td>
                          <td align="left"><? echo $rows_worders[21] ?></td>
                          </tr>
                          
                          </table>
                          </div>
                          <div class="popup-footer">
                            <div link="library/submenu/manager-cabang/acc-order-kerja" class="button-back">Kembali</div>
                            	<? if($rows_worders['gmsign']=='') { ?>
                                <div link="modul/manager-cabang/acc-order-kerja?<? echo $rows_worders[0] ?>" title="Setuju" mode="7" type="popup" class="acc-button">Setuju</div>
                                <? } else { ?>
                            	<div class="disabled-acc-button">Setuju</div>
                            	<? } ?>
                                <? if($rows_worders['gmsign']=='') { ?>
                                <div link="modul/manager-cabang/acc-order-kerja?<? echo $rows_worders[0] ?>" title="Tolak" mode="8" type="popup" class="hold-button">Tolak</div>
                                <? } else { ?>
                            	<div class="disabled-hold-button">Tolak</div>
                            	<? } ?>
                          </div>
                          </div>
                        </div>
                      	<div class="ctabletitle">Daftar Order Kerja</div>
						<table class="ctable">
                        <tr class="ctableheader">
                            <td width="6%">No</td>
                            <td>Nama Pekerjaan</td>
                            <td width="10%">Biaya</td>
                            
                        </tr>
                        <?php
							$qry_wodetails = "select * from wodetails JOIN items ON (wodetails.item_id = items.id) where worder_id = '".$_GET['gid']."';";
							$rs_wodetails = mysql_query($qry_wodetails);
							$no= 1;
							while($rows_wodetails=mysql_fetch_array($rs_wodetails)) {
								
						?>
                        <tr>
                            <td align="right"><? echo $no ?></td>
                            <td class="ltext"><? echo $rows_wodetails['name'] ?></td>
                                                  
                            <td align="right"><? echo cFormat($rows_wodetails['price'],false) ?></td>
                           
                            
                        </tr>
						<?php
						$no++;
							}
						?>
                        </table>
						</div>
                        <div class="ctablefooter">
							
                        
                        </div>
                           
                    <input name="p" type="hidden" value="<? echo $page ?>" />