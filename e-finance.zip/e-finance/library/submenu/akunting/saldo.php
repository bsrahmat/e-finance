<?php
/////// konfigurasi
///// query untuk paging

if(file_exists('../../connectionmysql.php')) {
	require_once '../../connectionmysql.php';
	Connected();
	$path = '../../../';
} else $path = '../../';

$perm = array();
$perm = getPermissions('52');

if(file_exists('../../error-menu.php')) if($perm[-1]=='1') { require_once '../../error-menu.php'; die; }
$IDmodul= $_SESSION['galaxy_unit'];

if($IDmodul=='none') $IDmodul = '-1';

//BAGIAN INPUTAN PENCARIAN
//Fungsi STRIPSTRING berfungsi hanya karakter a-z, A-Z, dan angka 0-9 yang diperbolehkan.
$get_search = '';
$search = '';
$search_name = 'Pencarian...';

if(isset($_GET['search'])) {
	$_GET['search'] = $_GET['search'];
	$search_name = $_GET['search'];
	
	$qry_cari="select ID_DETAIL from ak_detail_perk where KODE_DETAIL='".$_GET['search']."' ";
	$qry_cari2="select ID_DETAIL from ak_detail_perk where NAMA_DETAIL LIKE '%".strtolower($_GET['search'])."%'";
	$row_cari=mysql_fetch_array(mysql_query($qry_cari));
	$row_cari2=mysql_fetch_array(mysql_query($qry_cari2));
	
	if($_GET['search'] || $_GET['search'] != 'Pencarian...' || $_GET['search'] != '') {
		if($row_cari){
		$search = "and ak_saldo_awal.ID_DETAIL= '".$row_cari['ID_DETAIL']."' ";
		}
		if($row_cari2){
		$search = "and ak_saldo_awal.ID_DETAIL= '".$row_cari2['ID_DETAIL']."'";
		}
		$get_search = '&search='.strtolower($_GET['search']);
	}
}

$qry_count = '';
if($_SESSION['galaxy_type']=='0')
	$qry_count = "select ak_detail_perk.KODE_DETAIL, ak_detail_perk.NAMA_DETAIL, ak_saldo_awal.ID, ak_saldo_awal.JUMLAH, ak_saldo_awal.TANGGAL from ak_detail_perk, ak_saldo_awal where ID_UNIT !='10' and ak_saldo_awal.ID_UNIT='".$_SESSION['galaxy_unit']."' and ak_saldo_awal.ID_DETAIL =ak_detail_perk.ID_DETAIL ".$search;
else
	$qry_count = "select ak_detail_perk.KODE_DETAIL, ak_detail_perk.NAMA_DETAIL, ak_saldo_awal.ID, ak_saldo_awal.JUMLAH, ak_saldo_awal.TANGGAL from ak_detail_perk, ak_saldo_awal where ak_saldo_awal.ID_UNIT !='10' and ak_saldo_awal.ID_UNIT='".$_SESSION['galaxy_unit']."' and ak_saldo_awal.ID_DETAIL =ak_detail_perk.ID_DETAIL ".$search;

$rs_count = mysql_query($qry_count);
$count  = mysql_num_rows($rs_count);

// variabel paging
$page  = (isset($_GET['p']))?( (is_numeric($_GET['p']))?( $page = $_GET['p']): $page = 1 ): $page = 1;
$limit = 20;
$start = $limit * ($page - 1);

$pager = new pagination();
$pager->currentPage 	= $page;
$pager->total			= $count;
$pager->limit			= $limit;
$pager->baseLink		= 'library/submenu/akunting/saldo?p=';
$pager->getHalaman(); 
/// output variabel paging
$selPrev = ($page==$pager->PagePrev )?"-selected":'';
$PevLink = 'link="'. $pager->LinkPrev.$get_search.'"';

$selNext	= ($page==$pager->PageNext )?"-selected":'';
$NextLink	= 'link="'. $pager->LinkNext.$get_search.'"';

//query untuk isi
$qry_saldo = '';
if($_SESSION['galaxy_type']=='0')
	$qry_saldo = "select ak_detail_perk.KODE_DETAIL, ak_detail_perk.NAMA_DETAIL, ak_saldo_awal.ID, ak_saldo_awal.JUMLAH, ak_saldo_awal.TANGGAL from ak_detail_perk, ak_saldo_awal where ID_UNIT !='10' and ak_saldo_awal.ID_UNIT='".$_SESSION['galaxy_unit']."' and ak_saldo_awal.ID_DETAIL =ak_detail_perk.ID_DETAIL ".$search." order by id DESC limit $limit offset $start;";
else
	$qry_saldo = "select ak_detail_perk.KODE_DETAIL, ak_detail_perk.NAMA_DETAIL, ak_saldo_awal.ID, ak_saldo_awal.JUMLAH, ak_saldo_awal.TANGGAL from ak_detail_perk, ak_saldo_awal where ak_saldo_awal.ID_UNIT !='10' and ak_saldo_awal.ID_UNIT='".$_SESSION['galaxy_unit']."' and ak_saldo_awal.ID_DETAIL =ak_detail_perk.ID_DETAIL ".$search." order by id DESC limit $limit offset $start;";

$rs_saldo = mysql_query($qry_saldo);

/////////////// ending konfigurasi
////////////// process
?>

<div class="sub-content-title sub-jenisobat">Saldo Awal</div>
                    
<div class="cboxtable">
    <div class="sub-content-bar">
		<? if($perm[0]!='1') { ?>
        <div class="input-button" type="popup" mode="0" link="modul/akunting/saldo">Tambah Saldo Awal</div>
        <? } else { ?>
        <div class="disabled-input-button">Tambah Saldo Awal</div>
        <? } ?>
        
        <div class="search-button" link="library/submenu/akunting/saldo"><img src="images/cari.png" /></div>
        <input class="search-input" type="text" value="<? echo $search_name ?>"  />
        <div class="search-text">Kd. Perk : </div>
	</div>

    <div class="ctabletitle">Data Saldo Awal</div>
    <table class="ctable">
    <tr class="ctableheader">
        <td width="3%">No</td>
        <td width="20%">Kode Perkiraan</td>
        <td >Nama Perkiraan</td>
        <td width="12%">Tanggal</td>
        <td width="15%">Saldo</td>
        <td align="center" width="5%">Action</td>
        </tr>
        <?php
            $no= $start+1;
            while($rows_saldo=mysql_fetch_array($rs_saldo)) 
            {
        ?>
        <tr>
            <td align="right"><? echo $no ?></td>
            
            <td><? echo $rows_saldo['KODE_DETAIL'] ?></td>
            <td><? echo $rows_saldo['NAMA_DETAIL'] ?></td>
            <td><? echo cDate2($rows_saldo['TANGGAL']) ?></td>
            <td align="right"><? echo cFormat($rows_saldo['JUMLAH'],false) ?></td>
            <td>
            <div class="cactions two">
            
            <? if($perm[1]!='1') { ?>
            <div class="cedit" type="popup" mode="1" title="Edit" link="modul/akunting/saldo?<? echo $rows_saldo['ID'] ?>"></div>
            <? } else { ?>
            <div class="disabled-cedit"></div>
            <? } ?>
            <? if($perm[2]!='1') { ?>
            <div link="modul/akunting/saldo?<? echo $rows_saldo['ID'] ?>" title="Hapus" mode="2" type="popup" class="cdelete"></div>
            <? } else { ?>
            <div class="disabled-cdelete"></div>
            <? } ?>
            </div>
            </td>
        </tr>
        <?php
        $no++;
            }
        ?>
        </table>
							
							
        </div>
        <div class="ctablefooter">
        
                            
            <ul class="paginationbox">
            <li><div class="pagination-button<?php echo $selPrev?>" <?php echo $PevLink?>>Sebelumnya</div></li>

            <?php
            for ($numPage=0;$numPage<count($pager->PageNumber);$numPage++){
            $selNnum	= ($page==$pager->PageNumber[$numPage] )?"-selected":'';
            $link		= 'link="'.$pager->LinkNumber[$numPage].$get_search.'"';
            echo	'<li><div class="pagination-button'. $selNnum .'" '.$link.'>'.$pager->PageNumber[$numPage].'</div></li>';
            }
            ?>
            <li><div class="pagination-button<?php echo $selNext?>" <?php echo $NextLink?>>Selanjutnya</div></li>
            </ul>
        
        </div>
                      
<input name="p" type="hidden" value="<? echo $page ?>" />