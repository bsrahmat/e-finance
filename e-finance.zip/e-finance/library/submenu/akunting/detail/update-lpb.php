<script type="text/javascript">
 $(document).ready(function(){
   $(".ctable tr").mouseover(function(){$(this).addClass("over");}).mouseout(function(){$(this).removeClass("over");});
   $(".ctable tr:even").addClass("alt");
 });
 </script>
<?php
if(file_exists('../../../connectionmysql.php')) {
	require_once '../../../connectionmysql.php';
	Connected();
}
$perm = array();
$perm = getPermissions('22');

if(file_exists('../../error-menu.php')) if($perm[-1]=='1') { require_once '../../error-menu.php'; die; }
$page  = (isset($_GET['p']))?( (is_numeric($_GET['p']))?( $page = $_GET['p']): $page = 1 ): $page = 1;

$qry_trrgoods = '';

$qry_trrgoods = "SELECT * FROM trrgoods LEFT JOIN trporders ON (trrgoods.trporder_id = trporders.id) LEFT JOIN suppliers ON (trporders.supplier_id = suppliers.id) WHERE trrgoods.id = '".$_GET['gid']."';";
$rs_trrgoods = mysql_query($qry_trrgoods);
$rows_trrgoods=mysql_fetch_array($rs_trrgoods);
$rows_akunting=mysql_fetch_array(mysql_query("select * from warehouses where id = '".$rows_trrgoods['warehouse_id']."';"));
$rows_admin=mysql_fetch_array(mysql_query("select * from tbl_admin where admin_kode = '".$rows_trrgoods['postby']."';"));
$posting['0'] = 'Belum';
$posting['1'] = 'Sudah';
$cocok['0'] = 'Tidak Cocok';
$cocok['1'] = 'Cocok';
$cocok['2'] = 'Belum';
$cocok[''] = 'Belum';

/////////////// ending konfigurasi
////////////// process

?>

                   <div class="sub-content-title">Laporan Penerimaan Barang (Bag. akunting)</div>
                    
				   <div class="cboxtable"> 
                   <div style="float: right; width: auto; padding: 2px 0; "><label style="width: 115px; color: black;"><input style="float: left; margin-right: 4px;" type="checkbox" name="show-hide" value="1" checked/>Show/Hide</label></div> 
					<script type="text/javascript">
                            $("input[name='show-hide']").unbind('click').click(function() { 
                                if($(this).attr('checked')==true) {
								$("div[class^='show-body']").slideToggle("normal");
                                $("div[class^='show-body']").show();
                                } else
								$("div[class^='show-body']").slideToggle("normal");
                                $("div[class^='show-body']").hide();
                            }) 
					</script>                                    
                    	<div class="sub-content-bar">
                          <div class="show-hide">
                          <div class="show-body">
                          <table class="show-table">
                          <tr>
                          <td width="20%" align="right">No. LPB</td>
                          <td width="1%" align="center">:</td>
                          <td align="left"><? echo $rows_trrgoods['rgnom'] ?></td>
                          </tr>
                          <tr>
                          <td align="right">Tanggal</td>
                          <td align="center">:</td>
                          <td align="left"><? echo cDate2($rows_trrgoods['rgdate']) ?></td>
                          </tr>
                          <tr>
                          <td align="right">No. PO</td>
                          <td align="center">:</td>
                          <td align="left"><? echo $rows_trrgoods['ponom'] ?></td>
                          </tr>
                          <tr>
                          <td align="right">Tanggal PO</td>
                          <td align="center">:</td>
                          <td align="left"><? echo cDate2($rows_trrgoods['podate']) ?></td>
                          </tr>
                          <tr>
                          <td align="right">No. Faktur</td>
                          <td align="center">:</td>
                          <td align="left"><? echo $rows_trrgoods['fakturnom'] ?></td>
                          </tr>
                          <tr>
                          <td align="right">Referensi (SJ/Faktur)</td>
                          <td align="center">:</td>
                          <td align="left"><? echo $rows_trrgoods['refnom'] ?></td>
                          </tr>
                          <tr>
                          <td align="right">Diterima dari</td>
                          <td align="center">:</td>
                          <td align="left"><? echo $rows_trrgoods['name'] ?></td>
                          </tr>
                          
                          
                          
                          <tr>
                          <td align="right">Alamat</td>
                          <td align="center">:</td>
                          <td align="left"><? echo $rows_trrgoods['address'] ?></td>
                          </tr>
                          <tr>
                          <td align="right">Nama akunting</td>
                          <td align="center">:</td>
                          <td align="left"><? echo $rows_akunting['name'] ?></td>
                          </tr>
                          <tr>
                          <td align="right">Penerima di akunting</td>
                          <td align="center">:</td>
                          <td align="left"><? echo $rows_trrgoods['recipient'] ?></td>
                          </tr>
                          <tr>
                          <td align="right">Kepala akunting</td>
                          <td align="center">:</td>
                          <td align="left"><? echo $rows_akunting['whhead'] ?></td>
                          </tr>
                          <tr>
                          <td align="right">Pemeriksaan akunting</td>
                          <td align="center">:</td>
                          <td align="left"><? echo $cocok[$rows_trrgoods['prsign']] ?></td>
                          </tr>
                          <tr>
                          <td align="right">Status Posting</td>
                          <td align="center">:</td>
                          <td align="left"><? echo $posting[$rows_trrgoods['isposted']] ?></td>
                          </tr>
                          <tr>
                          <td align="right">Di Posting oleh</td>
                          <td align="center">:</td>
                          <td align="left"><? echo $rows_admin['admin_full_name'] ?></td>
                          </tr>
                          <tr>
                          <td align="right">Tanggal Posting</td>
                          <td align="center">:</td>
                          <td align="left"><? echo $rows_trrgoods['postdate'] ?></td>
                          </tr>
                          </table>
                          </div>
                          <div class="popup-footer">
                            <div link="library/submenu/akunting/update-lpb" class="button-back">Kembali</div>
                            <div target="<? echo md5('update-lpb') ?>" type="pdf" link="modul/laporan/report?<? echo $rows_trrgoods[0] ?>" class="pdf-button" >Cetak LPB</div>                    
                            <div class="input-button" type="popup" mode="1" link="modul/akunting/update-lpb?<? echo $rows_trrgoods[0] ?>">No Faktur</div>
                            
                            <? if($rows_trrgoods['fakturnom']!='' && $rows_trrgoods['isposted'] != '1') { ?>
                                <div link="modul/akunting/update-lpb?<? echo $rows_trrgoods[0] ?>" title="Close" mode="0" type="popup" class="hold-button">Close</div>
                                <? } else { ?>
                            	<div class="disabled-hold-button">Close</div>
                            	<? } ?>
                           
                          </div>
                          </div>
                        </div>
                       
                        
                        <div class="ctabletitle">Daftar LPB</div>
						<table class="ctable">
                        <tr class="ctableheader">
                            <td width="6%">No</td>
                            <td>Nama Barang</td>
                            <td width="5%">Jumlah</td>
                            <td width="9%">Satuan</td>
                            <td width="8%">HP</td>
                            <td width="8%">HP Tot</td>
                            <td width="8%">PPn/Brang</td>
                            <td width="8%">Utang Dagang</td>
                            <td align="center" width="2%">Act</td>
                        </tr>
                        <?php
							$qry_trrgdetails = "select * from trrgdetails JOIN items ON ( trrgdetails.item_id = items.id) where trrgood_id = '".$_GET['gid']."';";
							$rs_trrgdetails = mysql_query($qry_trrgdetails);
							$no= 1;
							while($rows_trrgdetails=mysql_fetch_array($rs_trrgdetails)) {
								$rows_satuan=mysql_fetch_array(mysql_query("select * from pieces where id = '".$rows_trrgdetails['piece_id']."';"));
								//$t_harga = $rows_trrgdetails['qty'] * $rows_trrgdetails['price'];
								//$t_ppn = $rows_trrgdetails['tax'] * $rows_trrgdetails['qty'];
								//$total = $t_harga - $t_ppn ;
							
						?>
                        <tr>
                            <td align="right"><? echo $no ?></td>
                            <td class="ltext"><? echo $rows_trrgdetails['name'] ?></td>
                            <td align="right"><? echo cFormat($rows_trrgdetails['qty'],false) ?></td>                            
                            <td><? echo $rows_satuan['name'] ?></td>
                            <td align="right"><? echo cFormat($rows_trrgdetails['hpp'],false) ?></td> 
                            <td align="right"><? echo cFormat($rows_trrgdetails['hpptot'],false) ?></td> 
                            <td align="right"><? echo cFormat($rows_trrgdetails['ppnperitem'],false) ?></td> 
                            <td align="right"><? echo cFormat($rows_trrgdetails['debt'],false) ?></td> 
                            <td>
                            	<div class="cactions one">
                                <? if($_SESSION['galaxy_kode'] == '1' || $rows_trrgoods['isposted']!='1') { ?>                               
                                <div class="cedit" type="popup" mode="1" title="Edit" link="modul/akunting/detail/update-lpb?<? echo $_GET['gid'] ?>&sub=<? echo $rows_trrgdetails[0] ?>"></div>
                                <? } else { ?>
                            	<div class="disabled-cedit"></div>
                            	<? } ?>
                                
                            	</div>
                            </td>
                        </tr>
						<?php
						$no++;
							}
						?>
                         
                        </table>
                        
						</div>
                        <input name="p" type="hidden" value="<? echo $page ?>" />