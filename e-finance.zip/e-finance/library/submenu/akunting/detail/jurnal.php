<script type="text/javascript">
 $(document).ready(function(){
   $(".ctable tr").mouseover(function(){$(this).addClass("over");}).mouseout(function(){$(this).removeClass("over");});
   $(".ctable tr:even").addClass("alt");
 });
 </script>
 
<?php
if(file_exists('../../../connectionmysql.php')) {
	require_once '../../../connectionmysql.php';
	Connected();
}

$qry_jurnal= '';

$qry_jurnal = "select * from ak_jurnal where id = '".$_GET['gid']."';";
$rs_jurnal = mysql_query($qry_jurnal);
$rows_jurnal = mysql_fetch_array($rs_jurnal);
/////////////// ending konfigurasi
////////////// process

?>
 
<div class="sub-content-title">Jurnal</div>
<div style="float: right; width: auto; padding: 2px 0; "><label style="width: 115px; color: black;"><input style="float: left; margin-right: 4px;" type="checkbox" name="show-hide" value="1" checked/>Show/Hide</label></div> 
<script type="text/javascript">
		$("input[name='show-hide']").unbind('click').click(function() { 
			if($(this).attr('checked')==true) {
			$("div[class^='show-body']").slideToggle("normal");
			$("div[class^='show-body']").show();
			} else
			$("div[class^='show-body']").slideToggle("normal");
			$("div[class^='show-body']").hide();
		}) 
</script>

<div class="cboxtable"> 
	<div class="sub-content-bar">
    	<div class="show-hide">
        <div class="show-body">
          <table class="show-table">
          <tr>
          <td width="20%" align="right">No. Bukti</td>
          <td width="5%" align="center">:</td>
          <td align="left"><? echo $rows_jurnal['NO_BUKTI'] ?></td>
          </tr>
          <tr>
          <td width="20%" align="right">Tanggal</td>
          <td width="5%" align="center">:</td>
          <td align="left"><? echo cDate2($rows_jurnal['TANGGAL_TRANS']) ?></td>
          </tr>
          <tr>
          <td width="20%" align="right">No. Reff</td>
          <td width="5%" align="center">:</td>
          <td align="left"><? echo $rows_jurnal['NO_REFF'] ?></td>
          </tr>
          
          </table>
		</div>
        <div class="popup-footer">
        	<div link="library/submenu/akunting/jurnal" class="button-back">Kembali</div>
            <div target="<? echo md5('cetak-Jurnal') ?>" type="pdf" link="modul/laporan/report?<? echo $rows_jurnal[0] ?>" class="pdf-button" >Cetak Jurnal</div>   
            <?
            if($_SESSION['galaxy_kode']==1)
			{
			?>
            <div class="input-button" type="popup" mode="1" link="modul/akunting/jurnal?<? echo $rows_jurnal[0] ?>">Edit Jurnal</div>
            <?
			}
			else
			{
            ?>
            <div class="disabled-input-button">Edit Jurnal</div>
            <?
			}
			?>
        </div>
    </div>
</div>
<div class="ctabletitle">Rincian Jurnal</div>
<table class="ctable">
	<tr class="ctableheader">
        <td width="10%">Kd. Perk</td>
        <td>Uraian</td>
        <td width="12%">Eq. Debit</td>
        <td width="12%">Eq. Credit</td>
        <td width="20%">Nm. Perk</td>
    </tr>
    <?php
		$qry_detail = "select * from ak_jurnal where ID = '".$_GET['gid']."';";
		$rs_detail = mysql_query($qry_detail);
		
		while($rows_detail=mysql_fetch_array($rs_detail)) 
		{
			$qry_nm= "select KODE_DETAIL, NAMA_DETAIL from ak_detail_perk where ID_DETAIL = '".$rows_detail['PERK_DEBET']."';";
			$rs_nm = mysql_query($qry_nm);
			$rows_nm=mysql_fetch_array($rs_nm)
	?>
			<tr>
                <td><? echo $rows_nm['KODE_DETAIL'] ?></td>
                <td><? echo $rows_detail['URAIAN_DEBET'] ?></td>
                <td align="right"><? echo cFormat($rows_detail['DEBET'],false) ?></td>
                <td></td>
                <td><? echo $rows_nm['NAMA_DETAIL'] ?></td>
            </tr>
            <?
            $qry_nm2= "select KODE_DETAIL, NAMA_DETAIL from ak_detail_perk where ID_DETAIL = '".$rows_detail['PERK_KREDIT']."';";
			$rs_nm2 = mysql_query($qry_nm2);
			$rows_nm2=mysql_fetch_array($rs_nm2)
			?>
            <tr>
                <td><? echo $rows_nm2['KODE_DETAIL'] ?></td>
            	<td><? echo $rows_detail['URAIAN_KREDIT'] ?></td>
                <td></td>
                <td align="right"><? echo cFormat($rows_detail['KREDIT'],false) ?></td>
                <td><? echo $rows_nm2['NAMA_DETAIL'] ?></td>
			</tr>
    <? 
		}
		
		$qry_detail2 = "select * from ak_temp_jurnal where JURNAL_ID = '".$_GET['gid']."';";
		$rs_detail2 = mysql_query($qry_detail2);
		while($rows_detail2=mysql_fetch_array($rs_detail2)) 
		{
			$qry_nm2= "select * from ak_detail_perk where ID_DETAIL = '".$rows_detail2['PERK']."';";
			$rs_nm2 = mysql_query($qry_nm2);
			$rows_nm2=mysql_fetch_array($rs_nm2)
	?>
			<tr>
            <td><? echo $no ?></td>
            <td><? echo $rows_nm2['KODE_DETAIL'] ?></td>
            <td><? echo $rows_detail2['URAIAN'] ?></td>
            <td align="right"><? echo cFormat($rows_detail2['DEBET'],false) ?></td>
            <td align="right"><? echo cFormat($rows_detail2['KREDIT'],false) ?></td>
            <td><? echo $rows_nm2['NAMA_DETAIL'] ?></td>
            
            <td>
                <div class="cactions two">
                	<div class="cedit" type="popup" mode="1" title="Edit" link="modul/akunting/detail/jurnal2?<? echo $_GET['gid'] ?>&sub=<? echo $rows_detail2[0] ?>"></div>
                	<div class="cdelete" type="popup" mode="2" title="Hapus" link="modul/akunting/detail/jurnal2?<? echo $rows_detail2[0] ?>"></div>
                </div>
            </td>
            </tr>
    <?
			
		}
		
	?>
           
</table>
</div>
