<script type="text/javascript">
 $(document).ready(function(){
   $(".ctable tr").mouseover(function(){$(this).addClass("over");}).mouseout(function(){$(this).removeClass("over");});
   $(".ctable tr:even").addClass("alt");
 });
 </script>
<?php
if(file_exists('../../../connectionmysql.php')) {
	require_once '../../../connectionmysql.php';
	Connected();
}
$perm = array();
$perm = getPermissions('25');

if(file_exists('../../error-menu.php')) if($perm[-1]=='1') { require_once '../../error-menu.php'; die; }
$page  = (isset($_GET['p']))?( (is_numeric($_GET['p']))?( $page = $_GET['p']): $page = 1 ): $page = 1;

$qry_fakturs = '';
$qry_fakturs = "SELECT fakturs.id, fakturs.isclosed, fakturs.sj_id, fakturs.fakdate, fakturs.faknom, fakturs.unitid, fakturs.tempodate, fakturs.ispost, fakturs.post, sjs.id, sjs.spb_id, sjs.sjdate, sjs.sjnom, sjs.unitid, sjs.isclosed, sjs.istaken, sjs.warehouse_id, sjs.jtdate FROM fakturs LEFT JOIN sjs ON (fakturs.sj_id = sjs.id) WHERE fakturs.id = '".$_GET['gid']."';";
$rs_fakturs = mysql_query($qry_fakturs);
$rows_fakturs=mysql_fetch_array($rs_fakturs);
$rows_customers=mysql_fetch_array(mysql_query("select spbs.id, spbs.customer_id, spbs.spbnom, customers.id, customers.name from spbs LEFT JOIN  customers ON (spbs.customer_id =  customers.id) where  spbs.id = '".$rows_fakturs['spb_id']."';"));
$posting['0'] = 'Belum';
$posting['1'] = 'Sudah';
$cocok['0'] = 'Tidak Cocok';
$cocok['1'] = 'Cocok';
$cocok['2'] = 'Belum';
$cocok[''] = 'Belum';

/////////////// ending konfigurasi
////////////// process

?>

                   <div class="sub-content-title">Faktur</div>
                    
				   <div class="cboxtable"> 
                   <div style="float: right; width: auto; padding: 2px 0; "><label style="width: 115px; color: black;"><input style="float: left; margin-right: 4px;" type="checkbox" name="show-hide" value="1" checked/>Show/Hide</label></div> 
					<script type="text/javascript">
                            $("input[name='show-hide']").unbind('click').click(function() { 
                                if($(this).attr('checked')==true) {
								$("div[class^='show-body']").slideToggle("normal");
                                $("div[class^='show-body']").show();
                                } else
								$("div[class^='show-body']").slideToggle("normal");
                                $("div[class^='show-body']").hide();
                            }) 
					</script>                                    
                    	<div class="sub-content-bar">
                          <div class="show-hide">
                          <div class="show-body">
                          <table class="show-table">
                          <tr>
                          <td width="20%" align="right">Tanggal SJ</td>
                          <td width="1%" align="center">:</td>
                          <td align="left"><? echo cDate2($rows_fakturs['sjdate']) ?></td>
                          </tr>
                          <tr>
                          <td align="right">Tanggal Faktur</td>
                          <td align="center">:</td>
                          <td align="left"><? echo cDate2($rows_fakturs['fakdate']) ?></td>
                          </tr>
                          <tr>
                          <td align="right">Tanggal Jatuh Tempo</td>
                          <td align="center">:</td>
                          <td align="left"><? echo cDate2($rows_fakturs['tempodate']) ?></td>
                          </tr>
                          <tr>
                          <td align="right">No. Faktur</td>
                          <td align="center">:</td>
                          <td align="left"><? echo $rows_fakturs['faknom'] ?></td>
                          </tr>
                          <tr>
                          <td align="right">No. SJ</td>
                          <td align="center">:</td>
                          <td align="left"><? echo $rows_fakturs['sjnom'] ?></td>
                          </tr>
                          <tr>
                          <td align="right">No. SPB</td>
                          <td align="center">:</td>
                          <td align="left"><? echo $rows_customers['spbnom'] ?></td>
                          </tr>
                          <tr>
                          <td align="right">Customer</td>
                          <td align="center">:</td>
                          <td align="left"><? echo $rows_customers['name'] ?></td>
                          </tr>
                          </table>
                          </div>
                          <div class="popup-footer">
                            <div link="library/submenu/akunting/pembuatan-faktur" class="button-back">Kembali</div>
                            <div target="<? echo md5('cetek-faktur') ?>" type="pdf" link="modul/laporan/report?<? echo $rows_fakturs[0] ?>" class="pdf-button" >Cetak Faktur</div>       
                            <? if($rows_fakturs[1]==NULL) { ?>
                                <div class="input-button" type="popup" mode="1" link="modul/akunting/pembuatan-faktur?<? echo $rows_fakturs[0] ?>">No Faktur</div>
                                <? } else { ?>
                            	<div class="disabled-hold-button">No Faktur</div>
                            	<? } ?>                   
                            
                            <? if($rows_fakturs[1]=='1') { ?>
                                <div link="modul/akunting/pembuatan-faktur?<? echo $rows_fakturs[0] ?>" title="Close" mode="0" type="popup" class="hold-button">Close</div>
                                <? } else { ?>
                            	<div class="disabled-hold-button">Close</div>
                            	<? } ?>
                          </div>
                          </div>
                        </div>
                       
                        
                        <div class="ctabletitle">Daftar Barang</div>
						<table class="ctable">
                        <tr class="ctableheader">
                            <td width="6%">No</td>
                            <td>Nama Barang</td>
                            <td width="9%">Qty</td>
                            <td width="9%">Satuan</td>
                            <td width="18%">Harga Satuan</td>
                            
                        </tr>
                        <?php
							$qry_fakdetails = "select * from fakdetails JOIN items ON ( fakdetails.item_id = items.id) where faktur_id = '".$_GET['gid']."';";
							$rs_fakdetails = mysql_query($qry_fakdetails);
							$no= 1;
							while($rows_fakdetails=mysql_fetch_array($rs_fakdetails)) {
								$rows_satuan=mysql_fetch_array(mysql_query("select * from pieces where id = '".$rows_fakdetails['piece_id']."';"));
								//$t_harga = $rows_fakdetails['qty'] * $rows_fakdetails['price'];
								//$t_ppn = $rows_fakdetails['tax'] * $rows_fakdetails['qty'];
								//$total = $t_harga - $t_ppn ;
							
						?>
                        <tr>
                            <td align="right"><? echo $no ?></td>
                            <td class="ltext"><? echo $rows_fakdetails['name'] ?></td>
                            <td align="right"><? echo cFormat($rows_fakdetails[3],false) ?></td>                            
                            <td><? echo $rows_satuan['name'] ?></td>
                            <td align="right"><? echo cFormat($rows_fakdetails[4],false) ?></td>
                           
                        </tr>
						<?php
						$no++;
							}
						?>
                         
                        </table>
                        
						</div>   
                    <input name="p" type="hidden" value="<? echo $page ?>" />