<script type="text/javascript">
 $(document).ready(function(){
   $(".ctable tr").mouseover(function(){$(this).addClass("over");}).mouseout(function(){$(this).removeClass("over");});
   $(".ctable tr:even").addClass("alt");
 });
 </script>
 
<?php
if(file_exists('../../../connectionmysql.php')) {
	require_once '../../../connectionmysql.php';
	Connected();
}
$page  = (isset($_GET['p']))?( (is_numeric($_GET['p']))?( $page = $_GET['p']): $page = 1 ): $page = 1;

$qry_wends= '';
 
$qry_wends = "SELECT wends.id, wends.worder_id, wends.wenom, wends.fakturnom, wends.wedate, wends.description, wends.postby, wends.postdate, wends.isposted, wends.ispay, wends.prname, wends.unitid, wends.isclosed, wends.refnom, wends.id, worders.id, worders.wodate, worders.wonom, worders.unit_id, worders.isclosed, worders.supplier_id, worders.gmsign FROM wends LEFT JOIN worders ON (wends.worder_id = worders.id)  WHERE wends.id = '".$_GET['gid']."';";
$rs_wends = mysql_query($qry_wends);
$rows_wends = mysql_fetch_array($rs_wends);
/////////////// ending konfigurasi
////////////// process
?>
 
<div class="sub-content-title">Data Penyelesaian Kerja</div>
<div style="float: right; width: auto; padding: 2px 0; "><label style="width: 115px; color: black;"><input style="float: left; margin-right: 4px;" type="checkbox" name="show-hide" value="1" checked/>Show/Hide</label></div> 
<script type="text/javascript">
		$("input[name='show-hide']").unbind('click').click(function() { 
			if($(this).attr('checked')==true) {
			$("div[class^='show-body']").slideToggle("normal");
			$("div[class^='show-body']").show();
			} else
			$("div[class^='show-body']").slideToggle("normal");
			$("div[class^='show-body']").hide();
		}) 
</script>

<div class="cboxtable"> 
	<div class="sub-content-bar">
    	<div class="show-hide">
        <div class="show-body">
          <table class="show-table">
          <tr>
          <td width="20%" align="right">No. PK</td>
          <td width="5%" align="center">:</td>
          <td align="left"><? echo $rows_wends['wenom'] ?></td>
          </tr>
          <tr>
          <td width="20%" align="right">Tanggal</td>
          <td width="5%" align="center">:</td>
          <td align="left"><? echo cDate2($rows_wends['wedate']) ?></td>
          </tr>
          <tr>
          <td width="20%" align="right">No. WO</td>
          <td width="5%" align="center">:</td>
          <td align="left"><? echo $rows_wends['wonom'] ?></td>
          </tr>
          <tr>
          <td width="20%" align="right">Tanggal WO</td>
          <td width="5%" align="center">:</td>
          <td align="left"><? echo $rows_wends['wodate'] ?>
          </tr>
          <tr>
          <td width="20%" align="right">No. Faktur</td>
          <td width="5%" align="center">:</td>
          <td align="left"><? echo $rows_wends['fakturnom'] ?></td>
          </tr>
          <tr>
          <? 
		  $qry_supplier="select * from suppliers where id='".$rows_wends['supplier_id']."'";
		  $row_supplier=mysql_fetch_array(mysql_query($qry_supplier));
		  ?>
          <td width="20%" align="right">Pelaksana</td>
          <td width="5%" align="center">:</td>
          <td align="left"><? echo $row_supplier['name']?></td>
          </tr>
          <tr>
          <td width="20%" align="right">Alamat</td>
          <td width="5%" align="center">:</td>
          <td align="left"><? echo $row_supplier['address'] ?></td>
          </tr>
          <tr>
          <?
          $status['1'] = 'SUDAH';
		  $status['0'] = 'BELUM';
		  ?>
          <td width="20%" align="right">Status Posting</td>
          <td width="5%" align="center">:</td>
          <td align="left"><? echo $status[$rows_wends['isposted']] ?></td>
          </tr>
          <tr>
          <?
          $qry_user="select * from tbl_admin where admin_kode='".$rows_wends['postby']."'";
		  $row_user=mysql_fetch_array(mysql_query($qry_user));
		  ?>
          <td width="20%" align="right">Di Posting oleh</td>
          <td width="5%" align="center">:</td>
          <td align="left"><? echo $row_user['admin_full_name'] ?></td>
          </tr>
          <tr>
          <td width="20%" align="right">Tanggal Posting</td>
          <td width="5%" align="center">:</td>
          <td align="left"><? echo $rows_wends['postdate'] ?></td>
          </tr>
          </table>
		</div>
        <div class="popup-footer">
            <div link="library/submenu/akunting/end-work" class="button-back">Kembali</div>
            <? if($rows_wends['ispay']=='2') 
			{ 
			?>
                <div class="disabled-input-button">Bayar Dengan Kas</div>
                <div class="disabled-input-button">Bayar Dengan Bank</div>
            
            <?
			}
			else
			{
			?>
            	<div class="input-button" type="popup" mode="11" link="modul/akunting/detail/end-work?<? echo $rows_wends[0] ?>">Bayar Dengan Kas</div>
            <div class="input-button" type="popup" mode="13" link="modul/akunting/detail/end-work?<? echo $rows_wends[0] ?>">Bayar Dengan Bank</div>
            <?
			}
			?>
            
        </div>
    </div>
</div>
<div class="ctabletitle">Daftar Pekerjaan</div>
						<table class="ctable">
                        <tr class="ctableheader">
                            <td width="6%">No</td>
                            <td>Nama Pekerjaan</td>
                            <td width="18%">HPP</td>
                            <td width="18%">PPN/work</td>
                            <td width="18%">Utang Dagang</td> 
                        </tr>
                        <?php
							$qry_wedetails = "select * from wedetails JOIN items ON ( wedetails.item_id = items.id) where wend_id = '".$_GET['gid']."';";
							$rs_wedetails = mysql_query($qry_wedetails);
							$no= 1;
							$total=0;
							while($rows_wedetails=mysql_fetch_array($rs_wedetails)) {
								$rows_satuan=mysql_fetch_array(mysql_query("select * from pieces where id = '".$rows_wedetails['piece_id']."';"));
								//$t_harga = $rows_wedetails['qty'] * $rows_wedetails['price'];
								//$t_ppn = $rows_wedetails['tax'] * $rows_wedetails['qty'];
								//$total = $t_harga - $t_ppn ;
							
						?>
                        <tr>
                            <td align="right"><? echo $no ?></td>
                            <td class="ltext"><? echo $rows_wedetails['name'] ?></td>
                            <td align="right"><? echo cFormat($rows_wedetails['hpp'],false) ?></td>                            
                            <td align="right"><? echo cFormat($rows_wedetails['ppnperitem'],false) ?></td> 
                            <td align="right"><? echo cFormat($rows_wedetails['debt'],false) ?></td>
    <? 
		$total=$total+$rows_wedetails['debt'];
		$no++;
	?>	</tr>
    <?
		}
	?>
    	<tr>
        <td colspan="4"><font size="+1">Total</font></td>
        <td colspan="1" align="right"><font size="+1"><? echo cformat($total,false) ?></font></td>
        </tr>
        <?
		$qry_sisa="select sum(KREDIT) as sisa from ak_htg where WEND_ID='".$_GET['gid']."' ";
		$row_sisa=mysql_fetch_array(mysql_query($qry_sisa));
		$kurang=$total-$row_sisa['sisa'];
		?>
        <tr>
        <td colspan="4"><font size="+1">Sisa</font></td>
        <td colspan="1" align="right"><font size="+1"><? echo cformat($kurang,false) ?></font></td>
        </tr>	
</table>
</div>   
                    <input name="p" type="hidden" value="<? echo $page ?>" />