<script type="text/javascript">
 $(document).ready(function(){
   $(".ctable tr").mouseover(function(){$(this).addClass("over");}).mouseout(function(){$(this).removeClass("over");});
   $(".ctable tr:even").addClass("alt");
 });
 </script>
 
<?php
if(file_exists('../../../connectionmysql.php')) {
	require_once '../../../connectionmysql.php';
	Connected();
}
$page  = (isset($_GET['p']))?( (is_numeric($_GET['p']))?( $page = $_GET['p']): $page = 1 ): $page = 1;

$qry_utang_awal= '';
 
$qry_utang_awal = "SELECT * FROM ak_piut_awal JOIN ak_piut ON (ak_piut_awal.id = ak_piut.piutang_awal_id) JOIN  customers ON (ak_piut.CUSTOMER_ID = customers.id) JOIN units ON (ak_piut.UNIT_ID = units.id) WHERE ak_piut_awal.id = '".$_GET['gid']."';";
$rs_utang_awal = mysql_query($qry_utang_awal);
$rows_utang_awal = mysql_fetch_array($rs_utang_awal);
/////////////// ending konfigurasi
////////////// process
?>
 
<div class="sub-content-title">Piutang Awal</div>
<div style="float: right; width: auto; padding: 2px 0; "><label style="width: 115px; color: black;"><input style="float: left; margin-right: 4px;" type="checkbox" name="show-hide" value="1" checked/>Show/Hide</label></div> 
<script type="text/javascript">
		$("input[name='show-hide']").unbind('click').click(function() { 
			if($(this).attr('checked')==true) {
			$("div[class^='show-body']").slideToggle("normal");
			$("div[class^='show-body']").show();
			} else
			$("div[class^='show-body']").slideToggle("normal");
			$("div[class^='show-body']").hide();
		}) 
</script>

<div class="cboxtable"> 
	<div class="sub-content-bar">
    	<div class="show-hide">
        <div class="show-body">
          <table class="show-table">
          <tr>
          <td width="20%" align="right">Unit</td>
          <td width="5%" align="center">:</td>
          <td align="left"><? echo $rows_utang_awal[29] ?></td>
          </tr>
          <tr>
          <td width="20%" align="right">No Bukti</td>
          <td width="5%" align="center">:</td>
          <td align="left"><? echo $rows_utang_awal[4] ?></td>
          </tr>
          <tr>
          <td width="20%" align="right">Nama Customer</td>
          <td width="5%" align="center">:</td>
          <td align="left"><? echo $rows_utang_awal[19] ?></td>
          </tr>
          <tr>
          <td width="20%" align="right">Alamat</td>
          <td width="5%" align="center">:</td>
          <td align="left"><? echo $rows_utang_awal[21] ?></td>
          </tr>
          <tr>
          <td width="20%" align="right">Kota</td>
          <td width="5%" align="center">:</td>
          <td align="left"><? echo $rows_utang_awal[22] ?></td>
          </tr>
          <tr>
          <td width="20%" align="right">Phone</td>
          <td width="5%" align="center">:</td>
          <td align="left"><? echo $rows_utang_awal[23] ?></td>
          </tr>
          <?
          $status['1'] = 'LUNAS';
		  $status['2'] = 'HUTANG';
		  $status['0'] = 'BELUM';
		  ?>
          <tr>
          <td width="20%" align="right">Status</td>
          <td width="5%" align="center">:</td>
          <td align="left"><? echo $status[$rows_utang_awal[6]] ?></td>
          </tr>
          
          </table>
		</div>
        <div class="popup-footer">
            <div link="library/submenu/akunting/piutang-awal" class="button-back">Kembali</div>
            <? if($rows_utang_awal[6]=='1') 
			{ 
			?>
                <div class="disabled-input-button">Bayar Dengan Kas</div>
                <div class="disabled-input-button">Bayar Dengan Bank</div>
            
            <?
			}
			else
			{
			?>
            	<div class="input-button" type="popup" mode="11" link="modul/akunting/detail/piutang-awal?<? echo $rows_utang_awal[0] ?>">Bayar Dengan Kas</div>
            <div class="input-button" type="popup" mode="13" link="modul/akunting/detail/piutang-awal?<? echo $rows_utang_awal[0] ?>">Bayar Dengan Bank</div>
            <?
			}
			?>
            
        </div>
    </div>
</div>
<div class="ctabletitle">Rincian Pembelian</div>
<table class="ctable">
	<tr class="ctableheader">
        <td width="6%">No</td>
        <td>Keterangan</td>
        <td width="20%">No Bukti</td>
        <td width="10%">Debet</td>
        <td width="10%">Kredit</td>
        
    </tr>
    <?php
		$qry_detail = "select * from ak_piut JOIN ak_kasbank ON (ak_piut.KASBANK_ID = ak_kasbank.ID) where ak_piut.piutang_awal_id = '".$_GET['gid']."';";
		$rs_detail = mysql_query($qry_detail);
		$no= 1;
		$debet= 0;
		$kridit = 0;
		while($rows_detail=mysql_fetch_array($rs_detail)) 
		{
			
	?>
		<tr>
            <td><? echo $no ?></td>
            <td class="ltext"><? echo $rows_detail[12] ?></td>
            
            <td class="ltext"><? echo $rows_detail[14] ?></td>
			<td align="right"><? echo cformat($rows_detail[5],false) ?></td>
            <td align="right"><? echo cformat($rows_detail[6],false) ?></td>
            
    <? 
		$debet=$debet+$rows_detail[5];
		$kridit=$kridit+$rows_detail[6];
		$no++;
	?>	</tr>
    <?
		}
	?>
    
    	<tr>
        <td colspan="3"><font size="+1">Total</font></td>
        <td colspan="2" align="right"><? echo cformat($rows_utang_awal[13],false) ?></td>
        </tr>
        <?
		
		$kurang=$kridit-$debet;
		?>
        <tr>
        <td colspan="3"><font size="+1">Sisa</font></td>
        <td colspan="2" align="right"><? echo cformat($kurang,false) ?></td>
        </tr>	
</table>
</div>   
                    <input name="p" type="hidden" value="<? echo $page ?>" />