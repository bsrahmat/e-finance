<script type="text/javascript">
 $(document).ready(function(){
   $(".ctable tr").mouseover(function(){$(this).addClass("over");}).mouseout(function(){$(this).removeClass("over");});
   $(".ctable tr:even").addClass("alt");
 });
 </script>
 
<?php
if(file_exists('../../../connectionmysql.php')) {
	require_once '../../../connectionmysql.php';
	Connected();
}
$page  = (isset($_GET['p']))?( (is_numeric($_GET['p']))?( $page = $_GET['p']): $page = 1 ): $page = 1;

$qry_kasbank= '';

$qry_kasbank = "select * from ak_kasbank where id = '".$_GET['gid']."';";
$rs_kasbank = mysql_query($qry_kasbank);
$rows_kasbank = mysql_fetch_array($rs_kasbank);
/////////////// ending konfigurasi
////////////// process

?>
 
<div class="sub-content-title">Kas Bank</div>
<div style="float: right; width: auto; padding: 2px 0; "><label style="width: 115px; color: black;"><input style="float: left; margin-right: 4px;" type="checkbox" name="show-hide" value="1" checked/>Show/Hide</label></div> 
<script type="text/javascript">
		$("input[name='show-hide']").unbind('click').click(function() { 
			if($(this).attr('checked')==true) {
			$("div[class^='show-body']").slideToggle("normal");
			$("div[class^='show-body']").show();
			} else
			$("div[class^='show-body']").slideToggle("normal");
			$("div[class^='show-body']").hide();
		}) 
</script>

<div class="cboxtable"> 
	<div class="sub-content-bar">
    	<div class="show-hide">
        <div class="show-body">
          <table class="show-table">
          <tr>
          <td width="20%" align="right">No. Bukti</td>
          <td width="5%" align="center">:</td>
          <td align="left"><? echo $rows_kasbank['NO_BUKTI'] ?></td>
          </tr>
          <tr>
          <td width="20%" align="right">Tanggal</td>
          <td width="5%" align="center">:</td>
          <td align="left"><? echo cDate2($rows_kasbank['TANGGAL']) ?></td>
          </tr>
          <tr>
          <td width="20%" align="right">No. Reff</td>
          <td width="5%" align="center">:</td>
          <td align="left"><? echo $rows_kasbank['NO_REFF'] ?></td>
          </tr>
          <tr>
          <td width="20%" align="right">Perk Kas/bank</td>
          <td width="5%" align="center">:</td>
          <?
		  	$qry_perk= '';

			$qry_perk = "select * from ak_detail_perk where ID_DETAIL = '".$rows_kasbank['PERK_KASBANK']."';";
			$rs_perk = mysql_query($qry_perk);
			$rows_perk = mysql_fetch_array($rs_perk);
		  ?>
          <td align="left"><? echo $rows_perk['KODE_DETAIL']." - ".$rows_perk['NAMA_DETAIL'] ?></td>
          </tr>
          <tr>
          <td width="20%" align="right">Diterima dr/Dibayar ke</td>
          <td width="5%" align="center">:</td>
          <td align="left"><? echo $rows_kasbank['TERIMA_DARI'] ?></td>
          </tr>
          <tr>
          <td width="20%" align="right">Keterangan</td>
          <td width="5%" align="center">:</td>
          <td align="left"><? echo $rows_kasbank['KETERANGAN'] ?></td>
          </tr>
          
          </table>
		</div>
        <div class="popup-footer">
            <div link="library/submenu/akunting/bank" class="button-back">Kembali</div>
            <div target="<? echo md5('cetak-kasbank') ?>" type="pdf" link="modul/laporan/report?<? echo $rows_kasbank[0] ?>" class="pdf-button" >Cetak Kas/Bank</div>
            
            <? 
			if($_SESSION['galaxy_kode']==1) { 
			?>
            <div class="input-button" type="popup" mode="1" link="modul/akunting/bank?<? echo $rows_kasbank[0] ?>">Edit Kas/Bank</div>
            <?
			 } else { 
			 ?>
            <div class="disabled-input-button">Edit Kas/Bank</div>

            <?
			 } 
			 ?>
        </div>
    </div>
</div>
<div class="ctabletitle">Rincian Kas/Bank</div>
<table class="ctable">
	<tr class="ctableheader">
        <td width="6%">No</td>
        <td width="10%">Kd. Perk</td>
        <td>Uraian</td>
        <td width="10%">Jumlah</td>
        <td width="30%">Nm. Perkiraan</td>
        <td align="center" width="5%">Action</td>
    </tr>
    <?php
		$qry_detail = "select * from ak_detail_kasbank where KASBANK_ID = '".$_GET['gid']."';";
		$rs_detail = mysql_query($qry_detail);
		$no= 1;
		while($rows_detail=mysql_fetch_array($rs_detail)) 
		{
			$qry_nm= "select * from ak_detail_perk where ID_DETAIL = '".$rows_detail['PERK_LAWAN']."';";
			$rs_nm = mysql_query($qry_nm);
			$rows_nm=mysql_fetch_array($rs_nm)
	?>
			<tr>
            <td class="rtext"><? echo $no ?></td>
            <td><? echo $rows_nm['KODE_DETAIL'] ?></td>
            <td class="ltext"><? echo $rows_detail['URAIAN'] ?></td>
            <?
			if($rows_detail['DEBET']!='0')
			{
			?>
            	<td class="rtext"><? echo cFormat($rows_detail['DEBET'],false) ?></td>
            <?
			}
			else
			{
			?>
				<td class="rtext"><? echo cFormat($rows_detail['KREDIT'],false) ?></td>
            <?
			}
			
			?>
            	<td class="ltext"><? echo $rows_nm['NAMA_DETAIL'] ?></td>
            
            <td>
                <div class="cactions two">
                <? 
				if($_SESSION['galaxy_kode']==1) 
				{ 
				?>                               
                	<div class="cedit" type="popup" mode="1" title="Edit" link="modul/akunting/detail/bank?<? echo $_GET['gid'] ?>&sub=<? echo $rows_detail[0] ?>"></div>
                <? 
				} 
				else 
				{ ?>
                	<div class="disabled-cedit"></div>
                <? 
				} 
				?>
                <? 
				if($_SESSION['galaxy_kode']==1) 
				{ 
				?> 
                	<div link="modul/akunting/detail/bank?<? echo $rows_detail[0] ?>" title="Hapus" mode="2" type="popup" class="cdelete"></div>
                <? 
				} 
				else 
				{ 
				?>
                	<div class="disabled-cdelete"></div>
                <? 
				} 
				?>
                </div>
            </td>
			
    <? 
		$no++;
		}
	?>
    		</tr>
</table>
</div>
<div class="ctablefooter">
	<? 
//	if($rows_trprequests['gmsign']=='2' || $rows_trprequests['gmsign']=='') { 
	?>               
    <div class="input-button" type="popup" mode="0" link="modul/akunting/detail/bank?<? echo $_GET['gid'] ?>">Tambah Baru</div>
    <?
//	 } else { 
	 ?>
<!--    <div class="disabled-input-button">Tambah Baru</div>
    <?
//	 } 
	 ?>

</div>