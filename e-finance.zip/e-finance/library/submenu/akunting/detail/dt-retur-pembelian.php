<script type="text/javascript">
 $(document).ready(function(){
   $(".ctable tr").mouseover(function(){$(this).addClass("over");}).mouseout(function(){$(this).removeClass("over");});
   $(".ctable tr:even").addClass("alt");
 });
 </script>
 
<?php
if(file_exists('../../../connectionmysql.php')) {
	require_once '../../../connectionmysql.php';
	Connected();
}
$page  = (isset($_GET['p']))?( (is_numeric($_GET['p']))?( $page = $_GET['p']): $page = 1 ): $page = 1;

$qry_breturs = '';

$qry_breturs = "SELECT breturs.id, breturs.trrgood_id, breturs.retdate, breturs.retnom, breturs.unitid, breturs.isclosed, breturs.isacc, breturs.isok, breturs.ispost, breturs.ispay, trrgoods.id, trrgoods.trporder_id, trrgoods.rgnom, trrgoods.fakturnom, trrgoods.rgdate, trrgoods.description, trrgoods.recipient, trrgoods.postby, trrgoods.postdate, trrgoods.prsign, trrgoods.isposted, trrgoods.prname, trrgoods.unitid, trrgoods.isclosed, trrgoods.warehouse_id, trrgoods.refnom, trrgoods.post FROM breturs LEFT JOIN trrgoods ON (breturs.trrgood_id = trrgoods.id)  WHERE breturs.id = '".$_GET['gid']."';";
$rs_breturs = mysql_query($qry_breturs);
$rows_breturs=mysql_fetch_array($rs_breturs);
$rows_supplier=mysql_fetch_array(mysql_query("select * from suppliers LEFT JOIN trporders ON (suppliers.id = trporders.supplier_id) LEFT JOIN trrgoods ON (trporders.id = trrgoods.trporder_id) where trrgoods.id = '".$rows_breturs['trrgood_id']."';"));
$rows_warehauses=mysql_fetch_array(mysql_query("select * from warehouses where id = '".$rows_supplier['warehouse_id']."';"));
/////////////// ending konfigurasi
////////////// process
?>
 
<div class="sub-content-title">Data Retur Pembelian</div>
<div style="float: right; width: auto; padding: 2px 0; "><label style="width: 115px; color: black;"><input style="float: left; margin-right: 4px;" type="checkbox" name="show-hide" value="1" checked/>Show/Hide</label></div> 
<script type="text/javascript">
		$("input[name='show-hide']").unbind('click').click(function() { 
			if($(this).attr('checked')==true) {
			$("div[class^='show-body']").slideToggle("normal");
			$("div[class^='show-body']").show();
			} else
			$("div[class^='show-body']").slideToggle("normal");
			$("div[class^='show-body']").hide();
		}) 
</script>

<div class="cboxtable"> 
	<div class="sub-content-bar">
    	<div class="show-hide">
        <div class="show-body">
          				<table class="show-table">
                          <tr>
                          <td width="20%" align="right">Tanggal</td>
                          <td width="5%" align="center">:</td>
                          <td align="left"><? echo cDate2($rows_breturs['retdate']) ?></td>
                          </tr>
                          <tr>
                          <td align="right">No. Retur</td>
                          <td align="center">:</td>
                          <td align="left"><? echo $rows_breturs['retnom'] ?></td>
                          </tr>
                          <tr>
                          <td align="right">No. LPB</td>
                          <td align="center">:</td>
                          <td align="left"><? echo $rows_breturs['rgnom'] ?></td>
                          </tr>
                          <tr>
                          <td align="right">Tanggal LPB</td>
                          <td align="center">:</td>
                          <td align="left"><? echo cDate2($rows_breturs['rgdate']) ?></td>
                          </tr>
                          <tr>
                          <td align="right">Supplier</td>
                          <td align="center">:</td>
                          <td align="left"><? echo $rows_supplier['name'] ?></td>
                          </tr>
                          <tr>
                          <td align="right">Gudang</td>
                          <td align="center">:</td>
                          <td align="left"><? echo $rows_warehauses['name'] ?></td>
                          </tr>
                          
                          </table>
		</div>
        <div class="popup-footer">
            <div link="library/submenu/akunting/dt-retur-pembelian" class="button-back">Kembali</div>
            <? if($rows_breturs['ispay']=='2') 
			{ 
			?>
                <div class="disabled-input-button">Masuk Ke Kas</div>
                <div class="disabled-input-button">Masuk Ke Bank</div>
            
            <?
			}
			else
			{
			?>
            <div class="input-button" type="popup" mode="10" link="modul/akunting/detail/dt-retur-pembelian?<? echo $rows_breturs[0] ?>">Masuk Ke Kas</div>
            <div class="input-button" type="popup" mode="12" link="modul/akunting/detail/dt-retur-pembelian?<? echo $rows_breturs[0] ?>">Masuk Ke Bank</div>
            <?
			}
			?>
        </div>
    </div>
</div>
<div class="ctabletitle">Rincian Retur Pembelian</div>
<table class="ctable">
	<tr class="ctableheader">
        <td width="6%">No</td>
        <td>Nama Barang</td>
        <td width="5%">Satuan</td>
        <td width="10%">Jumlah</td>
        <td width="10%">Harga Satuan</td>
        <td width="10%">Total</td>
    </tr>
    <?php
		$qry_detail = "select * from  bretdetails where bretur_id = '".$_GET['gid']."';";
		$rs_detail = mysql_query($qry_detail);
		$no= 1;
		$total='';
		while($rows_detail=mysql_fetch_array($rs_detail)) 
		{
			$qry_nm= "select * from items where id = '".$rows_detail['item_id']."';";
			$rs_nm = mysql_query($qry_nm);
			$rows_nm=mysql_fetch_array($rs_nm)
	?>
		<tr>
            <td><? echo $no ?></td>
            <td><? echo $rows_nm['name'] ?></td>
            <td><? echo $rows_nm['pcsname'] ?></td>
            <td align="right"><? echo cFormat($rows_detail['qty'], false) ?></td>
			<td align="right"><? echo cFormat($rows_detail['price'],false) ?></td>
            <td align="right"><? echo cFormat($rows_detail['price']*$rows_detail['qty'],false) ?></td>
    <? 
		$total=$total+($rows_detail['price']*$rows_detail['qty']);
		$no++;
	?>	</tr>
    <?
		}
	?>
    	<tr>
        <td colspan="5"><font size="+1">Total</font></td>
        <td colspan="1" align="right"><font size="+1"><? echo cFormat($total,false) ?></font></td>
        </tr>
        <?
		$qry_sisa="select sum(BAYAR) as sisa from ak_piutang where ID_BRETUR='".$_GET['gid']."' ";
		$row_sisa=mysql_fetch_array(mysql_query($qry_sisa));
		$kurang=$total-$row_sisa['sisa'];
		?>
        <tr>
        <td colspan="5"><font size="+1">Sisa</font></td>
        <td colspan="1" align="right"><font size="+1"><? echo cFormat($kurang,false) ?></font></td>
        </tr>	
</table>
</div>   
                    <input name="p" type="hidden" value="<? echo $page ?>" />