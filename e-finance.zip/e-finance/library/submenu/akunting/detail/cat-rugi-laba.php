<script type="text/javascript">	
$(document).ready(function(){
        $("input[type^='datepicker-range']").datepicker({			
        
        dateFormat:"d/m/yy"
        
        });
        
        });
</script>	
<?php
if(file_exists('../../../connectionmysql.php')) {
	require_once '../../../connectionmysql.php';
	Connected();

}
?>

                   <div class="sub-content-title">Catatan Rugi Laba (Bag. akunting)</div>
                    
				   <div class="cboxtable"> 
                                                      
                    	<div class="sub-content-bar">
                          
                          <form action="modul/laporan/cat-rugi-laba.php" target="_new" method="post">
                          <table class="show-table">
                          <tr>
                          <td width="20%" align="right">Dari Tanggal</td>
                          <td width="1%" align="center">:</td>
                          <td align="left"><input class="datepicker-text" name="tgl-awal" type="datepicker-range" value="" /></td>
                          </tr>
                          <tr>
                          <td align="right">Sampai tanggal</td>
                          <td align="center">:</td>
                          <td align="left"><input class="datepicker-text" name="tgl-akhir" type="datepicker-range" value="" /></td>
                          </tr>
                          </table>
                          
                          
                          
                          <div class="popup-footer">
                           <div print="3" style="margin-left: 22px;" class="print-button">Cetak</div>
                            <div link="library/submenu/akunting/laporan" class="button-back">Kembali</div>
                            
                            
                           
                          </div>
                          </form>
                          </div>
                        </div>   
                    <input name="p" type="hidden" value="<? echo $page ?>" />