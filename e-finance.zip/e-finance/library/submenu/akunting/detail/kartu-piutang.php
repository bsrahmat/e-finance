 <script type="text/javascript">	
$(document).ready(function(){
        $("input[type^='datepicker-range']").datepicker({			
        
        dateFormat:"d/m/yy"
        
        });
        
        });
</script>	
<?php
if(file_exists('../../../connectionmysql.php')) {
	require_once '../../../connectionmysql.php';
	Connected();
}
?>

<div class="sub-content-title">Kartu Piutang</div>

<div class="cboxtable"> 
                                  
    <div class="sub-content-bar">
      
      <form action="modul/akunting/laporan/kartu-piutang.php" method="post">
      <table class="show-table">
      <tr>
      <td width="20%" align="right">Nama Unit</td>
      <td width="1%" align="center">:</td>
      <td align="left">
      	<select name="unit" class="select-text input-small">
        <option value="">Pilih..</option>
		  <? 	  
          $qry_unit = "select * from units where id!=10;";
          $rs_unit = mysql_query($qry_unit);
          while($rows_unit=mysql_fetch_array($rs_unit)) {
          ?>
            <option value="<? echo $rows_unit['id']?>" ><? echo $rows_unit['name']; ?></option>
          <? } ?>
        </select>
      </td>
      </tr>
      <tr>
      <td width="20%" align="right">Customers</td>
      <td width="1%" align="center">:</td>
      <td align="left"><select name="customer" class="select-text select-small">
                <option value="">Pilih..</option>
              <? 	  
              $qry_Supplier = "select * from customers;";
              $rs_Supplier = mysql_query($qry_Supplier);
              while($rows_Supplier=mysql_fetch_array($rs_Supplier)) {
              ?>
                <option value="<? echo $rows_Supplier['id']?>"><? echo $rows_Supplier['name']; ?> </option>
              <? } ?>
            </select></td>
      </tr>
      <tr>
      <td width="20%" align="right">Tanggal Awal</td>
      <td width="1%" align="center">:</td>
      <td align="left"><input class="datepicker-text" name="tgl-awal" type="datepicker-range" value="" /></td>
      </tr>
      <tr>
      <td align="right">Sampai tanggal</td>
      <td align="center">:</td>
      <td align="left"><input class="datepicker-text" name="tgl-akhir" type="datepicker-range" value="" /></td>
      </tr>
      <tr>
      <td align="right"></td>
      <td align="center"></td>
      <td valign="middle"><label style="float: left; width: 150px; height: 20px; color: black;"><input style="float: left; margin-right: 4px;" type="checkbox" name="jthtempo" value="1" />Jatuh Tempo</label>
      </td>
      </tr>
      </table>
      
      
      
     <div class="popup-footer">
       	<div print="0" style="margin-left: 22px;" class="print-button">Preview</div>
        <div link="library/submenu/akunting/laporan" class="button-back">Kembali</div>
      </div>
      </form>
      <div class="box-paper"></div>
                        
                    </div>
	</div>
</div>   
<input name="p" type="hidden" value="<? echo $page ?>" />