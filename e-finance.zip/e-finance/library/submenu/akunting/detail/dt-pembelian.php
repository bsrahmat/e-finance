<script type="text/javascript">
 $(document).ready(function(){
   $(".ctable tr").mouseover(function(){$(this).addClass("over");}).mouseout(function(){$(this).removeClass("over");});
   $(".ctable tr:even").addClass("alt");
 });
 </script>
 
<?php
if(file_exists('../../../connectionmysql.php')) {
	require_once '../../../connectionmysql.php';
	Connected();
}
$page  = (isset($_GET['p']))?( (is_numeric($_GET['p']))?( $page = $_GET['p']): $page = 1 ): $page = 1;

$qry_trrgoods= '';
 
$qry_trrgoods = "SELECT * FROM trrgoods LEFT JOIN trporders ON (trrgoods.trporder_id = trporders.id) WHERE trrgoods.id = '".$_GET['gid']."';";
$rs_trrgoods = mysql_query($qry_trrgoods);
$rows_trrgoods = mysql_fetch_array($rs_trrgoods);
/////////////// ending konfigurasi
////////////// process
?>
 
<div class="sub-content-title">Data Pembelian</div>
<div style="float: right; width: auto; padding: 2px 0; "><label style="width: 115px; color: black;"><input style="float: left; margin-right: 4px;" type="checkbox" name="show-hide" value="1" checked/>Show/Hide</label></div> 
<script type="text/javascript">
		$("input[name='show-hide']").unbind('click').click(function() { 
			if($(this).attr('checked')==true) {
			$("div[class^='show-body']").slideToggle("normal");
			$("div[class^='show-body']").show();
			} else
			$("div[class^='show-body']").slideToggle("normal");
			$("div[class^='show-body']").hide();
		}) 
</script>

<div class="cboxtable"> 
	<div class="sub-content-bar">
    	<div class="show-hide">
        <div class="show-body">
          <table class="show-table">
          <tr>
          <td width="20%" align="right">No. LPB</td>
          <td width="5%" align="center">:</td>
          <td align="left"><? echo $rows_trrgoods['rgnom'] ?></td>
          </tr>
          <tr>
          <td width="20%" align="right">Tanggal</td>
          <td width="5%" align="center">:</td>
          <td align="left"><? echo cDate2($rows_trrgoods['rgdate']) ?></td>
          </tr>
          <tr>
          <td width="20%" align="right">No. PO</td>
          <td width="5%" align="center">:</td>
          <td align="left"><? echo $rows_trrgoods['ponom'] ?></td>
          </tr>
          <tr>
          <td width="20%" align="right">Tanggal PO</td>
          <td width="5%" align="center">:</td>
          <td align="left"><? echo $rows_trrgoods['podate'] ?>
          </tr>
          <tr>
          <td width="20%" align="right">No. Faktur</td>
          <td width="5%" align="center">:</td>
          <td align="left"><? echo $rows_trrgoods['fakturnom'] ?></td>
          </tr>
          <tr>
          <td width="20%" align="right">Referensi (SJ/Faktur)</td>
          <td width="5%" align="center">:</td>
          <td align="left"><? echo $rows_trrgoods['refnom'] ?></td>
          </tr>
          <tr>
          <? 
		  $qry_supplier="select * from suppliers where id='".$rows_trrgoods['supplier_id']."'";
		  $row_supplier=mysql_fetch_array(mysql_query($qry_supplier));
		  ?>
          <td width="20%" align="right">Diterima dari</td>
          <td width="5%" align="center">:</td>
          <td align="left"><? echo $row_supplier['name']?></td>
          </tr>
          <tr>
          <td width="20%" align="right">Alamat</td>
          <td width="5%" align="center">:</td>
          <td align="left"><? echo $row_supplier['address'] ?></td>
          </tr>
          <tr>
          <?
          $qry_warehouse="select * from warehouses where id='".$rows_trrgoods['warehouse_id']."'";
		  $row_warehouse=mysql_fetch_array(mysql_query($qry_warehouse));
		  ?>
          <td width="20%" align="right">Nama Gudang</td>
          <td width="5%" align="center">:</td>
          <td align="left"><? echo $row_warehouse['name'] ?></td>
          </tr>
          <tr>
          <td width="20%" align="right">Penerima di Gudang</td>
          <td width="5%" align="center">:</td>
          <td align="left"><? echo $rows_trrgoods['recipient'] ?></td>
          </tr>
          <tr>
          <td width="20%" align="right">Kepala Gudang</td>
          <td width="5%" align="center">:</td>
          <td align="left"><? echo $row_warehouse['whhead'] ?></td>
          </tr>
          <tr>
          <?
          $cocok[0]='TIDAK COCOK';
		  $cocok[1]='COCOK';
		  ?>
          <td width="20%" align="right">Pemeriksaan Purchasing</td>
          <td width="5%" align="center">:</td>
          <td align="left"><? echo $cocok[$rows_trrgoods['prsign']] ?></td>
          </tr>
          <tr>
          <?
          $status['1'] = 'SUDAH';
		  $status['0'] = 'BELUM';
		  ?>
          <td width="20%" align="right">Status Posting</td>
          <td width="5%" align="center">:</td>
          <td align="left"><? echo $status[$rows_trrgoods['isposted']] ?></td>
          </tr>
          <tr>
          <?
          $qry_user="select * from tbl_admin where admin_kode='".$rows_trrgoods['postby']."'";
		  $row_user=mysql_fetch_array(mysql_query($qry_user));
		  ?>
          <td width="20%" align="right">Di Posting oleh</td>
          <td width="5%" align="center">:</td>
          <td align="left"><? echo $row_user['admin_full_name'] ?></td>
          </tr>
          <tr>
          <td width="20%" align="right">Tanggal Posting</td>
          <td width="5%" align="center">:</td>
          <td align="left"><? echo $rows_trrgoods['postdate'] ?></td>
          </tr>
          </table>
		</div>
        <div class="popup-footer">
            <div link="library/submenu/akunting/dt-pembelian" class="button-back">Kembali</div>
            <? if($rows_trrgoods['is_bayar']=='2') 
			{ 
			?>
                <div class="disabled-input-button">Bayar Dengan Kas</div>
                <div class="disabled-input-button">Bayar Dengan Bank</div>
            
            <?
			}
			else
			{
			?>
            	<div class="input-button" type="popup" mode="11" link="modul/akunting/detail/dt-pembelian?<? echo $rows_trrgoods[0] ?>">Bayar Dengan Kas</div>
            <div class="input-button" type="popup" mode="13" link="modul/akunting/detail/dt-pembelian?<? echo $rows_trrgoods[0] ?>">Bayar Dengan Bank</div>
            <?
			}
			?>
            
        </div>
    </div>
</div>
<div class="ctabletitle">Rincian Pembelian</div>
<table class="ctable">
	<tr class="ctableheader">
        <td width="6%">No</td>
        <td>Nama Barang</td>
        <td width="10%">Jumlah</td>
        <td width="5%">Satuan</td>
        <td width="10%">HP</td>
        <td width="10%">HP Tot.</td>
        <td width="10%">PPN/Brg</td>
        <td width="15%">Utang Dgng</td>
    </tr>
    <?php
		$qry_detail = "select * from  trrgdetails where trrgood_id = '".$_GET['gid']."';";
		$rs_detail = mysql_query($qry_detail);
		$no= 1;
		$total='';
		while($rows_detail=mysql_fetch_array($rs_detail)) 
		{
			$qry_nm= "select * from items where id = '".$rows_detail['item_id']."';";
			$rs_nm = mysql_query($qry_nm);
			$rows_nm=mysql_fetch_array($rs_nm)
	?>
		<tr>
            <td><? echo $no ?></td>
            <td class="ltext"><? echo $rows_nm['name'] ?></td>
            <td align="right"><? echo cformat($rows_detail['qty'],false) ?></td>
            <td><? echo $rows_nm['pcsname'] ?></td>
            <td align="right"><? echo cformat($rows_detail['hpp'],false) ?></td>
			<td align="right"><? echo cformat($rows_detail['hpptot'],false) ?></td>
            <td align="right"><? echo cformat($rows_detail['ppnperitem'],false) ?></td>
            <td align="right"><? echo cformat($rows_detail['debt'],false) ?></td>
    <? 
		$total=$total+$rows_detail['debt'];
		$no++;
	?>	</tr>
    <?
		}
	?>
    
    <?php
		$qry_rdetail = "select * from  bretdetails JOIN breturs ON (bretdetails.bretur_id = breturs.id)  where breturs.trrgood_id = '".$_GET['gid']."';";
		$rs_rdetail = mysql_query($qry_rdetail);
		$no= $no;
		$total= $total;
		while($rows_rdetail=mysql_fetch_array($rs_rdetail)) 
		{
			$qry_nm= "select * from items where id = '".$rows_rdetail['item_id']."';";
			$rs_nm = mysql_query($qry_nm);
			$rows_nm=mysql_fetch_array($rs_nm)
	?>
		<tr>
            <td><? echo $no ?></td>
            <td class="ltext">Retur @<b><? echo $rows_nm['name'] ?></b></td>
            <td align="right"><? echo cformat($rows_rdetail['qty'],false) ?></td>
            <td><? echo $rows_nm['pcsname'] ?></td>
            <td align="right"><? echo cformat($rows_rdetail['price'],false) ?></td>
			<td align="right"><? echo cformat($rows_rdetail['price'] * $rows_rdetail['qty'],false) ?></td>
            <td align="right"><? echo cformat($rows_rdetail['ppnperitem'],false) ?></td>
            <td align="right"><? echo cformat(($rows_rdetail['price'] + $rows_rdetail['ppnperitem'])* $rows_rdetail['qty'],false) ?></td>
    <? 
		$total=$total-(($rows_rdetail['price'] + $rows_rdetail['ppnperitem'])* $rows_rdetail['qty']);
		$no++;
	?>	</tr>
    <?
		}
	?>
    	<tr>
        <td colspan="6"><font size="+1">Total</font></td>
        <td colspan="2" align="right"><font size="+1"><? echo cformat($total,false) ?></font></td>
        </tr>
        <?
		$qry_sisa="select sum(ak_htg.DEBET) as debet, sum(ak_htg.KREDIT) as kredit from ak_htg where ak_htg.TRRGOOD_ID='".$_GET['gid']."'";
		$row_sisa=mysql_fetch_array(mysql_query($qry_sisa));
		$kurang=$row_sisa['debet']-$row_sisa['kredit'];
		?>
        <tr>
        <td colspan="6"><font size="+1">Sisa</font></td>
        <td colspan="2" align="right"><font size="+1"><? echo cformat($kurang,false) ?></font></td>
        </tr>	
</table>
</div>   
                    <input name="p" type="hidden" value="<? echo $page ?>" />