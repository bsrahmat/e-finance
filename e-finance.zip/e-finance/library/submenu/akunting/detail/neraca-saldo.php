<script type="text/javascript">	
$(document).ready(function(){
        $("input[type^='datepicker-range']").datepicker({			
        
        dateFormat:"d/m/yy"
        
        });
        
        });
</script>	
<?php
if(file_exists('../../../connectionmysql.php')) {
	require_once '../../../connectionmysql.php';
	Connected();
}
?>

<div class="sub-content-title">Neraca Saldo (Bag. akunting)</div>

<div class="cboxtable"> 
                                  
    <div class="sub-content-bar">
      
      <form action="modul/laporan/neraca-saldo.php" target="_new" method="post">
      <table class="show-table">
      <tr>
      <td width="20%" align="right">Nama Unit</td>
      <td width="1%" align="center">:</td>
      <td align="left">
      	<select name="unit" class="select-text input-small">
        <option value="">Pilih..</option>
		  <? 	  
          $qry_unit = "select * from units where id!=10;";
          $rs_unit = mysql_query($qry_unit);
          while($rows_unit=mysql_fetch_array($rs_unit)) {
          ?>
            <option value="<? echo $rows_unit['id']?>" ><? echo $rows_unit['name']; ?></option>
          <? } ?>
        </select>
      </td>
      </tr>
      <tr>
      <td width="20%" align="right">Tanggal akhir</td>
      <td width="1%" align="center">:</td>
      <td align="left"><input class="datepicker-text" name="tgl-akhir" type="datepicker-range" value="" /></td>
      </tr>
      </table>
      
      
      
      <div class="popup-footer">
       <div print="3" style="margin-left: 22px;" class="print-button">Cetak</div>
        <div link="library/submenu/akunting/laporan" class="button-back">Kembali</div>
        
        
       
      </div>
      </form>
	</div>
</div>   
<input name="p" type="hidden" value="<? echo $page ?>" />