<script type="text/javascript">
 $(document).ready(function(){
   $(".ctable tr").mouseover(function(){$(this).addClass("over");}).mouseout(function(){$(this).removeClass("over");});
   $(".ctable tr:even").addClass("alt");
 });
 </script>
 
<?php
if(file_exists('../../../connectionmysql.php')) {
	require_once '../../../connectionmysql.php';
	Connected();
}
$page  = (isset($_GET['p']))?( (is_numeric($_GET['p']))?( $page = $_GET['p']): $page = 1 ): $page = 1;

$qry_fakturs= '';
 
$qry_fakturs = "SELECT fakturs.id, sjs.sjdate, fakturs.fakdate, sjs.jtdate, fakturs.faknom, sjs.sjnom, spbs.spbnom, spbs.customer_id, sjs.id FROM fakturs LEFT JOIN sjs ON (fakturs.sj_id = sjs.id) LEFT JOIN  spbs ON (sjs.spb_id = spbs.id) WHERE fakturs.id = '".$_GET['gid']."';";
$rs_fakturs = mysql_query($qry_fakturs);
$rows_fakturs = mysql_fetch_array($rs_fakturs);
/////////////// ending konfigurasi
////////////// process
?>
 
<div class="sub-content-title">Data Penjualan</div>
<div style="float: right; width: auto; padding: 2px 0; "><label style="width: 115px; color: black;"><input style="float: left; margin-right: 4px;" type="checkbox" name="show-hide" value="1" checked/>Show/Hide</label></div> 
<script type="text/javascript">
		$("input[name='show-hide']").unbind('click').click(function() { 
			if($(this).attr('checked')==true) {
			$("div[class^='show-body']").slideToggle("normal");
			$("div[class^='show-body']").show();
			} else
			$("div[class^='show-body']").slideToggle("normal");
			$("div[class^='show-body']").hide();
		}) 
</script>

<div class="cboxtable"> 
	<div class="sub-content-bar">
    	<div class="show-hide">
        <div class="show-body">
          <table class="show-table">
          <tr>
          <td width="20%" align="right">Tanggal SJ</td>
          <td width="5%" align="center">:</td>
          <td align="left"><? echo cDate2($rows_fakturs['sjdate']) ?></td>
          </tr>
          <tr>
          <td width="20%" align="right">Tanggal Faktur</td>
          <td width="5%" align="center">:</td>
          <td align="left"><? echo cDate2($rows_fakturs['fakdate']) ?></td>
          </tr>
          <tr>
          <td width="20%" align="right">Tanggal Jatuh Tempo</td>
          <td width="5%" align="center">:</td>
          <td align="left"><? echo cDate2($rows_fakturs['jtdate']) ?></td>
          </tr>
          <tr>
          <td width="20%" align="right">No. Faktur</td>
          <td width="5%" align="center">:</td>
          <td align="left"><? echo $rows_fakturs['faknom'] ?></td>
          </tr>
          <tr>
          <td width="20%" align="right">No. SJ</td>
          <td width="5%" align="center">:</td>
          <td align="left"><? echo $rows_fakturs['sjnom'] ?></td>
          </tr>
          <tr>
          <td width="20%" align="right">No. SPB</td>
          <td width="5%" align="center">:</td>
          <td align="left"><? echo $rows_fakturs['spbnom'] ?></td>
          </tr>
          <tr>
          <? 
		  $qry_customers="select * from customers where id='".$rows_fakturs['customer_id']."'";
		  $row_customers=mysql_fetch_array(mysql_query($qry_customers));
		  ?>
          <td width="20%" align="right">Customer</td>
          <td width="5%" align="center">:</td>
          <td align="left"><? echo $row_customers['name']?></td>
          </tr>
          </table>
		</div>
        <div class="popup-footer">
            <div link="library/submenu/akunting/dt-penjualan" class="button-back">Kembali</div>
            <? if($rows_fakturs['is_bayar']=='2') 
			{ 
			?>
                <div class="disabled-input-button">Masuk Ke Kas</div>
                <div class="disabled-input-button">Masuk Ke Bank</div>
            
            <?
			}
			else
			{
			?>
            <div class="input-button" type="popup" mode="10" link="modul/akunting/detail/dt-penjualan?<? echo $rows_fakturs[0] ?>">Masuk Ke Kas</div>
            <div class="input-button" type="popup" mode="12" link="modul/akunting/detail/dt-penjualan?<? echo $rows_fakturs[0] ?>">Masuk Ke Bank</div>
            <?
			}
			?>
        </div>
    </div>
</div>
<div class="ctabletitle">Rincian penjualan</div>
<table class="ctable">
	<tr class="ctableheader">
        <td width="6%">No</td>
        <td>Nama Barang</td>
        <td width="5%">Satuan</td>
        <td width="10%">Jumlah</td>
        <td width="10%">Harga Satuan</td>
        <td width="10%">Disc</td>
        <td width="10%">Ppn</td>
        <td width="10%">Total</td>
        
    </tr>
    <?php
		$qry_detail = "select * from  fakdetails where faktur_id = '".$_GET['gid']."';";
		$rs_detail = mysql_query($qry_detail);
		$no= 1;
		$total='';
		while($rows_detail=mysql_fetch_array($rs_detail)) 
		{
			$qry_nm= "select * from items where id = '".$rows_detail['item_id']."';";
			$rs_nm = mysql_query($qry_nm);
			$rows_nm=mysql_fetch_array($rs_nm)
	?>
		<tr>
            <td><? echo $no ?></td>
            <td class="ltext"><? echo $rows_nm['name'] ?></td>
            <td><? echo $rows_nm['pcsname'] ?></td>
            <td align="right"><? echo cFormat($rows_detail['qty'],false) ?></td>
			<td align="right"><? echo cFormat($rows_detail['price'],false) ?></td>
            <td align="right"><? echo cFormat($rows_detail['disc'],false) ?></td>
            <td align="right"><? echo cFormat($rows_detail['ppnperitem'],false) ?></td>
            <? $subtotal = ($rows_detail['price']-$rows_detail['disc']+$rows_detail['ppnperitem'])*$rows_detail['qty'];?>
            <td align="right"><? echo cFormat($subtotal,false) ?></td>
    <? 
		$total=$total+$subtotal;
		$no++;
	?>	</tr>
    <?
		}
	?>
    
    <?php
		$qry_rdetail = "select * from  sretdetails JOIN sreturs ON (sretdetails.sretur_id = sreturs.id)  where sreturs.faktur_id = '".$_GET['gid']."';";
		$rs_rdetail = mysql_query($qry_rdetail);
		$no= $no;
		$total= $total;
		while($rows_rdetail=mysql_fetch_array($rs_rdetail)) 
		{
			$qry_nm= "select * from items where id = '".$rows_rdetail['item_id']."';";
			$rs_nm = mysql_query($qry_nm);
			$rows_nm=mysql_fetch_array($rs_nm)
	?>
		<tr>
            <td><? echo $no ?></td>
            <td class="ltext"><? echo $rows_nm['name'] ?></td>
            <td><? echo $rows_nm['pcsname'] ?></td>
            <td align="right"><? echo cFormat($rows_rdetail['qty'],false) ?></td>
			<td align="right"><? echo cFormat($rows_rdetail['price'],false) ?></td>
            <td align="right"><? echo cFormat($rows_rdetail['disc'],false) ?></td>
            <td align="right"><? echo cFormat($rows_rdetail['ppnperitem'],false) ?></td>
            <? $rsubtotal = ($rows_rdetail['price']-$rows_rdetail['disc']+$rows_rdetail['ppnperitem'])*$rows_rdetail['qty'];?>
            <td align="right"><? echo cFormat($rsubtotal,false) ?></td>
    <? 
		$total=$total-$rsubtotal;
		$no++;
	?>	</tr>
    <?
		}
	?>
    	<tr>
        <td colspan="6"><font size="+1">Total</font></td>
        <td colspan="2" align="right"><font size="+1"><? echo cFormat($total,false) ?></font></td>
        </tr>
        <?
		$qry_sisa="select sum(ak_piut.DEBET) as debet , sum(ak_piut.KREDIT) as kredit from ak_piut where SJ_ID='".$rows_fakturs['8']."' ";
		$row_sisa=mysql_fetch_array(mysql_query($qry_sisa));
		$kurang=$row_sisa['debet']-$row_sisa['kredit'];
		?>
        <tr>
        <td colspan="6"><font size="+1">Sisa</font></td>
        <td colspan="2" align="right"><font size="+1"><? echo cFormat($kurang,false) ?></font></td>
        </tr>	
</table>
</div>   
                    <input name="p" type="hidden" value="<? echo $page ?>" />