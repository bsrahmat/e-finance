<?php
/////// konfigurasi
///// query untuk paging

if(file_exists('../../connectionmysql.php')) {
	require_once '../../connectionmysql.php';
	Connected();
	$path = '../../../';
} else $path = '../../';

$perm = array();
$perm = getPermissions('51');
?>


<div class="sub-content-title">Laporan</div>
<div class="cboxtable"> 
    <div class="sub-content-bar">
        <div class="cview-button" title="Cetak" link="library/submenu/akunting/detail/kartu-htng">Kartu Hutang</div>
        <div class="cview-button" title="Cetak" link="library/submenu/akunting/detail/rekap-kartu-hutang">Rekap Hutang</div>
        <div class="cview-button" title="Cetak" link="library/submenu/akunting/detail/kartu-piutang">Kartu Piutang</div>
    	<div class="cview-button" title="Cetak" link="library/submenu/akunting/detail/rekap-kartu-piutang">Rekap Piutang</div>
    </div>
</div>
<div class="cboxtable"> 
    <div class="sub-content-bar">
        <div class="cview-button" title="Cetak" link="library/submenu/akunting/detail/report-buku-besar">Buku Besar</div>
        <div class="cview-button" title="Cetak" link="library/submenu/akunting/detail/rekap-buku-besar">Rekap Buku Besar</div>
        <div class="cview-button" title="Cetak" link="library/submenu/akunting/detail/neraca-saldo">Neraca Saldo</div>
        <div class="cview-button" title="Cetak" link="library/submenu/akunting/detail/neraca">Neraca</div>
        <div class="cview-button" title="Cetak" link="library/submenu/akunting/detail/rugi-laba">Rugi laba</div>
<!--        <div class="cview-button" title="Cetak" link="library/submenu/akunting/detail/cat-rugi-laba">Catatan Rugi laba</div> -->
    </div>
</div>
                       