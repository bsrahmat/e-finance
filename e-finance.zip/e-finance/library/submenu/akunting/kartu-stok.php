<?php
if(file_exists('../../connectionmysql.php')) {
	require_once '../../connectionmysql.php';
	require_once '../../session.php';
	Connected();
	
	$perm = array();
	$perm = getPermissions('27');

	if(file_exists('../../error-menu.php')) if($perm[-1]=='1') { require_once '../../error-menu.php'; die; }
}
?>
                    <div class="sub-content-title">Kartu Stock Barang</div>
                    
                	<div class="cboxtable">
                    	<div class="sub-content-bar">
                        <form action="modul/akunting/kartu-stok.php" method="post">
                        <table style="width:100%;">
                        <tr>
                        <td valign="top" width="25%"><div style="margin-top:4px;">Unit / Cabang</div></td>
                        <td valign="top" width="1%" align="center"><div style="margin-top:4px;">:</div></td>
                        <td valign="top" width="74%"><select name="unit_id" class="select-text input-large">
                            <option value="">Pilih..</option>
                          <? 	  
                          $qry_unit = "select * from units WHERE id != '10' order by id;";
                          $rs_unit = mysql_query($qry_unit);
                          while($rows_unit=mysql_fetch_array($rs_unit)) {
                          ?>
                            <option value="<? echo $rows_unit['id']?>"><? echo $rows_unit['name']; ?></option>
                          <? } ?>
                          </select></td>
                        </tr>
                        <tr>
                        <td valign="top" width="15%"><div style="margin-top:4px;">Nama Gudang</div></td>
                        <td valign="top" width="1%" align="center"><div style="margin-top:4px;">:</div></td>
                        <td valign="top">
                        	<select name="warehouse_id" class="select-text input-large">
                            <option value="">Pilih..</option>
                          <? 
						  $qry_warehouses = "select * from warehouses order by id;";
                          $rs_warehouses = mysql_query($qry_warehouses);
                          while($rows_warehouses=mysql_fetch_array($rs_warehouses)) {
                          ?>
                            <option value="<? echo $rows_warehouses['id']?>"><? echo $rows_warehouses['name']; ?></option>
                          <? } ?>
                          </select>
                          
                        </td>
                        </tr>
                        <tr>
                        <td valign="top" width="15%"><div style="margin-top:4px;"></div></td>
                        <td valign="top" width="1%" align="center"><div style="margin-top:4px;"></div></td>
                        <td valign="middle"><label style="float: left; width: 150px; height: 20px; color: black;"><input style="float: left; margin-right: 4px;" type="checkbox" name="summary" value="1" />Summary</label> 
                          <div print="0" style="margin-left: 22px;" class="print-button">Preview</div>           
                          <div print="3" style="margin-left: 7px;" class="print-button">Print</div>
                        </td>
                        </tr>                        
                        </table>
						</form>
                        
                        </div>
						<div class="box-paper"></div>                        
                        
                    </div>
                                    

