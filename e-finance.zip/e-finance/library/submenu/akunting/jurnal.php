<?php
/////// konfigurasi
///// query untuk paging

if(file_exists('../../connectionmysql.php')) {
	require_once '../../connectionmysql.php';
	Connected();
	$path = '../../../';
} else $path = '../../';

$perm = array();
$perm = getPermissions('45');

if(file_exists('../../error-menu.php')) if($perm[-1]=='1') { require_once '../../error-menu.php'; die; }
$IDmodul= $_SESSION['galaxy_unit'];

if($IDmodul=='none') $IDmodul = '-1';

//BAGIAN INPUTAN PENCARIAN
//Fungsi STRIPSTRING berfungsi hanya karakter a-z, A-Z, dan angka 0-9 yang diperbolehkan.
$get_search = '';
$search = '';
$search_name = 'Pencarian...';

if(isset($_GET['search'])) {
	$_GET['search'] = $_GET['search'];
	$search_name = $_GET['search'];
	
	if($_GET['search'] || $_GET['search'] != 'Pencarian...' || $_GET['search'] != '') {
		$search = "and LOWER(ak_jurnal.NO_BUKTI) LIKE '%".strtolower($_GET['search'])."%'
			OR LOWER(ak_jurnal.NO_REFF) LIKE '%".strtolower($_GET['search'])."%'";
		$get_search = '&search='.strtolower($_GET['search']);
	}
}

$qry_count = '';
if($_SESSION['galaxy_type']=='0')
	$qry_count = "select * from ak_jurnal where unit_kode != '10' ".$search;
// $qry_count = "select * from trprequests where unit_id != '10' ".$search;
else
	$qry_count = "select * from ak_jurnal where unit_kode != '10' AND unit_kode ='".$_SESSION['galaxy_unit']."' ".$search;
// $qry_count = "select * from trprequests where unit_id != '10' AND unit_id = '".$_SESSION['galaxy_unit']."' ".$search;

$rs_count = mysql_query($qry_count);
$count  = mysql_num_rows($rs_count);

// variabel paging
$page  = (isset($_GET['p']))?( (is_numeric($_GET['p']))?( $page = $_GET['p']): $page = 1 ): $page = 1;
$limit = 20;
$start = $limit * ($page - 1);

$pager = new pagination();
$pager->currentPage 	= $page;
$pager->total			= $count;
$pager->limit			= $limit;
$pager->baseLink		= 'library/submenu/akunting/jurnal?p=';
$pager->getHalaman(); 
/// output variabel paging
$selPrev = ($page==$pager->PagePrev )?"-selected":'';
$PevLink = 'link="'. $pager->LinkPrev.$get_search.'"';

$selNext	= ($page==$pager->PageNext )?"-selected":'';
$NextLink	= 'link="'. $pager->LinkNext.$get_search.'"';

//query untuk isi
$qry_jurnal = '';
if($_SESSION['galaxy_type']=='0')
	$qry_jurnal = "select * from ak_jurnal where unit_kode !='10' ".$search." order by id DESC limit $limit offset $start;";
else
	$qry_jurnal = "select * from ak_jurnal where unit_kode !='10' AND unit_kode='".$_SESSION['galaxy_unit']."' ".$search." order by id DESC limit $limit offset $start;";

$rs_jurnal = mysql_query($qry_jurnal);

/////////////// ending konfigurasi
////////////// process


$qry_temp="select * from ak_temp_jurnal where UNIT_KODE = '".$_SESSION['galaxy_unit']."' ";
$rs_temp=mysql_query($qry_temp);
while($rows_temp=mysql_fetch_array($rs_temp)) 
{
	mysql_query("DELETE from ak_temp_jurnal where id ='".$rows_temp['ID']."'");
}
?>

<div class="sub-content-title">Jurnal</div>
<div class="cboxtable">
	<div class="sub-content-bar">
    	<? if($perm[0]!='1') { ?>
        <div class="input-button" type="popup" mode="0" link="modul/akunting/jurnal">Tambah jurnal</div>
        <? } else { ?>
        <div class="disabled-input-button">Tambah jurnal</div>
        <? } ?>

        <div class="search-button" link="library/submenu/akunting/jurnal"><img src="images/cari.png" /></div>
        <input class="search-input" type="text" value="<? echo $search_name ?>"  />
        <div class="search-text">No. Bukti : </div>
	</div>
    
    <div class="ctabletitle">Data Jurnal</div>
    <table class="ctable">
    	<tr class="ctableheader">
            <td width="1%">No</td>
            <td width="8%">Tanggal</td>
            <td width="12%">No. Bukti</td>
            <td width="12%">No. Reff</td>
            <td>Perk. Debet</td>
            <td>Perk. Kredit</td>
            <td width="10%">Jumlah</td>
            <td align="center" width="1%">Action</td>

        </tr>
        <?PHP
        $no= $start+1;
		while($rows_jurnal=mysql_fetch_array($rs_jurnal)) {
			$perk_debet = mysql_fetch_array(mysql_query("select * from ak_detail_perk where ID_DETAIL = '".$rows_jurnal['PERK_DEBET']."';"));
			$perk_kredit = mysql_fetch_array(mysql_query("select * from ak_detail_perk where ID_DETAIL = '".$rows_jurnal['PERK_KREDIT']."';"));
		?>
			<tr>
            	<td><? echo $no ?></td>
                <td><? echo cDate2($rows_jurnal['TANGGAL_TRANS'])?></td>
                <td class="ltext"><? echo $rows_jurnal['NO_BUKTI']?></td>
                <td class="ltext"><? echo $rows_jurnal['NO_REFF']?></td>
                <td class="ltext"><? echo $perk_debet['NAMA_DETAIL']?></td>
                <td  class="ltext"><? echo $perk_kredit['NAMA_DETAIL']?></td>
                <td class="rtext"><? echo cFormat($rows_jurnal['DEBET'],false)?></td>
                
                <td>
                	<div class="cactions two">
                    	<? if($_SESSION['galaxy_unit']!=10)  {  ?>
						<div class="cedit" type="popup" mode="1" title="Edit" link="modul/akunting/jurnal?<? echo $rows_jurnal[0] ?>"></div>
						<? } else { ?>
						<div class="disabled-cedit"></div>
						<? } ?>
                    	
                        <? if($_SESSION['galaxy_unit']!=10)  {  ?>
                        <div link="modul/akunting/jurnal?<? echo $rows_jurnal['ID'] ?>" title="Hapus" mode="2" type="popup" class="cdelete"></div>
                         <? } else { ?>
                        <div class="disabled-cdelete"></div>
                        <?
						}
						?>
                    </div>
                </td>
            </tr>
        <?
			$no++;
		}
		?>
    </table>
</div>

<div class="ctablefooter">
    <ul class="paginationbox">
    <li><div class="pagination-button<?php echo $selPrev?>" <?php echo $PevLink?>>Sebelumnya</div></li>

    <?php
    for ($numPage=0;$numPage<count($pager->PageNumber);$numPage++){
    $selNnum	= ($page==$pager->PageNumber[$numPage] )?"-selected":'';
    $link		= 'link="'.$pager->LinkNumber[$numPage].$get_search.'"';
    echo	'<li><div class="pagination-button'. $selNnum .'" '.$link.'>'.$pager->PageNumber[$numPage].'</div></li>';
    }
    ?>
    <li><div class="pagination-button<?php echo $selNext?>" <?php echo $NextLink?>>Selanjutnya</div></li>
    </ul>
</div>
<input name="p" type="hidden" value="<? echo $page ?>" />