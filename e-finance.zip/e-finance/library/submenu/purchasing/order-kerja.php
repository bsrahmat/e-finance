
<?php
/////// konfigurasi
///// query untuk paging

if(file_exists('../../connectionmysql.php')) {
	require_once '../../connectionmysql.php';
	Connected();
	$path = '../../../';
} else $path = '../../';

$perm = array();
$perm = getPermissions('18');

if(file_exists('../../error-menu.php')) if($perm[-1]=='1') { require_once '../../error-menu.php'; die; }
$IDmodul= $_SESSION['galaxy_unit'];
	
if($IDmodul=='none') $IDmodul = '-1';

//BAGIAN INPUTAN PENCARIAN
//Fungsi STRIPSTRING berfungsi hanya karakter a-z, A-Z, dan angka 0-9 yang diperbolehkan.
$get_search = '';
$search = '';
$search_name = 'Pencarian...';

if(isset($_GET['search'])) {
	$_GET['search'] = stripInput($_GET['search']);
	$search_name = $_GET['search'];
	
	if($_GET['search'] || $_GET['search'] != 'Pencarian...' || $_GET['search'] != '') {
		$search = "AND LOWER(worders.wonom) LIKE '%".strtolower($_GET['search'])."%'";
		$get_search = '&search='.strtolower($_GET['search']);
	}
}
$qry_count = '';
if($_SESSION['galaxy_type']=='0')
 $qry_count = "SELECT worders.id, worders.wodate, worders.wonom, worders.unit_id, worders.isclosed, worders.supplier_id, worders.gmsign, worders.id, units.id, units.gmanager_id, units.name, units.code, units.address, units.phone, units.fax, units.headsale_id, units.rek, units.rekname, units.pusat, units.ismanu, suppliers.id, suppliers.name, suppliers.code, suppliers.address, suppliers.city, suppliers.phone, suppliers.fax, suppliers.upname, suppliers.issubkon FROM worders LEFT JOIN units ON (worders.unit_id = units.id) LEFT JOIN suppliers ON (worders.supplier_id = suppliers.id) where worders.unit_id != '10' ".$search;
else
$qry_count = "SELECT worders.id, worders.wodate, worders.wonom, worders.unit_id, worders.isclosed, worders.supplier_id, worders.gmsign, worders.id, units.id, units.gmanager_id, units.name, units.code, units.address, units.phone, units.fax, units.headsale_id, units.rek, units.rekname, units.pusat, units.ismanu, suppliers.id, suppliers.name, suppliers.code, suppliers.address, suppliers.city, suppliers.phone, suppliers.fax, suppliers.upname, suppliers.issubkon FROM worders LEFT JOIN units ON (worders.unit_id = units.id) LEFT JOIN suppliers ON (worders.supplier_id = suppliers.id) where worders.unit_id != '10' ".$search;
//$qry_count = "SELECT worders.id, worders.wodate, worders.wonom, worders.unit_id, worders.isclosed, worders.supplier_id, worders.gmsign, worders.id, units.id, units.gmanager_id, units.name, units.code, units.address, units.phone, units.fax, units.headsale_id, units.rek, units.rekname, units.pusat, units.ismanu, suppliers.id, suppliers.name, suppliers.code, suppliers.address, suppliers.city, suppliers.phone, suppliers.fax, suppliers.upname, suppliers.issubkon FROM worders LEFT JOIN units ON (worders.unit_id = units.id) LEFT JOIN suppliers ON (worders.supplier_id = suppliers.id) where worders.unit_id != '10' AND worders.unit_id = '".$_SESSION['galaxy_unit']."' ".$search;

$rs_count = mysql_query($qry_count);
$count  = mysql_num_rows($rs_count);

// variabel paging
$page  = (isset($_GET['p']))?( (is_numeric($_GET['p']))?( $page = $_GET['p']): $page = 1 ): $page = 1;
$limit = 20;
$start = $limit * ($page - 1);

$pager = new pagination();
$pager->currentPage 	= $page;
$pager->total			= $count;
$pager->limit			= $limit;
$pager->baseLink		= 'library/submenu/purchasing/order-kerja?p=';
$pager->getHalaman(); 
/// output variabel paging
$selPrev = ($page==$pager->PagePrev )?"-selected":'';
$PevLink = 'link="'. $pager->LinkPrev.$get_search.'"';

$selNext	= ($page==$pager->PageNext )?"-selected":'';
$NextLink	= 'link="'. $pager->LinkNext.$get_search.'"';

//query untuk isi
$qry_worders = '';
if($_SESSION['galaxy_type']=='0')
 $qry_worders = "SELECT worders.id, worders.wodate, worders.wonom, worders.unit_id, worders.isclosed, worders.supplier_id, worders.gmsign, worders.id, units.id, units.gmanager_id, units.name, units.code, units.address, units.phone, units.fax, units.headsale_id, units.rek, units.rekname, units.pusat, units.ismanu, suppliers.id, suppliers.name, suppliers.code, suppliers.address, suppliers.city, suppliers.phone, suppliers.fax, suppliers.upname, suppliers.issubkon FROM worders LEFT JOIN units ON (worders.unit_id = units.id) LEFT JOIN suppliers ON (worders.supplier_id = suppliers.id) where worders.unit_id != '10' ".$search." order by worders.id DESC limit $limit offset $start;";
else
 $qry_worders = "SELECT worders.id, worders.wodate, worders.wonom, worders.unit_id, worders.isclosed, worders.supplier_id, worders.gmsign, worders.id, units.id, units.gmanager_id, units.name, units.code, units.address, units.phone, units.fax, units.headsale_id, units.rek, units.rekname, units.pusat, units.ismanu, suppliers.id, suppliers.name, suppliers.code, suppliers.address, suppliers.city, suppliers.phone, suppliers.fax, suppliers.upname, suppliers.issubkon FROM worders LEFT JOIN units ON (worders.unit_id = units.id) LEFT JOIN suppliers ON (worders.supplier_id = suppliers.id) where worders.unit_id != '10' ".$search." order by worders.id DESC limit $limit offset $start;";
 //$qry_worders = "SELECT worders.id, worders.wodate, worders.wonom, worders.unit_id, worders.isclosed, worders.supplier_id, worders.gmsign, worders.id, units.id, units.gmanager_id, units.name, units.code, units.address, units.phone, units.fax, units.headsale_id, units.rek, units.rekname, units.pusat, units.ismanu, suppliers.id, suppliers.name, suppliers.code, suppliers.address, suppliers.city, suppliers.phone, suppliers.fax, suppliers.upname, suppliers.issubkon FROM worders LEFT JOIN units ON (worders.unit_id = units.id) LEFT JOIN suppliers ON (worders.supplier_id = suppliers.id) where worders.unit_id != '10' AND worders.unit_id = '".$_SESSION['galaxy_unit']."' ".$search." order by worders.id DESC limit $limit offset $start;";

$rs_worders = mysql_query($qry_worders);

/////////////// ending konfigurasi
////////////// process

?>

                   <div class="sub-content-title">Order Kerja</div>
                    
<div class="cboxtable">
                    	<div class="sub-content-bar">
                        	<? if($perm[0]!='1') { ?>
                        	<div class="input-button" type="popup" mode="0" link="modul/purchasing/order-kerja">Tambah Baru</div>
                            <? } else { ?>
                            <div class="disabled-input-button">Tambah Baru</div>
                            <? } ?>
                        	                            
                            <div class="search-button" link="library/submenu/purchasing/order-kerja"><img src="images/cari.png" /></div>
                            <input class="search-input" type="text" value="<? echo $search_name ?>"  />
                            <div class="search-text">No. Order Kerja : </div>

                        </div>
                      	<div class="ctabletitle">Data Order Kerja</div>
						<table class="ctable">
                        <tr class="ctableheader">
                            <td width="6%">No</td>
                            <td width="18%">No. Order Kerja</td>
                            <td width="9%">Tanggal</td>
                            <td>Cabang</td>
                            <td>Pelaksana</td>
                            <td width="10%">Status</td>
                            <td align="center" width="5%">Action</td>
                        </tr>
                        <?php
							$no= $start+1;
							$bg = '';
							$status = '';
							while($rows_worders=mysql_fetch_array($rs_worders)) {
							
							if($rows_worders[6] == NULL) { $bg = 'style="background-color:#FFCC99; color:#000"';}
							if($rows_worders[6] == '1') { $bg = 'style="background-color:#93C194; color:#000"';}
							if($rows_worders[6] == '0') { $bg = 'style="background-color:#F31E1E; color:#000"';}
							
							if($rows_worders[6] == NULL) { $status = 'BELUM';}
							if($rows_worders[6] == '1') { $status = 'SETUJU';}
							if($rows_worders[6] == '0') { $status = 'TOLAK';}
						?>
						
                        <tr <? echo $bg ?>>
                            <td align="right"><? echo $no ?></td>
                            <td class="ltext"><? echo $rows_worders['wonom'] ?></td>
                            <td><? echo cDate2($rows_worders['wodate']) ?></td>                            
                            <td class="ltext"><? echo $rows_worders[10] ?></td>
                            <td class="ltext"><? echo $rows_worders[21] ?></td>
                            <td><b><? echo $status ?></b></td>
                            <td>
                            	<div class="cactions two">                                
                                <div class="cview" title="Detail" link="library/submenu/purchasing/detail/order-kerja?<? echo $rows_worders[0] ?>&p=<? echo $page ?>"></div>
                                
                                <? if($rows_worders['gmsign']=='2' || $rows_worders['gmsign']=='') { ?>
                                <div link="modul/purchasing/order-kerja?<? echo $rows_worders[0] ?>" title="Hapus" mode="2" type="popup" class="cdelete"></div>
                                <? } else { ?>
                            	<div class="disabled-cdelete"></div>
                            	<? } ?>
                            	</div>
                            </td>
                        </tr>
						<?php
						$no++;
							}
						?>
                        </table>
							
							
						</div>
                        <div class="ctablefooter">
                        
                        	                
                        	<ul class="paginationbox">
                            <li><div class="pagination-button<?php echo $selPrev?>" <?php echo $PevLink?>>Sebelumnya</div></li>
    
                            <?php
                            for ($numPage=0;$numPage<count($pager->PageNumber);$numPage++){
							$selNnum	= ($page==$pager->PageNumber[$numPage] )?"-selected":'';
							$link		= 'link="'.$pager->LinkNumber[$numPage].$get_search.'"';
							echo	'<li><div class="pagination-button'. $selNnum .'" '.$link.'>'.$pager->PageNumber[$numPage].'</div></li>';
                            }
                            ?>
                            <li><div class="pagination-button<?php echo $selNext?>" <?php echo $NextLink?>>Selanjutnya</div></li>
                            </ul>
                        
                        </div>
                      
                    <input name="p" type="hidden" value="<? echo $page ?>" />
                    





