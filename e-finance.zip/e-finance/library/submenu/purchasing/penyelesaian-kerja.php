<?php
/////// konfigurasi
///// query untuk paging

if(file_exists('../../connectionmysql.php')) {
	require_once '../../connectionmysql.php';
	Connected();
	$path = '../../../';
} else $path = '../../';

$perm = array();
$perm = getPermissions('20');

if(file_exists('../../error-menu.php')) if($perm[-1]=='1') { require_once '../../error-menu.php'; die; }
$IDmodul= $_SESSION['galaxy_unit'];
	
if($IDmodul=='none') $IDmodul = '-1';

//BAGIAN INPUTAN PENCARIAN
//Fungsi STRIPSTRING berfungsi hanya karakter a-z, A-Z, dan angka 0-9 yang diperbolehkan.
$get_search = '';
$search = '';
$search_name = 'Pencarian...';

if(isset($_GET['search'])) {
	$_GET['search'] = stripInput($_GET['search']);
	$search_name = $_GET['search'];
	
	if($_GET['search'] || $_GET['search'] != 'Pencarian...' || $_GET['search'] != '') {
		$search = "AND LOWER(wends.wenom) LIKE '%".strtolower($_GET['search'])."%'
		OR LOWER(worders.wonom) LIKE '%".strtolower($_GET['search'])."%'";
		$get_search = '&search='.strtolower($_GET['search']);
	}
}
$qry_count = '';
if($_SESSION['galaxy_type']=='0')
 $qry_count = "SELECT wends.id, wends.worder_id, wends.wenom, wends.fakturnom, wends.wedate, wends.description, wends.postby, wends.postdate, wends.isposted, wends.prname, wends.unitid, wends.isclosed, wends.refnom, wends.id, worders.id, worders.wodate, worders.wonom, worders.unit_id, worders.isclosed, worders.supplier_id, worders.gmsign FROM wends LEFT JOIN worders ON (wends.worder_id = worders.id)  WHERE wends.unitid != '10' ".$search;
else
$qry_count = "SELECT wends.id, wends.worder_id, wends.wenom, wends.fakturnom, wends.wedate, wends.description, wends.postby, wends.postdate, wends.isposted, wends.prname, wends.unitid, wends.isclosed, wends.refnom, wends.id, worders.id, worders.wodate, worders.wonom, worders.unit_id, worders.isclosed, worders.supplier_id, worders.gmsign FROM wends LEFT JOIN worders ON (wends.worder_id = worders.id)  WHERE wends.unitid != '10' ".$search;
 //$qry_count = "SELECT * FROM wends LEFT JOIN trprequests ON (wends.trprequest_id = trprequests.id) LEFT JOIN suppliers ON (wends.supplier_id = suppliers.id)  WHERE wends.unitid != '10' AND wends.unitid = '".$_SESSION['galaxy_unit']."' ".$search;

$rs_count = mysql_query($qry_count);
$count  = mysql_num_rows($rs_count);

// variabel paging
$page  = (isset($_GET['p']))?( (is_numeric($_GET['p']))?( $page = $_GET['p']): $page = 1 ): $page = 1;
$limit = 20;
$start = $limit * ($page - 1);

$pager = new pagination();
$pager->currentPage 	= $page;
$pager->total			= $count;
$pager->limit			= $limit;
$pager->baseLink		= 'library/submenu/purchasing/penyelesaian-kerja?p=';
$pager->getHalaman(); 
/// output variabel paging
$selPrev = ($page==$pager->PagePrev )?"-selected":'';
$PevLink = 'link="'. $pager->LinkPrev.$get_search.'"';

$selNext	= ($page==$pager->PageNext )?"-selected":'';
$NextLink	= 'link="'. $pager->LinkNext.$get_search.'"';

//query untuk isi
$qry_wends = '';
if($_SESSION['galaxy_type']=='0')
 $qry_wends = "SELECT wends.id, wends.worder_id, wends.wenom, wends.fakturnom, wends.wedate, wends.description, wends.postby, wends.postdate, wends.isposted, wends.prname, wends.unitid, wends.isclosed, wends.refnom, wends.id, worders.id, worders.wodate, worders.wonom, worders.unit_id, worders.isclosed, worders.supplier_id, worders.gmsign FROM wends LEFT JOIN worders ON (wends.worder_id = worders.id)  WHERE wends.unitid != '10' ".$search." order by wends.id DESC limit $limit offset $start;";
else
 $qry_wends = "SELECT wends.id, wends.worder_id, wends.wenom, wends.fakturnom, wends.wedate, wends.description, wends.postby, wends.postdate, wends.isposted, wends.prname, wends.unitid, wends.isclosed, wends.refnom, wends.id, worders.id, worders.wodate, worders.wonom, worders.unit_id, worders.isclosed, worders.supplier_id, worders.gmsign FROM wends LEFT JOIN worders ON (wends.worder_id = worders.id)  WHERE wends.unitid != '10' ".$search." order by wends.id DESC limit $limit offset $start;";

$rs_wends = mysql_query($qry_wends);

/////////////// ending konfigurasi
////////////// process

?>

                   <div class="sub-content-title">Penyelesaian Kerja</div>
                    
<div class="cboxtable">
                    	<div class="sub-content-bar">
                        	                            
                            <div class="search-button" link="library/submenu/purchasing/penyelesaian-kerja"><img src="images/cari.png" /></div>
                            <input class="search-input" type="text" value="<? echo $search_name ?>"  />
                            <div class="search-text">No. Penyelesaian / Order Kerja: </div>

                        </div>
                      	<div class="ctabletitle">Data Penyelesaian Kerja</div>
						<table class="ctable">
                        <tr class="ctableheader">
                            <td width="6%">No</td>
                            <td width="17%">No Penyelesaian Kerja</td>
                            <td width="17%">No Order Kerja</td>
                            <td>Cabang/Unit</td>
                            <td width="10%">Tanggal</td>
                            <td>Deskripsi</td>
                            <td width="7%">Status</td>
                            <td align="center" width="1%">Act</td>
                        </tr>
                        <?php
							$no= $start+1;
							$bg = '';
							$status = '';
							while($rows_wends=mysql_fetch_array($rs_wends)) {
								$rows_unit=mysql_fetch_array(mysql_query("select * from units where id = '".$rows_wends['unitid']."';"));
								if($rows_wends[11] == NULL) { $bg = 'style="background-color:#FFCC99; color:#000"';}
								if($rows_wends[11] == '1') { $bg = 'style="background-color:#93C194; color:#000"';}
								if($rows_wends[11] == '0') { $bg = 'style="color:#000"';}
								
								if($rows_wends[11] == NULL) { $status = 'BELUM';}
								if($rows_wends[11] == '1') { $status = 'CLOSE';}
								if($rows_wends[11] == '0') { $status = 'PK';}
						?>
                        <tr <? echo $bg ?>>
                            <td align="right"><? echo $no ?></td>
                            <td class="ltext"><? echo $rows_wends['wenom'] ?></td>
                            <td class="ltext"><? echo $rows_wends['wonom'] ?></td>                            
                            <td class="ltext"><? echo $rows_unit['name'] ?></td>
                            <td><? echo cDate2($rows_wends['wedate']) ?></td> 
                            <td class="ltext"><? echo $rows_wends['description'] ?></td> 
                            <td><b><? echo $status ?></b></td>
                            
                            <td>
                            	<div class="cactions one">
								<div class="cview" title="Detail" link="library/submenu/purchasing/detail/penyelesaian-kerja?<? echo $rows_wends[0] ?>&p=<? echo $page ?>"></div>
                                
                                
                                
                            	</div>
                            </td>
                        </tr>
						<?php
						$no++;
							}
						?>
                        </table>
							
							
						</div>
                        <div class="ctablefooter">
                        
                        	                
                        	<ul class="paginationbox">
                            <li><div class="pagination-button<?php echo $selPrev?>" <?php echo $PevLink?>>Sebelumnya</div></li>
    
                            <?php
                            for ($numPage=0;$numPage<count($pager->PageNumber);$numPage++){
							$selNnum	= ($page==$pager->PageNumber[$numPage] )?"-selected":'';
							$link		= 'link="'.$pager->LinkNumber[$numPage].$get_search.'"';
							echo	'<li><div class="pagination-button'. $selNnum .'" '.$link.'>'.$pager->PageNumber[$numPage].'</div></li>';
                            }
                            ?>
                            <li><div class="pagination-button<?php echo $selNext?>" <?php echo $NextLink?>>Selanjutnya</div></li>
                            </ul>
                        
                        </div>
                      
                    <input name="p" type="hidden" value="<? echo $page ?>" />
                    





