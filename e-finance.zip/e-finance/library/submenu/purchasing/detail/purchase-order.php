<script type="text/javascript">
 $(document).ready(function(){
   $(".ctable tr").mouseover(function(){$(this).addClass("over");}).mouseout(function(){$(this).removeClass("over");});
   $(".ctable tr:even").addClass("alt");
 });
 </script>
<?php
if(file_exists('../../../connectionmysql.php')) {
	require_once '../../../connectionmysql.php';
	Connected();
}

$perm = array();
$perm = getPermissions('17');

if(file_exists('../../error-menu.php')) if($perm[-1]=='1') { require_once '../../error-menu.php'; die; }
$IDmodul= $_SESSION['galaxy_unit'];
$page  = (isset($_GET['p']))?( (is_numeric($_GET['p']))?( $page = $_GET['p']): $page = 1 ): $page = 1;
$qry_trporders = '';

$qry_trporders = "SELECT * FROM trporders LEFT JOIN trprequests ON (trporders.trprequest_id = trprequests.id) LEFT JOIN suppliers ON (trporders.supplier_id = suppliers.id)  WHERE trporders.id = '".$_GET['gid']."';";
$rs_trporders = mysql_query($qry_trporders);
$rows_trporders=mysql_fetch_array($rs_trporders);

$qry_isi = "SELECT * FROM trpodetails WHERE trporder_id = '".$_GET['gid']."';";
$rs_isi = mysql_query($qry_isi);
$cnt_isi = mysql_num_rows($rs_isi);

$ada_isi = mysql_query("SELECT * FROM trpodetails WHERE trporder_id = '".$_GET['gid']."' AND price ='0.00';");
$ada_isi = mysql_num_rows($ada_isi);

/////////////// ending konfigurasi
////////////// process

?>

                   <div class="sub-content-title">Purchase Order</div>
                    
				   <div class="cboxtable"> 
                   <div style="float: right; width: auto; padding: 2px 0; "><label style="width: 115px; color: black;"><input style="float: left; margin-right: 4px;" type="checkbox" name="show-hide" value="1" checked/>Show/Hide</label></div> 
					<script type="text/javascript">
                            $("input[name='show-hide']").unbind('click').click(function() { 
                                if($(this).attr('checked')==true) {
								$("div[class^='show-body']").slideToggle("normal");
                                $("div[class^='show-body']").show();
                                } else
								$("div[class^='show-body']").slideToggle("normal");
                                $("div[class^='show-body']").hide();
                            }) 
					</script>                                    
                    	<div class="sub-content-bar">
                          <div class="show-hide">
                          <div class="show-body">
                          <table class="show-table">
                          <tr>
                          <td width="15%" align="right">Tanggal</td>
                          <td width="5%" align="center">:</td>
                          <td align="left"><? echo cDate2($rows_trporders['podate']) ?></td>
                          </tr>
                          <tr>
                          <td align="right">No. PO</td>
                          <td align="center">:</td>
                          <td align="left"><? echo $rows_trporders['ponom'] ?></td>
                          </tr>
                          <tr>
                          <td align="right">No. Permintaan</td>
                          <td align="center">:</td>
                          <td align="left"><? echo $rows_trporders['prnom'] ?></td>
                          </tr>
                          <tr>
                          <td align="right">Tanggal Kirim</td>
                          <td align="center">:</td>
                          <td align="left"><? echo cdate2($rows_trporders['posend']) ?></td>
                          </tr>
                          <tr>
                          <td align="right">Supplier</td>
                          <td align="center">:</td>
                          <td align="left"><? echo $rows_trporders['name'] ?></td>
                          </tr>
                          </table>
                          </div>
                          <div class="popup-footer">
                            <div link="library/submenu/purchasing/purchase-order" class="button-back">Kembali</div>
                            <div target="<? echo md5('cetek-po') ?>" type="pdf" link="modul/laporan/report?<? echo $rows_trporders[0] ?>" class="pdf-button" >Cetak PO</div>
                            <?  if($rows_trporders['isclosed']!='1') { ?>
                            <div class="input-button" type="popup" mode="1" link="modul/purchasing/purchase-order?<? echo $rows_trporders[0] ?>">Edit PO</div>
                           <? } else { ?>
                            <div class="disabled-input-button" >Edit PO</div>
                            <? }?>
                            <? if($rows_trporders['isclosed']=='0' && $cnt_isi>0 && $ada_isi<=0) { ?>
                                <div link="modul/purchasing/purchase-order?<? echo $rows_trporders[0] ?>" title="Close" mode="0" type="popup" class="hold-button">Close</div>
                                <? } else { ?>
                            	<div class="disabled-hold-button">Close</div>
                            	<? } ?>
                          </div>
                          </div>
                        </div>
                        <?  
                        if($rows_trporders['isclosed']!='1') {
						
						?>
                      	<div class="ctabletitle">Daftar Referensi Permintaan Pembelian</div>
						<table class="ctable">
                        <tr class="ctableheader">
                            <td width="6%">No</td>
                            <td>Nama Barang</td>
                            <td width="15%">Satuan</td>
                            <td width="9%">Qty</td>
                            <td width="9%">Sisa</td>
                            <td width="10%">W.Butuh</td>
                            <td align="center" width="2%">Act</td>
                        </tr>
                        <?php
							$qry_trprdetails = "select * from trprdetails JOIN items ON (trprdetails.item_id = items.id) where trprequest_id = '".$rows_trporders['trprequest_id']."';";
							$rs_trprdetails = mysql_query($qry_trprdetails);
							$no= 1;
							while($rows_trprdetails=mysql_fetch_array($rs_trprdetails)) {
								$rows_satuan=mysql_fetch_array(mysql_query("select * from pieces where id = '".$rows_trprdetails['piece_id']."';"));
							
						?>
                        <tr>
                            <td align="right"><? echo $no ?></td>
                            <td class="ltext"><? echo $rows_trprdetails['name'] ?></td>
                            <td><? echo $rows_satuan['name'] ?></td>                            
                            <td align="right"><? echo cFormat($rows_trprdetails['qty'],false) ?></td>
                            <td align="right"><? echo cFormat($rows_trprdetails['rest'],false) ?></td>
                            <td><? echo cDate2($rows_trprdetails['timereq']) ?></td>
                            <td>
                            	<div class="cactions one">
                                <? if($rows_trprdetails['trpstatus']=='1') { ?>                               
                                <div class="cadd" type="popup" mode="0" title="Tambah PO" link="modul/purchasing/detail/purchase-order?<? echo $_GET['gid'] ?>&sub=<? echo $rows_trprdetails[0] ?>"></div>
                                <? } else { ?>
                            	<div class="disabled-cadd"></div>
                            	<? } ?>
                                
                            	</div>
                            </td>
                        </tr>
						<?php
						$no++;
							}
						?>
                        </table>
                        
						</div>
                        <div class="ctablefooter">
						<?  }
						?>
                        
                        </div>
                        
                        <div class="ctabletitle">Daftar PO</div>
						<table class="ctable">
                        <tr class="ctableheader">
                            <td width="6%">No</td>
                            <td>Nama Barang</td>
                            <td width="15%">Jumlah</td>
                            <td width="9%">Satuan</td>
                            <td width="9%">Harga @Rp</td>
                            <td width="10%">PPn</td>
                            <td width="10%">Total</td>
                            <td align="center" width="5%">Action</td>
                        </tr>
                        <?php
							$qry_trpodetails = "select * from trpodetails JOIN items ON ( trpodetails.item_id = items.id) where trporder_id = '".$_GET['gid']."';";
							$rs_trpodetails = mysql_query($qry_trpodetails);
							$no= 1;
							$subtotal = '0';
							while($rows_trpodetails=mysql_fetch_array($rs_trpodetails)) {
								$rows_satuan=mysql_fetch_array(mysql_query("select * from pieces where id = '".$rows_trpodetails['piece_id']."';"));
								$t_harga = $rows_trpodetails['qty'] * $rows_trpodetails['price'];
								$t_ppn = $rows_trpodetails['tax'] * $rows_trpodetails['qty'];
								$total = $t_harga + $t_ppn ;
							
						?>
                        <tr>
                            <td align="right"><? echo $no ?></td>
                            <td class="ltext"><? echo $rows_trpodetails['name'] ?></td>
                            <td align="right"><? echo cFormat($rows_trpodetails['qty'],false) ?></td>                            
                            <td><? echo $rows_satuan['name'] ?></td>
                            <td align="right"><? echo cFormat($rows_trpodetails['price'],false) ?></td>
                            <td align="right"><? echo cFormat($t_ppn,false) ?></td>
                            <td align="right"><? echo cFormat($total,false) ?></td>
                            
                            <td>
                            	<div class="cactions two">
                                <? if($rows_trporders['isclosed']!='1') { ?>                               
                                <div class="cedit" type="popup" mode="1" title="Edit" link="modul/purchasing/detail/purchase-order?<? echo $_GET['gid'] ?>&sub=<? echo $rows_trpodetails[0] ?>"></div>
                                <? } else { ?>
                            	<div class="disabled-cedit"></div>
                            	<? } ?>
                                <? if($rows_trporders['isclosed']!='1') { ?> 
                                <div link="modul/purchasing/detail/purchase-order?<? echo $_GET['gid'] ?>&sub=<? echo $rows_trpodetails[0] ?>" title="Hapus" mode="2" type="popup" class="cdelete"></div>
                                <? } else { ?>
                            	<div class="disabled-cdelete"></div>
                            	<? } ?>
                            	</div>
                            </td>
                        </tr>
						<?php
						$subtotal = $subtotal + $total;
						$no++;
							}
						?>
                         <tr>
                            <td align="right"colspan="6"><b>TOTAL</b></td>
                            
                            <td align="right" class="rtext tabletotal"><b group="count1"><? echo cFormat($subtotal,false)?></b></td>
                            <td>
                            </td>
                        </tr>
                        </table>
                        
						</div>   
                    <input name="p" type="hidden" value="<? echo $page ?>" />