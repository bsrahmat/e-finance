
<?php
/////// konfigurasi
///// query untuk paging

if(file_exists('../../connectionmysql.php')) {
	require_once '../../connectionmysql.php';
	Connected();
	$path = '../../../';
} else $path = '../../';

$perm = array();
$perm = getPermissions('6');

if(file_exists('../../error-menu.php')) if($perm[-1]=='1') { require_once '../../error-menu.php'; die; }
$IDmodul= $_SESSION['galaxy_unit'];
	
if($IDmodul=='none') $IDmodul = '-1';

//BAGIAN INPUTAN PENCARIAN
//Fungsi STRIPSTRING berfungsi hanya karakter a-z, A-Z, dan angka 0-9 yang diperbolehkan.
$get_search = '';
$search = '';
$search_name = 'Pencarian...';

if(isset($_GET['search'])) {
	$_GET['search'] = stripInput($_GET['search']);
	$search_name = $_GET['search'];
	
	if($_GET['search'] || $_GET['search'] != 'Pencarian...' || $_GET['search'] != '') {
		$search = "AND LOWER(spbs.spbnom) LIKE '%".strtolower($_GET['search'])."%'";
		$get_search = '&search='.strtolower($_GET['search']);
	}
}
$qry_count = '';
if($_SESSION['galaxy_type']=='0')
 $qry_count = "SELECT spbs.id, spbs.spbdate, spbs.spbnom, spbs.customer_id, spbs.sale_id, spbs.description, spbs.unit_id, spbs.isclosed, spbs.istake, spbs.tempodate, spbs.id, customers.id, customers.name, customers.code, customers.address, customers.city, customers.phone, customers.fax, customers.upname, customers.unit_id, sales.id, sales.name, sales.code, sales.phone, sales.unit_id, units.id, units.gmanager_id, units.name, units.code, units.address, units.phone, units.fax, units.headsale_id, units.rek, units.rekname, units.pusat, units.ismanu FROM spbs LEFT JOIN customers ON (spbs.customer_id = customers.id) LEFT JOIN sales ON (spbs.sale_id = sales.id) LEFT JOIN units ON (spbs.unit_id = units.id) where spbs.unit_id != '10' ".$search;
else
 $qry_count = "SELECT spbs.id, spbs.spbdate, spbs.spbnom, spbs.customer_id, spbs.sale_id, spbs.description, spbs.unit_id, spbs.isclosed, spbs.istake, spbs.tempodate, spbs.id, customers.id, customers.name, customers.code, customers.address, customers.city, customers.phone, customers.fax, customers.upname, customers.unit_id, sales.id, sales.name, sales.code, sales.phone, sales.unit_id, units.id, units.gmanager_id, units.name, units.code, units.address, units.phone, units.fax, units.headsale_id, units.rek, units.rekname, units.pusat, units.ismanu FROM spbs LEFT JOIN customers ON (spbs.customer_id = customers.id) LEFT JOIN sales ON (spbs.sale_id = sales.id) LEFT JOIN units ON (spbs.unit_id = units.id) where spbs.unit_id != '10' AND spbs.unit_id = '".$_SESSION['galaxy_unit']."' ".$search;

$rs_count = mysql_query($qry_count);
$count  = mysql_num_rows($rs_count);

// variabel paging
$page  = (isset($_GET['p']))?( (is_numeric($_GET['p']))?( $page = $_GET['p']): $page = 1 ): $page = 1;
$limit = 20;
$start = $limit * ($page - 1);

$pager = new pagination();
$pager->currentPage 	= $page;
$pager->total			= $count;
$pager->limit			= $limit;
$pager->baseLink		= 'library/submenu/hsales/pembuatan-spb?p=';
$pager->getHalaman(); 
/// output variabel paging
$selPrev = ($page==$pager->PagePrev )?"-selected":'';
$PevLink = 'link="'. $pager->LinkPrev.$get_search.'"';

$selNext	= ($page==$pager->PageNext )?"-selected":'';
$NextLink	= 'link="'. $pager->LinkNext.$get_search.'"';

//query untuk isi
$qry_spbs = '';
if($_SESSION['galaxy_type']=='0')
 $qry_spbs = "SELECT spbs.id, spbs.spbdate, spbs.spbnom, spbs.customer_id, spbs.sale_id, spbs.description, spbs.unit_id, spbs.isclosed, spbs.istake, spbs.tempodate, spbs.id, customers.id, customers.name, customers.code, customers.address, customers.city, customers.phone, customers.fax, customers.upname, customers.unit_id, sales.id, sales.name, sales.code, sales.phone, sales.unit_id, units.id, units.gmanager_id, units.name, units.code, units.address, units.phone, units.fax, units.headsale_id, units.rek, units.rekname, units.pusat, units.ismanu FROM spbs LEFT JOIN customers ON (spbs.customer_id = customers.id) LEFT JOIN sales ON (spbs.sale_id = sales.id) LEFT JOIN units ON (spbs.unit_id = units.id) where spbs.unit_id != '10' ".$search." order by spbs.id DESC limit $limit offset $start;";
else
 $qry_spbs = "SELECT spbs.id, spbs.spbdate, spbs.spbnom, spbs.customer_id, spbs.sale_id, spbs.description, spbs.unit_id, spbs.isclosed, spbs.istake, spbs.tempodate, spbs.id, customers.id, customers.name, customers.code, customers.address, customers.city, customers.phone, customers.fax, customers.upname, customers.unit_id, sales.id, sales.name, sales.code, sales.phone, sales.unit_id, units.id, units.gmanager_id, units.name, units.code, units.address, units.phone, units.fax, units.headsale_id, units.rek, units.rekname, units.pusat, units.ismanu FROM spbs LEFT JOIN customers ON (spbs.customer_id = customers.id) LEFT JOIN sales ON (spbs.sale_id = sales.id) LEFT JOIN units ON (spbs.unit_id = units.id) where spbs.unit_id != '10' AND spbs.unit_id = '".$_SESSION['galaxy_unit']."' ".$search." order by spbs.id DESC limit $limit offset $start;";

$rs_spbs = mysql_query($qry_spbs);

/////////////// ending konfigurasi
////////////// process

?>

                   <div class="sub-content-title">Surat Permintaan Barang (SPB)</div>
                    
<div class="cboxtable">
                    	<div class="sub-content-bar">
                        	<? if($perm[0]!='1') { ?>
                        	<div class="input-button" type="popup" mode="0" link="modul/hsales/pembuatan-spb">Tambah Baru</div>
                            <? } else { ?>
                            <div class="disabled-input-button">Tambah Baru</div>
                            <? } ?>
                        	                            
                            <div class="search-button" link="library/submenu/hsales/pembuatan-spb"><img src="images/cari.png" /></div>
                            <input class="search-input" type="text" value="<? echo $search_name ?>"  />
                            <div class="search-text">No. SPB : </div>

                        </div>
                      	<div class="ctabletitle">Data Surat Permintaan Barang (SPB)</div>
						<table class="ctable">
                        <tr class="ctableheader">
                            <td width="6%">No</td>
                            <td width="18%">No. SPB</td>
                            <td width="20%">units/Cabang</td>
                            <td width="9%">Tanggal</td>
                            <td>Nama saless</td>
                            <td width="10%">Status</td>
                            <td align="center" width="5%">Action</td>
                        </tr>
                        <?php
							$no= $start+1;
							$bg = '';
							$status = '';
							while($rows_spbs=mysql_fetch_array($rs_spbs)) {
								if($rows_spbs[8] == NULL) { $bg = 'style="background-color:#C2B4A2; color:#000"';}
								if($rows_spbs[8] == '1') { $bg = 'style="background-color:#93C194; color:#000"';}
								
								
								if($rows_spbs[8] == NULL) { $status = 'BELUM';}
								if($rows_spbs[8] == '1') { $status = 'SUDAH';}
								
						?>
                        <tr <? echo $bg ?>>
                            <td align="right"><? echo $no ?></td>
                            <td class="ltext"><? echo $rows_spbs[2] ?></td>
                            <td class="ltext"><? echo $rows_spbs[27] ?></td>
                            <td><? echo cDate2($rows_spbs[1]) ?></td>                            
                            <td class="ltext"><? echo $rows_spbs[21] ?></td>
                            <td><b><? echo $status ?></b></td>
                            <td>
                            	<div class="cactions two">                                
                                <div class="cview" title="Detail" link="library/submenu/hsales/detail/pembuatan-spb?<? echo $rows_spbs[0] ?>&p=<? echo $page ?>"></div>
                                
                                <? if($rows_spbs['istake']=='2' || $rows_spbs['istake']=='') { ?>
                                <div link="modul/hsales/pembuatan-spb?<? echo $rows_spbs[0] ?>" title="Hapus" mode="2" type="popup" class="cdelete"></div>
                                <? } else { ?>
                            	<div class="disabled-cdelete"></div>
                            	<? } ?>
                            	</div>
                            </td>
                        </tr>
						<?php
						$no++;
							}
						?>
                        </table>
							
							
						</div>
                        <div class="ctablefooter">
                        
                        	                
                        	<ul class="paginationbox">
                            <li><div class="pagination-button<?php echo $selPrev?>" <?php echo $PevLink?>>Sebelumnya</div></li>
    
                            <?php
                            for ($numPage=0;$numPage<count($pager->PageNumber);$numPage++){
							$selNnum	= ($page==$pager->PageNumber[$numPage] )?"-selected":'';
							$link		= 'link="'.$pager->LinkNumber[$numPage].$get_search.'"';
							echo	'<li><div class="pagination-button'. $selNnum .'" '.$link.'>'.$pager->PageNumber[$numPage].'</div></li>';
                            }
                            ?>
                            <li><div class="pagination-button<?php echo $selNext?>" <?php echo $NextLink?>>Selanjutnya</div></li>
                            </ul>
                        
                        </div>
                      
                    <input name="p" type="hidden" value="<? echo $page ?>" />
                    





