<script type="text/javascript">
 $(document).ready(function(){
   $(".ctable tr").mouseover(function(){$(this).addClass("over");}).mouseout(function(){$(this).removeClass("over");});
   $(".ctable tr:even").addClass("alt");
 });
</script>
<?php
/////// konfigurasi
///// query untuk paging

if(file_exists('../../connectionmysql.php')) {
	require_once '../../connectionmysql.php';
	Connected();
	$path = '../../../';
} else $path = '../../';

$perm = array();
$perm = getPermissions('33');

if(file_exists('../../error-menu.php')) if($perm[-1]=='1') { require_once '../../error-menu.php'; die; }

//BAGIAN INPUTAN PENCARIAN
//Fungsi STRIPSTRING berfungsi hanya karakter a-z, A-Z, dan angka 0-9 yang diperbolehkan.
$get_search = '';
$search = '';
$search_name = 'Pencarian...';

if(isset($_GET['search'])) {
	$_GET['search'] = stripString($_GET['search']);
	$search_name = $_GET['search'];
	
	if($_GET['search'] || $_GET['search'] != 'Pencarian...' || $_GET['search'] != '') {
		$search = "and LOWER(tbl_admin.admin_full_name) LIKE '%".strtolower($_GET['search'])."%'
			OR LOWER(units.name) LIKE '%".strtolower($_GET['search'])."%'";
		$get_search = '&search='.strtolower($_GET['search']);
		
	}
}
$qry_count = '';
if($_SESSION['galaxy_type']=='0')
 $qry_count = "select * from tbl_admin join units ON units.id = tbl_admin.unit_kode where  admin_kode <> '".$_SESSION['galaxy_kode']."' ".$search;
// $qry_count = "select * from tbl_admin where  admin_kode <> '".$_SESSION['galaxy_kode']."' ".$search;
else
 $qry_count = "select * from tbl_admin join units ON units.id = tbl_admin.unit_kode where tbl_admin.unit_kode = '".$_SESSION['galaxy_unit']."' and tbl_admin.admin_kode <> '".$_SESSION['galaxy_kode']."' ".$search;

$rs_count = mysql_query($qry_count);
$count  = mysql_num_rows($rs_count);

// variabel paging
$page  = (isset($_GET['p']))?( (is_numeric($_GET['p']))?( $page = $_GET['p']): $page = 1 ): $page = 1;
$limit = 5;
$start = $limit * ($page - 1);

$pager = new pagination();
$pager->currentPage 	= $page;
$pager->total			= $count;
$pager->limit			= $limit;
$pager->baseLink		= 'library/submenu/user/daftar-user?p=';
$pager->getHalaman(); 
/// output variabel paging
$selPrev = ($page==$pager->PagePrev )?"-selected":'';
$PevLink = 'link="'. $pager->LinkPrev.$get_search.'"';

$selNext	= ($page==$pager->PageNext )?"-selected":'';
$NextLink	= 'link="'. $pager->LinkNext.$get_search.'"';

//query untuk isi
$qry_admin = '';
if($_SESSION['galaxy_type']=='0')
 $qry_admin = "select * from tbl_admin join units ON units.id = tbl_admin.unit_kode where  admin_kode <> '".$_SESSION['galaxy_kode']."' ".$search." order by units.id ASC, tbl_admin.admin_type ASC limit $limit offset $start;";
else
 $qry_admin = "select * from tbl_admin join units ON units.id = tbl_admin.unit_kode where tbl_admin.unit_kode = '".$_SESSION['galaxy_unit']."' and tbl_admin.admin_kode <> '".$_SESSION['galaxy_kode']."' ".$search." order by units.id ASC, tbl_admin.admin_type ASC  limit $limit offset $start;";

$rs_admin = mysql_query($qry_admin);

/////////////// ending konfigurasi
////////////// process
?>

                   <div class="sub-content-title sub-jenisobat">Management User</div>
                    
<div class="cboxtable">
                    	<div class="sub-content-bar">
                        	<? if($perm[0]!='1') { ?>
                        	<div class="input-button" type="popup" mode="0" link="modul/user/daftar-user">Tambah Baru</div>
                            <? } else { ?>
                            <div class="disabled-input-button">Tambah Baru</div>
                            <? } ?>
                            <div class="search-button" link="library/submenu/user/daftar-user"><img src="images/cari.png" /></div>
                            <input class="search-input" type="text" value="<? echo $search_name ?>"  />

                        </div>
                      	<div class="ctabletitle">Data Management User</div>
						<table class="ctable">
                        <tr class="ctableheader">
                            <td width="1%">No</td>
                            <td width="8%">Foto</td>
                            <td>Nama</td>
                            <td width="15%">Gruop</td>
                            <td align="center" width="5%">Actions</td>
                        </tr>
                        <?php
							$no= $start+1;
							while($rows_admin=mysql_fetch_array($rs_admin)) {
								$grup = mysql_fetch_array(mysql_query("select * from groups where id = '".$rows_admin['admin_type']."';"));
							if($rows_admin['admin_photo_small']) {
								if(file_exists($path.'photo/small/'.$rows_admin['admin_photo_small'])) {
									list($width, $height) = getimagesize($path.'photo/small/'.$rows_admin['admin_photo_small']);
									$photo_small = 'photo/small/'.$rows_admin['admin_photo_small'];
								} else{
									if($rows_admin['admin_gender']=='1') {
										$photo_small = 'photo/small/cew.gif';
									}elseif($rows_admin['admin_gender']=='0') {
										$photo_small = 'photo/small/cow.gif';
									}
								}
							} else{
									if($rows_admin['admin_gender']=='1') {
										$photo_small = 'photo/small/cew.gif';
									}elseif($rows_admin['admin_gender']=='0') {
										$photo_small = 'photo/small/cow.gif';
									}
								}
							
							
						?>
                        <tr>
                            <td width="3%"><? echo $no; ?></td>
                            <td><img class="img" src="<? echo $photo_small; ?>" /></td>
                            <td class="ltext vtop">
								<b><? echo $rows_admin['admin_full_name'] ?></b><br />                                
                                <span style="font-size:11px;"><? echo $grup['name'] ?></span><br />
                                <span style="font-size:11px;"><? echo $rows_admin['admin_tempat_lahir'] ?> / <? echo cTextDate($rows_admin['admin_tgl_lahir'])?></span><br />
                                <span style="font-size:11px;"><? echo $rows_admin['admin_alamat'] ?></span><br />
                                 <span style="font-size:11px;"><? echo $rows_admin['admin_email'] ?></span><br />
                                <span style="font-size:11px;"><b><? echo $rows_admin['name'] ?></b></span><br />
                                <span style="font-size:11px;"><b><? echo $rows_admin['address'] ?></b></span>                                 
                            </td>
                            <td><b><? echo $grup['name'] ?></b></td>
                            <td>
                            	<div class="cactions three">
                                <? if($perm[3]!='1') { ?>
                                <div class="caccess" type="popup" mode="1" title="Hak Akses" link="modul/user/daftar-access?<? echo $rows_admin['admin_kode'] ?>"></div>
                            	<? } else { ?>
                            	<div class="disabled-caccess"></div>
                            	<? } ?>
								<? if($perm[1]!='1') { ?>
                                <div class="cedit" type="popup" mode="1" title="Edit" link="modul/user/daftar-user?<? echo $rows_admin['admin_kode'] ?>"></div>
                                <? } else { ?>
                            	<div class="disabled-cedit"></div>
                            	<? } ?>
                                <? if($perm[2]!='1') { ?>
                                <div link="modul/user/daftar-user?<? echo $rows_admin['admin_kode'] ?>" title="Hapus" mode="2" type="popup" class="cdelete"></div>
                                <? } else { ?>
                            	<div class="disabled-cdelete"></div>
                            	<? } ?>
                            	</div>
                            </td>
                        </tr>
						<?php
						$no++;
							}
						?>
                        </table>
							
						</div>
                        <div class="ctablefooter">
                        
                        	                
                        	<ul class="paginationbox">
                            <li><div class="pagination-button<?php echo $selPrev?>" <?php echo $PevLink?>>Sebelumnya</div></li>
    
                            <?php
                            for ($numPage=0;$numPage<count($pager->PageNumber);$numPage++){
							$selNnum	= ($page==$pager->PageNumber[$numPage] )?"-selected":'';
							$link		= 'link="'.$pager->LinkNumber[$numPage].$get_search.'"';
							echo	'<li><div class="pagination-button'. $selNnum .'" '.$link.'>'.$pager->PageNumber[$numPage].'</div></li>';
                            }
                            ?>
                            <li><div class="pagination-button<?php echo $selNext?>" <?php echo $NextLink?>>Selanjutnya</div></li>
                            </ul>
                        
                        </div>
                      
                    <input name="p" type="hidden" value="<? echo $page ?>" />
                    





