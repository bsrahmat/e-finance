<?php
if(file_exists('../../connectionmysql.php')) {
	require_once '../../connectionmysql.php';
	require_once '../../session.php';
	Connected();
	
	$perm = array();
	$perm = getPermissions('16');
	if(file_exists('../../error-menu.php')) if($perm[-1]=='1') { require_once '../../error-menu.php'; die; }
}
?>
                    <div class="sub-content-title">Kartu Stock Barang</div>
                    
                	<div class="cboxtable">
                    	<div class="sub-content-bar">
                        <form action="modul/gudang/kartu-stok.php" method="post">
                        <table width="100%">
                        <tr>
                        <td valign="top" width="25%"><div style="margin-top:4px;">Nama Gudang</div></td>
                        <td valign="top" width="1%" align="center"><div style="margin-top:4px;">:</div></td>
                        <td valign="top"  width="74%">
                        	<select name="warehouse_id" id="warehouse_id" class="select-text input-large">
                            <option value="">Pilih..</option>
                          <? 
                          $qry_warehouses = '';
                          if($_SESSION['galaxy_type']=='0')	{
                              $qry_modul = "select * from warehouses JOIN units_warehouses ON (units_warehouses.warehouse_id = warehouses.id)  order by units_warehouses.id;";
                          }
                          else{
                            $qry_warehouses = "select * from warehouses JOIN units_warehouses ON (units_warehouses.unit_id = '".$_SESSION['galaxy_unit']."' AND units_warehouses.warehouse_id = warehouses.id)  order by units_warehouses.id;";
                          } 
                          $rs_warehouses = mysql_query($qry_warehouses);
                          while($rows_warehouses=mysql_fetch_array($rs_warehouses)) {
                          ?>
                            <option value="<? echo $rows_warehouses['warehouse_id']?>"><? echo $rows_warehouses['name']; ?></option>
                          <? } ?>
                          </select>
                          
                        </td>
                        </tr>
                        <tr>
                        <td valign="top" width="15%"><div style="margin-top:4px;"></div></td>
                        <td valign="top" width="1%" align="center"><div style="margin-top:4px;"></div></td>
                        <td valign="middle"><label style="float: left; width: 150px; height: 20px; color: black;"><input style="float: left; margin-right: 4px;" type="checkbox" name="summary" value="1" />Summary</label> 
                          <div print="0" style="margin-left: 22px;" class="print-button">Preview</div>
                         
                          <div print="3" style="margin-left: 7px;" class="print-button">Excel</div>
                        </td>
                        </tr>
                        </table>
						</form>
                        
                        </div>
						
                    	
                        <div class="box-paper"></div>
                        
                    </div>

