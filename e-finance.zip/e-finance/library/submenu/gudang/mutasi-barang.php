
<?php
/////// konfigurasi
///// query untuk paging

if(file_exists('../../connectionmysql.php')) {
	require_once '../../connectionmysql.php';
	Connected();
	$path = '../../../';
} else $path = '../../';

$perm = array();
$perm = getPermissions('15');

if(file_exists('../../error-menu.php')) if($perm[-1]=='1') { require_once '../../error-menu.php'; die; }
$IDmodul= $_SESSION['galaxy_unit'];
	
if($IDmodul=='none') $IDmodul = '-1';

//BAGIAN INPUTAN PENCARIAN
//Fungsi STRIPSTRING berfungsi hanya karakter a-z, A-Z, dan angka 0-9 yang diperbolehkan.
$get_search = '';
$search = '';
$search_name = 'Pencarian...';

if(isset($_GET['search'])) {
	$_GET['search'] = stripInput($_GET['search']);
	$search_name = $_GET['search'];
	
	if($_GET['search'] || $_GET['search'] != 'Pencarian...' || $_GET['search'] != '') {
		$search = "AND LOWER(Moveitem.mvnom) LIKE '%".strtolower($_GET['search'])."%'";
		$get_search = '&search='.strtolower($_GET['search']);
	}
}
$qry_count = '';
if($_SESSION['galaxy_type']=='0')
 $qry_count = "SELECT Moveitem.id, Moveitem.mvdate, Moveitem.mvnom, Moveitem.warehouse1_id, Moveitem.warehouse2_id, Moveitem.unit_id, Moveitem.description, Moveitem.isclose, Moveitem.id, Warehouse1.id, Warehouse1.code, Warehouse1.name, Warehouse1.location, Warehouse1.whhead, Warehouse2.id, Warehouse2.code, Warehouse2.name, Warehouse2.location, Warehouse2.whhead, Unit.id, Unit.gmanager_id, Unit.name, Unit.code, Unit.address, Unit.phone, Unit.fax, Unit.headsale_id, Unit.rek, Unit.rekname, Unit.pusat, Unit.ismanu FROM moveitems AS Moveitem LEFT JOIN warehouses AS Warehouse1 ON (Moveitem.warehouse1_id = Warehouse1.id) LEFT JOIN warehouses AS Warehouse2 ON (Moveitem.warehouse2_id = Warehouse2.id) LEFT JOIN units AS Unit ON (Moveitem.unit_id = Unit.id) where Moveitem.unit_id != '10' ".$search;
else
 $qry_count = "SELECT Moveitem.id, Moveitem.mvdate, Moveitem.mvnom, Moveitem.warehouse1_id, Moveitem.warehouse2_id, Moveitem.unit_id, Moveitem.description, Moveitem.isclose, Moveitem.id, Warehouse1.id, Warehouse1.code, Warehouse1.name, Warehouse1.location, Warehouse1.whhead, Warehouse2.id, Warehouse2.code, Warehouse2.name, Warehouse2.location, Warehouse2.whhead, Unit.id, Unit.gmanager_id, Unit.name, Unit.code, Unit.address, Unit.phone, Unit.fax, Unit.headsale_id, Unit.rek, Unit.rekname, Unit.pusat, Unit.ismanu FROM moveitems AS Moveitem LEFT JOIN warehouses AS Warehouse1 ON (Moveitem.warehouse1_id = Warehouse1.id) LEFT JOIN warehouses AS Warehouse2 ON (Moveitem.warehouse2_id = Warehouse2.id) LEFT JOIN units AS Unit ON (Moveitem.unit_id = Unit.id) where Moveitem.unit_id != '10' AND Moveitem.unit_id = '".$_SESSION['galaxy_unit']."' ".$search;

$rs_count = mysql_query($qry_count);
$count  = mysql_num_rows($rs_count);

// variabel paging
$page  = (isset($_GET['p']))?( (is_numeric($_GET['p']))?( $page = $_GET['p']): $page = 1 ): $page = 1;
$limit = 20;
$start = $limit * ($page - 1);

$pager = new pagination();
$pager->currentPage 	= $page;
$pager->total			= $count;
$pager->limit			= $limit;
$pager->baseLink		= 'library/submenu/gudang/mutasi-barang?p=';
$pager->getHalaman(); 
/// output variabel paging
$selPrev = ($page==$pager->PagePrev )?"-selected":'';
$PevLink = 'link="'. $pager->LinkPrev.$get_search.'"';

$selNext	= ($page==$pager->PageNext )?"-selected":'';
$NextLink	= 'link="'. $pager->LinkNext.$get_search.'"';

//query untuk isi
$qry_moveitems = '';
if($_SESSION['galaxy_type']=='0')
 $qry_moveitems = "SELECT Moveitem.id, Moveitem.mvdate, Moveitem.mvnom, Moveitem.warehouse1_id, Moveitem.warehouse2_id, Moveitem.unit_id, Moveitem.description, Moveitem.isclose, Moveitem.id, Warehouse1.id, Warehouse1.code, Warehouse1.name, Warehouse1.location, Warehouse1.whhead, Warehouse2.id, Warehouse2.code, Warehouse2.name, Warehouse2.location, Warehouse2.whhead, Unit.id, Unit.gmanager_id, Unit.name, Unit.code, Unit.address, Unit.phone, Unit.fax, Unit.headsale_id, Unit.rek, Unit.rekname, Unit.pusat, Unit.ismanu FROM moveitems AS Moveitem LEFT JOIN warehouses AS Warehouse1 ON (Moveitem.warehouse1_id = Warehouse1.id) LEFT JOIN warehouses AS Warehouse2 ON (Moveitem.warehouse2_id = Warehouse2.id) LEFT JOIN units AS Unit ON (Moveitem.unit_id = Unit.id) where Moveitem.unit_id != '10' ".$search." order by moveitems.id DESC limit $limit offset $start;";
else
 $qry_moveitems = "SELECT Moveitem.id, Moveitem.mvdate, Moveitem.mvnom, Moveitem.warehouse1_id, Moveitem.warehouse2_id, Moveitem.unit_id, Moveitem.description, Moveitem.isclose, Moveitem.id, Warehouse1.id, Warehouse1.code, Warehouse1.name, Warehouse1.location, Warehouse1.whhead, Warehouse2.id, Warehouse2.code, Warehouse2.name, Warehouse2.location, Warehouse2.whhead, Unit.id, Unit.gmanager_id, Unit.name, Unit.code, Unit.address, Unit.phone, Unit.fax, Unit.headsale_id, Unit.rek, Unit.rekname, Unit.pusat, Unit.ismanu FROM moveitems AS Moveitem LEFT JOIN warehouses AS Warehouse1 ON (Moveitem.warehouse1_id = Warehouse1.id) LEFT JOIN warehouses AS Warehouse2 ON (Moveitem.warehouse2_id = Warehouse2.id) LEFT JOIN units AS Unit ON (Moveitem.unit_id = Unit.id) where Moveitem.unit_id != '10' AND Moveitem.unit_id = '".$_SESSION['galaxy_unit']."' ".$search." order by Moveitem.id DESC limit $limit offset $start;";

$rs_moveitems = mysql_query($qry_moveitems);

/////////////// ending konfigurasi
////////////// process

?>

                   <div class="sub-content-title">Mutasi Barang</div>
                    
<div class="cboxtable">
                    	<div class="sub-content-bar">
                        	<? if($perm[0]!='1') { ?>
                        	<div class="input-button" type="popup" mode="0" link="modul/gudang/mutasi-barang">Tambah Baru</div>
                            <? } else { ?>
                            <div class="disabled-input-button">Tambah Baru</div>
                            <? } ?>
                        	                            
                            <div class="search-button" link="library/submenu/gudang/mutasi-barang"><img src="images/cari.png" /></div>
                            <input class="search-input" type="text" value="<? echo $search_name ?>"  />
                            <div class="search-text">No. Mutasi : </div>

                        </div>
                      	<div class="ctabletitle">Data Mutasi Barang</div>
						<table class="ctable">
                        <tr class="ctableheader">
                            <td width="6%">No</td>
                            <td width="18%">No. Mutasi</td>
                            <td width="9%">Tanggal</td>
                            <td>Dari Gudang</td>
                            <td>Ke Gudang</td>
                            <td width="10%">Status</td>
                            <td align="center" width="5%">Action</td>
                        </tr>
                        <?php
							$no= $start+1;
							while($rows_moveitems=mysql_fetch_array($rs_moveitems)) {
							$status['0'] = 'TOLAK';
							$status['1'] = 'SETUJU';
							$status['2'] = 'BELUM';
							$status[''] = 'BELUM';
							$status['Null'] = 'BELUM';
							$bg['0'] = 'style="background-color:#F99085; color:#FFF"';
							$bg['1'] = 'style="background-color:#B6F7AB;"';
							$bg['2'] = 'style="background-color:#7698EE; color:#000"';
							$bg[''] = 'style="background-color:#7698EE; color:#000"';
							$bg['Null'] = 'style="background-color:#7698EE; color:#000"';
						?>
                        <tr <? echo $bg[$rows_moveitems['isclose']] ?>>
                            <td align="right"><? echo $no ?></td>
                            <td class="ltext"><? echo $rows_moveitems['mvnom'] ?></td>
                            <td><? echo cDate2($rows_moveitems['mvdate']) ?></td>                            
                            <td class="ltext"><? echo $rows_moveitems[11] ?></td>
                            <td class="ltext"><? echo $rows_moveitems[16] ?></td>
                            <td><b><? echo $status[$rows_moveitems['isclose']] ?></b></td>
                            <td>
                            	<div class="cactions two">                                
                                <div class="cview" title="Detail" link="library/submenu/gudang/detail/mutasi-barang?<? echo $rows_moveitems[0] ?>&p=<? echo $page ?>"></div>
                                
                                <? if($rows_moveitems['isclose']=='') { ?>
                                <div link="modul/gudang/mutasi-barang?<? echo $rows_moveitems[0] ?>" title="Hapus" mode="2" type="popup" class="cdelete"></div>
                                <? } else { ?>
                            	<div class="disabled-cdelete"></div>
                            	<? } ?>
                                
                            	</div>
                            </td>
                        </tr>
						<?php
						$no++;
							}
						?>
                        </table>
							
							
						</div>
                        <div class="ctablefooter">
                        
                        	                
                        	<ul class="paginationbox">
                            <li><div class="pagination-button<?php echo $selPrev?>" <?php echo $PevLink?>>Sebelumnya</div></li>
    
                            <?php
                            for ($numPage=0;$numPage<count($pager->PageNumber);$numPage++){
							$selNnum	= ($page==$pager->PageNumber[$numPage] )?"-selected":'';
							$link		= 'link="'.$pager->LinkNumber[$numPage].$get_search.'"';
							echo	'<li><div class="pagination-button'. $selNnum .'" '.$link.'>'.$pager->PageNumber[$numPage].'</div></li>';
                            }
                            ?>
                            <li><div class="pagination-button<?php echo $selNext?>" <?php echo $NextLink?>>Selanjutnya</div></li>
                            </ul>
                        
                        </div>
                      
                    <input name="p" type="hidden" value="<? echo $page ?>" />
                    





