
<?php
/////// konfigurasi
///// query untuk paging

if(file_exists('../../connectionmysql.php')) {
	require_once '../../connectionmysql.php';
	Connected();
	$path = '../../../';
} else $path = '../../';

$perm = array();
$perm = getPermissions('9');

if(file_exists('../../error-menu.php')) if($perm[-1]=='1') { require_once '../../error-menu.php'; die; }
$IDmodul= $_SESSION['galaxy_unit'];
	
if($IDmodul=='none') $IDmodul = '-1';

//BAGIAN INPUTAN PENCARIAN
//Fungsi STRIPSTRING berfungsi hanya karakter a-z, A-Z, dan angka 0-9 yang diperbolehkan.
$get_search = '';
$search = '';
$search_name = 'Pencarian...';

if(isset($_GET['search'])) {
	$_GET['search'] = stripInput($_GET['search']);
	$search_name = $_GET['search'];
	
	if($_GET['search'] || $_GET['search'] != 'Pencarian...' || $_GET['search'] != '') {
		$search = "AND LOWER(trprequests.prnom) LIKE '%".strtolower($_GET['search'])."%'";
		$get_search = '&search='.strtolower($_GET['search']);
	}
}
$qry_count = '';
if($_SESSION['galaxy_type']=='0')
 $qry_count = "SELECT trprequests.id, trprequests.unit_id, trprequests.prdate, trprequests.prname, trprequests.prnom, trprequests.gmsign, trprequests.correct_pb, trprequests.id, units.id, units.gmanager_id, units.name, units.code, units.address, units.phone, units.fax, units.headsale_id, units.rek, units.rekname, units.pusat, units.ismanu FROM trprequests LEFT JOIN units ON (trprequests.unit_id = units.id) where trprequests.unit_id != '10' ".$search;
else
 $qry_count = "SELECT trprequests.id, trprequests.unit_id, trprequests.prdate, trprequests.prname, trprequests.prnom, trprequests.gmsign, trprequests.correct_pb, trprequests.id, units.id, units.gmanager_id, units.name, units.code, units.address, units.phone, units.fax, units.headsale_id, units.rek, units.rekname, units.pusat, units.ismanu FROM trprequests LEFT JOIN units ON (trprequests.unit_id = units.id) where trprequests.unit_id != '10' AND trprequests.unit_id = '".$_SESSION['galaxy_unit']."' ".$search;

$rs_count = mysql_query($qry_count);
$count  = mysql_num_rows($rs_count);

// variabel paging
$page  = (isset($_GET['p']))?( (is_numeric($_GET['p']))?( $page = $_GET['p']): $page = 1 ): $page = 1;
$limit = 20;
$start = $limit * ($page - 1);

$pager = new pagination();
$pager->currentPage 	= $page;
$pager->total			= $count;
$pager->limit			= $limit;
$pager->baseLink		= 'library/submenu/gudang/pembuatan-pb?p=';
$pager->getHalaman(); 
/// output variabel paging
$selPrev = ($page==$pager->PagePrev )?"-selected":'';
$PevLink = 'link="'. $pager->LinkPrev.$get_search.'"';

$selNext	= ($page==$pager->PageNext )?"-selected":'';
$NextLink	= 'link="'. $pager->LinkNext.$get_search.'"';

//query untuk isi
$qry_trprequests = '';
if($_SESSION['galaxy_type']=='0')
 $qry_trprequests = "SELECT trprequests.id, trprequests.unit_id, trprequests.prdate, trprequests.prname, trprequests.prnom, trprequests.gmsign, trprequests.correct_pb, trprequests.id, units.id, units.gmanager_id, units.name, units.code, units.address, units.phone, units.fax, units.headsale_id, units.rek, units.rekname, units.pusat, units.ismanu FROM trprequests LEFT JOIN units ON (trprequests.unit_id = units.id) where trprequests.unit_id != '10' ".$search." order by trprequests.id DESC limit $limit offset $start;";
else
 $qry_trprequests = "SELECT trprequests.id, trprequests.unit_id, trprequests.prdate, trprequests.prname, trprequests.prnom, trprequests.gmsign, trprequests.correct_pb, trprequests.id, units.id, units.gmanager_id, units.name, units.code, units.address, units.phone, units.fax, units.headsale_id, units.rek, units.rekname, units.pusat, units.ismanu FROM trprequests LEFT JOIN units ON (trprequests.unit_id = units.id) where trprequests.unit_id != '10' AND trprequests.unit_id = '".$_SESSION['galaxy_unit']."' ".$search." order by trprequests.id DESC limit $limit offset $start;";

$rs_trprequests = mysql_query($qry_trprequests);

/////////////// ending konfigurasi
////////////// process

?>

                   <div class="sub-content-title">Permintaan Pembelian</div>
                    
<div class="cboxtable">
                    	<div class="sub-content-bar">
                        	<? if($perm[0]!='1') { ?>
                        	<div class="input-button" type="popup" mode="0" link="modul/gudang/pembuatan-pb">Tambah Baru</div>
                            <? } else { ?>
                            <div class="disabled-input-button">Tambah Baru</div>
                            <? } ?>
                        	                            
                            <div class="search-button" link="library/submenu/gudang/pembuatan-pb"><img src="images/cari.png" /></div>
                            <input class="search-input" type="text" value="<? echo $search_name ?>"  />
                            <div class="search-text">No. Permintaan : </div>

                        </div>
                      	<div class="ctabletitle">Data Permintaan Pembelian</div>
						<table class="ctable">
                        <tr class="ctableheader">
                            <td width="6%">No</td>
                            <td width="18%">No. Permintaan</td>
                            <td width="9%">Tanggal</td>
                            <td>Nama Peminta</td>
                            <td width="10%">Status</td>
                            <td align="center" width="5%">Action</td>
                        </tr>
                        <?php
							$no= $start+1;
							$bg = '';
							$status = '';
							while($rows_trprequests=mysql_fetch_array($rs_trprequests)) {
							if($rows_trprequests[5] == NULL) { $bg = 'style="background-color:#FFCC99; color:#000"';}
							if($rows_trprequests[5] == '1') { $bg = 'style="background-color:#93C194; color:#000"';}
							if($rows_trprequests[5] == '0') { $bg = 'style="background-color:#FF3333; color:#000"';}
							
							if($rows_trprequests[5] == NULL) { $status = 'BELUM';}
							if($rows_trprequests[5] == '1') { $status = 'SETUJU';}
							if($rows_trprequests[5] == '0') { $status = 'TOLAK';}
						?>
                        <tr <? echo $bg ?>>
                            <td align="right"><? echo $no ?></td>
                            <td class="ltext"><? echo $rows_trprequests['prnom'] ?></td>
                            <td><? echo cDate2($rows_trprequests['prdate']) ?></td>                            
                            <td class="ltext"><? echo $rows_trprequests['prname'] ?></td>
                            <td><b><? echo $status ?></b></td>
                            <td>
                            	<div class="cactions two">                                
                                <div class="cview" title="Detail" link="library/submenu/gudang/detail/pembuatan-pb?<? echo $rows_trprequests[0] ?>&p=<? echo $page ?>"></div>
                                
                                <? if($rows_trprequests['gmsign']=='2' || $rows_trprequests['gmsign']=='') { ?>
                                <div link="modul/gudang/pembuatan-pb?<? echo $rows_trprequests[0] ?>" title="Hapus" mode="2" type="popup" class="cdelete"></div>
                                <? } else { ?>
                            	<div class="disabled-cdelete"></div>
                            	<? } ?>
                            	</div>
                            </td>
                        </tr>
						<?php
						$no++;
							}
						?>
                        </table>
							
							
						</div>
                        <div class="ctablefooter">
                        
                        	                
                        	<ul class="paginationbox">
                            <li><div class="pagination-button<?php echo $selPrev?>" <?php echo $PevLink?>>Sebelumnya</div></li>
    
                            <?php
                            for ($numPage=0;$numPage<count($pager->PageNumber);$numPage++){
							$selNnum	= ($page==$pager->PageNumber[$numPage] )?"-selected":'';
							$link		= 'link="'.$pager->LinkNumber[$numPage].$get_search.'"';
							echo	'<li><div class="pagination-button'. $selNnum .'" '.$link.'>'.$pager->PageNumber[$numPage].'</div></li>';
                            }
                            ?>
                            <li><div class="pagination-button<?php echo $selNext?>" <?php echo $NextLink?>>Selanjutnya</div></li>
                            </ul>
                        
                        </div>
                      
                    <input name="p" type="hidden" value="<? echo $page ?>" />
                    





