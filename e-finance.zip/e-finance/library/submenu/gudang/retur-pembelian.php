
<?php
/////// konfigurasi
///// query untuk paging

if(file_exists('../../connectionmysql.php')) {
	require_once '../../connectionmysql.php';
	Connected();
	$path = '../../../';
} else $path = '../../';

$perm = array();
$perm = getPermissions('11');

if(file_exists('../../error-menu.php')) if($perm[-1]=='1') { require_once '../../error-menu.php'; die; }
$IDmodul= $_SESSION['galaxy_unit'];
	
if($IDmodul=='none') $IDmodul = '-1';

//BAGIAN INPUTAN PENCARIAN
//Fungsi STRIPSTRING berfungsi hanya karakter a-z, A-Z, dan angka 0-9 yang diperbolehkan.
$get_search = '';
$search = '';
$search_name = 'Pencarian...';

if(isset($_GET['search'])) {
	$_GET['search'] = stripInput($_GET['search']);
	$search_name = $_GET['search'];
	
	if($_GET['search'] || $_GET['search'] != 'Pencarian...' || $_GET['search'] != '') {
		$search = "AND LOWER(breturs.retnom) LIKE '%".strtolower($_GET['search'])."%'
		OR LOWER(trrgoods.rgnom) LIKE '%".strtolower($_GET['search'])."%'";
		$get_search = '&search='.strtolower($_GET['search']);
	}
}
$qry_count = '';
if($_SESSION['galaxy_type']=='0')
 $qry_count = "SELECT breturs.id, breturs.trrgood_id, breturs.retdate, breturs.retnom, breturs.unitid, breturs.isclosed, breturs.isacc, breturs.isok, breturs.ispost, trrgoods.id, trrgoods.trporder_id, trrgoods.rgnom, trrgoods.fakturnom, trrgoods.rgdate, trrgoods.description, trrgoods.recipient, trrgoods.postby, trrgoods.postdate, trrgoods.prsign, trrgoods.isposted, trrgoods.prname, trrgoods.unitid, trrgoods.isclosed, trrgoods.warehouse_id, trrgoods.refnom, trrgoods.post FROM breturs LEFT JOIN trrgoods ON (breturs.trrgood_id = trrgoods.id)  WHERE breturs.unitid != '10' ".$search;
else
 $qry_count = "SELECT breturs.id, breturs.trrgood_id, breturs.retdate, breturs.retnom, breturs.unitid, breturs.isclosed, breturs.isacc, breturs.isok, breturs.ispost, trrgoods.id, trrgoods.trporder_id, trrgoods.rgnom, trrgoods.fakturnom, trrgoods.rgdate, trrgoods.description, trrgoods.recipient, trrgoods.postby, trrgoods.postdate, trrgoods.prsign, trrgoods.isposted, trrgoods.prname, trrgoods.unitid, trrgoods.isclosed, trrgoods.warehouse_id, trrgoods.refnom, trrgoods.post FROM breturs LEFT JOIN trrgoods ON (breturs.trrgood_id = trrgoods.id)  WHERE breturs.unitid != '10' AND breturs.unitid = '".$_SESSION['galaxy_unit']."' ".$search;

$rs_count = mysql_query($qry_count);
$count  = mysql_num_rows($rs_count);

// variabel paging
$page  = (isset($_GET['p']))?( (is_numeric($_GET['p']))?( $page = $_GET['p']): $page = 1 ): $page = 1;
$limit = 20;
$start = $limit * ($page - 1);

$pager = new pagination();
$pager->currentPage 	= $page;
$pager->total			= $count;
$pager->limit			= $limit;
$pager->baseLink		= 'library/submenu/gudang/retur-pembelian?p=';
$pager->getHalaman(); 
/// output variabel paging
$selPrev = ($page==$pager->PagePrev )?"-selected":'';
$PevLink = 'link="'. $pager->LinkPrev.$get_search.'"';

$selNext	= ($page==$pager->PageNext )?"-selected":'';
$NextLink	= 'link="'. $pager->LinkNext.$get_search.'"';

//query untuk isi
$qry_breturs = '';
if($_SESSION['galaxy_type']=='0')
 $qry_breturs = "SELECT breturs.id, breturs.trrgood_id, breturs.retdate, breturs.retnom, breturs.unitid, breturs.isclosed, breturs.isacc, breturs.isok, breturs.ispost, trrgoods.id, trrgoods.trporder_id, trrgoods.rgnom, trrgoods.fakturnom, trrgoods.rgdate, trrgoods.description, trrgoods.recipient, trrgoods.postby, trrgoods.postdate, trrgoods.prsign, trrgoods.isposted, trrgoods.prname, trrgoods.unitid, trrgoods.isclosed, trrgoods.warehouse_id, trrgoods.refnom, trrgoods.post FROM breturs LEFT JOIN trrgoods ON (breturs.trrgood_id = trrgoods.id)  WHERE breturs.unitid != '10' ".$search." order by breturs.id DESC limit $limit offset $start;";
else
 $qry_breturs = "SELECT breturs.id, breturs.trrgood_id, breturs.retdate, breturs.retnom, breturs.unitid, breturs.isclosed, breturs.isacc, breturs.isok, breturs.ispost, trrgoods.id, trrgoods.trporder_id, trrgoods.rgnom, trrgoods.fakturnom, trrgoods.rgdate, trrgoods.description, trrgoods.recipient, trrgoods.postby, trrgoods.postdate, trrgoods.prsign, trrgoods.isposted, trrgoods.prname, trrgoods.unitid, trrgoods.isclosed, trrgoods.warehouse_id, trrgoods.refnom, trrgoods.post FROM breturs LEFT JOIN trrgoods ON (breturs.trrgood_id = trrgoods.id)  WHERE breturs.unitid != '10' AND breturs.unitid = '".$_SESSION['galaxy_unit']."' ".$search." order by breturs.id DESC limit $limit offset $start;";

$rs_breturs = mysql_query($qry_breturs);

/////////////// ending konfigurasi
////////////// process

?>

                   <div class="sub-content-title">Retur Pembelian</div>
                    
<div class="cboxtable">
                    	<div class="sub-content-bar">
                        	<? if($perm[0]!='1') { ?>
                        	<div class="input-button" type="popup" mode="0" link="modul/gudang/retur-pembelian">Tambah Baru</div>
                            <? } else { ?>
                            <div class="disabled-input-button">Tambah Baru</div>
                            <? } ?>
                        	                            
                            <div class="search-button" link="library/submenu/gudang/retur-pembelian"><img src="images/cari.png" /></div>
                            <input class="search-input" type="text" value="<? echo $search_name ?>"  />
                            <div class="search-text">No. LPB / No. Retur : </div>

                        </div>
                      	<div class="ctabletitle">Data Retur Pembelian</div>
						<table class="ctable">
                        <tr class="ctableheader">
                            <td width="6%">No</td>
                            <td width="18%">No. Retur</td>
                            <td width="18%">No. LPB</td>
                            <td width="9%">Tanggal</td>
                            <td>Supplier</td>
                            <td width="10%">Status</td>
                            <td align="center" width="5%">Action</td>
                        </tr>
                        <?php
							$no= $start+1;
							$bg = '';
							$status = '';
							while($rows_breturs=mysql_fetch_array($rs_breturs)) {
								$rows_supplier=mysql_fetch_array(mysql_query("select * from suppliers LEFT JOIN trporders ON (suppliers.id = trporders.supplier_id) LEFT JOIN trrgoods ON (trporders.id = trrgoods.trporder_id) where trrgoods.id = '".$rows_breturs['trrgood_id']."';"));
							if($rows_breturs[7] == NULL) { $bg = 'style="background-color:#FFCC99; color:#000"';}
							if($rows_breturs[7] == '1' && $rows_breturs[6] == NULL) { $bg = 'style="background-color:#FDF684; color:#000"';}
							if($rows_breturs[7] == '1' && $rows_breturs[6] == '1') { $bg = 'style="background-color:#93C194; color:#000"';}
							if($rows_breturs[7] == '1' && $rows_breturs[6] == '0') { $bg = 'style="background-color:#F31E1E; color:#000"';}
							
							if($rows_breturs[7] == NULL) { $status = 'BELUM';}
							if($rows_breturs[7] == '1' && $rows_breturs[6] == NULL) { $status = 'KIRIM';}
							if($rows_breturs[7] == '1' && $rows_breturs[6] == '1') { $status = 'SETUJU';}
							if($rows_breturs[7] == '1' && $rows_breturs[6] == '0') { $status = 'TOLAK';}
							
							
						?>
                        <tr <? echo $bg ?>>
                            <td align="right"><? echo $no ?></td>
                            <td class="ltext"><? echo $rows_breturs['retnom'] ?></td>
                            <td class="ltext"><? echo $rows_breturs['rgnom'] ?></td>
                            <td><? echo cDate2($rows_breturs['retdate']) ?></td>                            
                            <td class="ltext"><? echo $rows_supplier['name'] ?></td>
                            <td><b><? echo $status ?></b></td>
                            <td>
                            	<div class="cactions two">                                
                                <div class="cview" title="Detail" link="library/submenu/gudang/detail/retur-pembelian?<? echo $rows_breturs[0] ?>&p=<? echo $page ?>"></div>
                                
                                <? if($rows_breturs['isok']=='2' || $rows_breturs['isok']=='') { ?>
                                <div link="modul/gudang/retur-pembelian?<? echo $rows_breturs[0] ?>" title="Hapus" mode="2" type="popup" class="cdelete"></div>
                                <? } else { ?>
                            	<div class="disabled-cdelete"></div>
                            	<? } ?>
                                
                                
                            	</div>
                            </td>
                        </tr>
						<?php
						$no++;
							}
						?>
                        </table>
							
							
						</div>
                        <div class="ctablefooter">
                        
                        	                
                        	<ul class="paginationbox">
                            <li><div class="pagination-button<?php echo $selPrev?>" <?php echo $PevLink?>>Sebelumnya</div></li>
    
                            <?php
                            for ($numPage=0;$numPage<count($pager->PageNumber);$numPage++){
							$selNnum	= ($page==$pager->PageNumber[$numPage] )?"-selected":'';
							$link		= 'link="'.$pager->LinkNumber[$numPage].$get_search.'"';
							echo	'<li><div class="pagination-button'. $selNnum .'" '.$link.'>'.$pager->PageNumber[$numPage].'</div></li>';
                            }
                            ?>
                            <li><div class="pagination-button<?php echo $selNext?>" <?php echo $NextLink?>>Selanjutnya</div></li>
                            </ul>
                        
                        </div>
                      
                    <input name="p" type="hidden" value="<? echo $page ?>" />
                    





