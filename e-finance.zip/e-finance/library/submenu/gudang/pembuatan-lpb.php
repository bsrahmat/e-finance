<?php
/////// konfigurasi
///// query untuk paging

if(file_exists('../../connectionmysql.php')) {
	require_once '../../connectionmysql.php';
	Connected();
	$path = '../../../';
} else $path = '../../';

$perm = array();
$perm = getPermissions('10');

if(file_exists('../../error-menu.php')) if($perm[-1]=='1') { require_once '../../error-menu.php'; die; }
$IDmodul= $_SESSION['galaxy_unit'];
	
if($IDmodul=='none') $IDmodul = '-1';

//BAGIAN INPUTAN PENCARIAN
//Fungsi STRIPSTRING berfungsi hanya karakter a-z, A-Z, dan angka 0-9 yang diperbolehkan.
$get_search = '';
$search = '';
$search_name = 'Pencarian...';

if(isset($_GET['search'])) {
	$_GET['search'] = stripInput($_GET['search']);
	$search_name = $_GET['search'];
	
	if($_GET['search'] || $_GET['search'] != 'Pencarian...' || $_GET['search'] != '') {
		$search = "AND LOWER(trrgoods.rgnom) LIKE '%".strtolower($_GET['search'])."%'
				OR LOWER(trporders.ponom) LIKE '%".strtolower($_GET['search'])."%'";
		$get_search = '&search='.strtolower($_GET['search']);
	}
}
$qry_count = '';
if($_SESSION['galaxy_type']=='0')
 $qry_count = "SELECT trrgoods.id, trrgoods.trporder_id, trrgoods.rgnom, trrgoods.fakturnom, trrgoods.rgdate, trrgoods.description, trrgoods.recipient, trrgoods.postby, trrgoods.postdate, trrgoods.prsign, trrgoods.isposted, trrgoods.prname, trrgoods.unitid, trrgoods.isclosed, trrgoods.warehouse_id, trrgoods.refnom, trrgoods.post, trrgoods.id, trporders.id, trporders.trprequest_id, trporders.podate, trporders.ponom, trporders.posend, trporders.unitid, trporders.isclosed, trporders.poby, trporders.accby, trporders.supplier_id, warehouses.id, warehouses.code, warehouses.name, warehouses.location, warehouses.whhead FROM trrgoods LEFT JOIN trporders ON (trrgoods.trporder_id = trporders.id) LEFT JOIN warehouses ON (trrgoods.warehouse_id = warehouses.id) WHERE trrgoods.unitid != '10' ".$search;
else
 $qry_count = "SELECT trrgoods.id, trrgoods.trporder_id, trrgoods.rgnom, trrgoods.fakturnom, trrgoods.rgdate, trrgoods.description, trrgoods.recipient, trrgoods.postby, trrgoods.postdate, trrgoods.prsign, trrgoods.isposted, trrgoods.prname, trrgoods.unitid, trrgoods.isclosed, trrgoods.warehouse_id, trrgoods.refnom, trrgoods.post, trrgoods.id, trporders.id, trporders.trprequest_id, trporders.podate, trporders.ponom, trporders.posend, trporders.unitid, trporders.isclosed, trporders.poby, trporders.accby, trporders.supplier_id, warehouses.id, warehouses.code, warehouses.name, warehouses.location, warehouses.whhead FROM trrgoods LEFT JOIN trporders ON (trrgoods.trporder_id = trporders.id) LEFT JOIN warehouses ON (trrgoods.warehouse_id = warehouses.id) WHERE trrgoods.unitid != '10' AND trrgoods.unitid = '".$_SESSION['galaxy_unit']."' ".$search;

$rs_count = mysql_query($qry_count);
$count  = mysql_num_rows($rs_count);

// variabel paging
$page  = (isset($_GET['p']))?( (is_numeric($_GET['p']))?( $page = $_GET['p']): $page = 1 ): $page = 1;
$limit = 20;
$start = $limit * ($page - 1);

$pager = new pagination();
$pager->currentPage 	= $page;
$pager->total			= $count;
$pager->limit			= $limit;
$pager->baseLink		= 'library/submenu/gudang/pembuatan-lpb?p=';
$pager->getHalaman(); 
/// output variabel paging
$selPrev = ($page==$pager->PagePrev )?"-selected":'';
$PevLink = 'link="'. $pager->LinkPrev.$get_search.'"';

$selNext	= ($page==$pager->PageNext )?"-selected":'';
$NextLink	= 'link="'. $pager->LinkNext.$get_search.'"';

//query untuk isi
$qry_trrgoods = '';
if($_SESSION['galaxy_type']=='0')
 $qry_trrgoods = "SELECT trrgoods.id, trrgoods.trporder_id, trrgoods.rgnom, trrgoods.fakturnom, trrgoods.rgdate, trrgoods.description, trrgoods.recipient, trrgoods.postby, trrgoods.postdate, trrgoods.prsign, trrgoods.isposted, trrgoods.prname, trrgoods.unitid, trrgoods.isclosed, trrgoods.warehouse_id, trrgoods.refnom, trrgoods.post, trrgoods.id, trporders.id, trporders.trprequest_id, trporders.podate, trporders.ponom, trporders.posend, trporders.unitid, trporders.isclosed, trporders.poby, trporders.accby, trporders.supplier_id, warehouses.id, warehouses.code, warehouses.name, warehouses.location, warehouses.whhead FROM trrgoods LEFT JOIN trporders ON (trrgoods.trporder_id = trporders.id) LEFT JOIN warehouses ON (trrgoods.warehouse_id = warehouses.id) WHERE trrgoods.unitid != '10' ".$search." order by trrgoods.id DESC limit $limit offset $start;";
else
 $qry_trrgoods = "SELECT trrgoods.id, trrgoods.trporder_id, trrgoods.rgnom, trrgoods.fakturnom, trrgoods.rgdate, trrgoods.description, trrgoods.recipient, trrgoods.postby, trrgoods.postdate, trrgoods.prsign, trrgoods.isposted, trrgoods.prname, trrgoods.unitid, trrgoods.isclosed, trrgoods.warehouse_id, trrgoods.refnom, trrgoods.post, trrgoods.id, trporders.id, trporders.trprequest_id, trporders.podate, trporders.ponom, trporders.posend, trporders.unitid, trporders.isclosed, trporders.poby, trporders.accby, trporders.supplier_id, warehouses.id, warehouses.code, warehouses.name, warehouses.location, warehouses.whhead FROM trrgoods LEFT JOIN trporders ON (trrgoods.trporder_id = trporders.id) LEFT JOIN warehouses ON (trrgoods.warehouse_id = warehouses.id) WHERE trrgoods.unitid != '10' AND trrgoods.unitid = '".$_SESSION['galaxy_unit']."' ".$search." order by trrgoods.id DESC limit $limit offset $start;";

$rs_trrgoods = mysql_query($qry_trrgoods);

/////////////// ending konfigurasi
////////////// process

?>

                   <div class="sub-content-title">Laporan Penerimaan Barang (Bag. Gudang)</div>
                    
<div class="cboxtable">
                    	<div class="sub-content-bar">
                        	                            
                            <div class="search-button" link="library/submenu/gudang/pembuatan-lpb"><img src="images/cari.png" /></div>
                            <input class="search-input" type="text" value="<? echo $search_name ?>"  />
                            <div class="search-text">No. PO / No. LPB: </div>

                        </div>
                      	<div class="ctabletitle">Data Purchase Order</div>
						<table class="ctable">
                        <tr class="ctableheader">
                            <td width="6%">No</td>
                            <td width="17%">No LPB</td>
                            <td width="17%">No PO</td>
                            <td width="15%">Gudang</td>
                            <td width="9%">Tanggal</td>
                            <td>Deskription</td>
                            <td width="10%">Status</td>
                            <td align="center" width="1%">Act</td>
                        </tr>
                        <?php
							$no= $start+1;
							$bg = '';
							$status = '';
							while($rows_trrgoods=mysql_fetch_array($rs_trrgoods)) {
								$rows_gudang=mysql_fetch_array(mysql_query("select * from units where id = '".$rows_trrgoods['warehouse_id']."';"));
												
								
								if($rows_trrgoods[13] == NULL) { $bg = 'style="background-color:#FFCC99; color:#000"';}
								if($rows_trrgoods[13] == '1'  && $rows_trrgoods[9] == NULL) { $bg = 'style="background-color:#FDF684; color:#000"';}
								if($rows_trrgoods[9] == '1')  { $bg = 'style="background-color:#93C194; color:#000"';}
								if($rows_trrgoods[9] == '0')  { $bg = 'style="background-color:#F31E1E; color:#000"';}
								
								if($rows_trrgoods[13] == NULL) { $status = 'BELUM';}
								if($rows_trrgoods[13] == '1' && $rows_trrgoods[9] == NULL) { $status = 'SUDAH';}
								
								if($rows_trrgoods[9] == '1') { $status = 'COCOK';}
								if($rows_trrgoods[9] == '0') { $status = 'TIDAK COCOK';}
								
								
								
								
								
								
								
						?>
                        <tr <? echo $bg ?>>
                            <td align="right"><? echo $no ?></td>
                            <td class="ltext"><? echo $rows_trrgoods['rgnom'] ?></td>
                            <td class="ltext"><? echo $rows_trrgoods['ponom'] ?></td>
                            <td class="ltext"><? echo $rows_trrgoods['name'] ?></td>
                            <td><? echo cDate2($rows_trrgoods['rgdate']) ?></td> 
                            <td class="ltext"><? echo $rows_trrgoods['description'] ?></td>
                            <td><b><? echo $status ?></b></td>
                            
                            <td>
                            	<div class="cactions one">
								<div class="cview" title="Detail" link="library/submenu/gudang/detail/pembuatan-lpb?<? echo $rows_trrgoods[0] ?>&p=<? echo $page ?>"></div>
                                
                                
                                
                            	</div>
                            </td>
                        </tr>
						<?php
						$no++;
							}
						?>
                        </table>
							
							
						</div>
                        <div class="ctablefooter">
                        
                        	                
                        	<ul class="paginationbox">
                            <li><div class="pagination-button<?php echo $selPrev?>" <?php echo $PevLink?>>Sebelumnya</div></li>
    
                            <?php
                            for ($numPage=0;$numPage<count($pager->PageNumber);$numPage++){
							$selNnum	= ($page==$pager->PageNumber[$numPage] )?"-selected":'';
							$link		= 'link="'.$pager->LinkNumber[$numPage].$get_search.'"';
							echo	'<li><div class="pagination-button'. $selNnum .'" '.$link.'>'.$pager->PageNumber[$numPage].'</div></li>';
                            }
                            ?>
                            <li><div class="pagination-button<?php echo $selNext?>" <?php echo $NextLink?>>Selanjutnya</div></li>
                            </ul>
                        
                        </div>
                      
                    <input name="p" type="hidden" value="<? echo $page ?>" />
                    





