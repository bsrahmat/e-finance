<script type="text/javascript">
 $(document).ready(function(){
   $(".ctable tr").mouseover(function(){$(this).addClass("over");}).mouseout(function(){$(this).removeClass("over");});
   $(".ctable tr:even").addClass("alt");
 });
 </script>
<?php
if(file_exists('../../../connectionmysql.php')) {
	require_once '../../../connectionmysql.php';
	Connected();
}

$perm = array();
$perm = getPermissions('9');
if(file_exists('../../error-menu.php')) if($perm[-1]=='1') { require_once '../../error-menu.php'; die; }

$page  = (isset($_GET['p']))?( (is_numeric($_GET['p']))?( $page = $_GET['p']): $page = 1 ): $page = 1;

$qry_trprequests = '';

$qry_trprequests = "SELECT trprequests.id, trprequests.unit_id, trprequests.prdate, trprequests.prname, trprequests.prnom, trprequests.gmsign, trprequests.correct_pb, trprequests.id, units.id, units.gmanager_id, units.name, units.code, units.address, units.phone, units.fax, units.headsale_id, units.rek, units.rekname, units.pusat, units.ismanu FROM trprequests LEFT JOIN units ON (trprequests.unit_id = units.id) where trprequests.id = '".$_GET['gid']."';";
$rs_trprequests = mysql_query($qry_trprequests);
$rows_trprequests=mysql_fetch_array($rs_trprequests);
/////////////// ending konfigurasi
////////////// process

?>

                   <div class="sub-content-title">Permintaan Pembelian</div>
                   
				   <div class="cboxtable">  
                   <div style="float: right; width: auto; padding: 2px 0; "><label style="width: 115px; color: black;"><input style="float: left; margin-right: 4px;" type="checkbox" name="show-hide" value="1" checked/>Show/Hide</label></div> 
					<script type="text/javascript">
                            $("input[name='show-hide']").unbind('click').click(function() { 
                                if($(this).attr('checked')==true) {
								$("div[class^='show-body']").slideToggle("normal");
                                $("div[class^='show-body']").show();
                                } else
								$("div[class^='show-body']").slideToggle("normal");
                                $("div[class^='show-body']").hide();
                            }) 
					</script>                
                    	<div class="sub-content-bar">
                          <div class="show-hide">
                          <div class="show-body">
                          <table class="show-table">
                          <tr>
                          <td width="20%" align="right">No. Permintaan</td>
                          <td width="5%" align="center">:</td>
                          <td align="left"><? echo $rows_trprequests['prnom'] ?></td>
                          </tr>
                          <tr>
                          <td width="20%" align="right">Tanggal</td>
                          <td width="5%" align="center">:</td>
                          <td align="left"><? echo cDate2($rows_trprequests['prdate']) ?></td>
                          </tr>
                          <tr>
                          <td width="20%" align="right">Cabang Peminta</td>
                          <td width="5%" align="center">:</td>
                          <td align="left"><? echo $rows_trprequests['name'] ?></td>
                          </tr>
                          <tr>
                          <td width="20%" align="right">Nama Peminta</td>
                          <td width="5%" align="center">:</td>
                          <td align="left"><? echo $rows_trprequests['prname'] ?></td>
                          </tr>
                          
                          </table>
                          </div>
                          <div class="popup-footer">
                            <div link="library/submenu/gudang/pembuatan-pb" class="button-back">Kembali</div>
                            <div target="<? echo md5('cetek-pr') ?>" type="pdf" link="modul/laporan/report?<? echo $rows_trprequests[0] ?>" class="pdf-button" >Cetak PB</div>
                            <? if($rows_trprequests['gmsign']=='') { ?>
                            <div class="input-button" type="popup" mode="1" link="modul/gudang/pembuatan-pb?<? echo $rows_trprequests[0] ?>">Edit PB</div>
                            <? } else { ?>
                            <div class="disabled-input-button">Edit PB</div>
                            <? } ?>
                          </div>
                          </div>
                        </div>
                      	<div class="ctabletitle">Daftar Permintaan Pembelian</div>
						<table class="ctable">
                        <tr class="ctableheader">
                            <td width="6%">No</td>
                            <td>Nama Barang</td>
                            <td width="15%">Satuan</td>
                            <td width="9%">Qty</td>
                            <td width="10%">W.Butuh</td>
                            <td align="center" width="5%">Action</td>
                        </tr>
                        <?php
							$qry_trprdetails = "select * from trprdetails JOIN items ON (trprdetails.item_id = items.id) where trprequest_id = '".$_GET['gid']."';";
							$rs_trprdetails = mysql_query($qry_trprdetails);
							$no= 1;
							while($rows_trprdetails=mysql_fetch_array($rs_trprdetails)) {
								$rows_satuan=mysql_fetch_array(mysql_query("select * from pieces where id = '".$rows_trprdetails['piece_id']."';"));
							
						?>
                        <tr>
                            <td align="right"><? echo $no ?></td>
                            <td class="ltext"><? echo $rows_trprdetails['name'] ?></td>
                            <td><? echo $rows_satuan['name'] ?></td>                            
                            <td align="right"><? echo cFormat($rows_trprdetails['qty'],false) ?></td>
                            <td><? echo cDate2($rows_trprdetails['timereq']) ?></td>
                            <td>
                            	<div class="cactions two">
                                <? if($rows_trprequests['gmsign']=='') { ?>                               
                                <div class="cedit" type="popup" mode="1" title="Edit" link="modul/gudang/detail/pembuatan-pb?<? echo $_GET['gid'] ?>&sub=<? echo $rows_trprdetails[0] ?>"></div>
                                <? } else { ?>
                            	<div class="disabled-cedit"></div>
                            	<? } ?>
                                <? if($rows_trprequests['gmsign']=='') { ?> 
                                <div link="modul/gudang/detail/pembuatan-pb?<? echo $rows_trprdetails[0] ?>" title="Hapus" mode="2" type="popup" class="cdelete"></div>
                                <? } else { ?>
                            	<div class="disabled-cdelete"></div>
                            	<? } ?>
                            	</div>
                            </td>
                        </tr>
						<?php
						$no++;
							}
						?>
                        </table>
						</div>
                        <div class="ctablefooter">
							<? if($rows_trprequests['gmsign']=='2' || $rows_trprequests['gmsign']=='') { ?>               
                        	<div class="input-button" type="popup" mode="0" link="modul/gudang/detail/pembuatan-pb?<? echo $_GET['gid'] ?>">Tambah Baru</div>
                            <? } else { ?>
                            <div class="disabled-input-button">Tambah Baru</div>
                            <? } ?>
                        
                        </div>
                        
                    <input name="p" type="hidden" value="<? echo $page ?>" />