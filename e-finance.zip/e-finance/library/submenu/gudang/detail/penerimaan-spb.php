<script type="text/javascript">
 $(document).ready(function(){
   $(".ctable tr").mouseover(function(){$(this).addClass("over");}).mouseout(function(){$(this).removeClass("over");});
   $(".ctable tr:even").addClass("alt");
 });
 </script>
<?php
if(file_exists('../../../connectionmysql.php')) {
	require_once '../../../connectionmysql.php';
	Connected();
}
$perm = array();
$perm = getPermissions('12');

if(file_exists('../../error-menu.php')) if($perm[-1]=='1') { require_once '../../error-menu.php'; die; }
$page  = (isset($_GET['p']))?( (is_numeric($_GET['p']))?( $page = $_GET['p']): $page = 1 ): $page = 1;
$qry_spbs = '';
$qry_spbs = "select * FROM spbs LEFT JOIN customers ON (spbs.customer_id = customers.id) LEFT JOIN sales ON (spbs.sale_id = sales.id) LEFT JOIN units ON (spbs.unit_id = units.id) where spbs.id = '".$_GET['gid']."';";
$rs_spbs = mysql_query($qry_spbs);
$rows_spbs=mysql_fetch_array($rs_spbs);
?>

                   <div class="sub-content-title">SPB (Kepala Sales)</div>
                   
				   <div class="cboxtable"> 
                   <div style="float: right; width: auto; padding: 2px 0; "><label style="width: 115px; color: black;"><input style="float: left; margin-right: 4px;" type="checkbox" name="show-hide" value="1" checked/>Show/Hide</label></div> 
					<script type="text/javascript">
                            $("input[name='show-hide']").unbind('click').click(function() { 
                                if($(this).attr('checked')==true) {
								$("div[class^='show-body']").slideToggle("normal");
                                $("div[class^='show-body']").show();
                                } else
								$("div[class^='show-body']").slideToggle("normal");
                                $("div[class^='show-body']").hide();
                            }) 
					</script>                  
                    	<div class="sub-content-bar">
                          <div class="show-hide">
                          <div class="show-body">
                          <table class="show-table">
                          <tr>
                          <td width="20%" align="right">No. SPB</td>
                          <td width="5%" align="center">:</td>
                          <td align="left"><? echo $rows_spbs[2] ?></td>
                          </tr>
                          <tr>
                          <td width="20%" align="right">Tanggal</td>
                          <td width="5%" align="center">:</td>
                          <td align="left"><? echo cDate2($rows_spbs[1]) ?></td>
                          </tr>
                          <tr>
                          <td width="20%" align="right">Nama Sales</td>
                          <td width="5%" align="center">:</td>
                          <td align="left"><? echo $rows_spbs[20] ?></td>
                          </tr>
                          <tr>
                          <td width="20%" align="right">Keterangan</td>
                          <td width="5%" align="center">:</td>
                          <td align="left"><? echo $rows_spbs[5] ?></td>
                          </tr>
                          
                          </table>
                          </div>
                          <div class="popup-footer">
                            <div link="library/submenu/gudang/penerimaan-spb" class="button-back">Kembali</div>
                            <div target="<? echo md5('cetek-spb') ?>" type="pdf" link="modul/laporan/report?<? echo $rows_spbs[0] ?>" class="pdf-button" >Cetak SPB</div>
                            
                            	<? if($rows_spbs['istake']=='2' || $rows_spbs['istake']=='') { ?>
                                <div link="modul/gudang/penerimaan-spb?<? echo $rows_spbs[0] ?>" title="Close" mode="0" type="popup" class="hold-button">Close</div>
                                <? } else { ?>
                            	<div class="disabled-hold-button">Close</div>
                            	<? } ?>
                            	</div>
                          </div>
                          </div>
                        </div>
                      	<div class="ctabletitle">Daftar Barang SPB</div>
						<table class="ctable">
                        <tr class="ctableheader">
                            <td width="6%">No</td>
                            <td>Nama Barang</td>
                            <td width="9%">Qty</td>
                            <td width="10%">Satuan</td>
                            <td width="10%">Harga Sat.</td>
                            <td width="10%">Disc</td>
                            <td width="10%">Harga Total</td>
                           
                        </tr>
                        <?php
							$qry_spbdetails = "select * from spbdetails JOIN items ON (spbdetails.item_id = items.id) where spb_id = '".$_GET['gid']."';";
							$rs_spbdetails = mysql_query($qry_spbdetails);
							$no= 1;
							while($rows_spbdetails=mysql_fetch_array($rs_spbdetails)) {
								$rows_satuan=mysql_fetch_array(mysql_query("select * from pieces where id = '".$rows_spbdetails['piece_id']."';"));
							
						?>
                        <tr>
                            <td align="right"><? echo $no ?></td>
                            <td class="ltext"><? echo $rows_spbdetails['name'] ?></td>
                            <td align="right"><? echo cFormat($rows_spbdetails['qty'],false) ?></td>
                            <td><? echo $rows_satuan['name'] ?></td>  
                            <td align="right"><? echo cFormat($rows_spbdetails['price'],false) ?></td>
                            <td align="right"><? echo cFormat($rows_spbdetails['disc'],false) ?></td>
                            <td align="right"><? echo cFormat($rows_spbdetails['qty']*($rows_spbdetails['price']-$rows_spbdetails['disc']),false) ?></td>
                            
                            
                        </tr>
						<?php
						$no++;
							}
						?>
                        </table>
						</div>
                        <div class="ctablefooter">
							
                        
                        </div>   
                    <input name="p" type="hidden" value="<? echo $page ?>" />