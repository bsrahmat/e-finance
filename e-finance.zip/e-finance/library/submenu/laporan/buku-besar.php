<script type="text/javascript">	
$(document).ready(function(){
        $("input[type^='datepicker-range']").datepicker({			
        
        dateFormat:"d/m/yy"
        
        });
        
        });
</script>	
<?php
if(file_exists('../../connectionmysql.php')) {
	require_once '../../connectionmysql.php';
	Connected();
}
?>

<div class="sub-content-title">Buku Besar (Bag. akunting)</div>

<div class="cboxtable"> 
                                  
    <div class="sub-content-bar">
      
      <form action="modul/akunting/laporan/buku-besar.php" method="post">
      <table class="show-table">
      <tr>
      <td width="20%" align="right">Nama Unit</td>
      <td width="1%" align="center">:</td>
      <td align="left">
      	<select name="unit" class="select-text input-small">
        <option value="">Pilih..</option>
		  <? 	  
          $qry_unit = "select * from units where id!=10;";
          $rs_unit = mysql_query($qry_unit);
          while($rows_unit=mysql_fetch_array($rs_unit)) {
          ?>
            <option value="<? echo $rows_unit['id']?>" ><? echo $rows_unit['name']; ?></option>
          <? } ?>
        </select>
      </td>
      </tr>
      <tr>
      <td width="20%" align="right">Perkiraan</td>
      <td width="1%" align="center">:</td>
      <td align="left">
      <select name="perkawal" class="select-text input-small">
      <option value="">Pilih..</option>
                  <? 	  
                  $qry_detail = '';
                  $qry_detail = "select * from ak_detail_perk;";
                  $rs_detail = mysql_query($qry_detail);
//				  $perk=$rows_kasbank['PERK_KASBANK'];
                  while($rows_detail=mysql_fetch_array($rs_detail)) {
                  ?>
                    <option value="<? echo $rows_detail['ID_DETAIL']?>" ><? echo $rows_detail['KODE_DETAIL']; ?> - [<? echo $rows_detail['NAMA_DETAIL']; ?>]</option>
                  <? } ?>
                </select></td>
      </tr>
      <tr>
      <td align="right">Dari tanggal</td>
      <td align="center">:</td>
      <td align="left"><input class="datepicker-text" name="tgl-awal" type="datepicker-range" value="" /></td>
      </tr>
      <tr>
      <td align="right">Sampai tanggal</td>
      <td align="center">:</td>
      <td align="left"><input class="datepicker-text" name="tgl-akhir" type="datepicker-range" value="" /></td>
      </tr>
      </table>
      
      
      
       <div class="popup-footer">
       	<div print="0" style="margin-left: 22px;" class="print-button">Preview</div>
        <div print="3" style="margin-left: 7px;" class="print-button">Excel</div> 
      </div>
      </form>
	<div class="box-paper"></div>
                        
  </div>
</div>
</div>   
<input name="p" type="hidden" value="<? echo $page ?>" />