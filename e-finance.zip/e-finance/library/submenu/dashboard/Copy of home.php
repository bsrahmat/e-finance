<?php
/////// konfigurasi
///// query untuk paging
if(file_exists('../../connectionmysql.php')) {
	require_once '../../connectionmysql.php';
	require_once '../../session.php';
	Connected();
}

$perm = array();
$perm = getPermissions('1');

if(file_exists('../../error-menu.php')) if($perm[-1]=='1') { require_once '../../error-menu.php'; die;}
//BAGIAN INPUTAN PENCARIAN
//Fungsi STRIPSTRING berfungsi hanya karakter a-z, A-Z, dan angka 0-9 yang diperbolehkan.
$get_search = '';
$search = '';
$search_name = 'Pencarian...';


$rs_count = '';
 
$rs_count = mysql_query("select detailkegiatan_tahun from tbl_detailkegiatan group by detailkegiatan_tahun");
$count  = mysql_num_rows($rs_count);

// variabel paging
$page  = (isset($_GET['p']))?( (is_numeric($_GET['p']))?( $page = $_GET['p']): $page = 1 ): $page = 1;
$limit = 1;
$start = $limit * ($page - 1);

$pager = new pagination();
$pager->currentPage 	= $page;
$pager->total			= $count;
$pager->limit			= $limit;
$pager->baseLink		= 'library/submenu/dashboard/home?p=';
$pager->getHalaman(); 
/// output variabel paging
$selPrev = ($page==$pager->PagePrev )?"-selected":'';
$PevLink = 'link="'. $pager->LinkPrev.$get_search.'"';

$selNext	= ($page==$pager->PageNext )?"-selected":'';
$NextLink	= 'link="'. $pager->LinkNext.$get_search.'"';

//query untuk isi
$rs_diagram = '';
$rs_diagram = mysql_query("select detailkegiatan_tahun from tbl_detailkegiatan group by detailkegiatan_tahun order by detailkegiatan_tahun ASC limit $limit offset $start;");

/////////////// ending konfigurasi
////////////// process
?>
 
                   
<div class="sub-content-title"  id="sub-master">Diagram Pertahun</div>
<div class="cboxtable">
	<?php
	$no =$start +1;
	while($rows_diagram=mysql_fetch_array($rs_diagram)) {
		$qry_anggarandpa = "select tbl_modul.modul_kode AS modul_kode,tbl_modul.modul_header AS modul_header, tbl_modul.modul_name AS modul_name, tbl_detailkegiatan.detailkegiatan_tahun from tbl_modul join tbl_kegiatan ON tbl_modul.modul_kode = tbl_kegiatan.modul_kode join tbl_detailkegiatan ON  tbl_kegiatan.kegiatan_kode = tbl_detailkegiatan.kegiatan_kode where tbl_kegiatan.modul_kode != '0'  AND tbl_detailkegiatan.detailkegiatan_tahun = '".$rows_diagram['detailkegiatan_tahun']."' group by tbl_kegiatan.modul_kode  order by tbl_kegiatan.modul_kode ASC;";
		$rs_anggarandpa = mysql_query($qry_anggarandpa);
		$jumlahtahun = mysql_num_rows($rs_anggarandpa);
	?> 
   <script type="text/javascript">
		$(function () {
			var chart;
			$(document).ready(function() {
				chart = new Highcharts.Chart({
					chart: {
						renderTo: 'diagram-simonev'
					},
					title: {
						text: 'Diagram Anggaran Per Skpd Tahun <? echo $rows_diagram['detailkegiatan_tahun'] ?>'
					},
					xAxis: {
						categories: [
							<?
							$rs_anggarandpa = mysql_query($qry_anggarandpa);
							while($rows_namamodul=mysql_fetch_array($rs_anggarandpa)) {	
							?>				
						
							'<? echo $rows_namamodul['modul_name'] ?>',
							
							<?php
							}
							?>]
					},
					yAxis: {
						title: {
							text: 'Jumlah Anggaran'
						}
					},
					tooltip: {
						formatter: function() {
							var s;
							if (this.point.name) { // the pie chart
								s = ''+
									this.point.name +': '+ this.y +' fruits';
							} else {
								s = ''+
									this.x  +': Rp.'+ this.y +',00';
							}
							return s;
						}
					},
					labels: {
						items: [{
							html: 'Total fruit consumption',
							style: {
								left: '40px',
								top: '8px',
								color: 'black'
							}
						}]
					},
					series: [{
						type: 'column',
						name: 'Biaya Menurut DPA',
						data: [<?
							$rs_anggarandpa = mysql_query($qry_anggarandpa);
							while($rows_namamodul=mysql_fetch_array($rs_anggarandpa)) {
								$rows_dpa=mysql_fetch_array(mysql_query("select SUM(detailkegiatan_biayadpa_update) AS sumdetailkegiatan_biayadpa_update, SUM(detailkegiatan_biayadpa) AS sumdetailkegiatan_biayadpa, SUM(detailkegiatan_noreport) AS sumdetailkegiatan_noreport, SUM(detailkegiatan_real_penyerapan) AS sumdetailkegiatan_real_penyerapan from tbl_detailkegiatan JOIN  tbl_kegiatan ON tbl_detailkegiatan.kegiatan_kode = tbl_kegiatan.kegiatan_kode where tbl_kegiatan.modul_kode ='".$rows_namamodul['modul_kode']."' AND tbl_detailkegiatan.detailkegiatan_tahun = '".$rows_diagram['detailkegiatan_tahun']."'"));?>	
						
						
						<? echo $rows_dpa['sumdetailkegiatan_biayadpa_update'] ?>,
						
						
						<?php
							}
						?>]
					}, {
						type: 'column',
						name: 'Realisasi Penyerapan Dana',
						data: [<?
							$rs_anggarandpa = mysql_query($qry_anggarandpa);
							while($rows_namamodul=mysql_fetch_array($rs_anggarandpa)) {
								$rows_dpa=mysql_fetch_array(mysql_query("select SUM(detailkegiatan_real_penyerapan) AS sumdetailkegiatan_real_penyerapan from tbl_detailkegiatan JOIN  tbl_kegiatan ON tbl_detailkegiatan.kegiatan_kode = tbl_kegiatan.kegiatan_kode where tbl_kegiatan.modul_kode ='".$rows_namamodul['modul_kode']."' AND tbl_detailkegiatan.detailkegiatan_tahun = '".$rows_diagram['detailkegiatan_tahun']."'"));?>	
						
						
						<? echo $rows_dpa['sumdetailkegiatan_real_penyerapan'] ?>,
						
						
						<?php
							}
						?>]
					}, {
						type: 'column',
						name: 'Sisa Anggaran',
						data: [<?
							$rs_anggarandpa = mysql_query($qry_anggarandpa);
							while($rows_namamodul=mysql_fetch_array($rs_anggarandpa)) {
								$rows_dpa=mysql_fetch_array(mysql_query("select SUM(detailkegiatan_biayadpa_update) AS sumdetailkegiatan_biayadpa_update, SUM(detailkegiatan_real_penyerapan) AS sumdetailkegiatan_real_penyerapan from tbl_detailkegiatan JOIN  tbl_kegiatan ON tbl_detailkegiatan.kegiatan_kode = tbl_kegiatan.kegiatan_kode where tbl_kegiatan.modul_kode ='".$rows_namamodul['modul_kode']."' AND tbl_detailkegiatan.detailkegiatan_tahun = '".$rows_diagram['detailkegiatan_tahun']."'"));
								$sisadana = $rows_dpa['sumdetailkegiatan_biayadpa_update'] - $rows_dpa['sumdetailkegiatan_real_penyerapan'] ;
								?>
													
						
						<? echo $sisadana ?>,
						
						
						<?php
							}
						?>]
					},  {
                type: 'pie',
                name: 'Anggaran Menurut DPA',
                data: [<?
							$rs_anggarandpa = mysql_query($qry_anggarandpa);
							while($rows_namamodul=mysql_fetch_array($rs_anggarandpa)) {
								$rows_dpa=mysql_fetch_array(mysql_query("select SUM(detailkegiatan_biayadpa_update) AS sumdetailkegiatan_biayadpa_update, SUM(detailkegiatan_biayadpa) AS sumdetailkegiatan_biayadpa, SUM(detailkegiatan_noreport) AS sumdetailkegiatan_noreport, SUM(detailkegiatan_real_penyerapan) AS sumdetailkegiatan_real_penyerapan from tbl_detailkegiatan JOIN  tbl_kegiatan ON tbl_detailkegiatan.kegiatan_kode = tbl_kegiatan.kegiatan_kode where tbl_kegiatan.modul_kode ='".$rows_namamodul['modul_kode']."' AND tbl_detailkegiatan.detailkegiatan_tahun = '".$rows_diagram['detailkegiatan_tahun']."'"));?>	
						
						{
							name: '<? echo $rows_namamodul['modul_name'] ?>',
							y: 13
                		},
						
						
						
						<?php
							}
						?>
				
				
				{
                    name: 'Jane',
                    y: 13,
                }],
                center: [100, 80],
                size: 100,
                showInLegend: false,
                dataLabels: {
                    enabled: false
                }
            }]
				});
			});
			
		});
		</script>
   <div class="box-papers"><div id="diagram-simonev" style="min-width: <? echo 150*$jumlahtahun ?>px; height: 680px; margin: 0 auto"></div></div>
	<script src="js/modules/exporting.js"></script>
                            
	<?php
	$no++;
	}
	?>	
							
						
							
						
                        <div class="ctablefooter">
                        
                        	                
                        	<ul class="paginationbox">
                            <li><div class="pagination-button<?php echo $selPrev?>" <?php echo $PevLink?>>Sebelumnya</div></li>
    
                            <?php
                            for ($numPage=0;$numPage<count($pager->PageNumber);$numPage++){
							$selNnum	= ($page==$pager->PageNumber[$numPage] )?"-selected":'';
							$link		= 'link="'.$pager->LinkNumber[$numPage].$get_search.'"';
							echo	'<li><div class="pagination-button'. $selNnum .'" '.$link.'>'.$pager->PageNumber[$numPage].'</div></li>';
                            }
                            ?>
                            <li><div class="pagination-button<?php echo $selNext?>" <?php echo $NextLink?>>Selanjutnya</div></li>
                            </ul>
                        
                        </div>
                        
                      
                        
                        </div>
                    
                    <input name="p" type="hidden" value="<? echo $page ?>" />

