<script type="text/javascript">
 $(document).ready(function(){
   $(".ctable tr").mouseover(function(){$(this).addClass("over");}).mouseout(function(){$(this).removeClass("over");});
   $(".ctable tr:even").addClass("alt");
 });
 </script>
<?php
/////// konfigurasi
///// query untuk paging

if(file_exists('../../connectionmysql.php')) {
	require_once '../../connectionmysql.php';
	Connected();
	$path = '../../../';
} else $path = '../../';

$perm = array();
$perm = getPermissions('38');

if(file_exists('../../error-menu.php')) if($perm[-1]=='1') { require_once '../../error-menu.php'; die; }
$IDmodul= $_SESSION['galaxy_unit'];
	
if($IDmodul=='none') $IDmodul = '-1';

//BAGIAN INPUTAN PENCARIAN
//Fungsi STRIPSTRING berfungsi hanya karakter a-z, A-Z, dan angka 0-9 yang diperbolehkan.
$get_search = '';
$search = '';
$search_name = 'Pencarian...';

if(isset($_GET['search'])) {
	$_GET['search'] = stripString($_GET['search']);
	$search_name = $_GET['search'];
	
	if($_GET['search'] || $_GET['search'] != 'Pencarian...' || $_GET['search'] != '') {
		$search = "WHERE LOWER(name) LIKE '%".strtolower($_GET['search'])."%'
			OR LOWER(code) LIKE '%".strtolower($_GET['search'])."%'";
		$get_search = '&search='.strtolower($_GET['search']);
	}
}
$rs_count = '';
$rs_count = mysql_query("select * from headsales  ".$search);
$count  = mysql_num_rows($rs_count);

// variabel paging
$page  = (isset($_GET['p']))?( (is_numeric($_GET['p']))?( $page = $_GET['p']): $page = 1 ): $page = 1;
$limit = 20;
$start = $limit * ($page - 1);

$pager = new pagination();
$pager->currentPage 	= $page;
$pager->total			= $count;
$pager->limit			= $limit;
$pager->baseLink		= 'library/submenu/master/kepala-sales?p=';
$pager->getHalaman(); 
/// output variabel paging
$selPrev = ($page==$pager->PagePrev )?"-selected":'';
$PevLink = 'link="'. $pager->LinkPrev.$get_search.'"';

$selNext	= ($page==$pager->PageNext )?"-selected":'';
$NextLink	= 'link="'. $pager->LinkNext.$get_search.'"';

//query untuk isi
$rs_headsales = '';
$rs_headsales = mysql_query("select * from headsales ".$search." order by id ASC limit $limit offset $start;");

/////////////// ending konfigurasi
////////////// process

?>

                   <div class="sub-content-title">Kepala Sales</div>
                    
<div class="cboxtable">
                    	<div class="sub-content-bar">
                        	<? if($perm[0]!='1') { ?>
                        	<div class="input-button" type="popup" mode="0" link="modul/master/kepala-sales">Tambah Baru</div>
                            <? } else { ?>
                            <div class="disabled-input-button">Tambah Baru</div>
                            <? } ?>
                            
                            <div class="search-button" link="library/submenu/master/kepala-sales"><img src="images/cari.png" /></div>
                            <input class="search-input" type="text" value="<? echo $search_name ?>"  />

                        </div>
                      	<div class="ctabletitle">Data Kepala Sales</div>
						<table class="ctable">
                        <tr class="ctableheader">
                            <td width="3%">No</td>
                            <td width="15%">Tanda Tangan</td>
                            <td>Nama</td>
                            <td align="center" width="5%">Action</td>
                        </tr>
                        <?php
							$no= $start+1;
							while($rows_headsales=mysql_fetch_array($rs_headsales)) {
								if($rows_headsales['large']) {
									if(file_exists($path.'photo/large-acc/'.$rows_headsales['large'])) {
										list($width, $height) = getimagesize($path.'photo/large-acc/'.$rows_headsales['large']);
										$photo_small = 'photo/large-acc/'.$rows_headsales['large'];
									} else
										$photo_small = 'photo/large-acc/kosong.png';
								} else
									$photo_small = 'photo/large-acc/kosong.png';
							
						?>
                        <tr>
                            <td align="right"><? echo $no ?></td>
                            <td><img class="img" src="<? echo $photo_small; ?>" /></td>
                            <td class="ltext"><? echo $rows_headsales['name'] ?></td>
                            <td>
                            	<div class="cactions two">
                                
								<? if($perm[1]!='1') { ?>
                                <div class="cedit" type="popup" mode="1" title="Edit" link="modul/master/kepala-sales?<? echo $rows_headsales['id'] ?>"></div>
                                <? } else { ?>
                            	<div class="disabled-cedit"></div>
                            	<? } ?>
                                <? if($perm[2]!='1') { ?>
                                <div link="modul/master/kepala-sales?<? echo $rows_headsales['id'] ?>" title="Hapus" mode="2" type="popup" class="cdelete"></div>
                                <? } else { ?>
                            	<div class="disabled-cdelete"></div>
                            	<? } ?>
                            	</div>
                            </td>
                        </tr>
						<?php
						$no++;
							}
						?>
                        </table>
							
							
						</div>
                        <div class="ctablefooter">
                        
                        	                
                        	<ul class="paginationbox">
                            <li><div class="pagination-button<?php echo $selPrev?>" <?php echo $PevLink?>>Sebelumnya</div></li>
    
                            <?php
                            for ($numPage=0;$numPage<count($pager->PageNumber);$numPage++){
							$selNnum	= ($page==$pager->PageNumber[$numPage] )?"-selected":'';
							$link		= 'link="'.$pager->LinkNumber[$numPage].$get_search.'"';
							echo	'<li><div class="pagination-button'. $selNnum .'" '.$link.'>'.$pager->PageNumber[$numPage].'</div></li>';
                            }
                            ?>
                            <li><div class="pagination-button<?php echo $selNext?>" <?php echo $NextLink?>>Selanjutnya</div></li>
                            </ul>
                        
                        </div>
                      
                    <input name="p" type="hidden" value="<? echo $page ?>" />
                    





