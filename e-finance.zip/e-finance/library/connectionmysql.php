<?php
error_reporting(0);
require_once 'paging.php';
//date_default_timezone_set('Asia/Jakarta'); // PHP 6 mengharuskan penyebutan timezone.
define('URL_DIRECT','index.php');



// fungsi untuk koneksi ke database;
function connecting($servername,$dbname,$dbuser,$dbpassword)
{
	global $link;
	$link=mysql_connect ("$servername","$dbuser","$dbpassword");
	if(!$link) die("Cannot Open Database!.");
	mysql_select_db("$dbname",$link) or die ("Tidak Bisa Membuka Database!. Silahkan Hubunggi Administrator.".mysql_error());
}
function Connected()
{
	session_start();
	
//	$servername='localhost';    // Your MySql Server Name or IP address here
//	$dbusername='puslit_root';         // Login user here
//	$dbpassword='bismillah123';             // Login password here
//	$dbname='puslit_demoakunting';		// nama database...

	$servername='localhost';    // Your MySql Server Name or IP address here
	$dbusername='ristekom_root';         // Login user here
	$dbpassword='bismillah123';             // Login password here
	$dbname='ristekom_demoakunting';		// nama database...

	global $link;
	connecting($servername,$dbname,$dbusername,$dbpassword);

	
	
}
function get_tag($tag,$xml)
{
	preg_match_all('/<'.$tag.'>(.*)<\/'.$tag.'>$/imU',$xml,$match);
	return $match[1];
}

function is_bot()
{
	
	$botlist = array("Teoma", "alexa", "froogle", "Gigabot", "inktomi",
	"looksmart", "URL_Spider_SQL", "Firefly", "NationalDirectory",
	"Ask Jeeves", "TECNOSEEK", "InfoSeek", "WebFindBot", "girafabot",
	"crawler", "www.galaxy.com", "Googlebot", "Scooter", "Slurp",
	"msnbot", "appie", "FAST", "WebBug", "Spade", "ZyBorg", "rabaz",
	"Baiduspider", "Feedfetcher-Google", "TechnoratiSnoop", "Rankivabot",
	"Mediapartners-Google", "Sogou web spider", "WebAlta Crawler","TweetmemeBot",
	"Butterfly","Twitturls","Me.dium","Twiceler");

	foreach($botlist as $bot)
	{
		if(strpos($_SERVER['HTTP_USER_AGENT'],$bot)!==false)
		return true;	// Is a bot
	}

	return false;	// Not a bot
}

function getLog($aktifitas, $detail, $ststus) {	
	$browser = $_SERVER['HTTP_USER_AGENT'];
	$url = $_SERVER['REQUEST_URI'];
	$ip = $_SERVER['REMOTE_ADDR'];
	$refurl = $_SERVER['HTTP_REFERER'];

	if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
		$proxy = 'Proxy IP : '.$_SERVER['HTTP_X_FORWARDED_FOR'];
	}else {
		$proxy = 'tidak ada proxy terdeteksi';
	}
	$datetime = date('Y-m-d H:i:s');	
	mysql_query("INSERT INTO tbl_logsystem (logsystem_date, logsystem_ip, logsystem_browser, logsystem_url, logsystem_proxy, logsystem_via, admin_kode, admin_name, logsystem_aktifitas, logsystem_detail,logsystem_ststus) VALUES ('".$datetime."', '".$ip."', '".$browser."', '".$refurl." | ".$url."', '".$proxy."', '', '".$_SESSION['galaxy_kode']."', '".$_SESSION['galaxy_full']."', '".$aktifitas."', '".$detail."','".$ststus."')");
	
}

function setID($seq,$type="mysql") {
	if($type=='mysql')
		return 'NULL';
	else
		return "nextval('".$seq."'::regclass)";
}

function getUserName($code) {
	$rs_user = mysql_query("select * from tbl_admin where admin_kode = '".$code."'");
	$cnt_user = mysql_num_rows($rs_user);
	$rows_user = mysql_fetch_array($rs_user);
	if($cnt_user>0)
		return $rows_user['admin_full_name'];
	else
		return 'Unknown';
}

//fungsi untuk ngecek tambah data baru sama dgn if($_GET['mod']=='0') echo 'blah.. blah..';
function isAdd() {
	if($_GET['mod']=='0') return true;	
}

//fungsi untuk ngecek edit sama dgn if($_GET['mod']=='1') echo 'blah.. blah..';
function isEdit() {
	if($_GET['mod']=='1') return true;	
}

//fungsi untuk konfirmasi hapus sama dgn if($_GET['mod']=='2') echo 'blah.. blah..';
function isConfirmDelete() {
	if($_GET['mod']=='2') return true;	
}

//fungsi untuk hapus sama dgn if($_GET['mod']=='3') echo 'blah.. blah..';
function isDelete() {
	if($_GET['mod']=='3') return true;	
}

//fungsi untuk konfirmasi hapus yg dipilih sama dgn if($_GET['mod']=='4') echo 'blah.. blah..';
function isConfirmDeleteSelected() {
	if($_GET['mod']=='4') return true;	
}

//fungsi untuk hapus yg dipilih sama dgn if($_GET['mod']=='5') echo 'blah.. blah..';
function isDeleteSelected() {
	if($_GET['mod']=='5') return true;	
}

//fungsi untuk menyimpan sama dgn if($_GET['mod']=='6') echo 'blah.. blah..';
function isSave() {
	if($_GET['mod']=='6') return true;	
}

function isApply() {
	if($_GET['mod']=='7') return true;	
}

function isCencel() {
	if($_GET['mod']=='8') return true;	
}
function isSave2() {
	if($_GET['mod']=='9') return true;	
}
function KasMasuk() {
	if($_GET['mod']=='10') return true;	
}

function KasKeluar() {
	if($_GET['mod']=='11') return true;	
}

function BankMasuk() {
	if($_GET['mod']=='12') return true;	
}

function BankKeluar() {
	if($_GET['mod']=='13') return true;	
}

function Balance() {
	if($_GET['mod']=='14') return true;	
}

function stripInput($val) {
	$val = preg_replace("/[^a-zA-Z0-9,.()-\/@ \s]/", "", $val);
	return $val;
}


function stripString($val) {
	$val = preg_replace("/[^a-zA-Z0-9,. \s]/", "", $val);
	return $val;
}

function stripUser($val) {
	$val = preg_replace("/[^a-zA-Z0-9@\s]/", "", $val);
	return $val;
}

function stripPass($val) {
	$val = preg_replace("/[^a-zA-Z0-9\s]/", "", $val);
	return $val;
}

//fungsi untuk ngecek nilai jika nilai kosong set nilai ke NULL jika field ditabel kamu mendukung NULL, kalo ga mendukung, ga usah dipake
// $type default = 'STR' / STRING
function isNull($value,$type='STR') {
	switch($type) {
		//untuk nilai STRING / CHARACTER
		case 'STR':
			if($value) {
				return "'".stripInput($value)."'";
			} else
				return "NULL";
			break;
		//untuk nilai STRING / CHARACTER
		case 'ESTR':
			if($value) {
				return "'".stripInput($value)."'";
			} else
				return "''";
			break;
		//untuk nilai INTEGER / FLOAT
		case 'INT':
			if($value) {
				$value = str_replace(',','',$value);
				if(is_numeric($value)) 
					return $value;
				else
					return "NULL";
			} else
				return "NULL";
			break;
		//untuk nilai CURRENCY / UANG
		case 'CUR':
			if($value) {
				$value = str_replace(',','',$value);
				if(is_numeric($value)) 
					return "'".$value."'";
				else
					return "NULL";
			} else
				return "NULL";
			break;
		//untuk nilai TANGGAL
		case 'DATE':
			if($value) {
				$tmp = explode('/',$value);
				if(strlen($tmp[0])<=1) $tmp[0] = '0'.$tmp[0];
				if(strlen($tmp[1])<=1) $tmp[1] = '0'.$tmp[1];
				$value = $tmp[2].'-'.$tmp[1].'-'.$tmp[0];
				if (preg_match("/^(\d{4})-(\d{2})-(\d{2})$/", $value, $matches)) {
					if (checkdate($matches[2], $matches[3], $matches[1]))
						return "'".$value."'";
					else
						return "NULL";
				} else
					return "NULL";
			} else
				return "NULL";
			break;
		//untuk default
		default: 
			return "NULL";
			break;
	}
}

function cFormat($val,$cond=true) {
	if($cond) {
		$val = str_replace(',','',$val);
		return $val;
	} else {
		$val = number_format($val);
		if($val==0) $val ='0';
		return $val;	
	}
}


function cPercent($val,$cond=true) {
	if($cond) {
		$val = str_replace(',','',$val);
		return $val;
	} else {
		$val = number_format($val,2);
		if($val!=0) $val =$val.'%';
		else $val = '0.00%';
		
		return $val;	
	}
}

function cFormatmin($val,$cond=true) {
	if($cond) {
		$val = str_replace(',','',$val);
		if($val>0) {
			$val = str_replace('-','',$val);
			$val ='('.$val.')';
		}
		return $val;
	} else {
		$val = number_format($val);
		if($val>0) {
			$val = str_replace('-','',$val);
			$val ='('.$val.')';
		}
		return $val;	
	}
}

function cCommon($val) {
	$val = explode('.',$val);
	return $val[1];
	
}

function cSays($angka) {
    // pastikan kita hanya berususan dengan tipe data numeric
    $angka = (float)$angka;
     
    // array bilangan 
    // sepuluh dan sebelas merupakan special karena awalan 'se'
    $bilangan = array(
            '',
            'satu',
            'dua',
            'tiga',
            'empat',
            'lima',
            'enam',
            'tujuh',
            'delapan',
            'sembilan',
            'sepuluh',
            'sebelas'
    );
     
    // pencocokan dimulai dari satuan angka terkecil
    if ($angka < 12) {
        // mapping angka ke index array $bilangan
        return $bilangan[$angka];
    } else if ($angka < 20) {
        // bilangan 'belasan'
        // misal 18 maka 18 - 10 = 8
        return $bilangan[$angka - 10] . ' belas';
    } else if ($angka < 100) {
        // bilangan 'puluhan'
        // misal 27 maka 27 / 10 = 2.7 (integer => 2) 'dua'
        // untuk mendapatkan sisa bagi gunakan modulus
        // 27 mod 10 = 7 'tujuh'
        $hasil_bagi = (int)($angka / 10);
        $hasil_mod = $angka % 10;
        return trim(sprintf('%s puluh %s', $bilangan[$hasil_bagi], $bilangan[$hasil_mod]));
    } else if ($angka < 200) {
        // bilangan 'seratusan' (itulah indonesia knp tidak satu ratus saja? :))
        // misal 151 maka 151 = 100 = 51 (hasil berupa 'puluhan')
        // daripada menulis ulang rutin kode puluhan maka gunakan
        // saja fungsi rekursif dengan memanggil fungsi cSays(51)
        return sprintf('seratus %s', cSays($angka - 100));
    } else if ($angka < 1000) {
        // bilangan 'ratusan'
        // misal 467 maka 467 / 100 = 4,67 (integer => 4) 'empat'
        // sisanya 467 mod 100 = 67 (berupa puluhan jadi gunakan rekursif cSays(67))
        $hasil_bagi = (int)($angka / 100);
        $hasil_mod = $angka % 100;
        return trim(sprintf('%s ratus %s', $bilangan[$hasil_bagi], cSays($hasil_mod)));
    } else if ($angka < 2000) {
        // bilangan 'seribuan'
        // misal 1250 maka 1250 - 1000 = 250 (ratusan)
        // gunakan rekursif cSays(250)
        return trim(sprintf('seribu %s', cSays($angka - 1000)));
    } else if ($angka < 1000000) {
        // bilangan 'ribuan' (sampai ratusan ribu
        $hasil_bagi = (int)($angka / 1000); // karena hasilnya bisa ratusan jadi langsung digunakan rekursif
        $hasil_mod = $angka % 1000;
        return sprintf('%s ribu %s', cSays($hasil_bagi), cSays($hasil_mod));
    } else if ($angka < 1000000000) {
        // bilangan 'jutaan' (sampai ratusan juta)
        // 'satu puluh' => SALAH
        // 'satu ratus' => SALAH
        // 'satu juta' => BENAR 
        // @#$%^ WT*
         
        // hasil bagi bisa satuan, belasan, ratusan jadi langsung kita gunakan rekursif
        $hasil_bagi = (int)($angka / 1000000);
        $hasil_mod = $angka % 1000000;
        return trim(sprintf('%s juta %s', cSays($hasil_bagi), cSays($hasil_mod)));
    } else if ($angka < 1000000000000) {
        // bilangan 'milyaran'
        $hasil_bagi = (int)($angka / 1000000000);
        // karena batas maksimum integer untuk 32bit sistem adalah 2147483647
        // maka kita gunakan fmod agar dapat menghandle angka yang lebih besar
        $hasil_mod = fmod($angka, 1000000000);
        return trim(sprintf('%s milyar %s', cSays($hasil_bagi), cSays($hasil_mod)));
    } else if ($angka < 1000000000000000) {
        // bilangan 'triliun'
        $hasil_bagi = $angka / 1000000000000;
        $hasil_mod = fmod($angka, 1000000000000);
        return trim(sprintf('%s triliun %s', cSays($hasil_bagi), cSays($hasil_mod)));
    } else {
        return 'Wow...';
    }
}
function cDate($val) {
	if($val) {
		$tmpval = explode('-',$val);
		$val = $tmpval[2].'/'.$tmpval[1].'/'.$tmpval[0];
	}
	return $val;
}
function cDate2($val) {
	if($val) {
		$tmpval = explode('-',$val);
		$val = $tmpval[2].'-'.$tmpval[1].'-'.$tmpval[0];
	}
	return $val;
}
function cDateR($val) {
	if($val) {
		$tmpval = explode('/',$val);
		$val = $tmpval[2].'-'.$tmpval[1].'-'.$tmpval[0];
	}
	return $val;
}
function cTextDate($val) {
	$day = array('','Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember');
	if($val) {
		$tmpval = explode('-',$val);
		$val = $tmpval[2].' '.$day[intval($tmpval[1])].' '.$tmpval[0];
	}
	return $val;
}

function gabungKontrakTanggal($kontrak, $tgl1, $tgl2) {
	$val = '';
	
	if($tgl1 && !$tgl2) $val = cDate($tgl1);
	if(!$tgl1 && $tgl2) $val = cDate($tgl2);
	if($tgl1 && $tgl2) $val = cDate($tgl1).' - '.cDate($tgl2);
	
	if($kontrak) $val = $kontrak.'<br />'.$val;
	
	return $val;
}

function generateArray($val) {
	$tmpVal = explode('^_^',$val);	
	if(count($tmpVal)>0)
		return $tmpVal;	
	else
		return $val;
}

function generateArray2($val) {
	$tmpVal = explode('^_^',$val);	
	if(count($tmpVal)>0)
		return $tmpVal;	
	else
		return $val;
}


function generateError($error) {
	$combine_error = '';
	for($i=0;$i<count($error);$i++) {
		$combine_error .= $error[$i].'|*|';	
	}
	$combine_error = substr($combine_error,0,strlen($combine_error)-3);
	return $combine_error;
}

function getValueByTable($query,$result) {
	$rs = mysql_query($query);
	$cnt = mysql_num_rows($rs);
	$rows = mysql_fetch_array($rs);
	if($cnt>0) 
		return $rows[$result];
	else
		return '';
}

function getPermissions($subID) {
	$acc = array();
	$rs_perm = mysql_query("select * from tbl_permissions where submenu_kode = '".$subID."' and admin_kode = '".$_SESSION['galaxy_kode']."'");
	$cnt_perm = mysql_num_rows($rs_perm);
	$rows_perm = mysql_fetch_array($rs_perm);
	if($cnt_perm>0)  {
		$acc[-1] = $rows_perm['permissions_view'];
		$acc[0] = $rows_perm['permissions_add'];
		$acc[1] = $rows_perm['permissions_edit'];
		$acc[2] = $rows_perm['permissions_delete'];
		$acc[3] = $rows_perm['permissions_grant'];
		$acc[4] = $rows_perm['permissions_detail'];
		return $acc;
	} else {
		if(isset($_SESSION['galaxy_unit'])) {
			if($_SESSION['galaxy_unit']=='none') {
				$acc[-1] = '1';
				$acc[0] = '1';
				$acc[1] = '1';
				$acc[2] = '1';
				$acc[3] = '1';
				$acc[4] = '1';
				return $acc;
			} else {
				$acc[-1] = '';
				$acc[0] = '';
				$acc[1] = '';
				$acc[2] = '';
				$acc[3] = '';
				$acc[4] = '';
				return $acc;
			}
		} else {
			$acc[-1] = '1';
			$acc[0] = '1';
			$acc[1] = '1';
			$acc[2] = '1';
			$acc[3] = '1';
			$acc[4] = '1';
			return $acc;
		}
	}
}
function encode($string, $key)
{
	$key = sha1($key);
	$strLen = strlen($string);
	$keyLen = strlen($key);
	$j = 0;
	$hash = '';
	
	for ($i = 0; $i < $strLen; ++$i)
	{
		$ordStr = ord(substr($string,$i,1));
		if ($j == $keyLen)
		{
			$j = 0;
		}
		$ordKey = ord(substr($key, $j, 1));
		$j++;
		$hash .= strrev(base_convert(dechex($ordStr+$ordKey), 16, 36));
	}
	
	return $hash;
}

/**
 * Simple string decoding - offer limited security to protect sensitive data from being viewed
 * @var string $string the string to decode
 * @var string $key the encoding key
 * @return string the decoded string
 */
function decode($string, $key)
{
	$key = sha1($key);
	$strLen = strlen($string);
	$keyLen = strlen($key);
	$j = 0;
	$hash = '';
	
	for ($i = 0; $i < $strLen; $i += 2)
	{
		$ordStr = hexdec(base_convert(strrev(substr($string, $i, 2)), 36, 16));
		if ($j == $keyLen)
		{
			$j = 0;
		}
		$ordKey = ord(substr($key, $j, 1));
		$j++;
		$hash .= chr($ordStr-$ordKey);
	}
	
	return $hash;
}

/**
 * Builds the context vars list for log and/or report
 * @var array $vars an array of vars to output
 * @var int $level the level in the context vars (prevent infinite recursion)
 * @return string the output to display
 */
function buildSimpleVarList($vars, $level = 0)
{
	$output = '';
	$indent = str_repeat('	', $level*2);
	$prefix = ($level == 0) ? '$' : '\'';
	$suffix = ($level == 0) ? '' : '\'';
	
	foreach ($vars as $key => $value)
	{
		if ($level == 0)
		{
			$key = $prefix.$key;
		}
		elseif (!is_numeric($key))
		{
			$key = $prefix.$key.$suffix;
		}
		
		if (is_array($value))
		{
			$length = count($value);
			
			$output .= '<li>'."\n".$indent;
			$output .= '	<b>'.$key.':</b> array('.$length.')'."\n".$indent;
			$output .= '	<ul>'."\n".$indent;
			
			if ($level > 5)
			{
				// Prevent infinite recursion
				$output .= '		<li><em>(too much levels)</em></li>'."\n".$indent;
			}
			elseif ($length > 0)
			{
				$output .= '		'.buildSimpleVarList($value, $level+1)."\n".$indent;
			}
			else
			{
				$output .= '	<li><em>(empty)</em></li>'."\n".$indent;
			}
			
			$output .= '	</ul>'."\n".$indent;
			$output .= '</li>'."\n".$indent;
		}
		else
		{
			$output .= '<li><b>'.$key.':</b> '.describeVar($value).'</li>'."\n".$indent;
		}
	}
	
	return rtrim($output);
}

/**
 * Builds the context vars list for display
 * @var array $vars an array of vars to output
 * @var int $level the level in the context vars (prevent infinite recursion)
 * @return string the output to display
 */
function buildVarList($vars, $level = 0)
{
	$output = '';
	$indent = str_repeat('	', 6+($level*2));
	$prefix = ($level == 0) ? '$' : '\'';
	$suffix = ($level == 0) ? '' : '\'';
	
	foreach ($vars as $key => $value)
	{
		if ($level == 0)
		{
			$key = $prefix.$key;
		}
		elseif (!is_numeric($key))
		{
			$key = $prefix.$key.$suffix;
		}
		
		if (is_array($value))
		{
			$length = count($value);
			
			$output .= '<li class="close">'."\n".$indent;
			$output .= '	<b class="toggle"></b>'."\n".$indent;
			$output .= '	<span><b>'.$key.':</b> array('.$length.')</span>'."\n".$indent;
			$output .= '	<ul>'."\n".$indent;
			
			if ($level > 5)
			{
				// Prevent infinite recursion
				$output .= '		<li><span><em>(too much levels)</em></span></li>'."\n".$indent;
			}
			elseif ($length > 0)
			{
				$output .= '		'.buildVarList($value, $level+1)."\n".$indent;
			}
			else
			{
				$output .= '	<li><span><em>(empty)</em></span></li>'."\n".$indent;
			}
			
			$output .= '	</ul>'."\n".$indent;
			$output .= '</li>'."\n".$indent;
		}
		else
		{
			$output .= '<li><span><b>'.$key.':</b> '.describeVar($value).'</span></li>'."\n".$indent;
		}
	}
	
	return rtrim($output);
}

/**
 * Return a description string of the var
 * @var mixed $var the var
 * @return string the description
 */
function describeVar($var)
{
	if (is_array($var))
	{
		return 'array('.count($var).')';
	}
	elseif (is_object($var))
	{
		$id = method_exists($var, 'getId') ? $var->getId() : (property_exists($var, 'id') ? $var->id : '');
		return get_class($var).'('.$id.')';
	}
	elseif (is_bool($var))
	{
		return ($var ? 'true' : 'false');
	}
	elseif (is_string($var))
	{
		return '\''.$var.'\'';
	}
	else
	{
		return $var;
	}
}

/**
 * Trim file path to hide document root
 * @var string $file the file path
 * @var int $maxLength the max number of chars, or 0 for no limit (optional)
 * @return string the path without the document root
 */
function trimDocumentRoot($file, $maxLength = 0)
{
	// Windows systems
	$file = str_replace('\\', '/', $file);
	
	if (isset($_SERVER['DOCUMENT_ROOT']))
	{
		if (strpos($file, $_SERVER['DOCUMENT_ROOT']) === 0)
		{
			$file = substr($file, strlen($_SERVER['DOCUMENT_ROOT']));
		}
	}
	
	if ($maxLength > 0)
	{
		$file = shortenFilePath($file, $maxLength);
	}
	
	return $file;
}

/**
 * Shorten file name to requested size
 * @param string $file the file path
 * @var int $maxLength the max number of chars
 * @return string the shortened path
 */
function shortenFilePath($file, $maxLength)
{
	if (strlen($file) > $maxLength)
	{
		$slashPos = strpos($file, '/', strlen($file)-$maxLength);
		if ($slashPos !== false)
		{
			$file = '...'.substr($file, $slashPos);
		}
		else
		{
			$file = '...'.substr($file, strlen($file)-$maxLength);
		}
	}
	
	return $file;
}

/**
 * Fallback if json_encode is not defined
 * Original code from multiple contributors on json_encode's manual page :
 * @url http://fr.php.net/manual/en/function.json-encode.php
 */
if (!function_exists('json_encode'))
{
	function json_encode($a)
	{
		// Generic types
		if (is_null($a))
		{
			return 'null';
		}
		if ($a === false)
		{
			return 'false';
		}
		if ($a === true)
		{
			return 'true';
		}
		
		if (is_scalar($a))
		{
			if (is_float($a))
			{
				// Always use "." for floats.
				return floatval(str_replace(",", ".", strval($a)));
			}
			
			if (is_string($a))
			{
				static $jsonReplaces = array(array("\\", "/", "\n", "\t", "\r", "\b", "\f", '"'), array('\\\\', '\\/', '\\n', '\\t', '\\r', '\\b', '\\f', '\"'));
				return '"'.str_replace($jsonReplaces[0], $jsonReplaces[1], $a).'"';
			}
			else
			{
				return $a;
			}
		}
		
		$isList = true;
		for ($i = 0, reset($a); $i < count($a); $i++, next($a))
		{
			if (key($a) !== $i)
			{
				$isList = false;
				break;
			}
		}
		
		$result = array();
		if ($isList)
		{
			foreach ($a as $v)
			{
				$result[] = json_encode($v);
			}
			return '['.join(',', $result).']';
		}
		else
		{
			foreach ($a as $k => $v)
			{
				$result[] = json_encode($k).':'.json_encode($v);
			}
			return '{'.join(',', $result).'}';
		}
	}
}

function indonesian_date ($timestamp = '', $date_format = 'l, j F Y ') {
	if (trim ($timestamp) == '')
	{
			$timestamp = time ();
	}
	elseif (!ctype_digit ($timestamp))
	{
		$timestamp = strtotime ($timestamp);
	}
	# remove S (st,nd,rd,th) there are no such things in indonesia :p
	$date_format = preg_replace ("/S/", "", $date_format);
	$pattern = array (
		'/Mon[^day]/','/Tue[^sday]/','/Wed[^nesday]/','/Thu[^rsday]/',
		'/Fri[^day]/','/Sat[^urday]/','/Sun[^day]/','/Monday/','/Tuesday/',
		'/Wednesday/','/Thursday/','/Friday/','/Saturday/','/Sunday/',
		'/Jan[^uary]/','/Feb[^ruary]/','/Mar[^ch]/','/Apr[^il]/','/May/',
		'/Jun[^e]/','/Jul[^y]/','/Aug[^ust]/','/Sep[^tember]/','/Oct[^ober]/',
		'/Nov[^ember]/','/Dec[^ember]/','/January/','/February/','/March/',
		'/April/','/June/','/July/','/August/','/September/','/October/',
		'/November/','/December/',
	);
	$replace = array ( 'Sen','Sel','Rab','Kam','Jum','Sab','Min',
		'Senin','Selasa','Rabu','Kamis','Jumat','Sabtu','Minggu',
		'Jan','Feb','Mar','Apr','Mei','Jun','Jul','Ags','Sep','Okt','Nov','Des',
		'Januari','Februari','Maret','April','Juni','Juli','Agustus','Sepember',
		'Oktober','November','Desember',
	);
	$date = date ($date_format, $timestamp);
	$date = preg_replace ($pattern, $replace, $date);
	$date = "{$date}";
	return $date;
} 

function UnitID()
	{
		$new_id='';
		$qry="SELECT CONCAT(MAX(id)+1) AS new_id FROM units";
		$sqlqry=mysql_query($qry);
		$result=mysql_fetch_array($sqlqry);
		$new_id = $result['new_id'];
		
		return $new_id;
	}
function Kode($initial,$tabel)
	{
		$qry = mysql_query("SELECT max(".$initial.") FROM ".$tabel);
		$row = mysql_fetch_array($qry);
		if($row[0]=='') {
			$angka=1;
		}
		else{
			$angka = $row[0]+1;
		}
	return $angka;
	}
function Romawi($n)
	{
		$hasil = "";
		$iromawi = array("","I","II","III","IV","V","VI","VII","VIII","IX","X",20=>"XX",30=>"XXX",40=>"XL",50=>"L",60=>"LX",70=>"LXX",80=>"LXXX",90=>"XC",100=>"C",200=>"CC",300=>"CCC",400=>"CD",500=>"D",600=>"DC",700=>"DCC",800=>"DCCC",900=>"CM",1000=>"M",2000=>"MM",3000=>"MMM");
		if(array_key_exists($n,$iromawi)){
			$hasil = $iromawi[$n];
		}elseif($n >= 11 && $n <= 99){
			$i = $n % 10;
			$hasil = $iromawi[$n-$i] . Romawi($n % 10);
		}elseif($n >= 101 && $n <= 999){
			$i = $n % 100;
			$hasil = $iromawi[$n-$i] . Romawi($n % 100);
		}else{
			$i = $n % 1000;
			$hasil = $iromawi[$n-$i] . Romawi($n % 1000);
		}
return $hasil;
}
	
function IDTrans($table,$field,$kode,$unit,$code)
	{
		//
		$rs_table=mysql_query("SELECT ".$field." FROM ".$table." where unit_id = '".$unit."' AND ".$field." != '' Order By id desc limit 1");
		$rows_table=mysql_fetch_row($rs_table);
		$count = mysql_num_rows($rs_table);
		$data = $rows_table[0];
		if($count>0){
			$pecah = explode('/',$rows_table[0]);
			if($pecah[3]!=date('Y')){
				$ID = sprintf("%06s", 1);
			}else{
				$id_new = (int) substr($data, 0, 6);
				$id_new++;
				$ID = sprintf("%06s", $id_new);
			}
		}else{
			$ID = sprintf("%06s", 1);	
		}
		$new_id = $ID.'/'.$code.'/'.Romawi(date('m')).'/'.date('Y').'/'.$kode;
		
		return $new_id;
	}
function IDwend($table,$field,$kode,$unit,$code)
	{
		//
		$rs_table=mysql_query("SELECT ".$field." FROM ".$table." where unitid = '".$unit."' AND ".$field." != '' Order By id desc limit 1");
		$rows_table=mysql_fetch_row($rs_table);
		$count = mysql_num_rows($rs_table);
		$data = $rows_table[0];
		if($count>0){
			$pecah = explode('/',$rows_table[0]);
			if($pecah[3]!=date('Y')){
				$ID = sprintf("%06s", 1);
			}else{
				$id_new = (int) substr($data, 0, 6);
				$id_new++;
				$ID = sprintf("%06s", $id_new);
			}
		}else{
			$ID = sprintf("%06s", 1);	
		}
		$new_id = $ID.'/'.$code.'/'.Romawi(date('m')).'/'.date('Y').'/'.$kode;
		
		return $new_id;
	}
		
function IDTransPO($code,$unitid)
	{
		//
		$rs_table=mysql_query("SELECT ponom FROM trporders where unitid = '".$unitid."'  AND ponom != '' Order By id desc limit 1");
		$rows_table=mysql_fetch_row($rs_table);
		$count = mysql_num_rows($rs_table);
		$data = $rows_table[0];
		if($count>0){
			$pecah = explode('/',$rows_table[0]);
			if($pecah[3]!=date('Y')){
				$ID = sprintf("%06s", 1);
			}else{
				$id_new = (int) substr($data, 0, 6);
				$id_new++;
				$ID = sprintf("%06s", $id_new);
			}
		}else{
			$ID = sprintf("%06s", 1);	
		}
		$new_id = $ID.'/'.$code.'/'.Romawi(date('m')).'/'.date('Y').'/PO';
		
		return $new_id;
	}
	
function IDTransLPB($code)
	{
		//
		$rs_table=mysql_query("SELECT rgnom FROM trrgoods where unitid = '".$_SESSION['galaxy_unit']."'  AND rgnom != '' Order By id desc limit 1");
		$rows_table=mysql_fetch_row($rs_table);
		$count = mysql_num_rows($rs_table);
		$data = $rows_table[0];
		if($count>0){
			$pecah = explode('/',$rows_table[0]);
			if($pecah[3]!=date('Y')){
				$ID = sprintf("%06s", 1);
			}else{
				$id_new = (int) substr($data, 0, 6);
				$id_new++;
				$ID = sprintf("%06s", $id_new);
			}
		}else{
			$ID = sprintf("%06s", 1);	
		}
		$new_id = $ID.'/'.$code.'/'.Romawi(date('m')).'/'.date('Y').'/LP';
		
		return $new_id;
	}
function IDTransSPB($code)
	{
		//
		$rs_table=mysql_query("SELECT spbnom FROM spbs where unit_id = '".$_SESSION['galaxy_unit']."'  AND spbnom != '' Order By id desc limit 1");
		$rows_table=mysql_fetch_row($rs_table);
		$count = mysql_num_rows($rs_table);
		$data = $rows_table[0];
		if($count>0){
			$pecah = explode('/',$rows_table[0]);
			if($pecah[3]!=date('Y')){
				$ID = sprintf("%06s", 1);
			}else{
				$id_new = (int) substr($data, 0, 6);
				$id_new++;
				$ID = sprintf("%06s", $id_new);
			}
		}else{
			$ID = sprintf("%06s", 1);	
		}
		$new_id = $ID.'/'.$code.'/'.Romawi(date('m')).'/'.date('Y').'/SPB';
		
		return $new_id;
	}	
function IDTransSJ($code)
	{
		//
		$rs_table=mysql_query("SELECT sjnom FROM sjs where unitid = '".$_SESSION['galaxy_unit']."'  AND sjnom != '' Order By id desc limit 1");
		$rows_table=mysql_fetch_row($rs_table);
		$count = mysql_num_rows($rs_table);
		$data = $rows_table[0];
		if($count>0){
			$pecah = explode('/',$rows_table[0]);
			if($pecah[3]!=date('Y')){
				$ID = sprintf("%06s", 1);
			}else{
				$id_new = (int) substr($data, 0, 6);
				$id_new++;
				$ID = sprintf("%06s", $id_new);
			}
		}else{
			$ID = sprintf("%06s", 1);	
		}
		$new_id = $ID.'/'.$code.'/'.Romawi(date('m')).'/'.date('Y').'/SJ';
		
		return $new_id;
	}

function IDTransFak($code, $unitid)
	{
		//
		$rs_table=mysql_query("SELECT faknom FROM fakturs where unitid = '".$unitid."'  AND faknom != '' Order By id desc limit 1");
		$rows_table=mysql_fetch_row($rs_table);
		$count = mysql_num_rows($rs_table);
		$data = $rows_table[0];
		if($count>0){
			$pecah = explode('/',$rows_table[0]);
			if($pecah[3]!=date('Y')){
				$ID = sprintf("%06s", 1);
			}else{
				$id_new = (int) substr($data, 0, 6);
				$id_new++;
				$ID = sprintf("%06s", $id_new);
			}
		}else{
			$ID = sprintf("%06s", 1);	
		}
		$new_id = $ID.'/'.$code.'/'.Romawi(date('m')).'/'.date('Y').'/FK';
		
		return $new_id;
	}
function IDTransRet($code)
	{
		//
		$rs_table=mysql_query("SELECT retnom FROM breturs where unitid = '".$_SESSION['galaxy_unit']."'  AND retnom != '' Order By id desc limit 1");
		$rows_table=mysql_fetch_row($rs_table);
		$count = mysql_num_rows($rs_table);
		$data = $rows_table[0];
		if($count>0){
			$pecah = explode('/',$rows_table[0]);
			if($pecah[3]!=date('Y')){
				$ID = sprintf("%06s", 1);
			}else{
				$id_new = (int) substr($data, 0, 6);
				$id_new++;
				$ID = sprintf("%06s", $id_new);
			}
		}else{
			$ID = sprintf("%06s", 1);	
		}
		$new_id = $ID.'/'.$code.'/'.Romawi(date('m')).'/'.date('Y').'/RB';
		
		return $new_id;
	}
function IDTransRet2($code)
	{
		$rs_table=mysql_query("SELECT retnom FROM sreturs where unitid = '".$_SESSION['galaxy_unit']."'  AND retnom != '' Order By id desc limit 1");
		$rows_table=mysql_fetch_row($rs_table);
		$count = mysql_num_rows($rs_table);
		$data = $rows_table[0];
		if($count>0){
			$pecah = explode('/',$rows_table[0]);
			if($pecah[3]!=date('Y')){
				$ID = sprintf("%06s", 1);
			}else{
				$id_new = (int) substr($data, 0, 6);
				$id_new++;
				$ID = sprintf("%06s", $id_new);
			}
		}else{
			$ID = sprintf("%06s", 1);	
		}
		$new_id = $ID.'/'.$code.'/'.Romawi(date('m')).'/'.date('Y').'/RJ';
		
		return $new_id;
	}
function UserID()
	{
		$new_id=rand(0,99999);
		$qry="SELECT * FROM tbl_admin where admin_kode='" . $new_id . "'";
		$sqlqry=mysql_query($qry);
		$result=mysql_fetch_array($sqlqry);
		while(!empty($result))
		{
			$new_id=rand(0,99999);
			$qry="SELECT * FROM tbl_admin where admin_kode='" . $new_id . "'";
			$sqlqry=mysql_query($qry);
			$result=mysql_fetch_array($sqlqry);
		}
		return $new_id;
	}

function nMdSb()
	{
		$name='';
		$qry="SELECT * FROM configurations where jabatan ='1'";
		$sqlqry=mysql_query($qry);
		$result=mysql_fetch_array($sqlqry);
		$name= $result['value'];
		return $name;
	}
function nFinance()
	{
		$name='';
		$qry="SELECT * FROM configurations where jabatan ='2'";
		$sqlqry=mysql_query($qry);
		$result=mysql_fetch_array($sqlqry);
		$name= $result['value'];
		return $name;
	}
function nPurchasing()
	{
		$name='';
		$qry="SELECT * FROM configurations where jabatan ='3'";
		$sqlqry=mysql_query($qry);
		$result=mysql_fetch_array($sqlqry);
		$name= $result['value'];
		return $name;
	}
function nKeuangan()
	{
		$name='';
		$qry="SELECT * FROM configurations where jabatan ='4'";
		$sqlqry=mysql_query($qry);
		$result=mysql_fetch_array($sqlqry);
		$name= $result['value'];
		return $name;
	}
function nAkunting()
	{
		$name='';
		$qry="SELECT * FROM configurations where jabatan ='5'";
		$sqlqry=mysql_query($qry);
		$result=mysql_fetch_array($sqlqry);
		$name= $result['value'];
		return $name;
	}
function nFam()
	{
		$name='';
		$qry="SELECT * FROM configurations where jabatan ='6'";
		$sqlqry=mysql_query($qry);
		$result=mysql_fetch_array($sqlqry);
		$name= $result['value'];
		return $name;
	}
	
	
	
function accTTD($kode)
	{
		$photo_small='';
		$qry="SELECT * FROM configurations where jabatan ='".$kode."'";
		$sqlqry=mysql_query($qry);
		$result=mysql_fetch_array($sqlqry);
		if($result['large']) {
		if(file_exists('./../../photo/large-acc/'.$result['large'])) {
		$photo_small = '<img style="height:60px;" src="./../../photo/large-acc/'.$result['large'].'">';
		} else
			$photo_small = '';
		} else
		$photo_small = '';
		
		
		return $photo_small;
	}
function accFinance()
	{
		$name='';
		$qry="SELECT * FROM configurations where jabatan ='2'";
		$sqlqry=mysql_query($qry);
		$result=mysql_fetch_array($sqlqry);
		$name= $result['value'];
		return $name;
	}
function accPurchasing()
	{
		$name='';
		$qry="SELECT * FROM configurations where jabatan ='3'";
		$sqlqry=mysql_query($qry);
		$result=mysql_fetch_array($sqlqry);
		$name= $result['value'];
		return $name;
	}
function accKeuangan()
	{
		$name='';
		$qry="SELECT * FROM configurations where jabatan ='4'";
		$sqlqry=mysql_query($qry);
		$result=mysql_fetch_array($sqlqry);
		$name= $result['value'];
		return $name;
	}
function accAkunting()
	{
		$name='';
		$qry="SELECT * FROM configurations where jabatan ='5'";
		$sqlqry=mysql_query($qry);
		$result=mysql_fetch_array($sqlqry);
		$name= $result['value'];
		return $name;
	}
function accFam()
	{
		$name='';
		$qry="SELECT * FROM configurations where jabatan ='6'";
		$sqlqry=mysql_query($qry);
		$result=mysql_fetch_array($sqlqry);
		$name= $result['value'];
		return $name;
	}

function KodeKasBank()
	{
		$qry = mysql_query("SELECT max(ID) FROM ak_kasbanks");
		$row = mysql_fetch_array($qry);
		if($row[0]=='') {
			$angka=1;
		}
		else{
			$angka = $row[0]+1;
		}
	return $angka;
	}
function KodeKasBank2()
	{
		$qry = mysql_query("SELECT max(ID) FROM ak_kasbanks");
		$row = mysql_fetch_array($qry);
		if($row[0]=='') {
			$angka=1;
		}
		else{
			$angka = $row[0]+2;
		}
	return $angka;
	}
function KodeAkUtang()
	{
		$qry = mysql_query("SELECT max(id) FROM ak_htg_awal");
		$row = mysql_fetch_array($qry);
		if($row[0]=='') {
			$angka=1;
		}
		else{
			$angka = $row[0]+1;
		}
	return $angka;
	}
function KodeAkPiutang()
	{
		$qry = mysql_query("SELECT max(id) FROM ak_piut_awal");
		$row = mysql_fetch_array($qry);
		if($row[0]=='') {
			$angka=1;
		}
		else{
			$angka = $row[0]+1;
		}
	return $angka;
	}
?>
