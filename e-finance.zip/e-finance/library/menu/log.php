<?php
	require_once '../connectionmysql.php';
	require_once '../session.php';
	Connected();
	
	$modulID = $_SESSION['simonev_module'];
	
	if($modulID=='none') $modulID = '-1';
?>

        <div class="content">
        	<div class="sub-nav-box">
				<ul class="sub-nav-button">
                <?php 
				if($_SESSION['simonev_type']=='0')
					$qry_submenus = "select * from tbl_submenu where menu_kode = '7' order by submenu_kode";
				else 
					$qry_submenus = "select * from tbl_submenu where menu_kode = '7' order by submenu_kode";
				
				$i = 0; $link='';
				$rs_submenu = mysql_query($qry_submenus);
				while($rows_submenu=mysql_fetch_array($rs_submenu)) {
					
				$qry_subaccess = "select * from tbl_permissions where admin_kode = '".$_SESSION['simonev_kode']."' and submenu_kode = '".$rows_submenu['submenu_kode']."'";
					
				$rs_sub_access = mysql_query($qry_subaccess);
				$rows_sub_access=mysql_fetch_array($rs_sub_access);	
				
				if($rows_sub_access['permissions_view']!='1') {
				if($i==0) { $link = $rows_submenu['menusub_link']; $selected = '-selected'; } else $selected = '';
				?>
                <li class="<? echo $rows_submenu['submenu_icon'] ?>" title="<? echo $rows_submenu['submenu_name'] ?>"><div class="tab<?php echo $selected ?>" link="<? echo $rows_submenu['menusub_link'] ?>"><? echo $rows_submenu['submenu_name'] ?></div></li>
               <?php
				$i++;
				}
				}
				?>
				</ul>
            </div>
            
            <div class="body">
				<div class="sub-content">
                    <?php
					if($link) { 
					$link = str_replace('library/','',$link);
						require_once('../'.$link.'.php');
					} else {
						require_once '../error-menu.php';	
					}
					?>
                    
                </div>
            </div>
        </div>