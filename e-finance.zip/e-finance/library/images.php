<?php

  	define ("MAXSIZE",1048576);
	define ("UPLOADDIR","/");
	 
	function upload_image($file_name)
	{
		$filesize=$_FILES['upload_foto']['size'];
		if($filesize <= MAXSIZE)
		{
			$filetype=file_extension($_FILES['upload_foto']['name']);
			if ($filetype=='jpeg' || $filetype=='jpg' || $filetype=='gif' || $filetype=='png')
			{
				move_uploaded_file($_FILES['upload_foto']['tmp_name'],$file_name.'.'.$filetype);
				return true;
			}
		}
	}
	function file_extension($filename)
	{
		$extension = substr( $filename, ( strrpos($filename, '.') + 1 ) ) ;
		$extension = strtolower( $extension ) ;
			
		return $extension;
	}
	function ResizeImage($image_source,$image_destination,$new_width,$new_height)
	{
		$image_source=strtolower($image_source);
		
		$width=$new_width;
		$height=$new_height;
		
		$filetype=file_extension($image_source);
		if ($filetype=='jpeg' || $filetype=='jpg') {
			$source = @imagecreatefromjpeg($image_source); 
		} elseif ($filetype=='gif') {
			$source = @imagecreatefromgif($image_source); 
		} elseif ($filetype=='png') {
			$source = @imagecreatefrompng($image_source); 
		}
		
		$new_img=imagecreatetruecolor($width, $height); 
		ImageCopyResampled($new_img, $source, 0, 0, 0, 0, $width, $height,imagesx($source), imagesy($source));
		imagedestroy($source);
		if ($filetype=='jpeg' || $filetype=='jpg') {
			$quality=90;
			imagejpeg($new_img,$image_destination,$quality);
		} elseif ($filetype=='gif') {
			imagegif($new_img,$image_destination); 
		} elseif ($filetype=='png') {
			imagepng($new_img,$image_destination);
		}
	
		return $image_destination;
	}
	
	function CropImage($image_source,$image_destination, $pos_x, $pos_y)
	{
		$image_source=strtolower($image_source);
		
		$filetype=file_extension($image_source);
		if ($filetype=='jpeg' || $filetype=='jpg') {
			$source = @imagecreatefromjpeg($image_source); 
		} elseif ($filetype=='gif') {
			$source = @imagecreatefromgif($image_source); 
		} elseif ($filetype=='png') {
			$source = @imagecreatefrompng($image_source); 
		}
		$width = 90;
		$height = 110;
		$new_img=imagecreatetruecolor($width, $height); 
		ImageCopyResampled($new_img, $source, 0, 0, $pos_x, $pos_y, $width, $height, $width, $height);
		imagedestroy($source);
		if ($filetype=='jpeg' || $filetype=='jpg') {
			$quality=90;
			imagejpeg($new_img,$image_destination,$quality);
		} elseif ($filetype=='gif') {
			imagegif($new_img,$image_destination); 
		} elseif ($filetype=='png') {
			imagepng($new_img,$image_destination);
		}
	
		 return $image_destination;
	}

?>