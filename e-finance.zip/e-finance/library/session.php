 <?
$inactive = 1000;
if(isset($_SESSION['timeout'])) {
	$session_life = time() - $_SESSION['timeout'];
	if($session_life > $inactive) {
		
		mysql_query("UPDATE tbl_admin SET admin_status = '1', admin_waktu = ".time()." WHERE admin_kode=".$_SESSION['simonev_kode']);
		
		session_start();	
		$_SESSION['simonev_kode'] = '';
		$_SESSION['simonev_full'] = 'none';
		$_SESSION['simonev_posisi'] = 'none';
		$_SESSION['simonev_type'] = 'none';
		$_SESSION['simonev_module'] = 'none';		
		
		header("Location: ".URL_DIRECT);
		}
}
$_SESSION['timeout'] = time();
?>