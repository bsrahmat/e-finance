<?php
	require_once '../../library/connectionmysql.php';
	Connected();
	
	$perm = array();
	$perm = getPermissions('30');
	

	if($perm[-1]=='1') { require_once '../../library/error-popup.php'; die; }
	if(isAdd()) { 
		if($perm[0]=='1') { require_once '../../library/error-popup.php'; die; }
	}if(isEdit()) { 
		if($perm[1]=='1') { require_once '../../library/error-popup.php'; die; }
	}if(isConfirmDelete() || isConfirmDeleteSelected()) { 
		if($perm[2]=='1') { require_once '../../library/error-popup.php'; die; }
	}
		
	if(isEdit())  {
		
		$rs_stockitems = mysql_query("SELECT * FROM stockitems LEFT JOIN warehouses ON (stockitems.warehouse_id = warehouses.id) LEFT JOIN items ON (stockitems.item_id = items.id) LEFT JOIN transtypes ON (stockitems.transtype_id = transtypes.id) where stockitems.id = '".$_GET['gid']."'");
		$rows_stockitems=mysql_fetch_array($rs_stockitems);
	}
//<!-- =========================================================================================================================== -->
?>

<?
//<!-- FORM TIPE MODE 0 = TAMBAH/ADD, TIPE MODE 1 = UBAH/EDIT -->
 if(isAdd() || isEdit()) {
	
?>

   <div class="popup-shadow" style="width: 600px;">
      <div class="popup-header">
         <span><? if(isAdd()) echo 'Tambah Data'; else echo 'Edit Data'; ?></span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <form action="modul/data/stok-awal-barang.php" method="post">
      <table>
      <tr>
      <td width="25%">Gudang</td>
      <td width="5%" align="center">:</td>
      <td><select name="warehouse_id" class="select-text select-small">
      	<option value="">Pilih..</option>
      <? 	  
	 
	  $qry_warehouse1 = "select * from warehouses LEFT JOIN units_warehouses  ON (units_warehouses.warehouse_id =warehouses.id) WHERE units_warehouses.unit_id = '".$_SESSION['galaxy_unit']."' order by warehouses.id;";	  
	  $rs_warehouse1 = mysql_query($qry_warehouse1);
	  while($rows_warehouse1=mysql_fetch_array($rs_warehouse1)) {
	  ?>
        <option value="<? echo $rows_warehouse1[0]?>" <? if(isEdit()) if($rows_warehouse1[0]==$rows_stockitems['warehouse_id']) echo 'selected'; ?>><? echo $rows_warehouse1['name']; ?></option>
      <? } ?>
      </select></td>
      </tr>
      
      <tr>
      <td>Nama Barang</td>
      <td align="center">:</td>
      <td><input class="input-text" name="nama_barang" type="text" value="<? if(isEdit()) echo $rows_stockitems[24] ?>" /></td>
      </tr>
      
      <tr>
      <td>Tanggal Input</td>
      <td align="center">:</td>
      <td><input class="input-text input-small" name="datestock" type="datepicker" value="<? if(isEdit()) echo cDate($rows_stockitems['stockdate']) ?>" /></td>
      </tr>
      <tr>
      <td>Harga Barang</td>
      <td align="center">:</td>
      <td><input class="input-text currency padmin" name="price" type="text" value="<? if(isEdit()) echo cFormat($rows_stockitems[14],false) ?>" /></td>
      </tr>
      <tr>
      <td>Stok Sekarang</td>
      <td align="center">:</td>
      <td><input class="input-text currency padmin" name="stock" type="text" value="<? if(isEdit()) echo cFormat($rows_stockitems['stock'], true) ?>" readonly="readonly"/></td>
      </tr>
      <tr>
      <td>Qty</td>
      <td align="center">:</td>
      <td><input class="input-text currency padmin" name="qty" type="text" value="<? if(isEdit()) echo cFormat($rows_stockitems[6], false) ?>"  onkeyup="Sumary(this.form)"/></td>
      </tr>
           
      </table>
      <? if(isEdit())  {?>
      <input type="hidden" name="gid" value="<? echo $_GET['gid'] ?>" />
      <input type="hidden" name="bupdate" value="<? echo $rows_stockitems[6] ?>" />
      <input type="hidden" name="items" value="<? echo $rows_stockitems['item_id'] ?>" />
      <input type="hidden" name="kode" value="<? echo strtoupper($rows_stockitems['code']) ?>" />
      
      <? }?>
      <input type="hidden" name="item_id" value="<? if(isEdit()) { echo $rows_stockitems['item_id']; }?>" />
      <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
      </form>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel">Batal</div>
      	<div mode="6" link="library/submenu/data/stok-awal-barang" class="popup-button" get="">Simpan</div>
      </div>
   </div>

<? }  
//<!-- END FORM -->

//<!-- =========================================================================================================================== -->
?>

<? 
//<!-- FORM TIPE MODE 2 = CONFIRM DELETE/KONFIRMASI HAPUS, TIPE MODE 4 = CONFIRM DELETE SELECTED/KONFIRMASI HAPUS YANG DIPILIH -->
if(isConfirmDelete() || isConfirmDeleteSelected()) { ?>
<?
	if(isConfirmDelete()) {
		$rs_stockitems = mysql_query("SELECT * FROM stockitems LEFT JOIN warehouses ON (stockitems.warehouse_id = warehouses.id) LEFT JOIN items ON (stockitems.item_id = items.id) LEFT JOIN transtypes ON (stockitems.transtype_id = transtypes.id) where stockitems.id = '".$_GET['gid']."'");
		$rows_stockitems=mysql_fetch_array($rs_stockitems);
	}
?>
   <div class="popup-shadow" style="width: 500px;">
      <div class="popup-header">
         <span>Konfirmasi Hapus</span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <table>
      <tr>
      <td class="center">
      <? if(isConfirmDelete()) {?>
      		<strong>Peringatan</strong>: <br /> 
      		Data <b>Barang</b> akan ikut terhapus, jika ada data yang terhubung!.
      		<br /><br />
      		Apakah anda yakin menghapus <br /><b style="text-decoration: underline;"><? echo $rows_stockitems[24] ?></b>?
      <? }?>
      
      <? if(isConfirmDeleteSelected()) {?>
      		<? if($_GET['gid']!='') { 
				$value = array();
				$value = generateArray($_GET['gid']); 
			?>
            	<strong>Peringatan: </strong><br /> Data <b>Barang</b> akan ikut terhapus, jika ada data yang terhubung!.
      		<br /><br />
                Sebanyak <b style="text-decoration: underline;"><? echo count($value) ?> item</b> yang akan dihapus!.<br />
                Apakah anda yakin untuk menghapusnya?
            <? } else { ?>
            	Tidak ada item yang akan dihapus.<br />Silahkan anda memilih check box untuk dicentang.
            <? } ?>
      <? }?>
      </td>
      </tr>
      </table>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel"><? if($_GET['gid']!='') echo 'Batal'; else echo 'Tutup' ?></div>
        <? if(isConfirmDelete()) { ?>
      		<div mode="3" link="modul/data/stok-awal-barang?<? echo $_GET['gid'] ?>" class="popup-button">Hapus</div>
        <? }?>
      	<? if(isConfirmDeleteSelected()) {
			if($_GET['gid']!='') {
				if(count($value)>0)
		?>
      		<div mode="5" link="modul/data/stok-awal-barang?<? echo htmlspecialchars($_GET['gid']) ?>" class="popup-button">Hapus</div>
        <? } } ?>
      </div>
      
   </div>

<? } 

?>

<?
 if(isDelete()) {
	
	
		$rs_stockitems = mysql_query("SELECT * FROM stockitems  where id = '".$_GET['gid']."'");
		$rows_stockitems=mysql_fetch_array($rs_stockitems);
		
		mysql_query("DELETE from stockitems where id =".$_GET['gid']);
		
		mysql_query("UPDATE items SET stock = stock-'".$rows_stockitems['qty']."' WHERE id ='".$rows_stockitems['item_id']."';");
	
 } ?>
 
<?
//<!-- END TIPE MODE 3 -->

//<!-- =========================================================================================================================== -->

//<!-- TIPE MODE 5 = DELETE SELECTED/HAPUS YANG DIPILIH -->
?>

<? if(isDeleteSelected()) { 
	
	$value = array();
	$value = generateArray($_GET['gid']); 

	// Taruh query ke database untuk menghapus disini...
	// Contoh :
	for($i=0;$i<count($value);$i++) {
	 	mysql_query("DELETE from items where id = '".$value[$i]."'");
	}
	
 } 
//<!-- END TIPE MODE 5 -->

//<!-- =========================================================================================================================== -->
?>

<?
//<!-- TIPE MODE 6 = SAVE/MENYIMPAN -->
 if(isSave()) { 

$error = array();
if(!$_POST['qty']) $error[] = 'qty:Silahkan Masukkan qty barang.';
if(!$_POST['item_id']) $error[] = 'nama_barang:Silahkan Masukkan Kode Barang.';
if(!$_POST['warehouse_id']) $error[] = 'warehouse_id:Silahkan Pilih Satuan.';


if(count($error)>0) {
	echo generateError($error);
	
} else {
	
	if($_POST['mod']=='0') {
		$_POST['qty'] = str_replace(',','',$_POST['qty']);
		$_POST['price'] = str_replace(',','',$_POST['price']);
		$tot = $_POST['qty'] * $_POST['price'];
		
		mysql_query("INSERT INTO stockitems (stockdate, warehouse_id, item_id, transtype_id, qty, tot, unit_id, price) VALUES (".isNull($_POST['datestock'],'DATE').", '".$_POST['warehouse_id']."', '".$_POST['item_id']."', '1', ".isNull($_POST['qty'],'CUR').", '".$tot."', '".$_SESSION['galaxy_unit']."',".isNull($_POST['price'],'CUR').")");
		
		mysql_query("UPDATE items SET stock = stock+".isNull($_POST['qty'],'CUR')." WHERE id ='".$_POST['item_id']."';");
		
		
	}
	
	if($_POST['mod']=='1') {
		$_POST['qty'] = str_replace(',','',$_POST['qty']);
		$_POST['price'] = str_replace(',','',$_POST['price']);
		$tot = $_POST['qty'] * $_POST['price'];
			
		mysql_query("UPDATE stockitems SET stockdate = ".isNull($_POST['datestock'],'DATE').", warehouse_id = '".$_POST['warehouse_id']."',  item_id = '".$_POST['item_id']."', qty = '".$_POST['qty']."', tot = '".$tot."', price = '".$_POST['price']."' WHERE id ='".$_POST['gid']."';");
		mysql_query("UPDATE items SET stock = stock-".isNull($_POST['bupdate'],'CUR')." WHERE id ='".$_POST['items']."';");
		
		mysql_query("UPDATE items SET stock = stock+".isNull($_POST['qty'],'CUR')." WHERE id ='".$_POST['item_id']."';");
	}
	
	
		
}

} 
//<!-- END TIPE MODE 6 --> 
?>

