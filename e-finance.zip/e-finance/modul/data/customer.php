<?php
	require_once '../../library/connectionmysql.php';
	Connected();
	
	$perm = array();
	$perm = getPermissions('32');
	

	if($perm[-1]=='1') { require_once '../../library/error-popup.php'; die; }
	if(isAdd()) { 
		if($perm[0]=='1') { require_once '../../library/error-popup.php'; die; }
	}if(isEdit()) { 
		if($perm[1]=='1') { require_once '../../library/error-popup.php'; die; }
	}if(isConfirmDelete() || isConfirmDeleteSelected()) { 
		if($perm[2]=='1') { require_once '../../library/error-popup.php'; die; }
	}
		
	if(isEdit())  {
		
		$rs_customers = mysql_query("select * from customers where id = '".$_GET['gid']."'");
		$rows_customers=mysql_fetch_array($rs_customers);
		$kode = explode('/',$rows_customers['code']);
		$kode = $kode[0];
	}
//<!-- =========================================================================================================================== -->
?>

<?
//<!-- FORM TIPE MODE 0 = TAMBAH/ADD, TIPE MODE 1 = UBAH/EDIT -->
 if(isAdd() || isEdit()) {
	$rs_units = mysql_query("select * from units where id = '".$_SESSION['galaxy_unit']."'");
	$rows_units=mysql_fetch_array($rs_units);
	
?>
 
   <div class="popup-shadow" style="width: 600px;">
      <div class="popup-header">
         <span><? if(isAdd()) echo 'Tambah Data'; else echo 'Edit Data'; ?></span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <form action="modul/data/customer.php" method="post">
      <table>
      <tr>
      <td width="25%">Nama Perusahaan</td>
      <td width="5%" align="center">:</td>
      <td><input class="input-text" name="name" type="text" value="<? if(isEdit()) echo $rows_customers['name'] ?>" /></td>
      </tr>
      <tr>
      <td>Nama Kontak</td>
      <td align="center">:</td>
      <td><input class="input-text" name="upname" type="text" value="<? if(isEdit()) echo $rows_customers['upname'] ?>" /></td>
      </tr>
      <tr>
      <td>Code</td>
      <td align="center">:</td>
      <td>
      <? if(isEdit()) { 
			$kode = explode('-',$rows_customers['code']);
			$rows_customers['code0'] = $kode[0];
			$rows_customers['code1'] = $kode[1];
	  ?>
      
      
      <? } ?>
      
      <span><? if(isEdit()) { echo $rows_customers['code0']; } if(isAdd()) { if($_SESSION['galaxy_type'] == '0') {echo 'SBC';} else{ echo $rows_units['code']; } } ?>-</span><input class="input-text input-vsmall" name="code" type="text" value="<? if(isEdit()) echo $rows_customers['code1'] ?>" /></td>
      </tr>
      <tr>
      <td>Alamat</td>
      <td align="center">:</td>
      <td><textarea rows="2" class="input-text" name="address" type="text"><? if(isEdit()) echo $rows_customers['address'] ?></textarea></td>
      </tr>
      <tr>
      <td>City</td>
      <td align="center">:</td>
      <td><input class="input-text input-small" name="city" type="text" value="<? if(isEdit()) echo $rows_customers['city'] ?>" /></td>
      </tr>
      <tr>
      <td>Phone</td>
      <td align="center">:</td>
      <td><input class="input-text phone padmin" name="phone" type="text" value="<? if(isEdit()) echo $rows_customers['phone'] ?>" /></td>
      </tr>
      <tr>
      <td>Fax</td>
      <td align="center">:</td>
      <td><input class="input-text phone padmin" name="fax" type="text" value="<? if(isEdit()) echo $rows_customers['fax'] ?>" /></td>
      </tr>
      </table>
      <? if(isEdit())  {?>
      <input type="hidden" name="gid" value="<? echo $_GET['gid'] ?>" />
      <input type="hidden" name="kode" value="<? echo strtoupper($rows_customers['code']) ?>" />
      
      <? }?>
      <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
      <input type="hidden" name="unit_id" value="<? echo $rows_units['id'] ?>" />
      <input type="hidden" name="kodene" value="<? if(isEdit()) { echo $rows_customers['code0']; } if(isAdd()) { if($_SESSION['galaxy_type'] == '0') {echo 'SBC';} else{ echo $rows_units['code']; } } ?>" />
      </form>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel">Batal</div>
      	<div mode="6" link="library/submenu/data/customer" class="popup-button" get="">Simpan</div>
      </div>
   </div>

<? }  
//<!-- END FORM -->

//<!-- =========================================================================================================================== -->
?>

<? 
//<!-- FORM TIPE MODE 2 = CONFIRM DELETE/KONFIRMASI HAPUS, TIPE MODE 4 = CONFIRM DELETE SELECTED/KONFIRMASI HAPUS YANG DIPILIH -->
if(isConfirmDelete() || isConfirmDeleteSelected()) { ?>
<?
	if(isConfirmDelete()) {
		$rs_customers = mysql_query("select * from customers where id = '".$_GET['gid']."'");
		$rows_customers=mysql_fetch_array($rs_customers);
	}
?>
   <div class="popup-shadow" style="width: 500px;">
      <div class="popup-header">
         <span>Konfirmasi Hapus</span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <table>
      <tr>
      <td class="center">
      <? if(isConfirmDelete()) {?>
      		<strong>Peringatan</strong>: <br /> 
      		Data <b>Customers</b> akan ikut terhapus, jika ada data yang terhubung!.
      		<br /><br />
      		Apakah anda yakin menghapus <br /><b style="text-decoration: underline;"><? echo $rows_customers['name'] ?></b>?
      <? }?>
      
      <? if(isConfirmDeleteSelected()) {?>
      		<? if($_GET['gid']!='') { 
				$value = array();
				$value = generateArray($_GET['gid']); 
			?>
            	<strong>Peringatan: </strong><br /> Data <b>Customers</b> akan ikut terhapus, jika ada data yang terhubung!.
      		<br /><br />
                Sebanyak <b style="text-decoration: underline;"><? echo count($value) ?> customers</b> yang akan dihapus!.<br />
                Apakah anda yakin untuk menghapusnya?
            <? } else { ?>
            	Tidak ada customers yang akan dihapus.<br />Silahkan anda memilih check box untuk dicentang.
            <? } ?>
      <? }?>
      </td>
      </tr>
      </table>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel"><? if($_GET['gid']!='') echo 'Batal'; else echo 'Tutup' ?></div>
        <? if(isConfirmDelete()) { ?>
      		<div mode="3" link="modul/data/customer?<? echo $_GET['gid'] ?>" class="popup-button">Hapus</div>
        <? }?>
      	<? if(isConfirmDeleteSelected()) {
			if($_GET['gid']!='') {
				if(count($value)>0)
		?>
      		<div mode="5" link="modul/data/customer?<? echo htmlspecialchars($_GET['gid']) ?>" class="popup-button">Hapus</div>
        <? } } ?>
      </div>
      
   </div>

<? } 

?>

<?
 if(isDelete()) {
	mysql_query("DELETE from customers where id =".$_GET['gid']);
	
 } ?>
 
<?
//<!-- END TIPE MODE 3 -->

//<!-- =========================================================================================================================== -->

//<!-- TIPE MODE 5 = DELETE SELECTED/HAPUS YANG DIPILIH -->
?>

<? if(isDeleteSelected()) { 
	
	$value = array();
	$value = generateArray($_GET['gid']); 

	// Taruh query ke database untuk menghapus disini...
	// Contoh :
	for($i=0;$i<count($value);$i++) {
	 	mysql_query("DELETE from customers where id = '".$value[$i]."'");
	}
	
 } 
//<!-- END TIPE MODE 5 -->

//<!-- =========================================================================================================================== -->
?>

<?
//<!-- TIPE MODE 6 = SAVE/MENYIMPAN -->
 if(isSave()) { 

$error = array();
if(!$_POST['name']) $error[] = 'name:Silahkan Masukkan Nama Perusahaan.';
if(!$_POST['upname']) $error[] = 'upname:Silahkan Masukkan Nama Kontak.';
if(!$_POST['code']) $error[] = 'code:Silahkan Masukkan Kode Customers.';


$rs_check = mysql_query("select * from customers where code = UPPER('".$_POST['kodene']."-".$_POST['code']."')");
$rows_check = mysql_num_rows($rs_check);

if($_POST['mod']=='0')
	if($rows_check>0) $error[] = 'code:Kode Customer Sudah Ada Silahkan Masukkan Yang lain.';

if($_POST['mod']=='1') 
	if($_POST['kode']!=strtoupper($_POST['kodene']."-".$_POST['code']))
		if($rows_check>0) $error[] = 'code:Kode Customer Sudah Ada Silahkan Masukkan Yang lain.';
		

if(count($error)>0) {
	echo generateError($error);
	
} else {
	
	if($_POST['mod']=='0') {
		
		mysql_query("INSERT INTO customers (unit_id, name, code, address, city, phone, fax, upname) VALUES ('".$_POST['unit_id']."', '".$_POST['name']."', '".strtoupper($_POST['kodene']."-".$_POST['code'])."', '".$_POST['address']."', '".$_POST['city']."', '".$_POST['phone']."', '".$_POST['fax']."','".$_POST['upname']."')");
		
	}
	
	if($_POST['mod']=='1') {	
		mysql_query("UPDATE customers SET unit_id = '".$_POST['unit_id']."', name = '".$_POST['name']."', code = '".strtoupper($_POST['kodene']."-".$_POST['code'])."',  address = '".$_POST['address']."', city = '".$_POST['city']."', phone = '".$_POST['phone']."', fax = '".$_POST['fax']."', upname = '".$_POST['upname']."' WHERE id ='".$_POST['gid']."';");
	}
	
	
		
}

} 
//<!-- END TIPE MODE 6 --> 
?>

