<?php
	require_once '../../library/connectionmysql.php';
	Connected();
	
	$perm = array();
	$perm = getPermissions('28');
	

	if($perm[-1]=='1') { require_once '../../library/error-popup.php'; die; }
	if(isAdd()) { 
		if($perm[0]=='1') { require_once '../../library/error-popup.php'; die; }
	}if(isEdit()) { 
		if($perm[1]=='1') { require_once '../../library/error-popup.php'; die; }
	}if(isConfirmDelete() || isConfirmDeleteSelected()) { 
		if($perm[2]=='1') { require_once '../../library/error-popup.php'; die; }
	}
		
	if(isEdit())  {
		
		$rs_item = mysql_query("select * from items where id = '".$_GET['gid']."'");
		$rows_item=mysql_fetch_array($rs_item);
	}
//<!-- =========================================================================================================================== -->
?>

<?
//<!-- FORM TIPE MODE 0 = TAMBAH/ADD, TIPE MODE 1 = UBAH/EDIT -->
 if(isAdd() || isEdit()) {
	$rs_units = mysql_query("select * from units where id = '".$_SESSION['galaxy_unit']."'");
	$rows_units=mysql_fetch_array($rs_units);
	$kode = explode('/',$rows_units['code']);
	$kode = $kode[0];
?>
 
   <div class="popup-shadow" style="width: 600px;">
      <div class="popup-header">
         <span><? if(isAdd()) echo 'Tambah Data'; else echo 'Edit Data'; ?></span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <form action="modul/data/barang.php" method="post">
      <table>
      <tr>
      <td width="25%">Nama Barang</td>
      <td width="5%" align="center">:</td>
      <td><input class="input-text" name="name" type="text" value="<? if(isEdit()) echo $rows_item['name'] ?>" /></td>
      </tr>
      <tr>
      <td>Code</td>
      <td align="center">:</td>
      <td>
      <? if(isEdit()) { 
			$kode = explode('-',$rows_item['code']);
			$rows_item['code0'] = $kode[0];
			$rows_item['code1'] = $kode[1];
	  ?>
      
      
      <? } ?>
      
      <span><? if(isEdit()) { echo $rows_item['code0']; } if(isAdd()) { if($_SESSION['galaxy_type'] == '0') {echo 'SBC';} else{ echo $rows_units['code']; } } ?>-</span><input class="input-text input-vsmall" name="code" type="text" value="<? if(isEdit()) echo $rows_item['code1'] ?>" /></td>
      </tr>
      <tr>
      <td>Satuan</td>
      <td align="center">:</td>
      <td><select name="piece_id" class="select-text select-small">
      	<option value="">Pilih..</option>
      <? 	  
	 
	  $qry_pieces = "select * from pieces order by id;";	  
	  $rs_pieces = mysql_query($qry_pieces);
	  while($rows_pieces=mysql_fetch_array($rs_pieces)) {
	  ?>
        <option value="<? echo $rows_pieces['id']?>" <? if(isEdit()) if($rows_pieces['id']==$rows_item['piece_id']) echo 'selected'; ?>><? echo $rows_pieces['name']; ?></option>
      <? } ?>
      </select></td>
      </tr>
      <tr>
      <td>Nama Sat.Terkecil</td>
      <td align="center">:</td>
      <td><input class="input-text input-small" name="pcsname" type="text" value="<? if(isEdit()) echo $rows_item['pcsname'] ?>" /></td>
      </tr>
      <tr>
      <td>Konversi Sat.Terkecil</td>
      <td align="center">:</td>
      <td><input class="input-text phone" maxlength="5" name="pcs" type="text" value="<? if(isEdit()) echo $rows_item['pcs'] ?>" /></td>
      </tr>
      <tr>
      <td>Harga Jual</td>
      <td align="center">:</td>
      <td><input class="input-text currency padmin" name="saleprice" type="text" value="<? if(isEdit()) echo cFormat($rows_item['saleprice'], false) ?>" /></td>
      </tr>
       <tr>
      <td>Harga Beli</td>
      <td align="center">:</td>
      <td><input class="input-text currency padmin" name="buyprice" type="text" value="<? if(isEdit()) echo cFormat($rows_item['buyprice'], false) ?>" /></td>
      </tr>
      <tr>
      <td>Golongan</td>
      <td align="center">:</td>
      <td><select name="icategory_id" class="select-text select-small">
      	<option value="">Pilih..</option>
      <? 	  
	 
	  $qry_icategories = "select * from icategories order by id;";	  
	  $rs_icategories = mysql_query($qry_icategories);
	  while($rows_icategories=mysql_fetch_array($rs_icategories)) {
	  ?>
        <option value="<? echo $rows_icategories['id']?>" <? if(isEdit()) if($rows_icategories['id']==$rows_item['icategory_id']) echo 'selected'; ?>><? echo $rows_icategories['name']; ?></option>
      <? } ?>
      </select></td>
      </tr>
      
      </table>
      <? if(isEdit())  {?>
      <input type="hidden" name="gid" value="<? echo $_GET['gid'] ?>" />
      <input type="hidden" name="kode" value="<? echo strtoupper($rows_item['code']) ?>" />
      
      <? }?>
      <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
      <input type="hidden" name="unit_id" value="<? echo $rows_units['id'] ?>" />
      <input type="hidden" name="kodene" value="<? if(isEdit()) { echo $rows_item['code0']; } if(isAdd()) { if($_SESSION['galaxy_type'] == '0') {echo 'SBC';} else{ echo $rows_units['code']; } } ?>" />
      </form>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel">Batal</div>
      	<div mode="6" link="library/submenu/data/barang" class="popup-button" get="">Simpan</div>
      </div>
   </div>

<? }  
//<!-- END FORM -->

//<!-- =========================================================================================================================== -->
?>

<? 
//<!-- FORM TIPE MODE 2 = CONFIRM DELETE/KONFIRMASI HAPUS, TIPE MODE 4 = CONFIRM DELETE SELECTED/KONFIRMASI HAPUS YANG DIPILIH -->
if(isConfirmDelete() || isConfirmDeleteSelected()) { ?>
<?
	if(isConfirmDelete()) {
		$rs_item = mysql_query("select * from items where id = '".$_GET['gid']."'");
		$rows_item=mysql_fetch_array($rs_item);
	}
?>
   <div class="popup-shadow" style="width: 500px;">
      <div class="popup-header">
         <span>Konfirmasi Hapus</span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <table>
      <tr>
      <td class="center">
      <? if(isConfirmDelete()) {?>
      		<strong>Peringatan</strong>: <br /> 
      		Data <b>Barang</b> akan ikut terhapus, jika ada data yang terhubung!.
      		<br /><br />
      		Apakah anda yakin menghapus <br /><b style="text-decoration: underline;"><? echo $rows_item['name'] ?></b>?
      <? }?>
      
      <? if(isConfirmDeleteSelected()) {?>
      		<? if($_GET['gid']!='') { 
				$value = array();
				$value = generateArray($_GET['gid']); 
			?>
            	<strong>Peringatan: </strong><br /> Data <b>Barang</b> akan ikut terhapus, jika ada data yang terhubung!.
      		<br /><br />
                Sebanyak <b style="text-decoration: underline;"><? echo count($value) ?> item</b> yang akan dihapus!.<br />
                Apakah anda yakin untuk menghapusnya?
            <? } else { ?>
            	Tidak ada item yang akan dihapus.<br />Silahkan anda memilih check box untuk dicentang.
            <? } ?>
      <? }?>
      </td>
      </tr>
      </table>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel"><? if($_GET['gid']!='') echo 'Batal'; else echo 'Tutup' ?></div>
        <? if(isConfirmDelete()) { ?>
      		<div mode="3" link="modul/data/barang?<? echo $_GET['gid'] ?>" class="popup-button">Hapus</div>
        <? }?>
      	<? if(isConfirmDeleteSelected()) {
			if($_GET['gid']!='') {
				if(count($value)>0)
		?>
      		<div mode="5" link="modul/data/barang?<? echo htmlspecialchars($_GET['gid']) ?>" class="popup-button">Hapus</div>
        <? } } ?>
      </div>
      
   </div>

<? } 

?>

<?
 if(isDelete()) {
	mysql_query("DELETE from items where id =".$_GET['gid']);
	
 } ?>
 
<?
//<!-- END TIPE MODE 3 -->

//<!-- =========================================================================================================================== -->

//<!-- TIPE MODE 5 = DELETE SELECTED/HAPUS YANG DIPILIH -->
?>

<? if(isDeleteSelected()) { 
	
	$value = array();
	$value = generateArray($_GET['gid']); 

	// Taruh query ke database untuk menghapus disini...
	// Contoh :
	for($i=0;$i<count($value);$i++) {
	 	mysql_query("DELETE from items where id = '".$value[$i]."'");
	}
	
 } 
//<!-- END TIPE MODE 5 -->

//<!-- =========================================================================================================================== -->
?>

<?
//<!-- TIPE MODE 6 = SAVE/MENYIMPAN -->
 if(isSave()) { 

$error = array();
if(!$_POST['name']) $error[] = 'name:Silahkan Masukkan Nama Barang.';
if(!$_POST['code']) $error[] = 'code:Silahkan Masukkan Kode Barang.';
if(!$_POST['piece_id']) $error[] = 'piece_id:Silahkan Pilih Satuan.';
if(!$_POST['icategory_id']) $error[] = 'icategory_id:Silahkan Pilih Golongan Barang.';

$rs_check = mysql_query("select * from items where code = UPPER('".$_POST['kodene']."-".$_POST['code']."')");
$rows_check = mysql_num_rows($rs_check);

if($_POST['mod']=='0')
	if($rows_check>0) $error[] = 'code:Kode Barang Sudah Ada Silahkan Masukkan Yang lain.';

if($_POST['mod']=='1') 
	if($_POST['kode']!=strtoupper($_POST['kodene']."-".$_POST['code']))
		if($rows_check>0) $error[] = 'code:Kode Barang Sudah Ada Silahkan Masukkan Yang lain.';
		

if(count($error)>0) {
	echo generateError($error);
	
} else {
	
	if($_POST['mod']=='0') {
		
		mysql_query("INSERT INTO items (piece_id, unit_id, name, code, pcs, pcsname, icategory_id, saleprice, buyprice) VALUES ('".$_POST['piece_id']."', '".$_POST['unit_id']."', '".$_POST['name']."', '".strtoupper($_POST['kodene']."-".$_POST['code'])."', '".$_POST['pcs']."', '".$_POST['pcsname']."', '".$_POST['icategory_id']."', ".isNull($_POST['saleprice'],'CUR').", ".isNull($_POST['buyprice'],'CUR').")");
		
	}
	
	if($_POST['mod']=='1') {	
		mysql_query("UPDATE items SET piece_id = '".$_POST['piece_id']."', unit_id = '".$_POST['unit_id']."', name = '".$_POST['name']."', code = '".strtoupper($_POST['kodene']."-".$_POST['code'])."', pcs = '".$_POST['pcs']."', pcsname = '".$_POST['pcsname']."', icategory_id = '".$_POST['icategory_id']."', saleprice = ".isNull($_POST['saleprice'],'CUR').", buyprice = ".isNull($_POST['buyprice'],'CUR')." WHERE id ='".$_POST['gid']."';");
	}
	
	
		
}

} 
//<!-- END TIPE MODE 6 --> 
?>

