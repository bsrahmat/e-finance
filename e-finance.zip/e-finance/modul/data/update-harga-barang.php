<?php
	require_once '../../library/connectionmysql.php';
	Connected();
	
	$perm = array();
	$perm = getPermissions('29');
	

	if($perm[-1]=='1') { require_once '../../library/error-popup.php'; die; }
			
	if(isEdit())  {
		
		$rs_item = mysql_query("select * from items where id = '".$_GET['gid']."'");
		$rows_item=mysql_fetch_array($rs_item);
	}
//<!-- =========================================================================================================================== -->
?>



<? 
//<!-- FORM TIPE MODE 2 = CONFIRM DELETE/KONFIRMASI HAPUS, TIPE MODE 4 = CONFIRM DELETE SELECTED/KONFIRMASI HAPUS YANG DIPILIH -->
if(isConfirmDeleteSelected()) { ?>

   <div class="popup-shadow" style="width: 500px;">
      <div class="popup-header">
         <span>Update Harga Jual dan Harga Beli</span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <table>
      <tr>
      <td class="center">
            
      <? if(isConfirmDeleteSelected()) {?>
      		<? if($_GET['gid']!='') { 
				$value = array();
				$value = generateArray($_GET['gid']); 
			?>
            	Data Barang Yang Akan di Update Sebanyak <b style="text-decoration: underline;"><? echo count($value) ?> item</b>!.<br />
                <? } else { ?>
            	Tidak ada item yang akan dihapus.<br />Silahkan anda memilih check box untuk dicentang.
            <? } ?>
      <? }?>
      </td>
      </tr>
      </table>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel"><? if($_GET['gid']!='') echo 'Batal'; else echo 'Tutup' ?></div>
        
      	<? if(isConfirmDeleteSelected()) {
			if($_GET['gid']!='') {
				if(count($value)>0)
		?>
      		<div mode="5" link="modul/data/update-harga-barang?<? echo htmlspecialchars($_GET['gid']) ?>" class="popup-button">Update</div>
        <? } } ?>
      </div>
      
   </div>

<? } 

?>

<? if(isDeleteSelected()) { 
	
	$value = array();
	$value = generateArray($_GET['gid']); 

	// Taruh query ke database untuk menghapus disini...
	// Contoh :
	for($i=0;$i<count($value);$i++) {
	 	//mysql_query("DELETE from items where id = '".$value[$i]."'");
		mysql_query("UPDATE  items SET isupdate = '1' WHERE id = '".$value[$i]."'");
	}
	
 } 
?>


