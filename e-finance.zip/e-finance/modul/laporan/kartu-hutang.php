<?php
	require_once '../../library/connectionmysql.php';
	Connected();
	
	
$error = array();

if(!$_POST['unit']) $error[] = 'unit:Silahkan masukkan Unit.';
if(!$_POST['supplier']) $error[] = 'supplier:Silahkan Pilih Supplier.';
if(!$_POST['tgl-awal']) $error[] = 'tgl-awal:Silahkan masukkan Tanggal Awal.';
if(!$_POST['tgl-akhir']) $error[] = 'tgl-akhir:Silahkan Pilih Tanggal Akhir.';

if(count($error)>0) {
	//tampilkan pesan error, jika ada error.. :D
	echo generateError($error).'|*|';
	
} else {	
	$name = 'Kartu_hutang';
    ob_start();
	
	include(dirname(__FILE__).'/res/kartu-htg.php');
    $content = ob_get_clean();

    // convert in PDF
    require_once(dirname(__FILE__).'/html2pdf/html2pdf.class.php');
    try
    {
        $html2pdf = new HTML2PDF('L', 'A4', 'fr');
//      $html2pdf->setModeDebug();
        $html2pdf->setDefaultFont('Arial');
        $html2pdf->writeHTML($content, isset($_GET['vuehtml']));
        $filename = $name.'-'.date('YmdHis').'.pdf';
        $html2pdf->Output($filename);
    }
    catch(HTML2PDF_exception $e) {
        echo $e;
        exit;
    }
}
