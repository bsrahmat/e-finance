<?php
require_once '../../library/connectionmysql.php';
Connected();

$unit=$_GET['unit'];
$customer=$_GET['customer'];
$tgl_awal=cDateR($_GET['tgl_awal']);
$tgl_akhir=cDateR($_GET['tgl_akhir']);
$tempo=$_GET['jthtempo'];

$t=explode('-',$tgl_awal);

$tgl= date("d F Y", mktime(0,0,0,date($t[1]),date($t[2])-1,date($t[0]))); 
$bulan=array(1=>'January', 2=>'February', 3=>'March', 4=>'April', 5=>'May', 6=>'June', 7=>'July', 8=>'August', 9=>'September', 10=>'October', 11=>'November', 12=>'December');
$t2=explode(' ',$tgl);
for ($i=1; $i <= 12; $i++)
{
	if($bulan[$i]==$t2[1]) { $bln="0".$i; }
}
$saldo_tanggal2=$t2[2].'-'.$bln.'-'.$t2[0];
$saldo_tanggal='2011-6-30';


if($_GET['jthtempo'])
{
	$tgl="JTH_TEMPO between '".$tgl_awal."'	and '".$tgl_akhir."' ";
	$tgl_saldo="JTH_TEMPO between '".$saldo_tanggal."'	and '".$saldo_tanggal2."'";
}
else
{
	$tgl="TANGGAL between '".$tgl_awal."' and '".$tgl_akhir."' ";
	$tgl_saldo="TANGGAL between '".$saldo_tanggal."' and '".$saldo_tanggal2."'";
}

$rows_units=mysql_fetch_array(mysql_query("select * from units where id = '".$unit."';"));
if($rows_units['logo'] == '') 
{
	$rows_units['logo'] = 'none.jpg';
}
?>

<table cellspacing="0" style="width: 100%; font-size: 12px; padding:15px 25px 15px 25px;">
		<tr>
			<td style="width: 50%; color: #444444; float:left;"><img style="height:55px;" src="./../../logo/<? echo $rows_units['logo'] ?>" alt="Logo"></td>
            <td style="width: 50%; color: #444444; text-align:right; font:'Times New Roman', Times, serif; font-style:italic; font-size:14px; font-weight:bold;"><? echo strtoupper($rows_units['name']) ?><br />Telp. <? echo $rows_units['phone'] ?><br /> Fax. <? echo $rows_units['fax'] ?></td>
        </tr>
        <tr style="margin-top:10px;">
			<td style="width: 100%; color: #444444; text-align:right; border-bottom:thin;" colspan="2"></td>
        </tr>
</table>

<table cellspacing="0" style="width: 100%; text-align: center;  font-weight:bold; font-style:italic; padding:0 25px 25px 10px;">
    <tr>
		<td style="width: 100%; text-align:center; font-size: 18px;">KARTU PIUTANG</td>
	</tr>
    <tr>
    <?
		$qry_customer = "select * from customers where id='".$customer."';";
		$rows_customer=mysql_fetch_array(mysql_query($qry_customer));
    ?>
		<td style="width: 100%; text-align:center;  font-size: 14px;">CUSTOMER : <? echo $rows_customer['name'] ?></td>
	</tr>
    <tr>
		<td style="width: 100%; text-align:center;  font-size: 14px;">Periode : <? echo cDate2($tgl_awal) ?> s/d <? echo cDate2($tgl_akhir) ?></td>
	</tr>  
</table>
<table cellspacing="0" style="width: 100%; padding:0 25px 25px 25px;">
    <tr>
    	<td>
        	<table border="0.3" cellspacing="0" style="width: 100%; border-color:#903; border:thin;">
            	<tr style="text-align:center; font-size:12px; background:#CCC;">
                    <td style="width: 4%; height:15px;">No</td>
                    <td style="width: 9%;">Tanggal</td>
                    <td style="width: 17%;">No. SJ</td>
                    <td style="width: 17%;">No. Retur</td>
                    <td style="width: 17%;">No. Kasbank</td>
                    <td style="width: 12%;">Debet</td>
                    <td style="width: 12%;">Kredit</td>
                    <td style="width: 12%;">Saldo</td>
               	</tr>
                <?
				$saldo_debet='0';
				$saldo_kredit='0';
                $qry_saldo="SELECT * FROM ak_piut WHERE UNIT_ID='".$unit."' and CUSTOMER_ID = '".$customer."' and ".$tgl_saldo;
				$rs_saldo=mysql_query($qry_saldo);
				while($rows_saldo=mysql_fetch_array($rs_saldo)) 
				{
					$saldo_debet=$saldo_debet+$rows_saldo['DEBET'];
					$saldo_kredit=$saldo_kredit+$rows_saldo['KREDIT'];
				}
				$total_saldo=$saldo_kredit-$saldo_debet;
				?>
                <tr style="font-size:10px;">
                    <td></td>
                    <td><? echo cDate2($saldo_tanggal2) ?></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td align="right"><? echo cFormat($total_saldo,false) ?></td>
               	</tr>
               <?php
				$no= 1;
				$qry_sj = "SELECT * FROM ak_piut WHERE ak_piut.UNIT_ID='".$unit."' and ak_piut.CUSTOMER_ID = '".$customer."' and ".$tgl;
				$rs_sj = mysql_query($qry_sj);
				while($rows_sj=mysql_fetch_array($rs_sj)) 
				{
				?>
					<tr style="font-size:10px;">
						<td align="center"><? echo $no?></td>
						<td><? echo cDate2($rows_sj['TANGGAL']) ?></td>
                        <?
                        $qry_sjs="select sjnom from sjs where id='".$rows_sj['SJ_ID']."' ";
						$row_sjs=mysql_fetch_array(mysql_query($qry_sjs));
						?>
						<td><? echo $row_sjs['sjnom'] ?></td>
                        <?
                        $qry_retur="select retnom from sreturs where id='".$rows_sj['SRETUR_ID']."' ";
						$row_retur=mysql_fetch_array(mysql_query($qry_retur));
						?>
						<td><? echo $row_retur['retnom'] ?></td>
                        <?
                        $qry_kasbank="select NO_BUKTI from ak_kasbank where ID='".$rows_sj['KASBANK_ID']."' ";
						$row_kasbank=mysql_fetch_array(mysql_query($qry_kasbank));
						?>
                        <td><? echo $row_kasbank['NO_BUKTI'] ?></td>
						<td align="right"><? echo cFormat($rows_sj['DEBET'],false) ?></td>
						<td align="right"><? echo cFormat($rows_sj['KREDIT'],false) ?></td>
                        <?
                        $total_saldo=$total_saldo+$rows_sj['KREDIT']-$rows_sj['DEBET'];
						?>
                        <td align="right"><? echo cFormat($total_saldo,false) ?></td>
					</tr>
                <?
					$no++;
				}
				?>
        	</table>
        </td>
    </tr>
</table>
