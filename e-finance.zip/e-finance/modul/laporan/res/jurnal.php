<?php
require_once '../../library/connectionmysql.php';
Connected();

$qry_jurnal="select * from ak_jurnal where ID='".$_GET['gid']."'";
$row_jurnal=mysql_fetch_array(mysql_query($qry_jurnal));

$rows_units=mysql_fetch_array(mysql_query("select * from units where id = '".$row_jurnal['UNIT_KODE']."';"));
if($rows_units['logo'] == '') 
{
	$rows_units['logo'] = 'none.jpg';
}
?>
	
<table cellspacing="0" style="width: 100%; font-size: 12px; padding:15px 25px 15px 25px;">
		<tr>
			<td style="width: 50%; color: #444444; float:left;"><img style="height:55px;" src="./../../logo/<? echo $rows_units['logo'] ?>" alt="Logo"></td>
            <td style="width: 50%; color: #444444; text-align:right; font:'Times New Roman', Times, serif; font-style:italic; font-size:14px; font-weight:bold;"><? echo strtoupper($rows_units['name']) ?><br />Telp. <? echo $rows_units['phone'] ?><br /> Fax. <? echo $rows_units['fax'] ?></td>
        </tr>
        <tr style="margin-top:10px;">
			<td style="width: 100%; color: #444444; text-align:right; border-bottom:thin;" colspan="2"></td>
        </tr>
</table>

<table cellspacing="0" style="width: 100%; text-align: center;  font-weight:bold; font-style:italic; padding:0 25px 25px 10px;">
    <tr>
		<td style="width: 100%; text-align:center; font-size: 18px;">BUKTI JURNAL MEMORIAL</td>
	</tr>
    <tr>
		<td style="width: 100%; text-align:center;  font-size: 14px;">No. <? echo $row_jurnal['NO_BUKTI'] ?></td>
	</tr>
    <tr>
		<td style="width: 100%; text-align:center;  font-size: 14px;">Tgl. <? echo cDate2($row_jurnal['TANGGAL_TRANS']) ?></td>
	</tr>
    
</table>

<table cellspacing="0" style="width: 100%; padding:0 25px 25px 25px;">
    <tr>
    	<td>
        	<table border="0.3" cellspacing="0" style="width: 100%; border-color:#903; border:thin;">
            	<tr style="text-align:center; font-size:12px; background:#CCC;">
                    <td style="width: 20%;">Kode Perkiraan</td>
                    <td style="width: 46%;">Uraian</td>
                    <td style="width: 17%;">Debet</td>
                    <td style="width: 17%;">Kredit</td>
               	</tr>
                
                <tr style="font-size:12px";>
                    <?
                        $qry_perk="select * from ak_detail_perk where ID_DETAIL = '".$row_jurnal['PERK_DEBET']."';";
                        $row_perk=mysql_fetch_array(mysql_query($qry_perk));
                    ?>
                    <td align="center"><? echo $row_perk['KODE_DETAIL'] ?></td>
                    <td align="left"><? echo $row_jurnal['URAIAN_DEBET']?></td>
                    <td align="right"><? echo cFormat($row_jurnal['DEBET'],false) ?></td>
                    <td></td>
                  </tr>
                  <tr style="font-size:12px";>
                  	<?
                        $qry_perk2="select * from ak_detail_perk where ID_DETAIL = '".$row_jurnal['PERK_KREDIT']."';";
                        $row_perk2=mysql_fetch_array(mysql_query($qry_perk2));
                    ?>
                    <td align="center"><? echo $row_perk2['KODE_DETAIL'] ?></td>
                    <td align="left"><? echo $row_jurnal['URAIAN_KREDIT']?></td>
                    <td></td>
                    <td align="right"><? echo cFormat($row_jurnal['KREDIT'],false) ?></td>
                </tr>
        	</table>
        </td>
    </tr>
</table>