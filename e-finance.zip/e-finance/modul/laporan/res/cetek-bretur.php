<?php

require_once '../../library/connectionmysql.php';
Connected();
$qry_breturs = "SELECT breturs.id, breturs.trrgood_id, breturs.retdate, breturs.retnom, breturs.unitid, breturs.isclosed, breturs.isacc, breturs.isok, breturs.ispost, trrgoods.id, trrgoods.trporder_id, trrgoods.rgnom, trrgoods.fakturnom, trrgoods.rgdate, trrgoods.description, trrgoods.recipient, trrgoods.postby, trrgoods.postdate, trrgoods.prsign, trrgoods.isposted, trrgoods.prname, trrgoods.unitid, trrgoods.isclosed, trrgoods.warehouse_id, trrgoods.refnom, trrgoods.post FROM breturs LEFT JOIN trrgoods ON (breturs.trrgood_id = trrgoods.id)  WHERE breturs.id = '".$_GET['gid']."';";
$rs_breturs = mysql_query($qry_breturs);
$rows_breturs=mysql_fetch_array($rs_breturs);
$rows_gudang=mysql_fetch_array(mysql_query("select * from warehouses where id = '".$rows_breturs['warehouse_id']."';"));
$rows_units=mysql_fetch_array(mysql_query("select * from units where id = '".$rows_breturs['unitid']."';"));

$sup=mysql_fetch_array(mysql_query("select * from trporders JOIN suppliers ON (trporders.supplier_id = suppliers.id) where trporders.id = '".$rows_breturs['trporder_id']."';"));
if($rows_units['logo'] == '') {
	$rows_units['logo'] = 'none.jpg';
}
?>

	<table cellspacing="0" style="width: 100%; font-size: 12px; padding:15px 25px 15px 25px;">
		<tr>
			<td style="width: 50%; color: #444444; float:left;"><img style="height:55px;" src="./../../logo/<? echo $rows_units['logo'] ?>" alt="Logo"></td>
            <td style="width: 50%; color: #444444; text-align:right; font:'Times New Roman', Times, serif; font-style:italic; font-size:14px; font-weight:bold;"><? echo strtoupper($rows_units['name']) ?><br />Telp. <? echo $rows_units['phone'] ?><br /> Fax. <? echo $rows_units['fax'] ?></td>
        </tr>
        <tr style="margin-top:10px;">
			<td style="width: 100%; color: #444444; text-align:right; border-bottom:thin;" colspan="2"></td>
        </tr>
    </table>
    
    <table cellspacing="0" style="width: 100%; text-align: center;  font-weight:bold; font-style:italic; padding:0 25px 25px 10px;">
    <tr>
	<td style="width: 100%; text-align:center; font-size: 18px;">RETUR PEMBELIAN</td>
	</tr>
    <tr>
	<td style="width: 100%; text-align:center;  font-size: 14px;">No. <? echo $rows_breturs['retnom'] ?></td>
	</tr>
    <tr>
	<td style="width: 100%; text-align:center;  font-size: 14px;">Tgl. <? echo cDate2($rows_breturs['retdate']) ?></td>
	</tr>
    
    </table>
    
    <table cellspacing="0" style="width: 100%; font-size: 12px; padding:0 25px 15px 25px;">
    	<tr>
			<td style="width: 60%; color: #444444;">Kepada YTH:</td>
            <td style="width: 40%; color: #444444; border:1px 1px 1px 1px;" rowspan="3">No. LPB : <? echo $rows_breturs['rgnom'] ?><br />Tgl LPB : <? echo cDate2($rows_breturs['rgdate']) ?></td>
        </tr>
        <tr>
            <td>( <? echo $sup[11] ?> )</td>
        </tr>
        <tr>
            <td><? echo $sup[13] ?></td>
        </tr>
    </table>
    
    <table cellspacing="0" style="width: 100%; padding:0 25px 25px 25px;">
    <tr>
	<td>
     <table border="0.3" cellspacing="0" style="width: 100%; border-color:#903; border:thin;">
      <tr style="text-align:center; font-size:12px; background:#CCC;">
		<td style="width: 5%; height:15px;">No</td>
		<td style="width: 45%;">Nama Barang</td>
		<td style="width: 8%;">Qty</td>
		<td style="width: 10%;">Satuan</td>
        <td style="width: 32%;">Keterangan</td>
        
	  </tr>
      <?php
		$qry_bretdetails = "select * from bretdetails JOIN items ON ( bretdetails.item_id = items.id) where bretdetails.bretur_id = '".$_GET['gid']."';";
		$rs_bretdetails = mysql_query($qry_bretdetails);
		$no= 1;
		while($rows_bretdetails=mysql_fetch_array($rs_bretdetails)) {
			$rows_satuan=mysql_fetch_array(mysql_query("select * from pieces where id = '".$rows_bretdetails['piece_id']."';"));
	  ?>
      <tr style="font-size:10px";>
		<td style="height:10px;" align="right"><? echo $no ?></td>
		<td><? echo $rows_bretdetails['name'] ?></td>
		<td align="right"><? echo cFormat($rows_bretdetails['qty'],false) ?></td>
		<td align="center"><? echo $rows_satuan['name'] ?></td>  
        <td align="center"><? echo $rows_bretdetails['description'] ?></td>                           
	 </tr>
     <?php
		$no++;
		}
	?>
    </table>
    </td>
    </tr>
    </table>
    <? if($rows_breturs[7] == '1') { ?>
    <table cellspacing="0" style="width: 100%; font-size: 12px; padding:15px 25px 15px 25px;">
		<tr>
			<td style="width: 40%; color: #444444; text-align:center;"><? if($rows_breturs[6] == '1') { ?> Disetujui <? } ?></td>
            <td style="width: 20%;" align="center"></td>
            <td style="width: 40%; color: #444444; text-align:center;"> Penerima </td>
        </tr><br />
<br />

        <tr>
			
            <td style="width: 40%; text-align:center; height:60px;"><? if($rows_breturs[6] == '1') { echo accTTD(3); }?></td>
            <td style="width: 20%; text-align:center; "></td>
            <?
								if($rows_gudang['large']) {
									if(file_exists('./../../photo/large-acc/'.$rows_gudang['large'])) {
										//list($width, $height) = getimagesize($path.'photo/large-acc/'.$rows_gm['large']);
										$photo_small = '<img style="height:60px;" src="./../../photo/large-acc/'.$rows_gudang['large'].'">';
									} else
										$photo_small = '';
								} else
									$photo_small = '';
			
			?>
			<td style="width: 40%; text-align:center; "><? echo $photo_small ?></td>
            
        </tr>
        <tr>
			<td style="width: 40%; color: #444444; text-align:center; font-weight:bold;"><? if($rows_breturs[6] == '1') { ?> ( <u><? echo nPurchasing(); ?></u> )<br />Bag. Pembelian <? } ?></td>
            <td style="width: 20%;" align="center"></td>
            
            
            
            
            
            <td style="width: 40%; color: #444444; text-align:center; font-weight:bold;"> ( <u><? echo $rows_gudang['whhead'] ?></u> )<br />KA. Gudang </td>
        </tr>
    </table>
    <? } ?>