<?php
require_once '../../library/connectionmysql.php';
Connected();

$tgl_awal= cDateR($_POST['tgl-awal']);
$tgl_akhir=  cDateR($_POST['tgl-akhir']);

$tgl=explode('-',$tgl_awal);
$tgl[2]=$tgl[2]-1;
$tgl_awal2=$tgl[0].'-'.$tgl[1].'-'.$tgl[2];

$rows_units=mysql_fetch_array(mysql_query("select * from units where id = '".$_SESSION['galaxy_unit']."';"));
if($rows_units['logo'] == '') 
{
	$rows_units['logo'] = 'none.jpg';
}
?>

<table cellspacing="0" style="width: 100%; font-size: 12px; padding:15px 25px 15px 25px;">
		<tr>
			<td style="width: 50%; color: #444444; float:left;"><img style="height:55px;" src="./../../logo/<? echo $rows_units['logo'] ?>" alt="Logo"></td>
            <td style="width: 50%; color: #444444; text-align:right; font:'Times New Roman', Times, serif; font-style:italic; font-size:14px; font-weight:bold;"><? echo strtoupper($rows_units['name']) ?><br />Telp. <? echo $rows_units['phone'] ?><br /> Fax. <? echo $rows_units['fax'] ?></td>
        </tr>
        <tr style="margin-top:10px;">
			<td style="width: 100%; color: #444444; text-align:right; border-bottom:thin;" colspan="2"></td>
        </tr>
</table>

<table cellspacing="0" style="width: 100%; text-align: center;  font-weight:bold; font-style:italic; padding:0 25px 25px 10px;">
    <tr>
		<td style="width: 100%; text-align:center; font-size: 18px;">RINCIAN RUGI LABA</td>
	</tr>
    <tr>
		<td style="width: 100%; text-align:center;  font-size: 14px;">Periode : <? echo cDate2($tgl_awal) ?> s/d <? echo cDate2($tgl_akhir) ?></td>
	</tr>
       
</table>

<table cellspacing="0" style="width: 100%; padding:0 25px 0x 25px;">
    <tr>
    	<td>
        	<table border="0" cellspacing="0" style="width: 100%; border-color:#903; border:thin;">
            <tr style="text-align:center; font-size:12px; ">
                <td style="width: 5%; height:15px;"></td>
                <td style="width: 45%;"></td>
                <td style="width: 15%;">Periode Sekarang</td>
                <td style="width: 10%;"></td>
                <td style="width: 15%;">Total Akumulasi</td>
            </tr>
            <tr>
            	<td style="width: 100%; color: #444444; text-align:right; border-bottom:thin;" colspan="5"></td>
            </tr>
            </table>
        </td>
    </tr>
</table>

<?
$total_sekarang='0';
$qry_kategori="select * from ak_kategori_perk where ID_KATEGORI='5' or ID_KATEGORI='6' ";
$rs_kategori=mysql_query($qry_kategori);
while($rows_kategori=mysql_fetch_array($rs_kategori))
{
?>
	<table border="0" cellspacing="0" style="width: 100%; font-weight:bold; padding:0 23px 0x 26px; ">
    <tr style="background-color:#CCC;">
 		<td style="width:100%; "><? echo $rows_kategori['NAMA_KATEGORI']; ?></td>
    </tr>
    </table>
    <table border="0" cellspacing="0" style="width: 100%; padding: 0 0 0 25px;">
    <?
	$qry_group="select * from ak_group_perk where ID_KATEGORI_GROUP='". $rows_kategori['ID_KATEGORI']."' ";
	$rs_group=mysql_query($qry_group);
	while($rows_group=mysql_fetch_array($rs_group))
	{
		$qry_subgroup="select * from ak_subgroup_perk where ID_GROUP_SUBGROUP='". $rows_group['KODE_GROUP']."' ";
		$rs_subgroup=mysql_query($qry_subgroup);
		while($rows_subgroup=mysql_fetch_array($rs_subgroup))
		{
			$qry_perk="select * from ak_detail_perk where ID_SUBGROUP_DETAIL='".$rows_subgroup['KODE_SUBGROUP']."'";
			$rs_perk=mysql_query($qry_perk);
			while($rows_perk=mysql_fetch_array($rs_perk))
			{
				$biaya='0';
				$qry_detail = "select * from  ak_detail_kasbank where PERK_LAWAN = '".$rows_perk['ID_DETAIL']."';";
				$rs_detail = mysql_query($qry_detail);
				while($rows_detail=mysql_fetch_array($rs_detail))
				{
					$qry_kasbank="select * from ak_kasbank where ID='".$rows_detail['KASBANK_ID']."' and TANGGAL between '".$tgl_awal."' and '".$tgl_akhir."' ";
					$rs_kasbank=mysql_query($qry_kasbank);
					while($rows_kasbank=mysql_fetch_array($rs_kasbank))
					{
					if($rows_detail['DEBET']!=0) { $biaya=$biaya-$rows_detail['DEBET']; }
					if($rows_detail['KREDIT']!=0) { $biaya=$biaya+$rows_detail['KREDIT']; }
					}
				}
				$biaya2='0';
				$qry_detail2 = "select * from  ak_detail_kasbank where PERK_LAWAN = '".$rows_perk['ID_DETAIL']."' and UNIT_KODE='".$_SESSION['galaxy_unit']."';";
				$rs_detail2 = mysql_query($qry_detail2);
				while($rows_detail2=mysql_fetch_array($rs_detail2))
				{
					$qry_kasbank2="select * from ak_kasbank where ID='".$rows_detail2['KASBANK_ID']."' and TANGGAL between '2011-6-30' and '".$tgl_awal2."' ";
					$rs_kasbank2=mysql_query($qry_kasbank2);
					while($rows_kasbank2=mysql_fetch_array($rs_kasbank2))
					{
						if($rows_detail2['DEBET']!=0) { $biaya2=$biaya2-$rows_detail2['DEBET']; }
						if($rows_detail2['KREDIT']!=0) { $biaya2=$biaya2+$rows_detail2['KREDIT']; }
					}
				}
				
				if($biaya!=0 || $biaya2!=0)
				{
	?>
    			<tr>
                	<td colspan="5"><? echo $rows_subgroup['NAMA_SUBGROUP']; ?></td>
                </tr>
                <tr>
                	<td align="center" style="width: 5%; height:15px;"></td>
                    <td align="left" style="width: 49%;"><? echo $rows_perk['NAMA_DETAIL'] ?></td>
                    <td align="right" style="width: 15%;"><? echo cFormat($biaya,false) ?></td>
                    <td style="width:11%;"></td>
                    <td align="right" style="width: 15%;"><? echo cFormat($biaya2,false) ?></td>
                </tr>
                <tr>
                	<td align="center" style="width: 5%; height:15px;"></td>
                    <td align="left" style="width: 49%;"></td>
                    <td style="width: 15%; color: #444444; text-align:right; border-bottom:thin; " ></td>
                    <td style="width:11%;"></td>
        			<td style="width: 15%; color: #444444; text-align:right; border-bottom:thin;" ></td>
                </tr>
                <tr>
                	<td align="center" style="width: 5%; height:15px;"></td>
                    <td align="left" style="width: 49%;"></td>
                    <td align="right" style="width: 15%;"><? echo cFormat($biaya,false) ?></td>
                    <td style="width:11%;"></td>
                    <td align="right" style="width: 15%;"><? echo cFormat($biaya2,false) ?></td>
                </tr>
    <?
					$total_sekarang=$total_sekarang+$biaya;
					$total_akumulasi=$total_akumulasi+$biaya2;
				}
			}
		}
	}
    ?>
    </table>
    <br />
<?
}
$rugilaba_sekarang=0-$total_sekarang;
$rugilaba_akumulasi=0-$total_akumulasi;
?>
<table border="0" cellspacing="0" style="width: 100%; font-weight:bold; padding:0 0 0x 26px; font-size:15px; ">
<tr>
	<td align="center" style="width: 54%;">TOTAL RUGI LABA</td>
    <td align="right" style="width: 15%;"><? echo cFormat($rugilaba_sekarang,false) ?></td>
    <td style="width:11%;"></td>
    <td align="right" style="width: 15%;"><? echo cFormat($rugilaba_akumulasi,false) ?></td>
</tr>
</table>