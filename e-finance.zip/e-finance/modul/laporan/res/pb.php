<?php

require_once '../../library/connectionmysql.php';
Connected();
$qry_trprequests = "SELECT trprequests.id, trprequests.unit_id, trprequests.prdate, trprequests.prname, trprequests.prnom, trprequests.gmsign, trprequests.correct_pb, trprequests.id, units.id, units.gmanager_id, units.name, units.code, units.address, units.phone, units.fax, units.headsale_id, units.rek, units.rekname, units.pusat, units.ismanu, units.logo FROM trprequests LEFT JOIN units ON (trprequests.unit_id = units.id) where trprequests.id = '".$_GET['gid']."';";
$rs_trprequests = mysql_query($qry_trprequests);
$rows_trprequests=mysql_fetch_array($rs_trprequests);
$rows_gm=mysql_fetch_array(mysql_query("select * from gmanagers where id = '".$rows_trprequests['gmanager_id']."';"));
if($rows_trprequests['logo'] == '') {
	$rows_trprequests['logo'] = 'none.jpg';
}
?>

	<table cellspacing="0" style="width: 100%; font-size: 12px; padding:15px 25px 15px 25px;">
		<tr>
			<td style="width: 50%; color: #444444; float:left;"><img style="height:55px;" src="./../../logo/<? echo $rows_trprequests['logo'] ?>" alt="Logo"></td>
            <td style="width: 50%; color: #444444; text-align:right; font:'Times New Roman', Times, serif; font-style:italic; font-size:14px; font-weight:bold;"><? echo strtoupper($rows_trprequests['name']) ?><br />Telp. <? echo $rows_trprequests['phone'] ?><br /> Fax. <? echo $rows_trprequests['fax'] ?></td>
        </tr>
        <tr style="margin-top:10px;">
			<td style="width: 100%; color: #444444; text-align:right; border-bottom:thin;" colspan="2"></td>
        </tr>
    </table>
    
    <table cellspacing="0" style="width: 100%; text-align: center;  font-weight:bold; font-style:italic; padding:0 25px 25px 25px;">
    <tr>
	<td style="width: 100%; text-align:center; font-size: 18px;">PERMINTAAN PEMBELIAN</td>
	</tr>
    <tr>
	<td style="width: 100%; text-align:center;  font-size: 14px;">No. <? echo $rows_trprequests['prnom'] ?></td>
	</tr>
    <tr>
	<td style="width: 100%; text-align:center;  font-size: 14px;">Tgl. <? echo cDate2($rows_trprequests['prdate']) ?></td>
	</tr>
    </table>
    <table cellspacing="0" style="width: 100%; padding:0 25px 25px 25px;">
    <tr>
	<td>
     <table border="0.3" cellspacing="0" style="width: 100%; border-color:#903; border:thin;">
      <tr style="text-align:center; font-size:12px; background:#CCC;">
		<td style="width: 3%; height:15px;">No</td>
		<td style="width: 38%;">Nama Barang</td>
		<td style="width: 8%;">Qty</td>
		<td style="width: 10%;">Satuan</td>
        <td style="width: 30%;">Peruntukan</td>
		<td style="width: 11%;">W.Butuh</td>
	  </tr>
      <?php
		$qry_trprdetails = "select * from trprdetails JOIN items ON (trprdetails.item_id = items.id) where trprequest_id = '".$_GET['gid']."';";
		$rs_trprdetails = mysql_query($qry_trprdetails);
		$no= 1;
		while($rows_trprdetails=mysql_fetch_array($rs_trprdetails)) {
		$rows_satuan=mysql_fetch_array(mysql_query("select * from pieces where id = '".$rows_trprdetails['piece_id']."';"));
	  ?>
      <tr style="font-size:10px";>
		<td style="height:10px;" align="right"><? echo $no ?></td>
		<td><? echo $rows_trprdetails['name'] ?></td>
		<td align="right"><? echo cFormat($rows_trprdetails['qty'],false) ?></td>
		<td align="center"><? echo $rows_satuan['name'] ?></td>                            
        <td></td>
		<td align="center"><? echo cDate2($rows_trprdetails['timereq']) ?></td>
		
	 </tr>
     <?php
		$no++;
		}
	?>
    </table>
    </td>
    </tr>
    </table>
    <table cellspacing="0" style="width: 100%; font-size: 12px; padding:15px 25px 15px 25px;">
		<tr>
			<td style="width: 40%; color: #444444; text-align:center;">Yang Meminta,</td>
            <td style="width: 20%;" align="center"></td>
            <td style="width: 40%; color: #444444; text-align:center;"><? if($rows_trprequests['gmsign'] == '1') {?> GM <? echo $rows_trprequests['name'] ?> <? }?></td>
        </tr><br />
<br />

        <tr>
        	<td style="width: 40%; color: #444444; text-align:center;  height:60px;"></td>
            <td style="width: 20%;"></td>
            
            <?
								if($rows_gm['large']) {
									if(file_exists('./../../photo/large-acc/'.$rows_gm['large'])) {
										//list($width, $height) = getimagesize($path.'photo/large-acc/'.$rows_gm['large']);
										$photo_small = '<img style="height:60px;" src="./../../photo/large-acc/'.$rows_gm['large'].'">';
									} else
										$photo_small = '';
								} else
									$photo_small = '';
			
			?>
            
            
            
            
			<td style="width: 40%; text-align:center; "><? if($rows_trprequests['gmsign'] == '1') {?> <? echo $photo_small ?><? }?></td>
            
        </tr>
        <tr>
			<td style="width: 40%; color: #444444; text-align:center; font-weight:bold;">( <u><? echo $rows_trprequests['prname'] ?></u> )</td>
            <td style="width: 20%;" align="center"></td>
            <td style="width: 40%; color: #444444; text-align:center; font-weight:bold;"><? if($rows_trprequests['gmsign'] == '1') {?> ( <u><? echo $rows_gm['name'] ?></u> )<? }?></td>
        </tr>
    </table>