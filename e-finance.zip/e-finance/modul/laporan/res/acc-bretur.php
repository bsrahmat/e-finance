<?php

require_once '../../library/connectionmysql.php';
Connected();
$qry_breturs = "SELECT breturs.id, breturs.trrgood_id, breturs.retdate, breturs.retnom, breturs.unitid, breturs.isclosed, breturs.isacc, breturs.isok, breturs.ispost, breturs.issign, trrgoods.id, trrgoods.trporder_id, trrgoods.rgnom, trrgoods.fakturnom, trrgoods.rgdate, trrgoods.description, trrgoods.recipient, trrgoods.postby, trrgoods.postdate, trrgoods.prsign, trrgoods.isposted, trrgoods.prname, trrgoods.unitid, trrgoods.isclosed, trrgoods.warehouse_id, trrgoods.refnom, trrgoods.post FROM breturs LEFT JOIN trrgoods ON (breturs.trrgood_id = trrgoods.id)  WHERE breturs.id = '".$_GET['gid']."';";
$rs_breturs = mysql_query($qry_breturs);
$rows_breturs=mysql_fetch_array($rs_breturs);
$rows_gudang=mysql_fetch_array(mysql_query("select * from warehouses where id = '".$rows_breturs['warehouse_id']."';"));
$rows_units=mysql_fetch_array(mysql_query("select * from units where id = '".$rows_breturs['unitid']."';"));
$rows_manager=mysql_fetch_array(mysql_query("select * from gmanagers where id = '".$rows_units['gmanager_id']."';"));

$sup=mysql_fetch_array(mysql_query("select * from trporders JOIN suppliers ON (trporders.supplier_id = suppliers.id) where trporders.id = '".$rows_breturs['trporder_id']."';"));
if($rows_units['logo'] == '') {
	$rows_units['logo'] = 'none.jpg';
}
?>

	<table cellspacing="0" style="width: 100%; font-size: 12px; padding:15px 25px 15px 25px;">
		<tr>
			<td style="width: 50%; color: #444444; float:left;"><img style="height:55px;" src="./../../logo/<? echo $rows_units['logo'] ?>" alt="Logo"></td>
            <td style="width: 50%; color: #444444; text-align:right; font:'Times New Roman', Times, serif; font-style:italic; font-size:14px; font-weight:bold;"><? echo strtoupper($rows_units['name']) ?><br />Telp. <? echo $rows_units['phone'] ?><br /> Fax. <? echo $rows_units['fax'] ?></td>
        </tr>
        <tr style="margin-top:10px;">
			<td style="width: 100%; color: #444444; text-align:right; border-bottom:thin;" colspan="2"></td>
        </tr>
    </table>
    
    <table cellspacing="0" style="width: 100%; text-align: center;  font-weight:bold; font-style:italic; padding:0 25px 25px 10px;">
    <tr>
	<td style="width: 100%; text-align:center; font-size: 18px;">RETUR PEMBELIAN</td>
	</tr>
    <tr>
	<td style="width: 100%; text-align:center;  font-size: 14px;">No. <? echo $rows_breturs['retnom'] ?></td>
	</tr>
    <tr>
	<td style="width: 100%; text-align:center;  font-size: 14px;">Tgl. <? echo cDate2($rows_breturs['retdate']) ?></td>
	</tr>
    
    </table>
    
    <table cellspacing="0" style="width: 100%; font-size: 12px; padding:0 25px 15px 25px;">
    	<tr>
			<td style="width: 60%; color: #444444;">Kepada YTH:</td>
            <td style="width: 40%; color: #444444; border:1px 1px 1px 1px;" rowspan="3">No. LPB : <? echo $rows_breturs['rgnom'] ?><br />Tgl LPB : <? echo cDate2($rows_breturs['rgdate']) ?></td>
        </tr>
        <tr>
            <td>( <? echo $sup[11] ?> )</td>
        </tr>
        <tr>
            <td><? echo $sup[13] ?></td>
        </tr>
    </table>
    
    <table cellspacing="0" style="width: 100%; padding:0 25px 25px 25px;">
    <tr>
	<td>
     <table border="0.3" cellspacing="0" style="width: 100%; border-color:#903; border:thin;">
      <tr style="text-align:center; font-size:12px; background:#CCC;">
		<td style="width: 5%; height:15px;">No</td>
		<td style="width: 32%;">Nama Barang</td>
		<td style="width: 5%;">Qty</td>
		<td style="width: 8%;">Satuan</td>
        <td style="width: 10%;">HP Sat</td>
        <td style="width: 10%;">HP Total</td>
        <td style="width: 30%;">Keterangan</td>
        
	  </tr>
      <?php
		$qry_bretdetails = "select * from bretdetails JOIN items ON ( bretdetails.item_id = items.id) where bretdetails.bretur_id = '".$_GET['gid']."';";
		$rs_bretdetails = mysql_query($qry_bretdetails);
		$no= 1;
		$subtotal = '0';
		while($rows_bretdetails=mysql_fetch_array($rs_bretdetails)) {
			$rows_satuan=mysql_fetch_array(mysql_query("select * from pieces where id = '".$rows_bretdetails['piece_id']."';"));
			$total = $rows_bretdetails['qty'] * $rows_bretdetails['price'];
	  ?>
      <tr style="font-size:10px";>
		<td style="height:10px;" align="right"><? echo $no ?></td>
		<td><? echo $rows_bretdetails['name'] ?></td>
		<td align="right"><? echo cFormat($rows_bretdetails['qty'],false) ?></td>
		<td align="center"><? echo $rows_satuan['name'] ?></td>  
        <td align="right"><? echo cFormat($rows_bretdetails['price'],false) ?></td>
        <td align="right"><? echo cFormat($total,false) ?></td> 
        <td align="center"><? echo $rows_bretdetails['description'] ?></td>                          
	 </tr>
     <?php
	 $subtotal = $subtotal + $total;
		$no++;
		}
	?>
    </table>
    <table border="0" cellspacing="0" style="width: 100%; padding:3px 0 0 0;"" >
      <tr>
		
		<td style="width: 60%; font-weight:bold; text-align:right;">Jumlah Harga : Rp.</td>
		<td style="width: 10%; font-weight:bold; text-align:right"><? echo cFormat($subtotal,false) ?></td>
        <td style="width: 30%; font-weight:bold; text-align:right;"></td>
	  </tr>
      
     </table>
    </td>
    </tr>
    </table>
    <?
								if($rows_gudang['large']) {
									if(file_exists('./../../photo/large-acc/'.$rows_gudang['large'])) {
										//list($width, $height) = getimagesize($path.'photo/large-acc/'.$rows_gm['large']);
										$photo_small = '<img style="height:60px;" src="./../../photo/large-acc/'.$rows_gudang['large'].'">';
									} else
										$photo_small = '';
								} else
									$photo_small = '';
									
								if($rows_manager['large']) {
									if(file_exists('./../../photo/large-acc/'.$rows_manager['large'])) {
										//list($width, $height) = getimagesize($path.'photo/large-acc/'.$rows_gm['large']);
										$manageracc = '<img style="height:60px;" src="./../../photo/large-acc/'.$rows_manager['large'].'">';
									} else
										$manageracc = '';
								} else
									$manageracc = '';
			
			?>
    <table cellspacing="0" style="width: 100%; font-size: 12px; padding:15px 25px 15px 25px;">
		<tr>
			<td style="width: 25%; color: #444444; text-align:center;"><? if($rows_breturs[6] == '1') { ?> Disetujui <? } ?></td>
             <td style="width: 25%; color: #444444; text-align:center;"><? if($rows_breturs[9] == '1') { ?> Mengetahui <? } ?></td>
             <td style="width: 25%; color: #444444; text-align:center;"><? if($rows_breturs[8] == '1') { ?> Mengetahui <? } ?></td>
            <td style="width: 25%; color: #444444; text-align:center;"> Penerima </td>
        </tr><br />
<br />

        <tr>
			<td style="width: 25%; color: #444444; text-align:center;  height:60px;"><? if($rows_breturs[6]=='1') {?> <? echo accTTD(3); ?><? }?></td>
            
            <td style="width: 25%; text-align:center;"><? if($rows_breturs[9]=='1') {?><? echo $manageracc ?><? }?></td>
            <td style="width: 25%; text-align:center;"><? if($rows_breturs[8]=='1') {?> <? echo accTTD(5); ?><? }?></td>
            <td style="width: 25%; text-align:center; "><? if($rows_breturs['isok']=='1') {?> <? echo $photo_small ?><? }?></td>
            
        </tr>
        <tr>
			<td style="color: #444444; text-align:center; font-weight:bold;"><? if($rows_breturs[6] == '1') { ?> ( <u><? echo nPurchasing(); ?></u> )<br />Bag. Pembelian <? } ?></td>
            <td style="color: #444444; text-align:center; font-weight:bold;"><? if($rows_breturs[9] == '1') { ?> ( <u><? echo $rows_manager['name'] ?></u> )<br />MD.<? echo $rows_units['code'] ?> <? } ?></td>
            <td style="color: #444444; text-align:center; font-weight:bold;"><? if($rows_breturs[8] == '1') { ?> ( <u><? echo nAkunting(); ?></u> )<br />Akunting <? } ?></td>
            
            <td style="color: #444444; text-align:center; font-weight:bold;"> ( <u><? echo $rows_gudang['whhead'] ?></u> )<br />KA. Gudang </td>
        </tr>
    </table>