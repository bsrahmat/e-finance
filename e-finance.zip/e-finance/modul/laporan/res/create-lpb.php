<?php

require_once '../../library/connectionmysql.php';
Connected();
$qry_trrgoods = "SELECT trrgoods.id, trrgoods.trporder_id, trrgoods.rgnom, trrgoods.fakturnom, trrgoods.rgdate, trrgoods.description, trrgoods.recipient, trrgoods.postby, trrgoods.postdate, trrgoods.prsign, trrgoods.isposted, trrgoods.prname, trrgoods.unitid, trrgoods.isclosed, trrgoods.warehouse_id, trrgoods.refnom, trrgoods.post, trrgoods.id, trporders.id, trporders.trprequest_id, trporders.podate, trporders.ponom, trporders.posend, trporders.unitid, trporders.isclosed, trporders.poby, trporders.accby, trporders.supplier_id, warehouses.id, warehouses.code, warehouses.name, warehouses.location, warehouses.whhead, warehouses.large FROM trrgoods LEFT JOIN trporders ON (trrgoods.trporder_id = trporders.id) LEFT JOIN warehouses ON (trrgoods.warehouse_id = warehouses.id) WHERE trrgoods.id = '".$_GET['gid']."';";
$rs_trrgoods = mysql_query($qry_trrgoods);
$rows_trrgoods=mysql_fetch_array($rs_trrgoods);
$rows_suppliers=mysql_fetch_array(mysql_query("select * from suppliers where id = '".$rows_trrgoods['supplier_id']."';"));

$rows_units=mysql_fetch_array(mysql_query("select * from units where id = '".$rows_trrgoods['unitid']."';"));
if($rows_units['logo'] == '') {
	$rows_units['logo'] = 'none.jpg';
}
?>

	<table cellspacing="0" style="width: 100%; font-size: 12px; padding:15px 25px 15px 25px;">
		<tr>
			<td style="width: 50%; color: #444444; float:left;"><img style="height:55px;" src="./../../logo/<? echo $rows_units['logo'] ?>" alt="Logo"></td>
            <td style="width: 50%; color: #444444; text-align:right; font:'Times New Roman', Times, serif; font-style:italic; font-size:14px; font-weight:bold;"><? echo strtoupper($rows_units['name']) ?><br />Telp. <? echo $rows_units['phone'] ?><br /> Fax. <? echo $rows_units['fax'] ?></td>
        </tr>
        <tr style="margin-top:10px;">
			<td style="width: 100%; color: #444444; text-align:right; border-bottom:thin;" colspan="2"></td>
        </tr>
    </table>
    
    <table cellspacing="0" style="width: 100%; text-align: center;  font-weight:bold; font-style:italic; padding:0 25px 25px 10px;">
    <tr>
	<td style="width: 100%; text-align:center; font-size: 18px;">LPB (GUDANG)</td>
	</tr>
    <tr>
	<td style="width: 100%; text-align:center;  font-size: 14px;">No. <? echo $rows_trrgoods['rgnom'] ?></td>
	</tr>
    <tr>
	<td style="width: 100%; text-align:center;  font-size: 14px;">Tgl. <? echo cDate2($rows_trrgoods['rgdate']) ?></td>
	</tr>
    
    </table>
    
    <table cellspacing="0" style="width: 100%; font-size: 12px; padding:0 25px 15px 25px;">
		<tr>
			<td style="width: 17%; color: #444444;">Diterima Dari</td>
            <td style="width: 1%; color: #444444;">:</td>
            <td style="width: 32%; color: #444444;"><? echo $rows_suppliers['name'] ?></td>
            <td style="width: 15%; color: #444444;">No. PO</td>
            <td style="width: 1%; color: #444444;">:</td>
            <td style="width: 34%; color: #444444;"><? echo $rows_trrgoods['ponom'] ?></td>
        </tr>
        <tr>
			<td>No. Ref (SJ/Faktur)</td>
            <td>:</td>
            <td><? echo $rows_trrgoods['refnom'] ?></td>
            <td>Tanggal PO</td>
            <td>:</td>
            <td><? echo cDate2($rows_trrgoods['podate']) ?></td>
        </tr>
        <tr>
        	<td>Alamat</td>
            <td>:</td>
            <td colspan="3"><? echo $rows_suppliers['address'] ?>, <? echo $rows_suppliers['city'] ?></td>
            
        </tr>
    </table>
    
    <table cellspacing="0" style="width: 100%; padding:0 25px 25px 25px;">
    <tr>
	<td>
     <table border="0.3" cellspacing="0" style="width: 100%; border-color:#903; border:thin;">
     <tr style="text-align:center; font-size:12px;">
		<td style="width: 100%; height:20px; text-align:center; font-size:14px;" colspan="4">DIISI OLEH SEKSI GUDANG</td>
	  </tr>
      <tr style="text-align:center; font-size:12px; background:#CCC;">
		<td style="width: 5%; height:15px;">No</td>
		<td style="width: 70%;">Nama Barang</td>
		<td style="width: 10%;">Qty</td>
		<td style="width: 15%;">Satuan</td>
        
	  </tr>
      <?php
		$qry_trrgdetails = "select * from trrgdetails JOIN items ON ( trrgdetails.item_id = items.id) where trrgood_id = '".$_GET['gid']."';";
		$rs_trrgdetails = mysql_query($qry_trrgdetails);
		$no= 1;
		while($rows_trrgdetails=mysql_fetch_array($rs_trrgdetails)) {
			$rows_satuan=mysql_fetch_array(mysql_query("select * from pieces where id = '".$rows_trrgdetails['piece_id']."';"));
	  ?>
      <tr style="font-size:10px";>
		<td style="height:10px;" align="right"><? echo $no ?></td>
		<td><? echo $rows_trrgdetails['name'] ?></td>
		<td align="right"><? echo cFormat($rows_trrgdetails['qty'],false) ?></td>
		<td align="center"><? echo $rows_satuan['name'] ?></td>                            
	 </tr>
     <?php
		$no++;
		}
	?>
    </table>
    </td>
    </tr>
    </table>
    <table cellspacing="0" style="width: 100%; font-size: 12px; padding:15px 25px 15px 25px;">
		<tr>
			<td style="width: 40%; color: #444444; text-align:center;">Yang Menerima,</td>
            <td style="width: 20%;" align="center"></td>
            <td style="width: 40%; color: #444444; text-align:center;">Ka. Gudang</td>
        </tr><br />
<br />

        <tr>
			<td style="width: 40%; color: #444444; text-align:center;  height:60px;"></td>
            <td style="width: 20%;"></td>
            
            <?
								if($rows_trrgoods['large']) {
									if(file_exists('./../../photo/large-acc/'.$rows_trrgoods['large'])) {
										//list($width, $height) = getimagesize($path.'photo/large-acc/'.$rows_gm['large']);
										$photo_small = '<img style="height:60px;" src="./../../photo/large-acc/'.$rows_trrgoods['large'].'">';
									} else
										$photo_small = '';
								} else
									$photo_small = '';
			
			?>
            
            
            
            
			<td style="width: 40%; text-align:center; "><? if($rows_trrgoods[13] != '0') {?> <? echo $photo_small ?><? }?></td>
            
        </tr>
        <tr>
			<td style="width: 40%; color: #444444; text-align:center; font-weight:bold;">( <u><? echo $rows_trrgoods['recipient'] ?></u> )</td>
            <td style="width: 20%;" align="center"></td>
            <td style="width: 40%; color: #444444; text-align:center; font-weight:bold;"> ( <u><? echo $rows_trrgoods['whhead'] ?></u> ) </td>
        </tr>
    </table>