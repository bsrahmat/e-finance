<?php
require_once '../../library/connectionmysql.php';
Connected();

$unit=$_POST['unit'];
$tgl_akhir= cDateR($_POST['tgl-akhir']);

$tgl=explode('-',$tgl_akhir);
$tgl_awal=$tgl['0'].'-'.$tgl['1'].'-1';

$tgl2=date("d F Y", mktime(0,0,0,date($tgl[1]),date('1')-1,date($tgl[0]))); 
$bulan=array(1=>'January', 2=>'February', 3=>'March', 4=>'April', 5=>'May', 6=>'June', 7=>'July', 8=>'August', 9=>'September', 10=>'October', 11=>'November', 12=>'December');
$t2=explode(' ',$tgl2);
for ($i=1; $i <= 12; $i++)
{
	if($bulan[$i]==$t2[1]) { $bln="0".$i; }
}
$tgl_sld_akhir=$t2[2].'-'.$bln.'-'.$t2[0];

$rows_units=mysql_fetch_array(mysql_query("select * from units where id = '".$unit."';"));
if($rows_units['logo'] == '') 
{
	$rows_units['logo'] = 'none.jpg';
}
?>

<table cellspacing="0" style="width: 100%; font-size: 12px; padding:15px 25px 15px 25px;">
		<tr>
			<td style="width: 50%; color: #444444; float:left;"><img style="height:55px;" src="./../../logo/<? echo $rows_units['logo'] ?>" alt="Logo"></td>
            <td style="width: 50%; color: #444444; text-align:right; font:'Times New Roman', Times, serif; font-style:italic; font-size:14px; font-weight:bold;"><? echo strtoupper($rows_units['name']) ?><br />Telp. <? echo $rows_units['phone'] ?><br /> Fax. <? echo $rows_units['fax'] ?></td>
        </tr>
        <tr style="margin-top:10px;">
			<td style="width: 100%; color: #444444; text-align:right; border-bottom:thin;" colspan="2"></td>
        </tr>
</table>

<table cellspacing="0" style="width: 100%; text-align: center;  font-weight:bold; font-style:italic; padding:0 25px 25px 10px;">
    <tr>
		<td style="width: 100%; text-align:center; font-size: 18px;">NERACA SALDO</td>
	</tr>
    <tr>
		<td style="width: 100%; text-align:center;  font-size: 14px;">Per : <? echo cDate2($tgl_akhir) ?></td>
	</tr>
       
</table>

<table border="0" cellspacing="0" style="width: 100%; font-weight:bold; border-color:#903; border:thin; padding: 0 10px 0 55px;">
<tr>
    <td align="center" style="width:33%; "></td>
    <td colspan="2" align="center" style="width:22%; "><? echo cDate2($tgl_sld_akhir) ?></td>
    <td colspan="2" align="center" style="width:22%; "><? echo "KasBank dan Jurnal"; ?></td>
    <td colspan="2" align="center" style="width:22%; "><? echo cDate2($tgl_akhir) ?></td>
</tr>
<tr>
    <td style="width:33%; "><? echo $rows_perk['NAMA_DETAIL']; ?></td>
    <td align="center" style="width:11%; "><? echo "Debet" ; ?></td>
    <td align="center" style="width:11%; "><? echo "Kredit" ; ?></td>
    <td align="center" style="width:11%; "><? echo "Debet" ; ?></td>
    <td align="center" style="width:11%; "><? echo "Kredit" ; ?></td>
    <td align="center" style="width:11%; "><? echo "Debet" ; ?></td>
    <td align="center" style="width:11%; "><? echo "Kredit" ; ?></td>
</tr>
</table>
<?
$total_saldo1='0';
$total_saldo2='0';
$total_dbt='0';
$total_krd='0';
$total_total1='0';
$total_total2='0';
$qry_kategori="select * from ak_kategori_perk where ID_KATEGORI='1' or ID_KATEGORI='2' or ID_KATEGORI='5' or ID_KATEGORI='6'";
$rs_kategori=mysql_query($qry_kategori);
while($rows_kategori=mysql_fetch_array($rs_kategori))
{
	$total_kategori='0';
?>
	<table border="0" cellspacing="0" style="width: 100%; font-size: 23px; font-weight:bold; padding: 0 0 0 25px;">
    <tr>
 		<td><? echo $rows_kategori['NAMA_KATEGORI']; ?></td>
    </tr>
    </table>
    <table border="0" cellspacing="0" style="width: 100%; border-color:#903; border:thin; padding: 0 10px 0 55px;">
    <?
	$qry_group="select * from ak_group_perk where ID_KATEGORI_GROUP='". $rows_kategori['ID_KATEGORI']."' ";
	$rs_group=mysql_query($qry_group);
	while($rows_group=mysql_fetch_array($rs_group))
	{
	?>
<!--    	<table border="0" cellspacing="0" style="width: 100%; font-size:16px; padding: 0 0 0 35px;">
        <tr>
        	<td><? //echo $rows_group['NAMA_GROUP']; ?></td>
        </tr>
        </table>
-->
        <?
		$qry_subgroup="select * from ak_subgroup_perk where ID_GROUP_SUBGROUP='". $rows_group['KODE_GROUP']."' ";
		$rs_subgroup=mysql_query($qry_subgroup);
		while($rows_subgroup=mysql_fetch_array($rs_subgroup))
		{
		?>
<!--        <table border="0" cellspacing="0" style="width: 100%; font-size:15px; padding: 0 0 0 45px;">
        <tr>
        	<td style="width:55%; "><? //echo $rows_subgroup['NAMA_SUBGROUP']; ?></td>
        </tr>
        </table>
-->

            
            <?
			$qry_perk="select * from ak_detail_perk where ID_SUBGROUP_DETAIL='".$rows_subgroup['KODE_SUBGROUP']."'";
			$rs_perk=mysql_query($qry_perk);
			
			while($rows_perk=mysql_fetch_array($rs_perk))
			{
				$cek=0;
				
				$saldo1='0';
				$saldo2='0';
				$total1='0';
				$total2='0';
				$qry_saldo="select * from ak_saldo_awal where ID_DETAIL='".$rows_perk['ID_DETAIL']."' and ID_UNIT='".$unit."'";
				$row_saldo=mysql_fetch_array(mysql_query($qry_saldo));
				if($row_saldo['JUMLAH']) 
				{ 
					if($rows_kategori['ID_KATEGORI']==1) { $saldo1=$row_saldo['JUMLAH']; }
					if($rows_kategori['ID_KATEGORI']==2) { $saldo2=$row_saldo['JUMLAH']; }
				}
				$tgl_saldo_awal=$row_saldo['TANGGAL'];
				
				$qry_kasbank="select * from ak_kasbank where PERK_KASBANK='".$rows_perk['ID_DETAIL']."' and TANGGAL between '".$tgl_saldo_awal."' and '".$tgl_sld_akhir."' and UNIT_KODE='".$unit."' ";
                $rs_kasbank=mysql_query($qry_kasbank);
				while($rows_kasbank=mysql_fetch_array($rs_kasbank))
				{
					$qry_detail = "select * from  ak_detail_kasbank where KASBANK_ID = '".$rows_kasbank['ID']."' and UNIT_KODE='".$unit."' ;";
					$rs_detail = mysql_query($qry_detail);
					while($rows_detail=mysql_fetch_array($rs_detail))
					{
						if($rows_kategori['ID_KATEGORI']==1) { $saldo1=$saldo1+$rows_detail['DEBET']-$rows_detail['KREDIT']; }
						if($rows_kategori['ID_KATEGORI']==2) { $saldo2=$saldo2+$rows_detail['DEBET']-$rows_detail['KREDIT']; }
					}
					$cek++;
				}
				$qry_detailB = "select * from  ak_detail_kasbank where PERK_LAWAN = '".$rows_perk['ID_DETAIL']."' and UNIT_KODE='".$unit."' ;";
				$rs_detailB = mysql_query($qry_detailB);
				while($rows_detailB=mysql_fetch_array($rs_detailB))
				{
					$qry_bbB="select * from ak_kasbank where ID='".$rows_detailB['KASBANK_ID']."' and TANGGAL between '".$tgl_saldo_awal."' and '".$tgl_sld_akhir."' and UNIT_KODE= '".$unit."' ";
					$rs_bbB = mysql_query($qry_bbB);
					while($rows_bbB=mysql_fetch_array($rs_bbB)) 
					{
						if($rows_kategori['ID_KATEGORI']==1) { $saldo1=$saldo1+$rows_detailB['KREDIT']-$rows_detailB['DEBET']; }
						if($rows_kategori['ID_KATEGORI']==2) { $saldo2=$saldo2+$rows_detailB['KREDIT']-$rows_detailB['DEBET']; }
					}
					$cek++;
				}
				
				$qry_jurnal="select * from ak_jurnal where TANGGAL_TRANS between '".$tgl_saldo_awal."' and '".$tgl_sld_akhir."' and UNIT_KODE='".$unit."' ";
				$rs_jurnal=mysql_query($qry_jurnal);
				while($rows_jurnal=mysql_fetch_array($rs_jurnal))
				{
					$qry_jurnal_detail="select * from ak_detail_jurnal where PERK='".$rows_perk['ID_DETAIL']."'; ";
					$rs_jurnal_detail=mysql_query($qry_jurnal);
					while($rows_jurnal_detail=mysql_fetch_array($rs_jurnal_detail))
					{
						if($rows_kategori['ID_KATEGORI']==1) { $saldo1=$saldo1+$rows_jurnal_detail['DEBET']-$rows_jurnal_detail['KREDIT']; }
						if($rows_kategori['ID_KATEGORI']==2) { $saldo2=$saldo2+$rows_jurnal_detail['DEBET']-$rows_jurnal_detail['KREDIT']; }
					}
					$cek++;
				}
				
				$dbt='0';
				$krd='0';
				$qry_kasbank2="select * from ak_kasbank where PERK_KASBANK='".$rows_perk['ID_DETAIL']."' and TANGGAL between '".$tgl_awal."' and '".$tgl_akhir."' and UNIT_KODE='".$unit."' ";
                $rs_kasbank2=mysql_query($qry_kasbank2);
				while($rows_kasbank2=mysql_fetch_array($rs_kasbank2))
				{
					$qry_detail2 = "select * from  ak_detail_kasbank where KASBANK_ID = '".$rows_kasbank2['ID']."' and UNIT_KODE='".$unit."' ;";
					$rs_detail2 = mysql_query($qry_detail2);
					while($rows_detail2=mysql_fetch_array($rs_detail2))
					{
						$dbt=$dbt+$rows_detail2['DEBET'];
						$krd=$krd+$rows_detail2['KREDIT'];
					}
					$cek++;
				}
				$qry_detailA = "select * from  ak_detail_kasbank where PERK_LAWAN = '".$rows_perk['ID_DETAIL']."' and UNIT_KODE='".$unit."' ;";
				$rs_detailA = mysql_query($qry_detailA);
				while($rows_detailA=mysql_fetch_array($rs_detailA))
				{
					$qry_bbA="select * from ak_kasbank where ID='".$rows_detailA['KASBANK_ID']."' and TANGGAL between '".$tgl_awal."' and '".$tgl_akhir."' and UNIT_KODE= '".$unit."' ";
					$rs_bbA = mysql_query($qry_bbA);
					while($rows_bbA=mysql_fetch_array($rs_bbA)) 
					{
						$dbt=$dbt+$rows_detailA['KREDIT'];
						$krd=$krd+$rows_detailA['DEBET'];
					}
					$cek++;
				}
				$qry_jurnal2="select * from ak_jurnal where TANGGAL_TRANS between '".$tgl_awal."' and '".$tgl_akhir."' and UNIT_KODE='".$unit."' ";
				$rs_jurnal2=mysql_query($qry_jurnal2);
				while($rows_jurnal2=mysql_fetch_array($rs_jurnal2))
				{
					$qry_jurnal_detail2="select * from ak_detail_jurnal where PERK='".$rows_perk['ID_DETAIL']."'; ";
					$rs_jurnal_detail2=mysql_query($qry_jurnal2);
					while($rows_jurnal_detail2=mysql_fetch_array($rs_jurnal_detail2))
					{
						$dbt=$dbt+$rows_jurnal_detail2['DEBET'];
						$krd=$krd+$rows_jurnal_detail2['KREDIT'];
					}
					$cek++;
				}
				
				if($rows_kategori['ID_KATEGORI']==1 || $rows_kategori['ID_KATEGORI']==5 || $rows_kategori['ID_KATEGORI']==6 ) { $total1=$saldo1+$dbt-$krd; }
				if($rows_kategori['ID_KATEGORI']==2) { $total2=$saldo2-$dbt+$krd; }
				
				if($cek!=0)
				{
			?>
            <tr>
            	<td style="width:33%; "><? echo $rows_perk['NAMA_DETAIL']; ?></td>
                <td align="right" style="width:11%; "><? if($saldo1==0) { echo "-"; } else { echo cFormat($saldo1,false) ; } ?></td>
                <td align="right" style="width:11%; "><? if($saldo2==0) { echo "-"; } else { echo cFormat($saldo2,false) ; } ?></td>
                <td align="right" style="width:11%; "><? echo cFormat($dbt,false) ; ?></td>
                <td align="right" style="width:11%; "><? echo cFormat($krd,false) ; ?></td>
                <td align="right" style="width:11%; "><? echo cFormat($total1,false) ; ?></td>
                <td align="right" style="width:11%; "><? echo cFormat($total2,false) ; ?></td>
            </tr>
            <?
				}
				
				$total_saldo1=$total_saldo1+$saldo1;
				$total_saldo2=$total_saldo2+$saldo2;
				$total_dbt=$total_dbt+$dbt;
				$total_krd=$total_krd+$krd;
				$total_total1=$total_total1+$total1;
				$total_total2=$total_total2+$total2;
			}
			?>
            
            
        <?
		}
    }
    ?>
    </table>
<?
}
$akhir=$total_total2-$total_total1;
?>
<table border="0" cellspacing="0" style="width: 100%; border-color:#903; border:thin; padding: 0 19px 0 25px;">
<tr style="margin-top:10px;">
    <td style="width: 100%; color: #444444; text-align:right; border-bottom:thin;" colspan="7"></td>
</tr>
<tr>
    <td align="center" style="width:33%; ">Total :</td>
    <td align="right" style="width:11%; "><? echo cFormat($total_saldo1,false) ; ?></td>
    <td align="right" style="width:11%; "><? echo cFormat($total_saldo2,false) ; ?></td>
    <td align="right" style="width:11%; "><? echo cFormat($total_dbt,false) ; ?></td>
    <td align="right" style="width:11%; "><? echo cFormat($total_krd,false) ; ?></td>
    <td align="right" style="width:11%; "><? echo cFormat($total_total1,false) ; ?></td>
    <td align="right" style="width:11%; "><? echo cFormat($total_total2,false) ; ?></td>
</tr>
<tr>
    <td colspan="6" align="center" style="width:33%; ">Total :</td>
    <td align="right" style="width:11%; "><? echo cFormat($akhir,false) ; ?></td>
</tr>
</table>