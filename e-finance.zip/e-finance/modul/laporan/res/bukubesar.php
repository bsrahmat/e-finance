<?php
require_once '../../library/connectionmysql.php';
Connected();

$unit= $_GET['unit'];
$perk = $_GET['perkawal'];
$tgl_awal = cDateR($_GET['tgl_awal']);
$tgl_akhir = cDateR($_GET['tgl_akhir']);

$saldo_awal=0;

$qry_saldo_awal="select * from ak_saldo_awal where ID_DETAIL='".$perk."' and ID_UNIT='".$unit."'";
$row_saldo_awal=mysql_fetch_array(mysql_query($qry_saldo_awal));

$saldo_awal=$row_saldo_awal['JUMLAH'];
$saldo_tanggal=$row_saldo_awal['TANGGAL'];

$t=explode('-',$tgl_awal);

$tgl= date("d F Y", mktime(0,0,0,date($t[1]),date($t[2])-1,date($t[0]))); 
$bulan=array(1=>'January', 2=>'February', 3=>'March', 4=>'April', 5=>'May', 6=>'June', 7=>'July', 8=>'August', 9=>'September', 10=>'October', 11=>'November', 12=>'December');
$t2=explode(' ',$tgl);
for ($i=1; $i <= 12; $i++)
{
	if($bulan[$i]==$t2[1]) { $bln="0".$i; }
}
$saldo_tanggal2=$t2[2].'-'.$bln.'-'.$t2[0];

$qry_perk="select * from ak_detail_perk where ID_DETAIL='".$perk."'";
$rows_perk = mysql_fetch_array(mysql_query($qry_perk));

$rows_units=mysql_fetch_array(mysql_query("select * from units where id = '".$unit."';"));
if($rows_units['logo'] == '') 
{
	$rows_units['logo'] = 'none.jpg';
}
?>

<table cellspacing="0" style="width: 100%; font-size: 12px; padding:15px 25px 15px 25px;">
		<tr>
			<td style="width: 50%; color: #444444; float:left;"><img style="height:55px;" src="./../../logo/<? echo $rows_units['logo'] ?>" alt="Logo"></td>
            <td style="width: 50%; color: #444444; text-align:right; font:'Times New Roman', Times, serif; font-style:italic; font-size:14px; font-weight:bold;"><? echo strtoupper($rows_units['name']) ?><br />Telp. <? echo $rows_units['phone'] ?><br /> Fax. <? echo $rows_units['fax'] ?></td>
        </tr>
        <tr style="margin-top:10px;">
			<td style="width: 100%; color: #444444; text-align:right; border-bottom:thin;" colspan="2"></td>
        </tr>
</table>

<table cellspacing="0" style="width: 100%; text-align: center;  font-weight:bold; font-style:italic; padding:0 25px 25px 10px;">
    <tr>
		<td style="width: 100%; text-align:center; font-size: 18px;">BUKU BESAR</td>
	</tr>
    <tr>
		<td style="width: 100%; text-align:center;  font-size: 14px;">Periode : <? echo cDate2($tgl_awal) ?> s/d <? echo cDate2($tgl_akhir) ?></td>
	</tr>
       
</table>

<table cellspacing="0" style="width: 100%; font-size: 12px; padding:15px 25px 15px 25px;">
    <tr>
        <td style="width: 10%;"><? echo $rows_perk['KODE_DETAIL'] ?></td>
        <td style="width: 50%;"><? echo $rows_perk['NAMA_DETAIL'] ?></td>
    </tr>
</table>

<table cellspacing="0" style="width: 100%; padding:0 25px 25px 25px;">
	<tr>
    	<td>
        	<table border="0" cellspacing="0" style="width: 100%; border-color:#903; border:thin;">
            	<tr style="text-align:center; font-size:12px; background:#CCC;">
                    <td style="width: 11%;">Tanggal</td>
                    <td align="left" style="width: 28%;">No. Bukti</td>
                    <td align="left" style="width: 30%;">Uraian</td>
                    <td align="right" style="width: 10%;">Debet</td>
                    <td align="right" style="width: 10%;">Kredit</td>
                    <td align="right" style="width: 11%;">Saldo</td>
               	</tr>
                <?
					$qry_saldo="select * from ak_kasbank where PERK_KASBANK='".$perk."' and TANGGAL between '".$saldo_tanggal."' and '".$saldo_tanggal2."' and UNIT_KODE= '".$unit."' ";
					$rs_saldo=mysql_query($qry_saldo);
					while($rows_saldo=mysql_fetch_array($rs_saldo))
					{
						$qry_saldo_detail="select * from  ak_detail_kasbank where KASBANK_ID = '".$rows_saldo['ID']."';";
						$rs_saldo_detail = mysql_query($qry_saldo_detail);
						while($rows_saldo_detail=mysql_fetch_array($rs_saldo_detail))
						{
							$saldo_awal=$saldo_awal+$rows_saldo_detail['DEBET']-$rows_saldo_detail['KREDIT'];
						}
					}
					$qry_saldo2="select * from  ak_detail_kasbank where PERK_LAWAN = '".$perk."' and UNIT_KODE= '".$unit."';";
					$rs_saldo2=mysql_query($qry_saldo2);
					while($rows_saldo2=mysql_fetch_array($rs_saldo2))
					{
						$qry_saldo3="select * from ak_kasbank where ID='".$rows_saldo2['KASBANK_ID']."' and TANGGAL between '2011-06-30' and '".$saldo_tanggal2."' and UNIT_KODE= '".$unit."' ";
						$rs_saldo3 = mysql_query($qry_saldo3);
						while($rows_saldo3=mysql_fetch_array($rs_saldo3)) 
						{
							$saldo_awal=$saldo_awal-$rows_saldo2['DEBET']+$rows_saldo2['KREDIT'];
						}
					}
					
					if($saldo_awal!=0)
					{
				?>
                <tr>
                    <td><? echo cDate2($saldo_tanggal2) ?></td>
                    <td></td>
                    <td>Saldo Awal</td>
                    <td></td>
                    <td></td>
                    <td align="right"><? echo cFormat($saldo_awal,false) ?></td>
               	</tr>
                <?
					}
				?>
                <?php
				$saldo=$saldo_awal;
				$Tdbt='0';
				$Tkrd='0';
				
				$cek1=0;
				$qry_bb="select * from ak_kasbank where PERK_KASBANK='".$perk."' and TANGGAL between '".$tgl_awal."' and '".$tgl_akhir."' and UNIT_KODE= '".$unit."' ";
				$rs_bb = mysql_query($qry_bb);
				while($rows_bb=mysql_fetch_array($rs_bb)) 
				{
					$qry_detailA = "select * from  ak_detail_kasbank where KASBANK_ID = '".$rows_bb['ID']."';";
					$rs_detailA = mysql_query($qry_detailA);
					while($rows_detailA=mysql_fetch_array($rs_detailA))
					{
					?>
						<tr>
							<td><? echo cDate2($rows_bb['TANGGAL']) ?></td>
							<td><? echo $rows_bb['NO_BUKTI'] ?></td>
							<td><? echo $rows_detailA['URAIAN'] ?></td>
							<td align="right">
								<?
									if($rows_detailA['DEBET']!=0) echo cFormat($rows_detailA['DEBET'],false) ;
								?>
							</td>
							<td align="right">
								<?
									if($rows_detailA['KREDIT']!=0) echo cFormat($rows_detailA['KREDIT'],false) ;
								?>
							</td>
							<?
								$saldo=$saldo+$rows_detailA['DEBET']-$rows_detailA['KREDIT'];
								$Tdbt=$Tdbt+$rows_detailA['DEBET'];
								$Tkrd=$Tkrd+$rows_detailA['KREDIT'];
							?>
							<td align="right"><? echo cFormat($saldo,false) ?></td>
						</tr>
                <?
					}
					$cek1++;
				}
				
				$cek2=0;
				$qry_detailB = "select * from  ak_detail_kasbank where PERK_LAWAN = '".$perk."' and UNIT_KODE= '".$unit."';";
				$rs_detailB = mysql_query($qry_detailB);
				while($rows_detailB=mysql_fetch_array($rs_detailB))
				{
					$qry_bbB="select * from ak_kasbank where ID='".$rows_detailB['KASBANK_ID']."' and TANGGAL between '".$tgl_awal."' and '".$tgl_akhir."' and UNIT_KODE= '".$unit."' ";
					$rs_bbB = mysql_query($qry_bbB);
					while($rows_bbB=mysql_fetch_array($rs_bbB)) 
					{
				?>
                		<tr>
                        	<td><? echo cDate2($rows_bbB['TANGGAL']) ?></td>
							<td><? echo $rows_bbB['NO_BUKTI'] ?></td>
							<td><? echo $rows_detailB['URAIAN'] ?></td>
                            <td align="right">
								<?
									if($rows_detailB['KREDIT']!=0) echo cFormat($rows_detailB['KREDIT'],false) ;
								?>
							</td>
							<td align="right">
								<?
									if($rows_detailB['DEBET']!=0) echo cFormat($rows_detailB['DEBET'],false) ;
								?>
							</td>
							<?
								$saldo=$saldo+$rows_detailB['KREDIT']-$rows_detailB['DEBET'];
								$Tdbt=$Tdbt+$rows_detailB['KREDIT'];
								$Tkrd=$Tkrd+$rows_detailB['DEBET'];
							?>
							<td align="right"><? echo cFormat($saldo,false) ?></td>
                        </tr>
                <?
					}
					$cek2++;
				}
				?>
                <tr style="margin-top:10px;">
                    <td style="width: 100%; color: #444444; text-align:right; border-bottom:thin;" colspan="6"></td>
                </tr>
                <tr>
                    <td colspan="3" align="center">Total</td>
                    <td align="right"><? echo cFormat($Tdbt,false) ?></td>
                    <td align="right"><? echo cFormat($Tkrd,false) ?></td>
                    <td align="right"><? echo cFormat($saldo,false) ?></td>
               	</tr>
            </table>
        </td>
    </tr>
</table>