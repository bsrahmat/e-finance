<?php

require_once '../../library/connectionmysql.php';
Connected();
$qry_trporders = "SELECT * FROM trporders LEFT JOIN trprequests ON (trporders.trprequest_id = trprequests.id) LEFT JOIN suppliers ON (trporders.supplier_id = suppliers.id)  WHERE trporders.id = '".$_GET['gid']."';";
$rs_trporders = mysql_query($qry_trporders);
$rows_trporders=mysql_fetch_array($rs_trporders);
$rows_suppliers=mysql_fetch_array(mysql_query("select * from suppliers where id = '".$rows_trporders['supplier_id']."';"));

$rows_units=mysql_fetch_array(mysql_query("select * from units where id = '".$rows_trporders['unitid']."';"));
if($rows_units['logo'] == '') {
	$rows_units['logo'] = 'none.jpg';
}
?>

	<table cellspacing="0" style="width: 100%; font-size: 12px; padding:15px 25px 15px 25px;">
		<tr>
			<td style="width: 50%; color: #444444; float:left;"><img style="height:55px;" src="./../../logo/<? echo $rows_units['logo'] ?>" alt="Logo"></td>
            <td style="width: 50%; color: #444444; text-align:right; font:'Times New Roman', Times, serif; font-style:italic; font-size:14px; font-weight:bold;"><? echo strtoupper($rows_units['name']) ?><br />Telp. <? echo $rows_units['phone'] ?><br /> Fax. <? echo $rows_units['fax'] ?></td>
        </tr>
        <tr style="margin-top:10px;">
			<td style="width: 100%; color: #444444; text-align:right; border-bottom:thin;" colspan="2"></td>
        </tr>
    </table>
    
    <table cellspacing="0" style="width: 100%; text-align: center;  font-weight:bold; font-style:italic; padding:0 25px 25px 10px;">
    <tr>
	<td style="width: 100%; text-align:center; font-size: 18px;">PURCHASE ORDER</td>
	</tr>
    <tr>
	<td style="width: 100%; text-align:center;  font-size: 14px;">No. <? echo $rows_trporders['ponom'] ?></td>
	</tr>
    <tr>
	<td style="width: 100%; text-align:center;  font-size: 14px;">Tgl. <? echo cDate2($rows_trporders['podate']) ?></td>
	</tr>
    <tr>
	<td style="width: 100%; text-align:center;  font-size: 14px;">Kirim. <? echo cDate2($rows_trporders['posend']) ?></td>
	</tr>
    </table>
    
    <table cellspacing="0" style="width: 100%; font-size: 12px; padding:0 25px 15px 25px;">
		<tr>
			<td style="width: 63%; color: #444444;">Kepada Yth:</td>
            <td style="width: 37%; color: #444444;">Kirim Kepada:</td>
        </tr>
        <tr>
            <td><? echo $rows_suppliers['name'] ?></td>
            <td><? echo $rows_units['name'] ?></td>
        </tr>
        <tr>
            <td><? echo $rows_suppliers['upname'] ?></td>
            <td></td>
        </tr>
        <tr>
            <td><? echo $rows_suppliers['phone'] ?></td>
            <td><? echo $rows_units['phone'] ?></td>
        </tr>
        <tr>
            <td><? echo $rows_suppliers['fax'] ?></td>
            <td><? echo $rows_units['fax'] ?></td>
        </tr>
    </table>
    
    <table cellspacing="0" style="width: 100%; padding:0 25px 25px 25px;">
    <tr>
	<td>
     <table border="0.3" cellspacing="0" style="width: 100%; border-color:#903; border:thin;">
     
      <tr style="text-align:center; font-size:12px; background:#CCC;">
		<td style="width: 5%; height:15px;">No</td>
		<td style="width: 32%;">Nama Barang</td>
		<td style="width: 7%;">Qty</td>
		<td style="width: 11%;">Satuan</td>
        <td style="width: 15%;">Harga<br />Satuan</td>
        <td style="width: 15%;">PPn</td>
        <td style="width: 15%;">Jumlah</td>
        
	  </tr>
      <?php
		$qry_trpodetails = "select * from trpodetails JOIN items ON ( trpodetails.item_id = items.id) where trporder_id = '".$_GET['gid']."';";
		$rs_trpodetails = mysql_query($qry_trpodetails);
		$no= 1;
		$subtotal = '0';
		while($rows_trpodetails=mysql_fetch_array($rs_trpodetails)) {
		$rows_satuan=mysql_fetch_array(mysql_query("select * from pieces where id = '".$rows_trpodetails['piece_id']."';"));
		$t_harga = $rows_trpodetails['qty'] * $rows_trpodetails['price'];
		$t_ppn = $rows_trpodetails['tax'] * $rows_trpodetails['qty'];
		$total = $t_harga + $t_ppn ;
		
	  ?>
      <tr style="font-size:10px";>
		<td style="height:10px;" align="right"><? echo $no ?></td>
		<td><? echo $rows_trpodetails['name'] ?></td>
		<td align="right"><? echo cFormat($rows_trpodetails['qty'],false) ?></td>
		<td align="center"><? echo $rows_satuan['name'] ?></td>  
        <td align="right"><? echo cFormat($rows_trpodetails['price'],false) ?></td>
        <td align="right"><? echo cFormat($t_ppn,false) ?></td>
        <td align="right"><? echo cFormat($total,false) ?></td>                          
	 </tr>
     <?php
	 	$subtotal = $subtotal + $total;
		$no++;
		}
	?>
    </table>
    <table border="0" cellspacing="0" style="width: 100%; padding:15px 0 0 0;"" >
      <tr>
		<td style="width: 40%; height:15px; height:20px;">Pembayaran :</td>
		<td style="width: 40%; font-weight:bold; text-align:right;">Rp.</td>
		<td style="width: 20%; font-weight:bold; text-align:right"><? echo cFormat($subtotal,false) ?></td>
	  </tr>
      <tr>
		
		<td style="font-style:italic; font-size:10px; text-align:right;" colspan="3">Terbilang : <? echo cSays($subtotal) ?> Rupiah</td>
		
	  </tr>
     </table>
    </td>
    </tr>
    </table>
    <table cellspacing="0" style="width: 100%; font-size: 12px; padding:15px 25px 15px 25px;">
		<tr>
			<td style="width: 40%; color: #444444; text-align:left;">Menyetujui,</td>
            
            <td style="width: 20%; color: #444444; text-align:left;">Disetujui,,</td>
            <td style="width: 20%; color: #444444; text-align:left;">Mengetahui,</td>
            <td style="width: 20%; color: #444444; text-align:left;">Dipesan Oleh,</td>
        </tr>

        <tr>
        	<td style="width: 40%; color: #444444; text-align:center;  height:60px;"></td>
            <td style="width: 20%; text-align:left; "><? if($rows_trporders[6] == '1') { echo accTTD(1); }?></td>
            <td style="width: 20%; text-align:left; "><? if($rows_trporders[6] == '1') { echo accTTD(2); }?></td>
			<td style="width: 20%; text-align:left; "><? if($rows_trporders[6] == '1') { echo accTTD(3); }?></td>
            
        </tr>
        <tr>
			<td style="width: 40%; color: #444444; text-align:left; font-weight:bold;">( <u><? echo $rows_trporders['name'] ?></u> )</td>
            <td style="width: 20%; color: #444444; text-align:left; font-weight:bold;"> ( <u><? if($rows_trporders[6] == '1') { echo nMdSb(); }?></u> ) </td>
            <td style="width: 20%; color: #444444; text-align:left; font-weight:bold;"> ( <u><? if($rows_trporders[6] == '1') { echo nFinance(); }?></u> ) </td>
            <td style="width: 20%; color: #444444; text-align:left; font-weight:bold;"> ( <u><? if($rows_trporders[6] == '1') { echo nPurchasing(); }?></u> ) </td>
        </tr>
        <tr>
			<td style="width: 40%; color: #444444; text-align:left; font-weight:bold;">Supplier</td>
            <td style="width: 20%; color: #444444; text-align:left; font-weight:bold;">MD. SBC</td>
            <td style="width: 20%; color: #444444; text-align:left; font-weight:bold;">Finance</td>
            <td style="width: 20%; color: #444444; text-align:left; font-weight:bold;">Purchasing
</td>
        </tr>
    </table>
    <table border="0" cellspacing="0" style="width: 100%; padding:15px 0 0 0; font-style:italic;"" >
      <tr>
		<td style="width: 5%; text-align:right;">1.</td>
		<td style="width: 95%; text-align:left">Apabila Barang yang dikirim tidak sesuai order, maka barang akan kami kembalikan</td>
	  </tr>
      <tr>
		<td style="width: 5%; text-align:right;">2.</td>
		<td style="width: 95%; text-align:left">Mohon pengiriman sesuai dengan jadwal</td>
	  </tr>
      <tr>
		<td style="width: 5%; text-align:right;">3.</td>
		<td style="width: 95%; text-align:left">Apabila disetujui mohon ditandatangani dan di kirim kembali ke SINAR BARU</td>
	  </tr>
      
     </table>