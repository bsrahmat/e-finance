<?php
require_once '../../library/connectionmysql.php';
Connected();

$qry_kasbank="select * from ak_kasbank where id='".$_GET['gid']."'";
$rs_kasbank=mysql_query($qry_kasbank);
$row_kasbank=mysql_fetch_array($rs_kasbank);
$trans=$row_kasbank['JNS_TRANS'];

$qry_detail="select * from ak_detail_kasbank where KASBANK_ID='".$_GET['gid']."' ";
$rs_detail=mysql_query($qry_detail);

$rows_units=mysql_fetch_array(mysql_query("select * from units where id = '".$row_kasbank['UNIT_KODE']."';"));
if($rows_units['logo'] == '') 
{
	$rows_units['logo'] = 'none.jpg';
}
?>

<table cellspacing="0" style="width: 100%; font-size: 12px; padding:15px 25px 15px 25px;">
		<tr>
			<td style="width: 50%; color: #444444; float:left;"><img style="height:55px;" src="./../../logo/<? echo $rows_units['logo'] ?>" alt="Logo"></td>
            <td style="width: 50%; color: #444444; text-align:right; font:'Times New Roman', Times, serif; font-style:italic; font-size:14px; font-weight:bold;"><? echo strtoupper($rows_units['name']) ?><br />Telp. <? echo $rows_units['phone'] ?><br /> Fax. <? echo $rows_units['fax'] ?></td>
        </tr>
        <tr style="margin-top:10px;">
			<td style="width: 100%; color: #444444; text-align:right; border-bottom:thin;" colspan="2"></td>
        </tr>
    </table>

<table cellspacing="0" style="width: 100%; text-align: center;  font-weight:bold; font-style:italic; padding:0 25px 25px 10px;">
    <tr>
		<td style="width: 100%; text-align:center; font-size: 18px;">
        <?
		if($trans=='KM') echo "BUKTI KAS MASUK";
    	if($trans=='KK') echo "BUKTI KAS KELUAR";
		if($trans=='BM') echo "BUKTI BANK MASUK";
    	if($trans=='BK') echo "BUKTI BANK KELUAR";
		
		if($trans=='HK') echo "BUKTI HUTANG KAS";
		if($trans=='HB') echo "BUKTI HUTANG BANK";
		if($trans=='PK') echo "BUKTI PIUTANG KAS";
		if($trans=='PB') echo "BUKTI PIUTANG BANK";
		?>
    	</td>
	</tr>
    <tr>
		<td style="width: 100%; text-align:center;  font-size: 14px;">No. <? echo $row_kasbank['NO_BUKTI'] ?></td>
	</tr>
    <tr>
		<td style="width: 100%; text-align:center;  font-size: 14px;">Tgl. <? echo cDate2($row_kasbank['TANGGAL']) ?></td>
	</tr>
    
    </table>

<table cellspacing="0" style="width: 100%; padding:0 25px 25px 25px;">
    <tr>
    	<td>
        	<table border="0.3" cellspacing="0" style="width: 100%; border-color:#903; border:thin;">
            	<tr style="text-align:center; font-size:12px; background:#CCC;">
                    <td style="width: 5%; height:15px;">No</td>
                    <td style="width: 15%;">Kode Perkiraan</td>
                    <td style="width: 65%;">Keterangan</td>
                    <td style="width: 15%;">Jumlah</td>
               	</tr>
                <?php
				$no= 1;
				$total = '0';
				while($rows_detail=mysql_fetch_array($rs_detail)) 
				{
				?>
                <tr style="font-size:12px";>
                	<td align="center"><? echo $no?></td>
                    <?
                        $qry_lawan="select * from ak_detail_perk where ID_DETAIL = '".$rows_detail['PERK_LAWAN']."';";
                        $row_lawan=mysql_fetch_array(mysql_query($qry_lawan));
                    ?>
                    <td align="center"><? echo $row_lawan['KODE_DETAIL']?></td>
                    <td align="left"><? echo $rows_detail['URAIAN']?></td>
                    <td align="right">
                    <? 
                        if($rows_detail['DEBET']!='0.00') { echo cFormat($rows_detail['DEBET'],false); $angka=$rows_detail['DEBET'];}
                        else { echo cFormat($rows_detail['KREDIT'],false); $angka=$rows_detail['KREDIT'];}
                    ?>
                    </td>
                    
                </tr>
                <?
					$total=$total+$angka;
					$no++;
				}
				?>
        	</table>
            <?
			$qry_perk="select * from ak_detail_perk where ID_DETAIL = '".$row_kasbank['PERK_KASBANK']."';";
			$row_perk=mysql_fetch_array(mysql_query($qry_perk));
            ?>
            <table border="0" cellspacing="0" style="width: 100%; border-color:#903; border:thin; padding:5px 0 0 0;">
              <tr>
                <td>Kas/Bank :</td>
                <td><? echo $row_perk['NAMA_DETAIL'] ?></td>
              </tr>
            </table>
            <table border="0" cellspacing="0" style="width: 100%; padding:15px 0 0 0;"" >
              <tr>
                <td style="width: 70%; height:15px; height:20px; text-align:right;">TOTAL :</td>
                <td style="width: 10%; font-weight:bold; text-align:right;">Rp.</td>
                <td style="width: 20%; font-weight:bold; text-align:right"><? echo cFormat($total,false) ?></td>
              </tr>
              <tr>
                
                <td style="font-style:italic; font-size:10px; text-align:right;" colspan="3">Terbilang : <? echo cSays($total) ?> Rupiah</td>
                
              </tr>
          </table>
        </td>
    </tr>
</table>

<table cellspacing="0" style="width: 100%; font-size: 12px; padding:15px 25px 15px 25px;">
    <tr style="font-weight:bold;">
        <td style="width: 20%; color: #444444; text-align:center;">Diperiksa oleh:</td>
        <td style="width: 20%; color: #444444; text-align:center;">Dibukukan oleh:</td>
        <td style="width: 20%; color: #444444; text-align:center;">Disetujui oleh:</td>
        <td style="width: 20%; color: #444444; text-align:center;">Dibuat oleh:</td>
        <td style="width: 20%; color: #444444; text-align:center;">Diterima oleh:</td>
    </tr><br />
<br />

    <tr>
        <td style="width: 40%; color: #444444; text-align:center;  height:60px;" colspan="3"></td>
        
    </tr>
    <tr>
        <td style="color: #444444; text-align:center; font-weight:bold;">( <u><? echo "_______________" ?></u> )</td>
        <td style="color: #444444; text-align:center; font-weight:bold;"> ( <u><? echo "_______________" ?></u> ) </td>
        <td style="color: #444444; text-align:center; font-weight:bold;"> ( <u><? echo "_______________" ?></u> ) </td>
        <td style="color: #444444; text-align:center; font-weight:bold;"> ( <u><? echo "_______________" ?></u> ) </td>
        <td style="color: #444444; text-align:center; font-weight:bold;"> ( <u><? echo "_______________" ?></u> ) </td>
    </tr>
</table>
