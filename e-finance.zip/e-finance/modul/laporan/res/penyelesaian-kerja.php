<?php

require_once '../../library/connectionmysql.php';
Connected();
$qry_wends = "SELECT wends.id, wends.worder_id, wends.wenom, wends.fakturnom, wends.wedate, wends.description, wends.postby, wends.postdate, wends.isposted, wends.prname, wends.unitid, wends.isclosed, wends.refnom, wends.id, worders.id, worders.wodate, worders.wonom, worders.unit_id, worders.isclosed, worders.supplier_id, worders.gmsign FROM wends LEFT JOIN worders ON (wends.worder_id = worders.id)  WHERE wends.id = '".$_GET['gid']."';";
$rs_wends = mysql_query($qry_wends);
$rows_wends=mysql_fetch_array($rs_wends);
$rows_suppliers=mysql_fetch_array(mysql_query("select * from suppliers where id = '".$rows_wends['supplier_id']."';"));

$rows_units=mysql_fetch_array(mysql_query("select * from units where id = '".$rows_wends['unitid']."';"));
if($rows_units['logo'] == '') {
	$rows_units['logo'] = 'none.jpg';
}
?>

	<table cellspacing="0" style="width: 100%; font-size: 12px; padding:15px 25px 15px 25px;">
		<tr>
			<td style="width: 50%; color: #444444; float:left;"><img style="height:55px;" src="./../../logo/<? echo $rows_units['logo'] ?>" alt="Logo"></td>
            <td style="width: 50%; color: #444444; text-align:right; font:'Times New Roman', Times, serif; font-style:italic; font-size:14px; font-weight:bold;"><? echo strtoupper($rows_units['name']) ?><br />Telp. <? echo $rows_units['phone'] ?><br /> Fax. <? echo $rows_units['fax'] ?></td>
        </tr>
        <tr style="margin-top:10px;">
			<td style="width: 100%; color: #444444; text-align:right; border-bottom:thin;" colspan="2"></td>
        </tr>
    </table>
    
    <table cellspacing="0" style="width: 100%; text-align: center;  font-weight:bold; font-style:italic; padding:0 25px 25px 10px;">
    <tr>
	<td style="width: 100%; text-align:center; font-size: 18px;">PENYELESAIAN KERJA</td>
	</tr>
    <tr>
	<td style="width: 100%; text-align:center;  font-size: 14px;">No. <? echo $rows_wends['wenom'] ?></td>
	</tr>
    <tr>
	<td style="width: 100%; text-align:center;  font-size: 14px;">Tgl. <? echo cDate2($rows_wends['wedate']) ?></td>
	</tr>
    
    </table>
    
    <table cellspacing="0" style="width: 100%; font-size: 12px; padding:0 25px 15px 25px;">
		<tr>
			<td style="width: 17%; color: #444444;">Pelaksana</td>
            <td style="width: 1%; color: #444444;">:</td>
          <td style="width: 42%; color: #444444;"><? echo $rows_suppliers['name'] ?></td>
          <td style="width: 40%; color: #444444; border:1px 1px 1px 1px" rowspan="2">No. Order Kerja : <? echo $rows_wends['wonom'] ?><br />Tgl. Order Kerja : <? echo cDate2($rows_wends['wodate']) ?></td>
            
      </tr>
        <tr>
			<td>No Faktur</td>
            <td>:</td>
            <td><? echo $rows_wends['refnom'] ?></td>
            
        </tr>
        <tr>
        	<td>Alamat</td>
            <td>:</td>
            <td colspan="2"><? echo $rows_suppliers['address'] ?>, <? echo $rows_suppliers['city'] ?></td>
            
        </tr>
    </table>
    
    <table cellspacing="0" style="width: 100%; padding:0 25px 25px 25px;">
    <tr>
	<td>
     <table border="0.3" cellspacing="0" style="width: 100%; border-color:#903; border:thin;">
     
      <tr style="text-align:center; font-size:12px; background:#CCC;">
		<td style="width: 5%; height:15px;">No</td>
		<td style="width: 65%;">Nama Pekerjaan</td>
		<td style="width: 15%;">Biaya</td>
        <td style="width: 15%;">Utang Dagang</td>
	  </tr>
      <?php
		$qry_wedetails = "select * from wedetails JOIN items ON ( wedetails.item_id = items.id) where wend_id = '".$_GET['gid']."';";
		$rs_wedetails = mysql_query($qry_wedetails);
		$no= 1;
		$subtotal = '0';
		while($rows_wedetails=mysql_fetch_array($rs_wedetails)) {
	  ?>
      <tr style="font-size:10px";>
		<td style="height:10px;" align="right"><? echo $no ?></td>
		<td><? echo $rows_wedetails['name'] ?></td>
        <td align="right"><? echo cFormat($rows_wedetails['hpp'],false) ?></td>
		<td align="right"><? echo cFormat($rows_wedetails['debt'],false) ?></td>
	 </tr>
     <?php
	 $subtotal = $subtotal + $rows_wedetails['debt'];
		$no++;
		}
	?>
    </table>
    <table border="0" cellspacing="0" style="width: 100%; padding:15px 0 0 0;"" >
      <tr>
		<td style="width: 70%; height:15px; height:20px; text-align:right;">TOTAL :</td>
		<td style="width: 10%; font-weight:bold; text-align:right;">Rp.</td>
		<td style="width: 20%; font-weight:bold; text-align:right"><? echo cFormat($subtotal,false) ?></td>
	  </tr>
      <tr>
		
		<td style="font-style:italic; font-size:10px; text-align:right;width: 100%;" colspan="3">Terbilang : <? echo cSays($subtotal) ?> Rupiah</td>
		
	  </tr>
     </table>
    </td>
    </tr>
    </table>
    <table cellspacing="0" style="width: 100%; font-size: 12px; padding:15px 25px 15px 25px;">
		<tr>
			<td style="width: 35%; color: #444444; text-align:center;">Pelaksana</td>
            <td style="width: 30%; color: #444444; text-align:center;"><? if($rows_wends[11]=='1') {?>Bag. Purchasing<? }?></td>
            <td style="width: 35%; color: #444444; text-align:center;"><? if($rows_wends[8]=='1') {?>Bag. Akunting<? }?></td>
        </tr><br />
<br />

        <tr>
			<td style="width: 40%; color: #444444; text-align:center;  height:60px;"></td>
            
            <td style="width: 20%; text-align:center;"><? if($rows_wends[11]=='1') {?> <? echo accTTD(3); ?><? }?></td>
            <td style="width: 40%; text-align:center;"><? if($rows_wends[8]=='1') {?> <? echo accTTD(5); ?><? }?></td>
            
        </tr>
        <tr>
			<td style="color: #444444; text-align:center; font-weight:bold;">( <u><? echo $rows_suppliers['name'] ?></u> )</td>
            <td style="color: #444444; text-align:center; font-weight:bold;"><? if($rows_wends[11]=='1') {?>( <u><? echo nPurchasing(); ?></u> )<? }?></td>
            <td style="color: #444444; text-align:center; font-weight:bold;"><? if($rows_wends[8]=='1') {?>( <u><? echo nAkunting(); ?></u> )<? }?></td>
        </tr>
    </table>