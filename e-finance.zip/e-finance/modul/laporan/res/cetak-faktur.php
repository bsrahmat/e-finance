<?php

require_once '../../library/connectionmysql.php';
Connected();
$qry_fakturs = "SELECT fakturs.id, fakturs.isclosed, fakturs.sj_id, fakturs.fakdate, fakturs.faknom, fakturs.unitid, fakturs.tempodate, fakturs.ispost, fakturs.post, sjs.id, sjs.spb_id, sjs.sjdate, sjs.sjnom, sjs.unitid, sjs.isclosed, sjs.istaken, sjs.warehouse_id, sjs.jtdate, spbs.spbnom, spbs.spbdate FROM fakturs LEFT JOIN sjs ON (fakturs.sj_id = sjs.id) LEFT JOIN spbs ON (sjs.spb_id = spbs.id) WHERE fakturs.id = '".$_GET['gid']."';";
$rs_fakturs = mysql_query($qry_fakturs);
$rows_fakturs=mysql_fetch_array($rs_fakturs);
$rows_customers=mysql_fetch_array(mysql_query("select spbs.id, spbs.customer_id, spbs.spbnom, customers.id, customers.name, customers.address from spbs LEFT JOIN  customers ON (spbs.customer_id =  customers.id) where  spbs.id = '".$rows_fakturs['spb_id']."';"));
//$rows_suppliers=mysql_fetch_array(mysql_query("select * from suppliers where id = '".$rows_fakturs['supplier_id']."';"));

$rows_units=mysql_fetch_array(mysql_query("select * from units where id = '".$rows_fakturs['unitid']."';"));
if($rows_units['logo'] == '') {
	$rows_units['logo'] = 'none.jpg';
}
?>

	<table cellspacing="0" style="width: 100%; font-size: 12px; padding:15px 25px 15px 25px;">
		<tr>
			<td style="width: 50%; color: #444444; float:left;"><img style="height:55px;" src="./../../logo/<? echo $rows_units['logo'] ?>" alt="Logo"></td>
            <td style="width: 50%; color: #444444; text-align:right; font:'Times New Roman', Times, serif; font-style:italic; font-size:14px; font-weight:bold;"><? echo strtoupper($rows_units['name']) ?><br />Telp. <? echo $rows_units['phone'] ?><br /> Fax. <? echo $rows_units['fax'] ?></td>
        </tr>
        <tr style="margin-top:10px;">
			<td style="width: 100%; color: #444444; text-align:right; border-bottom:thin;" colspan="2"></td>
        </tr>
    </table>
    
    <table cellspacing="0" style="width: 100%; text-align: center;  font-weight:bold; font-style:italic; padding:0 25px 25px 10px;">
    <tr>
	<td style="width: 100%; text-align:center; font-size: 18px;">FAKTUR</td>
	</tr>
    <tr>
	<td style="width: 100%; text-align:center;  font-size: 14px;">No. <? echo $rows_fakturs['faknom'] ?></td>
	</tr>
    </table>
    
    <table cellspacing="0" style="width: 100%; font-size: 12px; padding:0 25px 15px 25px;">
		<tr>
			<td style="width: 50%; color: #444444;">Kepada YTH:</td>
            <td style="width: 25%; color: #444444; border:0.5px 0.5px 0.5px 0.5px;" rowspan="3">No. SPB :<br /><? echo $rows_fakturs['spbnom'] ?><br />Tgl SPB : <? echo cDate2($rows_fakturs['spbdate']) ?></td>
            <td style="width: 25%; color: #444444; border:0.5px 0.5px 0.5px 0.5px;" rowspan="3">No. SJ :<br /><? echo $rows_fakturs['sjnom'] ?><br />Tgl SJ : <? echo cDate2($rows_fakturs['sjdate']) ?></td>
        </tr>
        <tr>
            <td>( <? echo $rows_customers['name'] ?> )</td>
        </tr>
        <tr>
            <td><? echo $rows_customers['address'] ?></td>
        </tr>
        
    </table>
    
    <table cellspacing="0" style="width: 100%; padding:0 25px 25px 25px;">
    <tr>
	<td>
     <table border="0.3" cellspacing="0" style="width: 100%; border-color:#903; border:thin;">
     
      <tr style="text-align:center; font-size:12px; background:#CCC;">
		<td style="width: 5%; height:15px;">No</td>
		<td style="width: 35%;">Nama Barang</td>
		<td style="width: 10%;">Qty</td>
		<td style="width: 10%;">Satuan</td>
        <td style="width: 10%;">Harga</td>
        <td style="width: 10%;">Disc</td>
        <td style="width: 10%;">PPN</td>
        <td style="width: 10%;">Total</td>
	  </tr>
      <?php
		$qry_fakdetails = "select * from fakdetails JOIN items ON ( fakdetails.item_id = items.id) where faktur_id = '".$_GET['gid']."';";
		//mysql_query("select * from  tbl_permissions where admin_kode = '".$_SESSION['galaxy_kode']."' and menu_kode = '".$rows_menu['menu_kode']."'");
		$qry_cek = mysql_query("select * from fakdetails JOIN items ON ( fakdetails.item_id = items.id) where faktur_id = '".$_GET['gid']."'AND ppnperitem != 0.00");
		$cnt_cek = mysql_num_rows($qry_cek);
		
		$rs_fakdetails = mysql_query($qry_fakdetails);
		$no= 1;
		$subtotal = '0';
		while($rows_fakdetails=mysql_fetch_array($rs_fakdetails)) {
		$rows_satuan=mysql_fetch_array(mysql_query("select * from pieces where id = '".$rows_fakdetails['piece_id']."';"));
		$total = $rows_fakdetails['qty'] * ($rows_fakdetails['price'] - $rows_fakdetails['disc'] + $rows_fakdetails['ppnperitem']);
						
		?>
      <tr style="font-size:10px";>
		<td style="height:10px;" align="right"><? echo $no ?></td>
		<td><? echo $rows_fakdetails['name'] ?></td>
		<td align="right"><? echo cFormat($rows_fakdetails['qty'],false) ?></td>
		<td align="center"><? echo $rows_satuan['name'] ?></td>  
        <td align="right"><? echo cFormat($rows_fakdetails['price'],false) ?></td>
        <td align="right"><? echo cFormat($rows_fakdetails['disc'],false) ?></td>
        <td align="right"><? echo cFormat($rows_fakdetails['ppnperitem'],false) ?></td>
        <td align="right"><? echo cFormat($total,false) ?></td>                          
	 </tr>
     <?php
	 	$subtotal = $subtotal + $total;
		$no++;
		}
	?>
    </table>
    <table border="0" cellspacing="0" style="width: 100%; padding:3px 0 0 0;"" >
      <tr>
		<td style="width: 23%; text-align:center; border:0.5px 0.5px 0.5px 0.5px;">Tgl Jatuh Tempo</td>
        <td style="width: 22%; text-align:center; border:0.5px 0.5px 0.5px 0.5px;"><? echo cDate2($rows_fakturs['tempodate']) ?></td>
        <td style="width: 10%;"></td>
		<td style="width: 30%; font-weight:bold; text-align:right;">Jumlah Harga : Rp.</td>
		<td style="width: 15%; font-weight:bold; text-align:right"><? echo cFormat($subtotal,false) ?></td>
	  </tr>
      
     </table>
     <table border="0" cellspacing="0" style="width: 100%; padding:3px 0 0 0;"" >
      <tr>
		<td style="width: 100%; font-style:italic; font-size:11px; text-align:left; border:0.5px 0.5px 0.5px 0.5px; height:15px;">Terbilang : <? echo cSays($subtotal) ?> Rupiah</td>
		
	  </tr>
     </table>
    </td>
    </tr>
    </table>
    <table cellspacing="0" style="width: 100%; font-size: 12px; padding:15px 25px 15px 25px;">
		<tr>
			<td style="width: 40%; color: #444444; text-align:center;">Surabaya, <? echo cDate2($rows_fakturs['sjdate']) ?> </td>
            <td style="width: 60%; color: #444444; text-align:left; border:0.5px 0.5px 0.5px 0.5px;" rowspan="2">&raquo; Pembayaran mohon di Transfer ke REK: <? if($cnt_cek > 0) { echo $rows_units['rek'] ?> a/n <? echo $rows_units['rekname']; } ?> <? if($cnt_cek <= 0) { echo $rows_units['rek_nonppn'] ?> a/n <? echo $rows_units['rekname_nonppn']; }?><br />&raquo; Pembayaran dianggap Lunas apabila checque/BG telah dicairkan</td>
            
        </tr>
        <tr>
			<td style="width: 40%; color: #444444; text-align:center;">Mengetahui/Menyetujui</td>
        </tr>

        <tr>
			<td style="width: 40%; color: #444444; text-align:center;  height:60px;"><? if($rows_fakturs[1]=='0') { echo accTTD(6); }?></td>
            <td style="width: 40%; text-align:center;"></td>
        </tr>
        <tr>
            <td style="color: #444444; text-align:center; font-weight:bold;"> ( <u><? echo nFam(); ?></u> ) </td>
            <td style="color: #444444; text-align:left; font-weight:bold;"></td>
        </tr>
        <tr>
			<td style="width: 40%; color: #444444; text-align:center; font-weight:bold;">F & A Manager</td>
            <td style="width: 60%; color: #444444; text-align:center; font-weight:bold;"></td>
           
        </tr>
    </table>
    <table border="0" cellspacing="0" style="width: 100%; padding:15px 0 0 0; font-style:italic; font-size: 12px;" >
      <tr>
		<td style="width: 5%; text-align:right;">1.</td>
		<td style="width: 95%; text-align:left">Apabila Barang yang dikirim tidak sesuai order, maka barang akan kami kembalikan</td>
	  </tr>
      <tr>
		<td style="width: 5%; text-align:right;">2.</td>
		<td style="width: 95%; text-align:left">Mohon pengiriman sesuai dengan jadwal</td>
	  </tr>
      <tr>
		<td style="width: 5%; text-align:right;">3.</td>
		<td style="width: 95%; text-align:left">Apabila disetujui mohon ditandatangani dan di kirim kembali ke <? echo strtoupper($rows_units['name']) ?></td>
	  </tr>
      
     </table>