<?php

require_once '../../library/connectionmysql.php';
Connected();
$qry_sjs = "SELECT sjs.id, sjs.spb_id, sjs.sjdate, sjs.sjnom, sjs.unitid, sjs.isclosed, sjs.istaken, sjs.warehouse_id, sjs.jtdate, spbs.id, spbs.spbdate, spbs.spbnom, spbs.customer_id, spbs.sale_id, spbs.description, spbs.unit_id, spbs.isclosed, spbs.istake, spbs.tempodate FROM sjs LEFT JOIN spbs ON (sjs.spb_id = spbs.id) where sjs.id = '".$_GET['gid']."';";
$rs_sjs = mysql_query($qry_sjs);
$rows_sjs=mysql_fetch_array($rs_sjs);
$rows_warehouses=mysql_fetch_array(mysql_query("select * from warehouses where id = '".$rows_sjs['warehouse_id']."';"));
$rows_cus=mysql_fetch_array(mysql_query("select * from customers where id = '".$rows_sjs['customer_id']."';"));
$rows_sales=mysql_fetch_array(mysql_query("select * from sales where id = '".$rows_sjs['sale_id']."';"));
$rows_units=mysql_fetch_array(mysql_query("select * from units where id = '".$rows_sjs['unit_id']."';"));
$rows_hsales=mysql_fetch_array(mysql_query("select * from headsales where id = '".$rows_units['headsale_id']."';"));
if($rows_units['logo'] == '') {
	$rows_units['logo'] = 'none.jpg';
}
?>

	<table cellspacing="0" style="width: 100%; font-size: 12px; padding:15px 25px 15px 25px;">
		<tr>
			<td style="width: 50%; color: #444444; float:left;"><img style="height:55px;" src="./../../logo/<? echo $rows_units['logo'] ?>" alt="Logo"></td>
            <td style="width: 50%; color: #444444; text-align:right; font:'Times New Roman', Times, serif; font-style:italic; font-size:14px; font-weight:bold;"><? echo strtoupper($rows_units['name']) ?><br />Telp. <? echo $rows_units['phone'] ?><br /> Fax. <? echo $rows_units['fax'] ?></td>
        </tr>
        <tr style="margin-top:10px;">
			<td style="width: 100%; color: #444444; text-align:right; border-bottom:thin;" colspan="2"></td>
        </tr>
    </table>
    
    <table cellspacing="0" style="width: 100%; text-align: center;  font-weight:bold; font-style:italic; padding:0 25px 25px 25px;">
    <tr>
	<td style="width: 100%; text-align:center; font-size: 18px;">SURAT JALAN</td>
	</tr>
    <tr>
	<td style="width: 100%; text-align:center;  font-size: 14px;">No. <? echo $rows_sjs['sjnom'] ?></td>
	</tr>
    <tr>
	<td style="width: 100%; text-align:center;  font-size: 14px;">Tgl. <? echo cDate2($rows_sjs['sjdate']) ?></td>
	</tr>
    </table>
    <table cellspacing="0" style="width: 100%; padding:0 25px 25px 25px;">
    <tr>
	<td>
     <table border="0.3" cellspacing="0" style="width: 100%; border-color:#903; border:thin;">
      <tr style="text-align:center; font-size:12px; background:#CCC;">
		<td style="width: 3%; height:15px;">No</td>
		<td style="width: 49%;">Nama Barang</td>
		<td style="width: 8%;">Qty</td>
		<td style="width: 10%;">Satuan</td>
        <td style="width: 30%;">Keterangan</td>
	  </tr>
      <?php
		$qry_spbdetails = "select * from spbdetails JOIN items ON ( spbdetails.item_id = items.id) where spb_id = '".$rows_sjs['spb_id']."';";
		$rs_spbdetails = mysql_query($qry_spbdetails);
		$no= 1;
		while($rows_spbdetails=mysql_fetch_array($rs_spbdetails)) {
		$rows_satuan=mysql_fetch_array(mysql_query("select * from pieces where id = '".$rows_spbdetails['piece_id']."';"));
	?>
      <tr style="font-size:10px";>
		<td style="height:10px;" align="right"><? echo $no ?></td>
		<td><? echo $rows_spbdetails['name'] ?></td>
		<td align="right"><? echo cFormat($rows_spbdetails['qty'],false) ?></td>
		<td align="center"><? echo $rows_satuan['name'] ?></td>                            
        <td></td>
	 </tr>
     <?php
		$no++;
		}
	?>
    </table>
    <table border="0" cellspacing="0" style="width: 100%; padding:15px 0 0 0;"" >
      <tr>
		<td style="width: 35%; height:15px; text-align:left; font-size:10px; font-style:italic; color:red; border:0.5px 0.5px 0.5px 0.5px; border-style:solid; border-color:red; ">Keluhan mengenai kerusakan barang hanya dilayani<br />dalam waktu 1 minggu setelah barang diterima</td>
		<td style="width: 10%; font-weight:bold; text-align:right;"></td>
	  </tr>
     </table>
    </td>
    </tr>
    </table>
    <table cellspacing="0" style="width: 100%; font-size: 12px; padding:0 25px 15px 25px;">
		<tr>
			<td style="width: 25%; color: #444444; text-align:center;"></td>
            <td style="width: 25%; color: #444444; text-align:center;"></td>
            <td style="width: 25%; color: #444444; text-align:center;"></td>
            <td style="width: 25%; color: #444444; text-align:center;">Surabaya, <? echo date('Y-m-d')?> </td>
        </tr>
        <tr>
			<td style="width: 25%; color: #444444; text-align:center;">Yang Meminta / Customer</td>
            <td style="width: 25%; color: #444444; text-align:center;">Yang Menyerahkan/  Sales</td>
            <td style="width: 25%; color: #444444; text-align:center;"><? if($rows_sjs[5]=='1') { ?>Kepala Sales<? } ?></td>
            <td style="width: 25%; color: #444444; text-align:center;"><? if($rows_sjs[6]=='1') { ?>Hormat Kami/ KA. Gudang<? } ?></td>
        </tr>
        <tr>
			<td style="width: 25%; color: #444444; text-align:center;  height:60px;"></td>
            <?
								if($rows_warehouses['large']) {
									if(file_exists('./../../photo/large-acc/'.$rows_warehouses['large'])) {
										$photo_small = '<img style="height:60px;" src="./../../photo/large-acc/'.$rows_warehouses['large'].'">';
									} else
										$photo_small = '';
								} else
									$photo_small = '';
								
								if($rows_hsales['large']) {
									if(file_exists('./../../photo/large-acc/'.$rows_hsales['large'])) {
										//list($width, $height) = getimagesize($path.'photo/large-acc/'.$rows_gm['large']);
										$hsalesacc = '<img style="height:60px;" src="./../../photo/large-acc/'.$rows_hsales['large'].'">';
									} else
										$hsalesacc = '';
								} else
									$hsalesacc = '';
			
			?>
            <td style="width: 25%; text-align:center;"></td>
            <td style="width: 25%; text-align:center;"><? if($rows_sjs[5]=='1') { ?><? echo $hsalesacc ?><? } ?></td>
            <td style="width: 25%; text-align:center;"><? if($rows_sjs[6]=='1') { ?><? echo $photo_small ?><? } ?></td>
        </tr>
        <tr>
			<td style="color: #444444; text-align:center; font-weight:bold; height:35px;">( <u><? echo $rows_cus['name'] ?></u> )</td>
            <td style="color: #444444; text-align:center; font-weight:bold;">( <u><? echo $rows_sales['name'] ?></u> )</td>
            <td style="color: #444444; text-align:center; font-weight:bold;"><? if($rows_sjs[5]=='1') { ?>( <u><? echo $rows_hsales['name'] ?></u> )<? } ?></td>
            <td style="color: #444444; text-align:center; font-weight:bold;"><? if($rows_sjs[6]=='1') { ?>( <u><? echo $rows_warehouses['whhead'] ?></u> )<? } ?></td>
        </tr>
        
    </table>