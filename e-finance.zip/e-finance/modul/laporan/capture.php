<?php

    ob_start();
	switch($_GET['target']) {
	case md5('kartu-hutang'):
		include(dirname(__FILE__).'/res/kartu-htg.php');
		$name = 'Kartu_hutang';
		break;
	case md5('rekap-hutang'):
		include(dirname(__FILE__).'/res/rekap-kartu-htg.php');
		$name = 'Rekap-hutang';
		break;
	case md5('kartu-piutang'):
		include(dirname(__FILE__).'/res/kartu-piut.php');
		$name = 'Rekap-hutang';
		break;
		default:
	case md5('rekap-piutang'):
		include(dirname(__FILE__).'/res/rekap-piutang.php');
		$name = 'Rekap-hutang';
		break;
	case md5('buku-besar'):
		include(dirname(__FILE__).'/res/bukubesar.php');
		$name = 'buku-besar';
		break;
	case md5('rekap-buku-besar'):
		include(dirname(__FILE__).'/res/rekap-bukubesar.php');
		$name = 'rekap-buku-besar';
		break;
		default:
	}
    
    $content = ob_get_clean();

    // convert in PDF
    require_once(dirname(__FILE__).'/html2pdf/html2pdf.class.php');
    try
    {
        $html2pdf = new HTML2PDF('P', 'A4', 'fr');
//      $html2pdf->setModeDebug();
        $html2pdf->setDefaultFont('Arial');
        $html2pdf->writeHTML($content, isset($_GET['vuehtml']));
        $filename = $name.'-'.date('YmdHis').'.pdf';
        $html2pdf->Output($filename);
    }
    catch(HTML2PDF_exception $e) {
        echo $e;
        exit;
    }
