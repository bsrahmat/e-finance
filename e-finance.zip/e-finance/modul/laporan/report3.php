<?php
	require_once '../../library/connectionmysql.php';
	Connected();
	
	
$error = array();
	switch($_POST['target']) {
	case md5('kas-besar'):
		if(!$_POST['tgl-awal']) $error[] = 'tgl-awal:Silahkan Masukkan Nama Sales.';
		if(!$_POST['code']) $error[] = 'code:Silahkan Masukkan Kode Sales.';
		break;
		default:
	}


if(count($error)>0) {
	echo generateError($error);
	
} else {	
	
    ob_start();
	
	switch($_POST['target']) {
	case md5('cetak-KrtHtg'):
		include(dirname(__FILE__).'/res/kartu-htg.php');
		$name = 'kartu-htg';
		break;
	
		default:
		
	}
    
    $content = ob_get_clean();

    // convert in PDF
    require_once(dirname(__FILE__).'/html2pdf/html2pdf.class.php');
    try
    {
        $html2pdf = new HTML2PDF('L', 'A4', 'fr');
//      $html2pdf->setModeDebug();
        $html2pdf->setDefaultFont('Arial');
        $html2pdf->writeHTML($content, isset($_GET['vuehtml']));
        $filename = $name.'-'.date('YmdHis').'.pdf';
        $html2pdf->Output($filename);
    }
    catch(HTML2PDF_exception $e) {
        echo $e;
        exit;
    }
}
