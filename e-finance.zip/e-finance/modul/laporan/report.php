<?php

    ob_start();
	switch($_GET['target']) {
	case md5('cetek-pr'):
		include(dirname(__FILE__).'/res/pb.php');
		$name = 'PR';
		break;
	case md5('cetek-po'):
		include(dirname(__FILE__).'/res/po.php');
		$name = 'PO';
		break;
	case md5('create-lpb'):
		include(dirname(__FILE__).'/res/create-lpb.php');
		$name = 'crete-lpb';
		break;
	case md5('update-lpb'):
		include(dirname(__FILE__).'/res/update-lpb.php');
		$name = 'update-lpb';
		break;
	case md5('cetek-spb'):
		include(dirname(__FILE__).'/res/cetek-spb.php');
		$name = 'cetek-spb';
		break;
	case md5('cetek-sj'):
		include(dirname(__FILE__).'/res/cetek-sj.php');
		$name = 'cetek-SJ';
		break;
	case md5('cetek-faktur'):
		include(dirname(__FILE__).'/res/cetak-faktur.php');
		$name = 'cetek-spb';
		break;
	case md5('cetek-bretur'):
		include(dirname(__FILE__).'/res/cetek-bretur.php');
		$name = 'cetek-bretur';
		break;
	case md5('acc-bretur'):
		include(dirname(__FILE__).'/res/acc-bretur.php');
		$name = 'acc-bretur';
		break;
	default:
	case md5('cetek-sretur'):
		include(dirname(__FILE__).'/res/cetek-sretur.php');
		$name = 'cetek-sretur';
		break;
	case md5('acc-sretur'):
		include(dirname(__FILE__).'/res/acc-sretur.php');
		$name = 'acc-sretur';
		break;
	case md5('order-kerja'):
		include(dirname(__FILE__).'/res/order-kerja.php');
		$name = 'order-kerja';
		break;
	case md5('penyelesaian-kerja'):
		include(dirname(__FILE__).'/res/penyelesaian-kerja.php');
		$name = 'penyelesaian-kerja';
		break;
	case md5('cetak-jurnal'):
		include(dirname(__FILE__).'/res/jurnal.php');
		$name = 'jurnal';
		break;
		case md5('cetak-kasbank'):
		include(dirname(__FILE__).'/res/kasbank.php');
		$name = 'kasbank';
		break;
	case md5('cetak-Jurnal'):
		include(dirname(__FILE__).'/res/jurnal.php');
		$name = 'jurnal';
		break;
	case md5('cetak-KrtHtg'):
		include(dirname(__FILE__).'/res/kartu-htg.php');
		$name = 'kartu-htg';
		break;
	case md5('cetak-bukubesar'):
		include(dirname(__FILE__).'/res/bukubesar.php');
		$name = 'bukubesar';
		break;
	case md5('cetak-Rekapbukubesar'):
		include(dirname(__FILE__).'/res/rekap-bukubesar.php');
		$name = 'rekap-bukubesar';
		break;
	case md5('cetak-neracaSal'):
		include(dirname(__FILE__).'/res/neraca-saldo.php');
		$name = 'neraca-saldo';
		break;	
	case md5('cetak-neraca'):
		include(dirname(__FILE__).'/res/neraca.php');
		$name = 'neraca';
		break;
	case md5('cetak-rugilaba'):
		include(dirname(__FILE__).'/res/rugilaba.php');
		$name = 'rugilaba';
		break;
	case md5('cetak-catatrugilaba'):
		include(dirname(__FILE__).'/res/catatan-rugilaba.php');
		$name = 'catatan-rugilaba';
		break;	
		default:
	}
    
    $content = ob_get_clean();

    // convert in PDF
    require_once(dirname(__FILE__).'/html2pdf/html2pdf.class.php');
    try
    {
        $html2pdf = new HTML2PDF('P', 'A4', 'fr');
//      $html2pdf->setModeDebug();
        $html2pdf->setDefaultFont('Arial');
        $html2pdf->writeHTML($content, isset($_GET['vuehtml']));
        $filename = $name.'-'.date('YmdHis').'.pdf';
        $html2pdf->Output($filename);
    }
    catch(HTML2PDF_exception $e) {
        echo $e;
        exit;
    }
