<?php

require_once '../../library/connectionmysql.php';
Connected();
if($_SESSION['galaxy_posisi']=='none' || !isset($_SESSION['galaxy_posisi'])) { header("Location: ../../index.php"); die; }
if($_SESSION['galaxy_unit']=='none' || !isset($_SESSION['galaxy_unit'])) { header("Location: ../../index.php"); die; }


$error = array();

if(!$_POST['warehouse_id']) $error[] = 'warehouse_id:Silahkan Pilih Gudang terlebih dahulu.';

if(count($error)>0) {
	//tampilkan pesan error, jika ada error.. :D
	echo generateError($error).'|*|';	
	
	
} else {
$rs_module=mysql_query("select * from tbl_modul where modul_kode = '".$_POST['modul_kode'] ."'");
$rows_module=mysql_fetch_array($rs_module);
	
header("Content-type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=laporan-skpd-".$rows_module['modul_header']."-".date('Y').".xls");

$_GET['gid']=$_POST['modul_kode'];
$_GET['tahun']=$_POST['tahun'];

	
	$rs_skpd= mysql_query("select * from tbl_modul  where modul_kode = '".$_GET['gid']."'");
		$rows_skpd=mysql_fetch_array($rs_skpd);
		$qry_anggarandpa = "select * from tbl_kegiatan JOIN  tbl_dpa ON tbl_kegiatan.dpa_kode = tbl_dpa.dpa_kode JOIN tbl_urusanpemerintah ON tbl_kegiatan.urusanpemerintah_kode  = tbl_urusanpemerintah.urusanpemerintah_kode  JOIN  tbl_modul ON tbl_kegiatan.modul_kode = tbl_modul.modul_kode JOIN tbl_program ON tbl_kegiatan.program_kode = tbl_program.program_kode JOIN tbl_jenisbelanja ON tbl_kegiatan.jenisbelanja_kode = tbl_jenisbelanja.jenisbelanja_kode where  tbl_modul.modul_kode = '".$rows_skpd['modul_kode']."' AND tbl_kegiatan.jenisbelanja_kode = '1' order by tbl_modul.modul_kode ASC, tbl_dpa.dpa_no ASC, tbl_urusanpemerintah.urusanpemerintah_no ASC, tbl_program.program_no ASC, tbl_jenisbelanja.jenisbelanja_kode ASC, tbl_kegiatan.kegiatan_no ASC";
		$rs_anggarandpa = mysql_query($qry_anggarandpa);
		
		$rows_dpa=mysql_fetch_array(mysql_query("select SUM(detailkegiatan_biayadpa_update) AS sumdetailkegiatan_biayadpa_update, SUM(detailkegiatan_biayadpa) AS sumdetailkegiatan_biayadpa, SUM(detailkegiatan_noreport) AS sumdetailkegiatan_noreport, SUM(detailkegiatan_real_penyerapan) AS sumdetailkegiatan_real_penyerapan from tbl_detailkegiatan JOIN  tbl_kegiatan ON tbl_detailkegiatan.kegiatan_kode = tbl_kegiatan.kegiatan_kode where tbl_kegiatan.modul_kode ='".$rows_skpd['modul_kode']."' AND tbl_detailkegiatan.detailkegiatan_tahun = '".$_GET['tahun']."'"));
								
		$rows_anggarandpa['detailkegiatan_sisadana'] = 	$rows_dpa['sumdetailkegiatan_biayadpa_update'] - $rows_dpa['sumdetailkegiatan_real_penyerapan'] ;
		$rows_anggarandpa['detailkegiatan_real_fisik'] = $rows_dpa['sumdetailkegiatan_noreport']/$rows_dpa['sumdetailkegiatan_biayadpa_update'] *100;
		$rows_anggarandpa['detailkegiatan_real_keu'] = $rows_dpa['sumdetailkegiatan_real_penyerapan']/$rows_dpa['sumdetailkegiatan_biayadpa_update'] *100;
		
		$rows_bl=mysql_fetch_array(mysql_query("select SUM(detailkegiatan_biayadpa_update) AS sumbiaya_bl, SUM(detailkegiatan_biayadpa) AS sumdetailkegiatan_biayadpa, SUM(detailkegiatan_noreport) AS sumdetailkegiatan_noreport, SUM(detailkegiatan_real_penyerapan) AS sumdetailkegiatan_real_penyerapan from tbl_detailkegiatan JOIN  tbl_kegiatan ON tbl_detailkegiatan.kegiatan_kode = tbl_kegiatan.kegiatan_kode where tbl_kegiatan.modul_kode ='".$rows_skpd['modul_kode']."' AND tbl_kegiatan.jenisbelanja_kode = '1' AND tbl_detailkegiatan.detailkegiatan_tahun = '".$_GET['tahun']."'"));
		$grid_bl_a = 	$rows_bl['sumbiaya_bl'] - $rows_bl['sumdetailkegiatan_real_penyerapan'] ;
		$grid_bl_b = $rows_bl['sumdetailkegiatan_noreport']/$rows_bl['sumbiaya_bl'] *100;
		$grid_bl_c = $rows_bl['sumdetailkegiatan_real_penyerapan']/$rows_bl['sumbiaya_bl'] *100;
		
		$rows_btl=mysql_fetch_array(mysql_query("select SUM(detailkegiatan_biayadpa_update) AS sumbiaya_btl,  SUM(detailkegiatan_biayadpa) AS sumdetailkegiatan_biayadpa, SUM(detailkegiatan_noreport) AS sumdetailkegiatan_noreport, SUM(detailkegiatan_real_penyerapan) AS sumdetailkegiatan_real_penyerapan from tbl_detailkegiatan JOIN  tbl_kegiatan ON tbl_detailkegiatan.kegiatan_kode = tbl_kegiatan.kegiatan_kode where tbl_kegiatan.modul_kode ='".$rows_skpd['modul_kode']."' AND tbl_kegiatan.jenisbelanja_kode = '2'  AND tbl_detailkegiatan.detailkegiatan_tahun = '".$_GET['tahun']."'"));
		$grid_btl_a = 	$rows_btl['sumbiaya_btl'] - $rows_btl['sumdetailkegiatan_real_penyerapan'] ;
		$grid_btl_b = $rows_btl['sumdetailkegiatan_noreport']/$rows_btl['sumbiaya_btl'] *100;
		$grid_btl_c = $rows_btl['sumdetailkegiatan_real_penyerapan']/$rows_btl['sumbiaya_btl'] * 100;
		
	
	
?>
      <table class="ctable-skpd" style="width: 100%;">
      <tr class="isi">
	  <td align="center" colspan="9"><b>LAPORAN KONSOLIDASI PEMBANGUNAN KOTA TARAKAN</b></td>
	  </tr>
	  <tr class="isi">
	  <td align="center" colspan="9"><b>SUMBER DANA APBD KOTA TARAKAN </b></td>
	  </tr>
	  <tr class="isi">
	  <td align="center" colspan="9"><b>TAHUN <? echo $_POST['tahun']; ?></b></td>
	  </tr>
      <tr class="isi">
	  <td align="center" colspan="9"><? echo $rows_module['modul_name']; ?></td>
	  </tr>
      <tr class="isi">
	  <td align="right" colspan="9"><span style="font-style: italic; font-size: 11;"></span></td>
	  </tr>
      </table>
      <table border="1" class="ctable-skpd" style="width: 100%;">
	  
	  	<tr class="ctableheader">
	  	<td width="10%" rowspan="2"  align="center" valign="middle">KODE</td>
	  	<td rowspan="2" colspan="2" align="center" valign="middle">PROGRAM / KEGIATAN</td>
      	<td width="9%" rowspan="2" align="center" valign="middle">BIAYA<br /> MENURUT DPA<br />(Rp.)</td>
      	
		<td width="18%" colspan="2" align="center" valign="middle">REALISASI</td>
		<td width="9%" rowspan="2" align="center" valign="middle">REALISASI <br />PENYERAPAN DANA<br />(Rp)</td>
		<td width="9%" rowspan="2" align="center" valign="middle"><br />SISA DANA<br />(RP)</td>
        <td width="15%" rowspan="2" align="center" valign="middle">PPTK</td>
		</tr>                      
                            
		<tr class="ctableheader">
		<td width="4%" align="center" valign="middle">Fisik<br />(%)</td>
		<td width="4%" align="center" valign="middle">Keu<br />(%)</td>
		</tr>
        <tr class="isi">
        <td align="center">1</td>
        <td align="center" colspan="2">2</td>
        <td align="center">3</td>
        
         <td align="center">4</td>
         <td align="center">5</td>
         <td align="center">6</td>
         <td align="center">7</td>
         <td align="center">8</td>
        </tr>
        <tr class="isi">
        <td align="center"></td>
        <td align="center" style="font-weight:bold;" colspan="2">JUMLAH</td>
        <td align="right" style="font-weight:bold;"><? echo cFormat($rows_dpa['sumdetailkegiatan_biayadpa_update'],false)?></td>
        
         <td align="right" style="font-weight:bold;"><? echo number_format($rows_anggarandpa['detailkegiatan_real_fisik'], 2, '.', '') ?></td>
         <td align="right" style="font-weight:bold;"><? echo number_format($rows_anggarandpa['detailkegiatan_real_keu'], 2, '.', '') ?></td>
         <td align="right" style="font-weight:bold;"><? echo cFormat($rows_dpa['sumdetailkegiatan_real_penyerapan'],false) ?></td>
         <td align="right" style="font-weight:bold;"><? echo cFormat($rows_anggarandpa['detailkegiatan_sisadana'],false) ?></td>
         <td align="left"></td>
        </tr>
        <tr class="isi" height="20px">
        <td align="center"></td>
        <td align="left" style="font-weight:bold;" colspan="2"></td>
        <td align="right" style="font-weight:bold;"></td>
        
         <td align="right" style="font-weight:bold;"></td>
         <td align="right" style="font-weight:bold;"></td>
         <td align="right" style="font-weight:bold;"></td>
         <td align="right" style="font-weight:bold;"></td>
         <td align="left"></td>
        </tr>     
        <tr class="isi">
        <td align="center"></td>
        <td align="left" style="font-weight:bold;" colspan="2">BELANJA TIDAK LANGSUNG</td>
        <td align="right" style="font-weight:bold;"><? echo cFormat($rows_btl['sumbiaya_btl'],false)?></td>
       
         <td align="right" style="font-weight:bold;"><? echo number_format($grid_btl_b, 2, '.', '') ?></td>
         <td align="right" style="font-weight:bold;"><? echo number_format($grid_btl_c, 2, '.', '') ?></td>
         <td align="right" style="font-weight:bold;"><? echo cFormat($rows_btl['sumdetailkegiatan_real_penyerapan'],false) ?></td>
         <td align="right" style="font-weight:bold;"><? echo cFormat($grid_btl_a,false) ?></td>
         <td align="left"></td>
        </tr>
        <tr class="isi">
        <td align="center"></td>
        <td align="left" style="font-weight:bold;" colspan="2">BELANJA LANGSUNG</td>
        <td align="right" style="font-weight:bold;"><? echo cFormat($rows_bl['sumbiaya_bl'],false)?></td>
        
         <td align="right" style="font-weight:bold;"><? echo number_format($grid_bl_b, 2, '.', '') ?></td>
         <td align="right" style="font-weight:bold;"><? echo number_format($grid_bl_c, 2, '.', '') ?></td>
         <td align="right" style="font-weight:bold;"><? echo cFormat($rows_bl['sumdetailkegiatan_real_penyerapan'],false) ?></td>
         <td align="right" style="font-weight:bold;"><? echo cFormat($grid_bl_a,false) ?></td>
         <td align="left"></td>
        </tr>
        <tr class="isi" height="20px">
        <td align="center"></td>
        <td align="left" style="font-weight:bold;" colspan="2"></td>
        <td align="right" style="font-weight:bold;"></td>
        
         <td align="right" style="font-weight:bold;"></td>
         <td align="right" style="font-weight:bold;"></td>
         <td align="right" style="font-weight:bold;"></td>
         <td align="right" style="font-weight:bold;"></td>
         <td align="left"></td>
        </tr>
	  <?php 
	 
		
		$i = 0;
		while($rows_kegiatan=mysql_fetch_array($rs_anggarandpa)) {
			$qry_detailkegiatan = "select * from tbl_detailkegiatan where kegiatan_kode = '".$rows_kegiatan['kegiatan_kode']."' order by detailkegiatan_kode ASC";
			$rs_detailkegiatan = mysql_query($qry_detailkegiatan);
			$cnt_detailkegiatan = mysql_num_rows($rs_detailkegiatan);
			if($cnt_detailkegiatan>0) {
		?>
            <tr class="isi">
            <td align="left" style="font-weight:bold;"><? echo $rows_kegiatan['dpa_no'] ?>.<? echo $rows_kegiatan['urusanpemerintah_no'] ?>.<? echo $rows_kegiatan['program_no'] ?>.<? echo $rows_kegiatan['jenisbelanja_kode'] ?>.<? echo $rows_kegiatan['kegiatan_no'] ?></td>
            <td align="left" style="font-weight:bold;" colspan="2"><? echo $rows_kegiatan['kegiatan_name']?></td>
            <td align="right" style="font-weight:bold;"></td>
            
             <td align="right" style="font-weight:bold;"></td>
             <td align="right" style="font-weight:bold;"></td>
             <td align="right" style="font-weight:bold;"></td>
             <td align="right" style="font-weight:bold;"></td>
             <td align="left"></td>
             </tr>
             <?
             while($rows_detailkegiatan=mysql_fetch_array($rs_detailkegiatan)) {
			 ?>
                    <tr class="isi">
                    <td align="center"><? echo $rows_kegiatan['dpa_no'] ?>.<? echo $rows_kegiatan['urusanpemerintah_no'] ?>.<? echo $rows_kegiatan['program_no'] ?>.<? echo $rows_kegiatan['jenisbelanja_kode'] ?>.<? echo $rows_kegiatan['kegiatan_no'] ?>.<? echo $rows_detailkegiatan['detailkegiatan_no'] ?></td>
                   
                    <td align="left" colspan="2">&nbsp; <? echo $rows_detailkegiatan['detailkegiatan_name']?></td>
                    <td align="right"><? echo cFormat($rows_detailkegiatan['detailkegiatan_biayadpa_update'],false) ?></td>
                    
                     <td align="right"><? echo number_format($rows_detailkegiatan['detailkegiatan_real_fisik'], 2, '.', '') ?></td>
                     <td align="right"><? echo number_format($rows_detailkegiatan['detailkegiatan_real_keu'], 2, '.', '') ?></td>
                     <td align="right"><? echo cFormat($rows_detailkegiatan['detailkegiatan_real_penyerapan'],false) ?></td>
                     <td align="right"><? echo cFormat($rows_detailkegiatan['detailkegiatan_sisadana'],false) ?></td>
                     <td align="left"><? echo $rows_detailkegiatan['detailkegiatan_pptk'] ?></td>
                     </tr>            
             <?
			 }			 
			}	
		}
		?>
      </table>
<? } ?>
      
   