<?php
	require_once '../../../library/connectionmysql.php';
	Connected();
			
	if(isEdit())  {
		$rs_spbs = mysql_query("select * from spbdetails JOIN items ON (spbdetails.item_id = items.id) JOIN pieces ON (items.piece_id = pieces.id) where spbdetails.id = '".$_GET['sub']."'");
		$rows_spbs=mysql_fetch_array($rs_spbs);
	}
//<!-- =========================================================================================================================== -->
?>

<?
//<!-- FORM TIPE MODE 0 = TAMBAH/ADD, TIPE MODE 1 = UBAH/EDIT -->
 if(isAdd() || isEdit()) {
	 //$id = UnitIDs(id,spbs);
	 //$prnom = IDTrans();
 ?>

   <div class="popup-shadow" style="width: 600px;">
      <div class="popup-header">
         <span><? if(isAdd()) echo 'Tambah Data'; else echo 'Edit Data'; ?></span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <form action="modul/hsales/detail/pembuatan-spb.php" method="post">
      <table>
      <tr>
      <td width="25%">Nama Barang</td>
      <td width="5%" align="center">:</td>
      <td><select name="item_id" class="select-text select-small">
      	<option value="">Pilih..</option>
      <? 	  
	  $qry_items = '';
	  if($_SESSION['galaxy_type']=='0')	{
		  $qry_items = "select * from items WHERE unit_id != '10' order by name;";
	  }
	  else{
	  	$qry_items = "select * from items WHERE unit_id = '".$_SESSION['galaxy_unit']."' order by name ASC;";
	  } 
	  $rs_items = mysql_query($qry_items);
	  while($rows_items=mysql_fetch_array($rs_items)) {
	  ?>
        <option value="<? echo $rows_items['id']?>" <? if(isEdit()) if($rows_items['id']==$rows_spbs['item_id']) echo 'selected'; ?>><? echo $rows_items['name']; ?> - [<? echo $rows_items['code']; ?>]</option>
      <? } ?>
      </select></td>
      </tr>
      <tr>
      <td>Jumlah</td>
      <td align="center">:</td>
      <td><input class="input-text currency padmin" name="qty" type="text" value="<? if(isEdit()) echo cFormat($rows_spbs['qty'],false) ?>" /></td>
      </tr>
      <tr>
      <td>Stok Barang</td>
      <td align="center">:</td>
      <td><input class="input-text currency padmin" name="stock" type="text" value="<? if(isEdit()) echo cFormat($rows_spbs['stock'],false) ?>" readonly="readonly"/></td>
      </tr>
      <tr>
      <td>Satuan</td>
      <td align="center">:</td>
      <td><input class="input-text input-small" name="satuan" type="text" value="<? if(isEdit()) echo $rows_spbs[22] ?>" readonly="readonly"/></td>
      </tr>
      <tr>
      <td>Harga Satuan</td>
      <td align="center">:</td>
      <td><input class="input-text currency padmin" name="price" type="text" value="<? if(isEdit()) echo cFormat($rows_spbs['price'],false) ?>" /></td>
      </tr>
      
      <tr>
      <td>Discount/Satuan</td>
      <td align="center">:</td>
      <td><input class="input-text currency padmin" name="disc" type="text" value="<? if(isEdit()) echo cFormat($rows_spbs['disc'],false) ?>" /></td>
      </tr>
      <tr>
      <td>Harga Satuan - Discount</td>
      <td align="center">:</td>
      <td><input class="input-text currency padmin" type="text" value="<? if(isEdit()) echo cFormat($rows_spbs['price']-$rows_spbs['disc'],false) ?>" readonly="readonly"/></td>
      </tr>
      
      <tr>
      <td>Harga Total</td>
      <td align="center">:</td>
      <td><input class="input-text currency padmin" type="text" value="<? if(isEdit()) echo cFormat($rows_spbs['qty']*($rows_spbs['price']-$rows_spbs['disc']),false) ?>" readonly="readonly"/></td>
      </tr>
      </table>
      <? if(isEdit())  {?>
      <input type="hidden" name="gid2" value="<? echo $_GET['sub'] ?>" />
      <input type="hidden" name="kode" value="<? echo $rows_spbs['item_id'] ?>" />
      <? }?>
      <input type="hidden" name="gid" value="<? echo $_GET['gid'] ?>" />
      <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
      </form>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel">Batal</div>
      	<div mode="6" link="library/submenu/hsales/detail/pembuatan-spb" class="popup-button" get="<? echo $_GET['gid'] ?>">Simpan</div>
      </div>
   </div>

<? }  
//<!-- END FORM -->

//<!-- =========================================================================================================================== -->
?>

<? 
//<!-- FORM TIPE MODE 2 = CONFIRM DELETE/KONFIRMASI HAPUS, TIPE MODE 4 = CONFIRM DELETE SELECTED/KONFIRMASI HAPUS YANG DIPILIH -->
if(isConfirmDelete() || isConfirmDeleteSelected()) { ?>
<?
	if(isConfirmDelete()) {
		$rs_spbs = mysql_query("select * from spbdetails JOIN items ON (spbdetails.item_id = items.id) JOIN pieces ON (items.piece_id = pieces.id) where spbdetails.id = '".$_GET['gid']."'");
		$rows_spbs=mysql_fetch_array($rs_spbs);
	}
?>
   <div class="popup-shadow" style="width: 500px;">
      <div class="popup-header">
         <span>Konfirmasi Hapus</span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <table>
      <tr>
      <td class="center">
      <? if(isConfirmDelete()) {?>
      		Apakah anda yakin menghapus <br /><b style="text-decoration: underline;"><? echo $rows_spbs[10] ?></b>?
      <? }?>
      
      <? if(isConfirmDeleteSelected()) {?>
      		<? if($_GET['gid']!='') { 
				$value = array();
				$value = generateArray($_GET['gid']); 
			?>
            	<strong>Peringatan: </strong><br /> Data <b>Satuan Barang</b> akan ikut terhapus, jika ada data yang terhubung!.
      		<br /><br />
                Sebanyak <b style="text-decoration: underline;"><? echo count($value) ?> item</b> yang akan dihapus!.<br />
                Apakah anda yakin untuk menghapusnya?
            <? } else { ?>
            	Tidak ada item yang akan dihapus.<br />Silahkan anda memilih check box untuk dicentang.
            <? } ?>
      <? }?>
      </td>
      </tr>
      </table>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel"><? if($_GET['gid']!='') echo 'Batal'; else echo 'Tutup' ?></div>
        <? if(isConfirmDelete()) { ?>
      		<div mode="3" link="modul/hsales/detail/pembuatan-spb?<? echo $_GET['gid'] ?>" class="popup-button">Hapus</div>
        <? }?>
      	<? if(isConfirmDeleteSelected()) {
			if($_GET['gid']!='') {
				if(count($value)>0)
		?>
      		<div mode="5" link="modul/hsales/pembuatan-spb?<? echo htmlspecialchars($_GET['gid']) ?>" class="popup-button">Hapus</div>
        <? } } ?>
      </div>
      
   </div>

<? } 

?>

<?
 if(isDelete()) {
	 
	//mysql_query("DELETE from spbs where trprequest_id =".$_GET['gid']);
	mysql_query("DELETE from spbdetails where id ='".$_GET['gid']."'");
	
 } ?>
 
<?
//<!-- END TIPE MODE 3 -->

//<!-- =========================================================================================================================== -->

//<!-- TIPE MODE 5 = DELETE SELECTED/HAPUS YANG DIPILIH -->
?>

<? if(isDeleteSelected()) { 
	
	$value = array();
	$value = generateArray($_GET['gid']); 

	// Taruh query ke database untuk menghapus disini...
	// Contoh :
	for($i=0;$i<count($value);$i++) {
		mysql_query("DELETE from spbs where trprequest_id = '".$value[$i]."'");
	 	mysql_query("DELETE from spbs where id = '".$value[$i]."'");
	}
	
 } 
//<!-- END TIPE MODE 5 -->

//<!-- =========================================================================================================================== -->
?>

<?
//<!-- TIPE MODE 6 = SAVE/MENYIMPAN -->
 if(isSave()) { 

$error = array();
/*
if(!$_POST['timereq']) $error[] = 'timereq:Silahkan Masukkan tanggal Kebutuhan.';
if(!$_POST['item_id']) $error[] = 'item_id:Silahkan Masukkan Nama Barang.';
if(!$_POST['qty']) $error[] = 'qty:Silahkan Masukkan Jumlah Barang.';
*/
//$tmp = explode('/',$_POST['item_id']);

$rs_check = mysql_query("select * from spbdetails where spb_id = '".$_POST['gid']."' AND item_id = UPPER('".$_POST['item_id']."')");
$rows_check = mysql_num_rows($rs_check);

if($_POST['mod']=='0')
	if($rows_check>0) $error[] = 'item_id:Maaf Barang Sudah Masuk Dalam List.';

if($_POST['mod']=='1') 
	if($_POST['kode']!=strtoupper($_POST['item_id']))
		if($rows_check>0) $error[] = 'item_id:Maaf Barang Sudah Masuk Dalam List.';
		

if(count($error)>0) {
	echo generateError($error);
	
} else {
	
	if($_POST['mod']=='0') {
		mysql_query("INSERT INTO spbdetails (spb_id, item_id, qty, price, disc, rest) VALUES ('".$_POST['gid']."', '".$_POST['item_id']."', ".isNull($_POST['qty'],'CUR').", ".isNull($_POST['price'],'CUR').", ".isNull($_POST['disc'],'CUR').", ".isNull($_POST['qty'],'CUR').")");
		
	}
	
	if($_POST['mod']=='1') {	
		mysql_query("UPDATE spbdetails SET item_id = '".$_POST['item_id']."', qty = ".isNull($_POST['qty'],'CUR').", rest = ".isNull($_POST['qty'],'CUR').", disc = ".isNull($_POST['disc'],'CUR').", price = ".isNull($_POST['price'],'CUR')." WHERE id ='".$_POST['gid2']."';");
	}
}

} 
//<!-- END TIPE MODE 6 --> 
?>

