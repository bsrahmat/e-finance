<?php
	require_once '../../library/connectionmysql.php';
	Connected();
	
	$perm = array();
	$perm = getPermissions('8');
	if($perm[-1]=='1') { require_once '../../library/error-popup.php'; die; }
	
	if(isEdit()) {
		$rs_sreturs = mysql_query("SELECT * FROM sreturs  WHERE id = '".$_GET['gid']."'");
		$rows_sreturs=mysql_fetch_array($rs_sreturs);
	}
	if(isAdd()) {
		 $rs_units = mysql_query("select * from units where id = '".$_SESSION['galaxy_unit']."'");
		 $rows_units=mysql_fetch_array($rs_units);
		 $retnom = IDTransRet($rows_units['code']);
		 $id = 'id';
		 $table = 'sreturs';
		 $id = Kode($id,$table);
	}
		
?>


<? 
if(isApply()) {
	$rs_sreturs = mysql_query("select * from sreturs where id = '".$_GET['gid']."'");
	$rows_sreturs=mysql_fetch_array($rs_sreturs);
?>
   <div class="popup-shadow" style="width: 500px;">
      <div class="popup-header">
         <span>Notifikasi Setuju</span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <form action="modul/hsales/acc-retur-penjualan.php" method="post">
      <table>
      <tr>
      <td class="center">
  
      		<strong>Peringatan</strong>: <br /> 
      		Data <b>Retur Penjualan</b> Akan Di disetujui!.
      		<br /><br />
      		Dengan No Retur : <b style="text-decoration: underline;"><? echo $rows_sreturs['retnom'] ?></b>?
      <input type="hidden" name="gid" value="<? echo $_GET['gid'] ?>" />
      <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
     
      </td>
      </tr>
      </table>
      </form>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel"><? if($_GET['gid']!='') echo 'Batal'; else echo 'Tutup' ?></div>
        <div mode="6" link="library/submenu/hsales/acc-retur-penjualan" class="popup-button" get="">Proses</div>
      </div>
      
   </div>

<? } 
?>

<? 
if(isCencel()) {
	$rs_sreturs = mysql_query("select * from sreturs where id = '".$_GET['gid']."'");
	$rows_sreturs=mysql_fetch_array($rs_sreturs);
?>
   <div class="popup-shadow" style="width: 500px;">
      <div class="popup-header">
         <span>Notifikasi Tolak</span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <form action="modul/hsales/acc-retur-penjualan.php" method="post">
      <table>
      <tr>
      <td class="center">
  
      		<strong>Peringatan</strong>: <br /> 
      		Data <b>Retur Penjualan</b> Akan Di ditolak!.
      		<br /><br />
      		Dengan No Retur : <b style="text-decoration: underline;"><? echo $rows_sreturs['retnom'] ?></b>?
      <input type="hidden" name="gid" value="<? echo $_GET['gid'] ?>" />
      <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
     
      </td>
      </tr>
      </table>
      </form>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel"><? if($_GET['gid']!='') echo 'Batal'; else echo 'Tutup' ?></div>
        <div mode="6" link="library/submenu/hsales/acc-retur-penjualan" class="popup-button" get="">Proses</div>
      </div>
      
   </div>

<? } 
?>

<?
//<!-- TIPE MODE 6 = SAVE/MENYIMPAN -->
if(isSave()) {
$error = array();
	

if(count($error)>0) {
	echo generateError($error);
	
} else { 
	if($_POST['mod']=='7') {	
		mysql_query("UPDATE sreturs SET isacc = '1' WHERE id ='".$_POST['gid']."';");
		/*$qry_bretdetails = "select * from bretdetails JOIN items ON ( bretdetails.item_id = items.id) where bretdetails.bretur_id = '".$_POST['gid']."';";
		$rs_bretdetails = mysql_query($qry_bretdetails);
		while($rows_bretdetailss=mysql_fetch_array($rs_bretdetails)) {
			mysql_query("UPDATE trrgdetails SET trrgstatus = '1' WHERE id ='".$rows_bretdetailss['trrgdetails_id']."';");
		}
		*/
	}
	if($_POST['mod']=='8') {	
		mysql_query("UPDATE sreturs SET isacc = '0' WHERE id ='".$_POST['gid']."';");
		
		$qry_bretdetails = "select * from sretdetails JOIN items ON ( sretdetails.item_id = items.id) where sretdetails.sretur_id = '".$_POST['gid']."';";
		$rs_bretdetails = mysql_query($qry_bretdetails);
		while($rows_bretdetailss=mysql_fetch_array($rs_bretdetails)) {
			mysql_query("UPDATE fakdetails SET fakstatus = '1' WHERE id ='".$rows_bretdetailss['fakdetails_id']."';");
		}
		
	}
 }
 }
?>

