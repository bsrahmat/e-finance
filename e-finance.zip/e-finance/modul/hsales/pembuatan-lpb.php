<?php
	require_once '../../library/connectionmysql.php';
	Connected();
	
	$perm = array();
	$perm = getPermissions('36');
	if($perm[-1]=='1') { require_once '../../library/error-popup.php'; die; }
	
?>

<?
//<!-- FORM TIPE MODE 0 = TAMBAH/ADD, TIPE MODE 1 = UBAH/EDIT -->
 if(isAdd()) {
	 $rs_trrgoods = mysql_query("SELECT * FROM trrgoods  WHERE trrgoods.id = '".$_GET['gid']."'");
	$rows_trrgoods=mysql_fetch_array($rs_trrgoods);
 ?>
 
   <div class="popup-shadow" style="width: 600px;">
      <div class="popup-header">
         <span>Close LPB</span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <form action="modul/gudang/pembuatan-lpb.php" method="post">
      <table>
      <tr>
      <td class="center">Apakah Anda Mau Menutup LPB : <b style="text-decoration: underline;"><? echo $rows_trrgoods['rgnom'] ?></b> ?</td>
      </tr>
      
      </table>
      <input type="hidden" name="gid" value="<? echo $_GET['gid'] ?>" />
      <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
      <input type="hidden" name="trporder_id" value="<? echo $rows_trrgoods['trporder_id'] ?>" />
      
      </form>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel">Batal</div>
      	<div mode="6" link="library/submenu/gudang/pembuatan-lpb" class="popup-button" get="">Simpan</div>
      </div>
   </div>

<? }  ?>


<?
//<!-- FORM TIPE MODE 0 = TAMBAH/ADD, TIPE MODE 1 = UBAH/EDIT -->
 if(isEdit()) {
	 $rs_trrgoods = mysql_query("SELECT * FROM trrgoods LEFT JOIN trporders ON (trrgoods.trporder_id = trporders.id) LEFT JOIN suppliers ON (trporders.supplier_id = suppliers.id)  WHERE trrgoods.id = '".$_GET['gid']."'");
	$rows_trrgoods=mysql_fetch_array($rs_trrgoods);
	$rs_units = mysql_query("select * from units where id = '".$_SESSION['galaxy_unit']."'");
	 $rows_units=mysql_fetch_array($rs_units);
	 $rgnom = IDTransLPB($rows_units['code']);
	 
 ?>
 
   <div class="popup-shadow" style="width: 600px;">
      <div class="popup-header">
         <span>Edit LPB</span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <form action="modul/gudang/pembuatan-lpb.php" method="post">
      <table>
      <tr>
      <td width="27%">No. LPB</td>
      <td width="5%" align="center">:</td>
      <td><input class="input-text" name="prnom-disable" type="text" value="<? if($rows_trrgoods[13]=='2' || $rows_trrgoods[13]=='') echo $rgnom ?><? if($rows_trrgoods[13]!='2' || $rows_trrgoods[13]!='2') echo $rows_trrgoods['rgnom'] ?>"  disabled="disabled"></td>
      </tr>
      <tr>
      <td>No. PO</td>
      <td align="center">:</td>
      <td><input class="input-text" name="prnom-disable" type="text" value="<? echo $rows_trrgoods['ponom'] ?>"  disabled="disabled"></td>
      </tr>
      
      <tr>
      <td>Referensi (No. SJ/Faktur)</td>
      <td align="center">:</td>
      <td><input class="input-text" name="refnom" value="<? echo $rows_trrgoods['refnom'] ?>" /></td>
      </tr>
      <tr>
      <td>Tanggal</td>
      <td align="center">:</td>
      <td><input class="input-text" name="rgdate" type="datepicker" value="<? if($rows_trrgoods[13]!='2' || $rows_trrgoods[13]!='2') echo cDate($rows_trrgoods['rgdate']) ?><? if($rows_trrgoods[13]=='2' || $rows_trrgoods[13]=='') echo cDate(date('Y-m-d')) ?>" /></td>
      </tr>
      <tr>
      <td>Keterangan</td>
      <td align="center">:</td>
      <td><textarea rows="3" class="input-text" name="description" type="text"><? echo $rows_trrgoods['description'] ?></textarea></td>
      </tr>
      <tr>
      <td>Gudang Penerima</td>
      <td align="center">:</td>
      <td><select name="warehouse_id" class="select-text select-small">
      	<option value="">Pilih..</option>
      <?
	  $qry_warehouses = "select * from units_warehouses JOIN warehouses ON (units_warehouses.warehouse_id = warehouses.id ) WHERE units_warehouses.unit_id = '".$_SESSION['galaxy_unit']."' order by warehouses.id;";
	  $rs_warehouses = mysql_query($qry_warehouses);
	  while($rows_warehouses=mysql_fetch_array($rs_warehouses)) {
	  ?>
        <option value="<? echo $rows_warehouses[3]?>" <? if(isEdit()) if($rows_warehouses[3]==$rows_trrgoods['warehouse_id']) echo 'selected'; ?>><? echo $rows_warehouses[5]; ?></option>
      <? } ?>
      </select></td>
      </tr>
      <tr>
      <td>Penerima</td>
      <td align="center">:</td>
      <td><input class="input-text" name="recipient" value="<? echo $rows_trrgoods['recipient'] ?>" /></td>
      </tr>
      </table>
      <input type="hidden" name="rgnom" value="<? if($rows_trrgoods[13]=='2' || $rows_trrgoods[13]=='') echo $rgnom ?><? if($rows_trrgoods[13]!='2' || $rows_trrgoods[13]!='2') echo $rows_trrgoods['rgnom'] ?>" />
      <input type="hidden" name="gid" value="<? echo $_GET['gid'] ?>" />
      <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
      <input type="hidden" name="trprequest_id" value="<? echo $rows_trrgoods['trprequest_id'] ?>" />
      
      </form>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel">Batal</div>
      	<div mode="6" link="library/submenu/gudang/detail/pembuatan-lpb" class="popup-button" get="<? echo $_GET['gid'] ?>">Simpan</div>
      </div>
   </div>

<? }  ?>

<?
//<!-- TIPE MODE 6 = SAVE/MENYIMPAN -->
 if(isSave()) {
	$error = array();
if($_POST['mod']=='1') {
if(!$_POST['rgdate']) $error[] = 'rgdate:Silahkan masukkan Tanggal LPB.';
if(!$_POST['warehouse_id']) $error[] = 'warehouse_id:Silahkan Pilih Gudang Penerima.';
if(!$_POST['recipient']) $error[] = 'recipient:Silahkan Masukkana Orang Penerima Barang.';

}
		

if(count($error)>0) {
	echo generateError($error);
	
} else { 
	 
	if($_POST['mod']=='0') {
		$rs_trprdetails = mysql_query("select * from trpodetails where trporder_id = '".$_POST['trporder_id']."' AND trpostatus = '1'");
		$count_trprdetails=mysql_num_rows($rs_trprdetails);
		if ($count_trprdetails>0){
			mysql_query("INSERT INTO trrgoods (trporder_id, unitid, isclosed) VALUES ('".$_POST['trporder_id']."', '".$_SESSION['galaxy_unit']."', '2')");
			mysql_query("UPDATE trrgoods SET isclosed = '1' WHERE id ='".$_POST['gid']."';");
			//mysql_query("INSERT INTO trrgoods (trporder_id, isposted, unitid) VALUES ('".$_POST['gid']."', '0', '".$_SESSION['galaxy_unit']."')");
			
		}else{
			mysql_query("UPDATE trrgoods SET isclosed = '1' WHERE id ='".$_POST['gid']."';");
			//mysql_query("INSERT INTO trrgoods (trporder_id, isposted, unitid) VALUES ('".$_POST['gid']."', '0', '".$_SESSION['galaxy_unit']."')");
		}
	}
	
	if($_POST['mod']=='1') {	
		mysql_query("UPDATE trrgoods SET rgnom = '".$_POST['rgnom']."', rgdate = ".isNull($_POST['rgdate'],'DATE').", description = '".$_POST['description']."', recipient = '".$_POST['recipient']."',  warehouse_id = '".$_POST['warehouse_id']."',isclosed = '0', refnom = '".$_POST['refnom']."'  WHERE id ='".$_POST['gid']."';");
	}
 }
 }
?>

