<?php
	require_once '../../library/connectionmysql.php';
	Connected();
	if(isEdit())  {
		$rs_utang_awal = mysql_query("SELECT * FROM ak_htg_awal LEFT JOIN ak_htg ON (ak_htg_awal.id = ak_htg.hutang_awal_id) LEFT JOIN  suppliers ON (ak_htg.SUPPLIER_ID = suppliers.id) LEFT JOIN units ON (ak_htg.UNIT_ID = units.id) WHERE ak_htg.id = '".$_GET['gid']."'");
	$rows_utang_awal=mysql_fetch_array($rs_utang_awal);
	}
	$perm = array();
	$perm = getPermissions('54');

	if($perm[-1]=='1') { require_once '../../library/error-popup.php'; die; }
	
?>

<?
//<!-- FORM TIPE MODE 0 = TAMBAH/ADD, TIPE MODE 1 = UBAH/EDIT -->
 if(isAdd() || isEdit()) {
	 
 ?>
 
   
 
   <div class="popup-shadow" style="width: 600px;">
      <div class="popup-header">
         <span>Piutang</span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <form action="modul/akunting/utang-awal.php" method="post">
      <table>
      <? if($_SESSION['galaxy_unit']=='10')  {?>
      <tr>
      <td>Unit</td>
      <td align="center">:</td>
      <td><select name="UNIT_ID" class="select-text select-small">
      	<option value="">Pilih..</option>
      <?
	  $qry_units = "select * from units WHERE id != '10' order by id;";
	  $rs_units = mysql_query($qry_units);
	  while($rows_units=mysql_fetch_array($rs_units)) {
	  ?>
        <option value="<? echo $rows_units['id']?>" <? if(isEdit()) if($rows_units['id']==$rows_utang_awal[4]) echo 'selected'; ?>><? echo $rows_units['name']; ?></option>
      <? } ?>
      </select></td>
      </tr>
      <?
	  }else {
	  ?>
      <input type="hidden" name="UNIT_ID" value="<? if(isEdit()) echo $rows_utang_awal['UNIT_ID'] ?><? if(isAdd()) echo $_SESSION['galaxy_unit'] ?>" />
      <?
	  }
	  ?>
      
      <tr>
      <td>Supplier</td>
      <td align="center">:</td>
      <td><select name="supplier_id" class="select-text select-small" <? if(isEdit()) echo 'disabled' ?>>
      	<option value="">Pilih..</option>
      <?
	  $qry_suppliers = "select * from suppliers WHERE issubkon = '0' order by id;";
	  $rs_suppliers = mysql_query($qry_suppliers);
	  while($rows_suppliers=mysql_fetch_array($rs_suppliers)) {
	  ?>
        <option value="<? echo $rows_suppliers['id']?>" <? if(isEdit()) if($rows_suppliers['id']==$rows_utang_awal['supplier_id']) echo 'selected'; ?>><? echo $rows_suppliers['name']; ?></option>
      <? } ?>
      </select></td>
      </tr>
      <tr>
      <td>Tanggal</td>
      <td align="center">:</td>
      <td><input class="input-text" name="TANGGAL" type="datepicker" value="<? if(isEdit()) echo cDate($rows_utang_awal[2]) ?><? if(isAdd()) echo cDate(date('Y-m-d')) ?>" /></td>
      </tr>
      <tr>
      <td>No Bukti</td>
      <td align="center">:</td>
      <td><input class="input-text" name="nobuk" type="text" value="<? if(isEdit()) echo $rows_utang_awal[3] ?>" /></td>
      </tr>
      
      <tr>
      <td width="25%">Jumlah</td>
      <td width="5%" align="center">:</td>
      <td><input class="input-text currency padmin" name="DEBET" type="text" value="<? if(isEdit())  echo cFormat($rows_utang_awal[12], false)?>"></td>
      </tr>
      </table>
      <input type="hidden" name="gid" value="<? echo $_GET['gid'] ?>" />
      <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
      <? if(isEdit())  {?>
      <input type="hidden" name="supplier" value="<? echo $rows_utang_awal[1] ?>" />
      <input type="hidden" name="kasbank_id" value="<? echo $rows_utang_awal['KASBANK_ID'] ?>" />
      <input type="hidden" name="hutang_awal_id" value="<? echo $rows_utang_awal['hutang_awal_id'] ?>" />
      <?
	  }
	  ?>
      </form>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel">Batal</div>
      	<div mode="6" link="library/submenu/akunting/utang-awal" class="popup-button" get="">Simpan</div>
      </div>
   </div>

<? }  
//<!-- FORM TIPE MODE 2 = CONFIRM DELETE/KONFIRMASI HAPUS, TIPE MODE 4 = CONFIRM DELETE SELECTED/KONFIRMASI HAPUS YANG DIPILIH -->
if(isConfirmDelete() || isConfirmDeleteSelected()) { ?>
<?
	if(isConfirmDelete()) {
		$rs_item = mysql_query("select * from items where id = '".$_GET['gid']."'");
		$rows_item=mysql_fetch_array($rs_item);
	}
?>
   <div class="popup-shadow" style="width: 500px;">
      <div class="popup-header">
         <span>Konfirmasi Hapus</span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <table>
      <tr>
      <td class="center">
      <? if(isConfirmDelete()) {?>
      		<strong>Peringatan</strong>: <br /> 
      		Data <b>Utang</b> akan ikut terhapus, jika ada data yang terhubung!.
      		<br /><br />
      		Apakah anda yakin menghapus <br /><b style="text-decoration: underline;"><? echo $rows_item['name'] ?></b>?
      <? }?>
      
      <? if(isConfirmDeleteSelected()) {?>
      		<? if($_GET['gid']!='') { 
				$value = array();
				$value = generateArray($_GET['gid']); 
			?>
            	<strong>Peringatan: </strong><br /> Data <b>Utang</b> akan ikut terhapus, jika ada data yang terhubung!.
      		<br /><br />
                Sebanyak <b style="text-decoration: underline;"><? echo count($value) ?> item</b> yang akan dihapus!.<br />
                Apakah anda yakin untuk menghapusnya?
            <? } else { ?>
            	Tidak ada item yang akan dihapus.<br />Silahkan anda memilih check box untuk dicentang.
            <? } ?>
      <? }?>
      </td>
      </tr>
      </table>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel"><? if($_GET['gid']!='') echo 'Batal'; else echo 'Tutup' ?></div>
        <? if(isConfirmDelete()) { ?>
      		<div mode="3" link="modul/data/barang?<? echo $_GET['gid'] ?>" class="popup-button">Hapus</div>
        <? }?>
      	<? if(isConfirmDeleteSelected()) {
			if($_GET['gid']!='') {
				if(count($value)>0)
		?>
      		<div mode="5" link="modul/akunting/utang-awal?<? echo htmlspecialchars($_GET['gid']) ?>" class="popup-button">Hapus</div>
        <? } } ?>
      </div>
      
   </div>

<? } 

?>

<?
 if(isDelete()) {
	mysql_query("DELETE from items where id =".$_GET['gid']);
	
 } ?>
 
<?
//<!-- END TIPE MODE 3 -->

//<!-- =========================================================================================================================== -->

//<!-- TIPE MODE 5 = DELETE SELECTED/HAPUS YANG DIPILIH -->
?>

<? if(isDeleteSelected()) { 
	
	$value = array();
	$value = generateArray($_GET['gid']); 

	// Taruh query ke database untuk menghapus disini...
	// Contoh :
	for($i=0;$i<count($value);$i++) {
	 	mysql_query("DELETE from items where id = '".$value[$i]."'");
	}
	
 } 
//<!-- END TIPE MODE 5 -->

//<!-- =========================================================================================================================== -->
?>

<?
 if(isSave()) {
	 
	 
	$error = array();
if(!$_POST['supplier_id']) $error[] = 'supplier_id:Silahkan Pilih Supplier.';
if(!$_POST['TANGGAL']) $error[] = 'TANGGAL:Silahkan Masukkan Tanggal.';
if(!$_POST['DEBET']) $error[] = 'DEBET:Silahkan Masukkan Jumlah Hutang.';
if(!$_POST['UNIT_ID']) $error[] = 'UNIT_ID:Silahkan Pilih Unit.';
if(!$_POST['nobuk']) $error[] = 'nobuk:Silahkan Inputkan No bUkti.';

/*
$rs_check = mysql_query("select * from ak_htg_awal where unit_id = '".$_POST['UNIT_ID']."' AND supplier_id = '".$_POST['supplier_id']."'");
$rows_check = mysql_num_rows($rs_check);

if($_POST['mod']=='0')
	if($rows_check>0) $error[] = 'supplier_id:Maaf Supplier Sudah Ada.';

if($_POST['mod']=='1') 
	if($_POST['supplier_id']!=strtoupper($_POST['supplier']))
		if($rows_check>0) $error[] = 'supplier_id:Maaf Supplier Sudah Ada';
		
	*/

if(count($error)>0) {
	echo generateError($error);
	
} else { 
	 
	if($_POST['mod']=='0') {
		$kodeKasBank = KodeKasBank();
		$KodeAkUtang = KodeAkUtang();
		mysql_query("INSERT INTO ak_htg_awal (id, supplier_id, nobukti, tanggal, unit_id, status_utang) VALUES ('".$KodeAkUtang."', '".$_POST['supplier_id']."', '".$_POST['nobuk']."',".isNull($_POST['TANGGAL'],'DATE').", '".$_POST['UNIT_ID']."', '0')");
		
		mysql_query("INSERT INTO ak_kasbank (ID, JNS_TRANS, NO_BUKTI, TANGGAL, PERK_KASBANK, TGL_INPUT, UNIT_KODE, TGL_BG) VALUES ('".$kodeKasBank."', 'HTG', '".$_POST['nobuk']."', ".isNull($_POST['TANGGAL'],'DATE').", '0', ".isNull($_POST['TANGGAL'],'DATE').", '".$_POST['UNIT_ID']."', ".isNull($_POST['TANGGAL'],'DATE').")");
		
		mysql_query("INSERT INTO ak_detail_kasbank (KASBANK_ID, PERK_LAWAN, DEBET, TGL_INPUT, UNIT_KODE) VALUES ('".$kodeKasBank."', '75', ".isNull($_POST['DEBET'],'CUR').", ".isNull($_POST['TANGGAL'],'DATE').", '".$_POST['UNIT_ID']."')");
		
		mysql_query("INSERT INTO ak_htg (SUPPLIER_ID, DEBET, TANGGAL, UNIT_ID, KASBANK_ID, hutang_awal_id) VALUES ('".$_POST['supplier_id']."', ".isNull($_POST['DEBET'],'CUR').", ".isNull($_POST['TANGGAL'],'DATE').", '".$_POST['UNIT_ID']."', '".$kodeKasBank."','".$KodeAkUtang."')");
		
	}
	
	if($_POST['mod']=='1') {
		mysql_query("UPDATE ak_htg_awal SET nobukti= '".$_POST['nobuk']."',tanggal = ".isNull($_POST['TANGGAL'],'DATE').", unit_id = '".$_POST['UNIT_ID']."'  WHERE id ='".$_POST['gid']."';");
			
		mysql_query("UPDATE ak_kasbank SET TANGGAL = ".isNull($_POST['TANGGAL'],'DATE').", TGL_INPUT = ".isNull($_POST['TANGGAL'],'DATE').", UNIT_KODE = '".$_POST['UNIT_ID']."'  WHERE ID ='".$_POST['kasbank_id']."';");
		mysql_query("UPDATE ak_detail_kasbank SET DEBET = ".isNull($_POST['DEBET'],'CUR').", TGL_INPUT = ".isNull($_POST['TANGGAL'],'DATE').", UNIT_KODE = '".$_POST['UNIT_ID']."' WHERE KASBANK_ID ='".$_POST['kasbank_id']."';");
		
		mysql_query("UPDATE ak_htg SET DEBET = ".isNull($_POST['DEBET'],'CUR').", TANGGAL = ".isNull($_POST['TANGGAL'],'DATE').", UNIT_ID =  '".$_POST['UNIT_ID']."' WHERE hutang_awal_id ='".$_POST['hutang_awal_id']."';");
		
	}
}

} 
//<!-- END TIPE MODE 6 --> 
?>



