<?php

require_once '../../library/connectionmysql.php';
Connected();
if($_SESSION['galaxy_posisi']=='none' || !isset($_SESSION['galaxy_posisi'])) { header("Location: ../../index.php"); die; }
if($_SESSION['galaxy_unit']=='none' || !isset($_SESSION['galaxy_unit'])) { header("Location: ../../index.php"); die; }
$perm = array();
$perm = getPermissions('27');
if($perm[-1]=='1') { require_once '../../library/error-popup.php'; die; }
$error = array();
if(!$_POST['unit_id']) $error[] = 'unit_id:Silahkan Pilih Unit/Cabang terlebih dahulu.';
if(!$_POST['warehouse_id']) $error[] = 'warehouse_id:Silahkan Pilih Gudang terlebih dahulu.';

if(count($error)>0) {
	//tampilkan pesan error, jika ada error.. :D
	echo generateError($error).'|*|';	
	
	
} else {
$rs_unit=mysql_query("select * from units where id = '".$_POST['unit_id'] ."'");
$rows_units=mysql_fetch_array($rs_unit);
	
header("Content-type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=Kartu-Stock-".$rows_units['code']."-".date('m-Y').".xls");
$_GET['warehouse_id']=$_POST['warehouse_id'];

$rs_warehouses= mysql_query("select * from warehouses where id = '".$_GET['warehouse_id']."'");
$rows_warehouses=mysql_fetch_array($rs_warehouses);

//$qry_stockitem = "SELECT * FROM stockitems LEFT JOIN warehouses ON (stockitems.warehouse_id = warehouses.id) LEFT JOIN items ON (stockitems.item_id = items.id) LEFT JOIN transtypes ON (stockitems.transtype_id = transtypes.id) where  stockitems.transtype_id = '1' AND stockitems.unit_id = '".$rows_units['id']."' AND stockitems.warehouse_id = '".$_GET['warehouse_id']."' group by items.id order by items.id ASC";

$qry_stockitem = "SELECT * FROM stockitems LEFT JOIN warehouses ON (stockitems.warehouse_id = warehouses.id) LEFT JOIN items ON (stockitems.item_id = items.id) LEFT JOIN transtypes ON (stockitems.transtype_id = transtypes.id) where  stockitems.unit_id = '".$rows_units['id']."' AND stockitems.warehouse_id = '".$_GET['warehouse_id']."' group by items.id order by items.id ASC";
$rs_stockitem = mysql_query($qry_stockitem);
		
?>
      <table class="ctable-skpd" style="width: 100%;">
      <tr class="isi">
	  <td align="center" colspan="9"><b><? echo strtoupper($rows_units['name']); ?></b></td>
	  </tr>
	  <tr class="isi">
	  <td align="center" colspan="9"><b>KARTU STOK</b></td>
	  </tr>
	  <tr class="isi">
	  <td align="center" colspan="9"><b><? echo strtoupper($rows_warehouses['name']); ?></b></td>
	  </tr>
      
      </table>
  <? if($_POST['summary'] =='1') {
	  
?>    
      <table border="1" class="ctable-skpd" style="width: 100%;">
	  
	  	<tr style="background:#999; background: #efefef;font-weight: bold; text-align:center;">
	  	<td width="3%" align="center" valign="middle">No</td>
	  	<td width="15%" valign="middle">Kode Barang</td>
        <td valign="middle" colspan="3">Nama Barang</td>
      	<td width="10%" align="center" valign="middle">Awal</td>
		<td width="10%" align="center" valign="middle">Debet</td>
		<td width="10%" align="center" valign="middle">Kredit</td>
		<td width="10%" align="center" valign="middle">Akhir</td>
        
		</tr>                      
	  <?php 
	 
		
		$i = 1;
		while($rows_stockitem=mysql_fetch_array($rs_stockitem)) {
			$rows_awal=mysql_fetch_array(mysql_query("select SUM(qty) AS awal, SUM(tot) AS harga_awal from stockitems where transtype_id ='1' AND warehouse_id = '".$_GET['warehouse_id']."' AND unit_id = '".$rows_units['id']."' and item_id = '".$rows_stockitem[3]."'"));
			$rows_pembelian=mysql_fetch_array(mysql_query("select SUM(qty) AS pembelian, SUM(tot) AS harga_pembelian from stockitems where transtype_id ='2' AND warehouse_id = '".$_GET['warehouse_id']."' AND unit_id = '".$rows_units['id']."' and item_id = '".$rows_stockitem[3]."'"));		
			$rows_penjualan=mysql_fetch_array(mysql_query("select SUM(qty) AS penjualan, SUM(tot) AS harga_penjualan from stockitems where transtype_id ='3'  AND warehouse_id = '".$_GET['warehouse_id']."' AND unit_id = '".$rows_units['id']."' and item_id = '".$rows_stockitem[3]."'"));
			$rows_retur_beli=mysql_fetch_array(mysql_query("select SUM(qty) AS retur_beli, SUM(tot) AS harga_retur_beli from stockitems where transtype_id ='4' AND warehouse_id = '".$_GET['warehouse_id']."' AND unit_id = '".$rows_units['id']."' and item_id = '".$rows_stockitem[3]."'"));
			$rows_retur_jual=mysql_fetch_array(mysql_query("select SUM(qty) AS retur_jual, SUM(tot) AS harga_retur_jual from stockitems where transtype_id ='5' AND warehouse_id = '".$_GET['warehouse_id']."' AND unit_id = '".$rows_units['id']."' and item_id = '".$rows_stockitem[3]."'"));
			$rows_mvmasuk=mysql_fetch_array(mysql_query("select SUM(qty) AS mvmasuk, SUM(tot) AS harga_mv_masuk from stockitems where transtype_id ='6' AND warehouse_id = '".$_GET['warehouse_id']."' AND unit_id = '".$rows_units['id']."' and item_id = '".$rows_stockitem[3]."'"));
			$rows_mvkeluar=mysql_fetch_array(mysql_query("select SUM(qty) AS mvkeluar, SUM(tot) AS harga_mv_keluar from stockitems where transtype_id ='7' AND warehouse_id = '".$_GET['warehouse_id']."' AND unit_id = '".$rows_units['id']."' and item_id = '".$rows_stockitem[3]."'"));
			
			$debet = $rows_pembelian['pembelian'] + $rows_retur_jual['retur_jual'] + $rows_mvmasuk['mvmasuk'];
			$kridit = $rows_penjualan['penjualan'] + $rows_retur_beli['retur_beli'] + $rows_mvkeluar['mvkeluar'] ;
			$akhir = $rows_awal['awal'] + ($debet - $kridit);
			
			
			
			
			
			?>
			<tr class="isi">
			<td align="right"><? echo $i ?></td>
			<td align="left"><? echo $rows_stockitem[28]?></td>
            <td align="left"colspan="3"><? echo $rows_stockitem[27]?></td>
			<td align="right"><? echo cFormat($rows_awal['awal'],false) ?></td>
			<td align="right"><? echo cFormat($debet,false) ?></td>
            <td align="right"><? echo cFormat($kridit,false) ?></td>
			<td align="right"><? echo cFormat($akhir,false) ?></td>
			</tr>            
             <?
			 $i++;
			 }	 		 
		?>
      </table>
      <table border="0" class="ctable-skpd" style="width: 100%;">
         <tr class="isi"><td width="100%" align="left" colspan="9">&nbsp;</td></tr>
      	 </table>
      <? }?> 
      <? if($_POST['summary'] !='1') {		  
 
		  while($rows_stockitem=mysql_fetch_array($rs_stockitem)) {
			  $rows_awal=mysql_fetch_array(mysql_query("select SUM(qty) AS awal, SUM(tot) AS harga_awal from stockitems where transtype_id ='1' AND warehouse_id = '".$_GET['warehouse_id']."' AND unit_id = '".$rows_units['id']."' and item_id = '".$rows_stockitem[3]."'"));
			$rows_pembelian=mysql_fetch_array(mysql_query("select SUM(qty) AS pembelian, SUM(tot) AS harga_pembelian from stockitems where transtype_id ='2' AND warehouse_id = '".$_GET['warehouse_id']."' AND unit_id = '".$rows_units['id']."' and item_id = '".$rows_stockitem[3]."'"));		
			$rows_penjualan=mysql_fetch_array(mysql_query("select SUM(qty) AS penjualan, SUM(tot) AS harga_penjualan from stockitems where transtype_id ='3'  AND warehouse_id = '".$_GET['warehouse_id']."' AND unit_id = '".$rows_units['id']."' and item_id = '".$rows_stockitem[3]."'"));
			$rows_retur_beli=mysql_fetch_array(mysql_query("select SUM(qty) AS retur_beli, SUM(tot) AS harga_retur_beli from stockitems where transtype_id ='4' AND warehouse_id = '".$_GET['warehouse_id']."' AND unit_id = '".$rows_units['id']."' and item_id = '".$rows_stockitem[3]."'"));
			$rows_retur_jual=mysql_fetch_array(mysql_query("select SUM(qty) AS retur_jual, SUM(tot) AS harga_retur_jual from stockitems where transtype_id ='5' AND warehouse_id = '".$_GET['warehouse_id']."' AND unit_id = '".$rows_units['id']."' and item_id = '".$rows_stockitem[3]."'"));
			$rows_mvmasuk=mysql_fetch_array(mysql_query("select SUM(qty) AS mvmasuk, SUM(tot) AS harga_mv_masuk from stockitems where transtype_id ='6' AND warehouse_id = '".$_GET['warehouse_id']."' AND unit_id = '".$rows_units['id']."' and item_id = '".$rows_stockitem[3]."'"));
			$rows_mvkeluar=mysql_fetch_array(mysql_query("select SUM(qty) AS mvkeluar, SUM(tot) AS harga_mv_keluar from stockitems where transtype_id ='7' AND warehouse_id = '".$_GET['warehouse_id']."' AND unit_id = '".$rows_units['id']."' and item_id = '".$rows_stockitem[3]."'"));
			
			$debet = $rows_pembelian['pembelian'] + $rows_retur_jual['retur_jual'] + $rows_mvmasuk['mvmasuk'] ;
			$kridit = $rows_penjualan['penjualan'] + $rows_retur_beli['retur_beli'] + $rows_mvkeluar['mvkeluar'] ;
			$akhir = $rows_awal['awal'] + ($debet - $kridit);
			
			$harga_debet = $rows_pembelian['harga_pembelian'] + $rows_retur_jual['harga_retur_jual'];
			$harga_kridit = $rows_penjualan['harga_penjualan'] + $rows_retur_beli['harga_retur_beli'];
			$harga_akhir = $rows_awal['harga_awal'] + ($harga_kridit - $harga_debet );
			
			
			?>
            <table border="1" class="ctable-skpd" style="width: 100%;">
	  		<tr  class="isi">
            <td width="3%" align="left" colspan="9"><b><? echo $rows_stockitem[27]?></b></td>
            
            </tr>
            <tr  style="background:#999; background: #efefef;font-weight: bold; text-align:center">
            <td width="3%" align="center" valign="middle">No</td>
            <td width="15%" valign="middle">Tanggal</td>
            <td valign="middle">No Bukti</td>
            <td valign="middle">Jenis</td>
            <td width="10%" align="center" valign="middle">Awal</td>
            <td width="10%" align="center" valign="middle">Debet</td>
            <td width="10%" align="center" valign="middle">Kredit</td>
            <td width="10%" align="center" valign="middle">Akhir</td>
            <td width="10%" align="center" valign="middle">Harga</td>
            </tr>                      
          <?php 
         
            $qry_dstockitem = "SELECT * FROM stockitems LEFT JOIN transtypes ON (stockitems.transtype_id = transtypes.id) where stockitems.unit_id = '".$rows_units['id']."' AND stockitems.warehouse_id = '".$_GET['warehouse_id']."' AND stockitems.item_id = '".$rows_stockitem[3]."' order by stockitems.transtype_id ASC";
			$rs_dstockitem = mysql_query($qry_dstockitem);
            $i = 1;
			$total['awal'] = 0;
			$total['harga_awal'] = 0;
            while($rows_dstockitem=mysql_fetch_array($rs_dstockitem)) {
                
                
                ?>
                <tr class="isi">
                <td align="right"><? echo $i ?></td>
                <td align="left"><? echo cDate2($rows_dstockitem[1])?></td>
                <td align="left"><? echo $rows_dstockitem[5]?></td>
                <td align="left"><? echo $rows_dstockitem['name']?></td>
                <? if($rows_dstockitem[4] =='1') { ?>
                <td align="right"><? echo cFormat($rows_dstockitem[6],false) ?></td>
                <td align="right"></td>
                <td align="right"></td>
                <? $total['awal'] = $total['awal'] + $rows_dstockitem[6]; $total['harga_awal'] = $total['harga_awal'] + $rows_dstockitem[7];}?>
                
                <? if($rows_dstockitem[4] =='2') { ?>
                <td align="right"></td>
                <td align="right"><? echo cFormat($rows_dstockitem[6],false) ?></td>
                <td align="right"></td>
                <? $total['awal'] = $total['awal'] + $rows_dstockitem[6]; $total['harga_awal'] = $total['harga_awal'] + $rows_dstockitem[7];}?>
                
                <? if($rows_dstockitem[4] =='3') { ?>
                <td align="right"></td>
                <td align="right"></td>
                <td align="right"><? echo cFormat($rows_dstockitem[6],false) ?></td>
                <? $total['awal'] = $total['awal'] - $rows_dstockitem[6]; $total['harga_awal'] = $total['harga_awal'] - $rows_dstockitem[7];}?>
                
                <? if($rows_dstockitem[4] =='4') { ?>
                <td align="right"></td>
                <td align="right"></td>
                <td align="right"><? echo cFormat($rows_dstockitem[6],false) ?></td>
                <? $total['awal'] = $total['awal'] - $rows_dstockitem[6]; $total['harga_awal'] = $total['harga_awal'] - $rows_dstockitem[7];}?>
                
                <? if($rows_dstockitem[4] =='5') { ?>
                <td align="right"></td>
                <td align="right"><? echo cFormat($rows_dstockitem[6],false) ?></td>
                <td align="right"></td>
                <? $total['awal'] = $total['awal'] + $rows_dstockitem[6]; $total['harga_awal'] = $total['harga_awal'] + $rows_dstockitem[7];}?>
                
                <? if($rows_dstockitem[4] =='6') { ?>
                <td align="right"></td>
                <td align="right"><? echo cFormat($rows_dstockitem[6],false) ?></td>
                <td align="right"></td>
                <? $total['awal'] = $total['awal'] + $rows_dstockitem[6]; $total['harga_awal'] = $total['harga_awal'] + $rows_dstockitem[7];}?>
                
                <? if($rows_dstockitem[4] =='7') { ?>
                <td align="right"></td>
                <td align="right"></td>
                <td align="right"><? echo cFormat($rows_dstockitem[6],false) ?></td>
                <? $total['awal'] = $total['awal'] - $rows_dstockitem[6]; $total['harga_awal'] = $total['harga_awal'] - $rows_dstockitem[7];}?>
                
                <td align="right"><? echo cFormat($total['awal'],false) ?></td>
                <td align="right"><? echo cFormat($rows_dstockitem[7],false) ?></td>
                </tr>            
                 <?
                 $i++;
                 }	 		 
            ?>
            <tr style="background:#CCC;">
            <td width="3%" align="center" valign="middle" colspan="4"><b>TOTAL</b></td>
            
            <td align="right"><b><? echo cFormat($rows_awal['awal'],false) ?></b></td>
			<td align="right"><b><? echo cFormat($debet,false) ?></b></td>
            <td align="right"><b><? echo cFormat($kridit,false) ?></b></td>
			<td align="right"><b><? echo cFormat($akhir,false) ?></b></td>
            
            <td align="right"><b><? echo cFormat($harga_akhir,false) ?></b></td>
            </tr>   
            
          </table>
     	 
         <table border="0" class="ctable-skpd" style="width: 100%;">
         <tr class="isi"><td width="100%" align="left" colspan="8">&nbsp;</td></tr>
      	 </table>
	    <?
			 $i++;
			 }	 		 
		?>
      <? }?> 
<? } ?>
      
   