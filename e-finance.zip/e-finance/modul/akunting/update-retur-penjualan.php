<?php
	require_once '../../library/connectionmysql.php';
	Connected();
	
	$perm = array();
	$perm = getPermissions('26');
	if($perm[-1]=='1') { require_once '../../library/error-popup.php'; die; }
	
?>


<? 
if(isApply()) {
	$rs_sreturs = mysql_query("select * from sreturs LEFT JOIN fakturs ON (sreturs.faktur_id = fakturs.id) LEFT JOIN sjs ON (fakturs.sj_id = sjs.id) where sreturs.id = '".$_GET['gid']."'");
	$rows_sreturs=mysql_fetch_array($rs_sreturs);
?>
   <div class="popup-shadow" style="width: 500px;">
      <div class="popup-header">
         <span>Notifikasi Setuju</span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <form action="modul/akunting/update-retur-penjualan.php" method="post">
      <table>
      <tr>
      <td class="center">
  
      		<strong>Peringatan</strong>: <br /> 
      		Data <b>Retur Penjualan</b> Akan Di Tanda Tangani!.
      		<br /><br />
      		Dengan No Retur : <b style="text-decoration: underline;"><? echo $rows_sreturs['retnom'] ?></b>?
      <input type="hidden" name="gid" value="<? echo $_GET['gid'] ?>" />
      <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
     
     <input type="hidden" name="faknom" value="<? echo $rows_sreturs['retnom'] ?>" />
      <input type="hidden" name="warehouse_id" value="<? echo $rows_sreturs['warehouse_id'] ?>" />
      <input type="hidden" name="sjnom" value="<? echo $rows_sreturs['sjnom'] ?>" />
      
      <input type="hidden" name="unitid" value="<? echo $rows_sreturs['unitid'] ?>" />
      </td>
      </tr>
      </table>
      </form>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel"><? if($_GET['gid']!='') echo 'Batal'; else echo 'Tutup' ?></div>
        <div mode="6" link="library/submenu/akunting/update-retur-penjualan" class="popup-button" get="">Proses</div>
      </div>
      
   </div>

<? } 
?>

<? 
if(isCencel()) {
	$rs_sreturs = mysql_query("select * from sreturs where id = '".$_GET['gid']."'");
	$rows_sreturs=mysql_fetch_array($rs_sreturs);
?>
   <div class="popup-shadow" style="width: 500px;">
      <div class="popup-header">
         <span>Notifikasi Tolak</span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <form action="modul/akunting/update-retur-penjualan.php" method="post">
      <table>
      <tr>
      <td class="center">
  
      		<strong>Peringatan</strong>: <br /> 
      		Data <b>Retur Penjualan</b> Akan Di ditolak!.
      		<br /><br />
      		Dengan No Retur : <b style="text-decoration: underline;"><? echo $rows_sreturs['retnom'] ?></b>?
      <input type="hidden" name="gid" value="<? echo $_GET['gid'] ?>" />
      <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
     
      </td>
      </tr>
      </table>
      </form>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel"><? if($_GET['gid']!='') echo 'Batal'; else echo 'Tutup' ?></div>
        <div mode="6" link="library/submenu/akunting/update-retur-penjualan" class="popup-button" get="">Proses</div>
      </div>
      
   </div>

<? } 
?>

<?
//<!-- TIPE MODE 6 = SAVE/MENYIMPAN -->
if(isSave()) {
$error = array();
	

if(count($error)>0) {
	echo generateError($error);
	
} else { 
	if($_POST['mod']=='7') {
			
		mysql_query("UPDATE sreturs SET ispost = '1' WHERE id ='".$_POST['gid']."';");
		$qry_bretdetails = "select * from sretdetails where sretur_id = '".$_POST['gid']."';";
		$rs_bretdetails = mysql_query($qry_bretdetails);
		while($rows_bretdetailss=mysql_fetch_array($rs_bretdetails)) {
			mysql_query("UPDATE fakdetails SET fakstatus = '1' WHERE id ='".$rows_bretdetailss['fakdetails_id']."';");
			mysql_query("UPDATE items SET stock = stock+'".$rows_bretdetailss['qty']."' WHERE id ='".$rows_bretdetailss['item_id']."';");
			
			mysql_query("INSERT INTO stockitems (stockdate, warehouse_id, item_id, transtype_id, nobukti1, qty, tot, sretdetail_id, unit_id, price) VALUES ('".date('Y-m-d')."', '".$_POST['warehouse_id']."', '".$rows_bretdetailss['item_id']."', '5',  '".$_POST['faknom']."', '".$rows_bretdetailss['qty']."', '".$rows_bretdetailss['qty']*$rows_bretdetailss['price']."', '".$rows_bretdetailss['id']."', '".$_POST['unitid']."',  '".$rows_bretdetailss['price']."')");
		}
		
		$today=date('Y-m-d');
		$qry_jumlah="select * from sretdetails where sretur_id='".$_POST['gid']."' ";
		$row_jumlah=mysql_fetch_array(mysql_query($qry_jumlah));
		$jumlah=$row_jumlah['qty']*$row_jumlah['price'];
		$qry_customer="select  sreturs.unitid, spbs.customer_id, sjs.jtdate, sjs.id from sreturs LEFT JOIN  fakturs ON(sreturs.faktur_id=fakturs.id) LEFT JOIN sjs ON(fakturs.sj_id=sjs.id) LEFT JOIN  spbs ON(sjs.spb_id=spbs.id) where sreturs.id='".$_POST['gid']."' ";
		$row_customer=mysql_fetch_array(mysql_query($qry_customer));
		
		
		
		$qry_jadi="select sretdetails.qty, sretdetails.price from  sretdetails JOIN items ON (sretdetails.item_id = items.id) where items.icategory_id = '1' AND sretdetails.sretur_id='".$_POST['gid']."' ";
		$rs_jadi = mysql_query($qry_jadi);
		$row_jaditotal = 0;
		while($row_jadi=mysql_fetch_array($rs_jadi)) {
			$row_jadiaja = $row_jadi['qty']*$row_jadi['price'];
			$row_jaditotal = $row_jaditotal + $row_jadiaja;
		}
		
		$qry_baku="select sretdetails.qty, sretdetails.price from  sretdetails JOIN items ON (sretdetails.item_id = items.id) where items.icategory_id = '3' AND sretdetails.sretur_id='".$_POST['gid']."' ";
		//$row_baku=mysql_fetch_array(mysql_query($qry_baku));
		$rs_baku = mysql_query($qry_baku);
		$row_bakutotal = 0;
		while($row_baku=mysql_fetch_array($rs_baku)) {
			$row_bakuaja = $row_baku['qty']*$row_baku['price'];
			$row_bakutotal = $row_bakutotal + $row_bakuaja;
		}
		
		if($row_jaditotal > 0) {
			$KodeKasBank = KodeKasBank(); 
			mysql_query("insert into ak_kasbanks (ID, JNS_TRANS, TANGGAL, NO_BUKTI, NO_REFF, PERK_KASBANK, URAIAN_DEBET, DEBET, PERK_KREDIT, URAIAN_KREDIT,  KREDIT, TERIMA_DARI, UNIT_KODE) VALUES ('".$KodeKasBank."', 'RTJ', '".$today."', '', '', '61', '', '".$row_jaditotal."', '17', '', '".$row_jaditotal."', '', '".$_POST['unitid']."') ");
			mysql_query("INSERT INTO ak_piut (CUSTOMER_ID, SJ_ID, SRETUR_ID, KASBANK_ID, KREDIT, TANGGAL, JTH_TEMPO, UNIT_ID) VALUES ('".$row_customer['customer_id']."',		'".$row_customer['id']."', '".$_POST['gid']."' , '".$KodeKasBank."',  '".$row_jaditotal."', '".$today."' , '".$row_customer['jtdate']."' , '".$_POST['unitid']."')");
		}
		
		if($row_bakutotal > 0) {
			$KodeKasBank = KodeKasBank(); 
			mysql_query("insert into ak_kasbanks (ID, JNS_TRANS, TANGGAL, NO_BUKTI, NO_REFF, PERK_KASBANK, URAIAN_DEBET, DEBET, PERK_KREDIT, URAIAN_KREDIT,  KREDIT, TERIMA_DARI, UNIT_KODE) VALUES ('".$KodeKasBank."', 'RTJ', '".$today."', '', '', '58', '', '".$row_bakutotal."', '17', '', '".$row_bakutotal."', '', '".$_POST['unitid']."') ");
			mysql_query("INSERT INTO ak_piut (CUSTOMER_ID, SJ_ID, SRETUR_ID, KASBANK_ID, KREDIT, TANGGAL, JTH_TEMPO, UNIT_ID) VALUES ('".$row_customer['customer_id']."',		'".$row_customer['id']."', '".$_POST['gid']."' , '".$KodeKasBank."',  '".$row_bakutotal."', '".$today."' , '".$row_customer['jtdate']."' , '".$_POST['unitid']."')");
		}
		
		/*
		mysql_query("insert into ak_kasbank (JNS_TRANS, TANGGAL, TGL_INPUT, USER_ID, UNIT_KODE) VALUES (
		'RTJ' ,
		'".$today."' ,
		'".$today."' ,
		'".$_SESSION['galaxy_kode']."' ,
		'".$row_customer['unitid']."' ) ");
		
		$qry_detail="select max(ID) as max from ak_kasbank ";
		$row_detail=mysql_fetch_array(mysql_query($qry_detail));
		mysql_query("insert into ak_detail_kasbank (KASBANK_ID,PERK_LAWAN,DEBET,TGL_INPUT,USER_ID,UNIT_KODE) VALUES (
		'".$row_detail['max']."' ,
		'17' ,
		'".$jumlah."' ,
		'".$today."' ,
		'".$_SESSION['galaxy_kode']."' ,
		'".$row_jumlah['unitid']."' )");
		
		mysql_query("insert into ak_piut (CUSTOMER_ID, SJ_ID, KASBANK_ID, KREDIT, TANGGAL, JTH_TEMPO, UNIT_ID) VALUES (
		'".$row_customer['customer_id']."',
		'".$row_customer['id']."',
		'".$row_detail['max']."' ,
		'".$jumlah."',
		'".$today."' ,
		'".$row_customer['jtdate']."' ,
		'".$row_customer['unitid']."')"); */
	}
	if($_POST['mod']=='8') {	
		mysql_query("UPDATE sreturs SET ispost = '0' WHERE id ='".$_POST['gid']."';");
		
		$qry_bretdetails = "select * from sretdetails JOIN items ON ( sretdetails.item_id = items.id) where sretdetails.sretur_id = '".$_POST['gid']."';";
		$rs_bretdetails = mysql_query($qry_bretdetails);
		while($rows_bretdetailss=mysql_fetch_array($rs_bretdetails)) {
			mysql_query("UPDATE fakdetails SET fakstatus = '1' WHERE id ='".$rows_bretdetailss['fakdetails_id']."';");
		}
		
	}
 }
 }
?>

