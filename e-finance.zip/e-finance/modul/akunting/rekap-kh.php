<?php
require_once '../../library/connectionmysql.php';
Connected();
	$perm = array();
	$perm = getPermissions('51');

	if($perm[-1]=='1') { require_once '../../library/error-popup.php'; die; }
	
?>
<?
if(isAdd())
{
	$today=date("Y-m-d");
?>
<div class="popup-shadow" style="width: 600px;">
	<div class="popup-header">
         <span>Kartu Piutang</span>
         <div class="popup-close">X</div>
    </div>
    <div class="popup-body">
    	<form action="modul/akunting/kartu-piutang.php" method="GET">
        <table>
            <tr>
            	<td>Dari</td>
                <td align="center">:</td>
                <td><input class="input-text" name="tgl-awal" type="datepicker" value="" /></td>
            </tr>
            <tr>
            	<td>Sampai</td>
                <td align="center">:</td>
                <td><input class="input-text" name="tgl-akhir" type="datepicker" value="<? echo cDate($today)?>" /></td>
            </tr>
        </table>
        </form>
    </div>
    <div class="popup-footer">
    
    	<div class="popup-cancel">Batal</div>
 <!--        <div target="<? //echo md5('cetak-KrtHtg') ?>" type="pdf" link="modul/laporan/report?<? //echo $rows_Supplier[0] ?>" class="pdf-button" >Cetak Kas/Bank</div>	-->
       <div mode="6" link="library/submenu/akunting/dt-pembelian" class="popup-button" get="<? echo $rows_Supplier['id'] ?>">Cetak Kartu Hutang</div>
     </div>
</div>
<?
}
?>