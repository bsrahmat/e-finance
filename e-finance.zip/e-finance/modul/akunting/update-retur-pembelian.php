<?php
	require_once '../../library/connectionmysql.php';
	Connected();
	
	$perm = array();
	$perm = getPermissions('24');
	if($perm[-1]=='1') { require_once '../../library/error-popup.php'; die; }
	
?>


<? 
if(isApply()) {
	$rs_breturs = mysql_query("select * from breturs LEFT JOIN trrgoods ON (breturs.trrgood_id = trrgoods.id) where breturs.id = '".$_GET['gid']."'");
	$rows_breturs=mysql_fetch_array($rs_breturs);
?>
   <div class="popup-shadow" style="width: 500px;">
      <div class="popup-header">
         <span>Notifikasi Setuju</span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <form action="modul/akunting/update-retur-pembelian.php" method="post">
      <table>
      <tr>
      <td class="center">
  
      		<strong>Peringatan</strong>: <br /> 
      		Data <b>Retur Pembelianr</b> Akan Di Tutup!.
      		<br /><br />
      		Dengan No Retur : <b style="text-decoration: underline;"><? echo $rows_breturs['retnom'] ?></b>?
      <input type="hidden" name="gid" value="<? echo $_GET['gid'] ?>" />
      <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
      
      <input type="hidden" name="faknom" value="<? echo $rows_breturs['retnom'] ?>" />
      <input type="hidden" name="warehouse_id" value="<? echo $rows_breturs['warehouse_id'] ?>" />
      <input type="hidden" name="unitid" value="<? echo $rows_breturs['unitid'] ?>" />
     
      </td>
      </tr>
      </table>
      </form>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel"><? if($_GET['gid']!='') echo 'Batal'; else echo 'Tutup' ?></div>
        <div mode="6" link="library/submenu/akunting/update-retur-pembelian" class="popup-button" get="">Proses</div>
      </div>
      
   </div>

<? } 
?>

<? 
if(isCencel()) {
	$rs_breturs = mysql_query("select * from breturs where id = '".$_GET['gid']."'");
	$rows_breturs=mysql_fetch_array($rs_breturs);
?>
   <div class="popup-shadow" style="width: 500px;">
      <div class="popup-header">
         <span>Notifikasi Setuju</span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <form action="modul/akunting/update-retur-pembelian.php" method="post">
      <table>
      <tr>
      <td class="center">
  
      		<strong>Peringatan</strong>: <br /> 
      		Data <b>Retur Pembelianr</b> Akan Di ditolak!.
      		<br /><br />
      		Dengan No Retur : <b style="text-decoration: underline;"><? echo $rows_breturs['retnom'] ?></b>?
      <input type="hidden" name="gid" value="<? echo $_GET['gid'] ?>" />
      <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
     
      </td>
      </tr>
      </table>
      </form>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel"><? if($_GET['gid']!='') echo 'Batal'; else echo 'Tutup' ?></div>
        <div mode="6" link="library/submenu/akunting/update-retur-pembelian" class="popup-button" get="">Proses</div>
      </div>
      
   </div>

<? } 
?>

<?
//<!-- TIPE MODE 6 = SAVE/MENYIMPAN -->
if(isSave()) {
$error = array();
	

if(count($error)>0) {
	echo generateError($error);
	
} else { 
	if($_POST['mod']=='7') {	
		
		mysql_query("UPDATE breturs SET ispost = '1' WHERE id ='".$_POST['gid']."';");
		$qry_bretdetails = "select * from bretdetails where bretur_id = '".$_POST['gid']."';";
		$rs_bretdetails = mysql_query($qry_bretdetails);
		while($rows_bretdetailss=mysql_fetch_array($rs_bretdetails)) {
			mysql_query("UPDATE trrgdetails SET trrgstatus = '1' WHERE id ='".$rows_bretdetailss['trrgdetails_id']."';");
			mysql_query("UPDATE items SET stock = stock-'".$rows_bretdetailss['qty']."' WHERE id ='".$rows_bretdetailss['item_id']."';");
			mysql_query("INSERT INTO stockitems (stockdate, warehouse_id, item_id, transtype_id, nobukti1, qty, tot, bretdetail_id, unit_id, price) VALUES ('".date('Y-m-d')."', '".$_POST['warehouse_id']."', '".$rows_bretdetailss['item_id']."', '4',  '".$_POST['faknom']."', '".$rows_bretdetailss['qty']."', '".$rows_bretdetailss['qty']*$rows_bretdetailss['price']."', '".$rows_bretdetailss['id']."', '".$_POST['unitid']."',  '".$rows_bretdetailss['price']."')");
		}
		
		$today=date('Y-m-d');
		$qry_jumlah="select * from bretdetails where bretur_id='".$_POST['gid']."' ";
		$row_jumlah=mysql_fetch_array(mysql_query($qry_jumlah));
		$jumlah=($row_jumlah['price']+$row_jumlah['ppnperitem'])*$row_jumlah['qty'];
		$qry_supplier="select trporders.supplier_id, trporders.unitid,breturs.trrgood_id from breturs LEFT JOIN trrgoods ON (breturs.trrgood_id=trrgoods.id) LEFT JOIN trporders ON (trrgoods.trporder_id = trporders.id) where breturs.id = '".$_POST['gid']."' ";
		$row_supplier=mysql_fetch_array(mysql_query($qry_supplier));
		
		
		
		$qry_jadi="select bretdetails.qty, bretdetails.price, bretdetails.ppnperitem  from  bretdetails JOIN items ON (bretdetails.item_id = items.id) where items.icategory_id = '1' AND bretdetails.bretur_id='".$_POST['gid']."' ";
		$rs_jadi = mysql_query($qry_jadi);
		$row_jaditotal = 0;
		while($row_jadi=mysql_fetch_array($rs_jadi)) {
			$row_jadiaja = ($row_jadi[1]+$row_jadi[2])*$row_jadi[0];
			$row_jaditotal = $row_jaditotal + $row_jadiaja;
		}
		
		$qry_baku="select bretdetails.qty, bretdetails.price, bretdetails.ppnperitem  from  bretdetails JOIN items ON (bretdetails.item_id = items.id) where items.icategory_id = '3' AND bretdetails.bretur_id='".$_POST['gid']."' ";
		//$row_baku=mysql_fetch_array(mysql_query($qry_baku));
		$rs_baku = mysql_query($qry_baku);
		$row_bakutotal = 0;
		while($row_baku=mysql_fetch_array($rs_baku)) {
			$row_bakuaja = ($row_baku[1]+$row_baku[2])*$row_baku[0];
			$row_bakutotal = $row_bakutotal + $row_bakuaja;
		}
		
		if($row_jaditotal > 0) {
			$KodeKasBank = KodeKasBank(); 
			mysql_query("insert into ak_kasbanks (ID, JNS_TRANS, TANGGAL, NO_BUKTI, NO_REFF, PERK_KASBANK, URAIAN_DEBET, DEBET, PERK_KREDIT, URAIAN_KREDIT,  KREDIT, TERIMA_DARI, UNIT_KODE) VALUES ('".$KodeKasBank."', 'RTB', '".$today."', '', '', '75', '', '".$row_jaditotal."', '61', '', '".$row_jaditotal."', '', '".$_POST['unitid']."') ");
			mysql_query("INSERT INTO ak_htg (SUPPLIER_ID,TRRGOOD_ID,BRETUR_ID, KASBANK_ID, KREDIT,TANGGAL, UNIT_ID) VALUES ('".$row_supplier['supplier_id']."', '".$row_supplier['trrgood_id']."', '".$_POST['gid']."', '".$KodeKasBank."', '".$row_jaditotal."', '".$today."' ,  '".$_POST['unitid']."')");
		}
		
		if($row_bakutotal > 0) {
			$KodeKasBank = KodeKasBank(); 
			mysql_query("insert into ak_kasbanks (ID, JNS_TRANS, TANGGAL, NO_BUKTI, NO_REFF, PERK_KASBANK, URAIAN_DEBET, DEBET, PERK_KREDIT, URAIAN_KREDIT,  KREDIT, TERIMA_DARI, UNIT_KODE) VALUES ('".$KodeKasBank."', 'RTB', '".$today."', '', '', '75', '', '".$row_bakutotal."', '58', '', '".$row_bakutotal."', '', '".$_POST['unitid']."') ");
			mysql_query("INSERT INTO ak_htg (SUPPLIER_ID,TRRGOOD_ID,BRETUR_ID, KASBANK_ID, KREDIT,TANGGAL, UNIT_ID) VALUES ('".$row_supplier['supplier_id']."', '".$row_supplier['trrgood_id']."', '".$_POST['gid']."', '".$KodeKasBank."', '".$row_bakutotal."', '".$today."' ,  '".$_POST['unitid']."')");
		}
		
		
		/*
		mysql_query("insert into ak_kasbank (ID, JNS_TRANS, TANGGAL, TGL_INPUT, USER_ID, UNIT_KODE) VALUES (
		'".$KodeKasBank."',
		'RTB' ,
		'".$today."' ,
		'".$today."' ,
		'".$_SESSION['galaxy_kode']."' ,
		'".$row_supplier['unitid']."' ) ");
		
		
		mysql_query("insert into ak_detail_kasbank (KASBANK_ID,PERK_LAWAN,KREDIT,TGL_INPUT,USER_ID,UNIT_KODE) VALUES (
		'".$KodeKasBank."' ,
		'75' ,
		'".$jumlah."' ,
		'".$today."' ,
		'".$_SESSION['galaxy_kode']."' ,
		'".$row_supplier['unitid']."' )");
		
		mysql_query("INSERT INTO ak_htg (SUPPLIER_ID,TRRGOOD_ID,BRETUR_ID,KREDIT,TANGGAL, UNIT_ID) VALUES (
		'".$row_supplier['supplier_id']."' ,
		'".$row_supplier['trrgood_id']."' ,
		'".$_POST['gid']."' ,
		'".$jumlah."' ,
		'".$today."' ,
		'".$row_supplier['unitid']."')");
		*/
	}
	if($_POST['mod']=='8') {	
		mysql_query("UPDATE breturs SET issign = '0' WHERE id ='".$_POST['gid']."';");
		
		$qry_bretdetails = "select * from bretdetails JOIN items ON ( bretdetails.item_id = items.id) where bretdetails.bretur_id = '".$_POST['gid']."';";
		$rs_bretdetails = mysql_query($qry_bretdetails);
		while($rows_bretdetailss=mysql_fetch_array($rs_bretdetails)) {
			mysql_query("UPDATE trrgdetails SET trrgstatus = '1' WHERE id ='".$rows_bretdetailss['trrgdetails_id']."';");
		}
		
	}
 }
 }
?>

