<?php
	require_once '../../library/connectionmysql.php';
	Connected();
	
	$perm = array();
	$perm = getPermissions('45');

	if($perm[-1]=='1') { require_once '../../library/error-popup.php'; die; }
	if(isAdd()) { 
		if($perm[0]=='1') { require_once '../../library/error-popup.php'; die; }
	}if(isEdit()) { 
		if($perm[1]=='1') { require_once '../../library/error-popup.php'; die; }
	}if(isConfirmDelete() || isConfirmDeleteSelected()) { 
		if($perm[2]=='1') { require_once '../../library/error-popup.php'; die; }
	}
	
	if(isEdit())  
	{
		$rs_jurnal = mysql_query("select * from ak_jurnal where id = '".$_GET['gid']."'");
		$rows_jurnal=mysql_fetch_array($rs_jurnal);
	}
	
?>

<?
if(isAdd() || isEdit() )
{
	$id = 'ID';
	$table = 'ak_jurnal';
	$id = Kode($id,$table);
	
/*	$qry_unit="select * from units where id='".$_SESSION['galaxy_unit']."'";
	$rs_unit=mysql_query($qry_unit);
	$row_unit=mysql_fetch_array($rs_unit);
	$temp1=$row_unit['code'];
	
	if(KasMasuk()) { $trans='KM'; }
	if(KasKeluar()) { $trans='KK'; }
	if(BankMasuk()) { $trans='BM'; }
	if(BankKeluar()) { $trans='BK'; }
	
	if(!isEdit())
	{
	$kode=$temp1."/".$trans."/";
	$query = "SELECT max(NO_BUKTI) AS last FROM ak_kasbank WHERE NO_BUKTI LIKE '$kode%'";
	$hasil = mysql_query($query);
	$data  = mysql_fetch_array($hasil);	
	$lastNoTransaksi = $data['last'];

	// baca nomor urut transaksi dari id tsransaksi terakhir
	$lastNoUrut = substr($lastNoTransaksi, 6, 4);
	if($lastNoUrut==NULL)
	{
		$lastNoUrut=0;
	}
	// nomor urut ditambah 1
	$nextNoUrut = $lastNoUrut + 1;
	
	$nextKode = $kode.sprintf('%04s', $nextNoUrut);
	}
*/
?>
	<div class="popup-shadow" style="width: 600px;">
    	<div class="popup-header">
             <span>
			 <? 
			 	if(isAdd()) echo 'Tambah Jurnal'; 
				else echo 'Edit Jurnal';
			 ?>
             </span>
             <div class="popup-close">X</div>
      	</div>
        <div class="popup-body">
        	<form action="modul/akunting/jurnal.php" method="post">
            <table>
            <tr>
              <td width="25%">No. Bukti</td>
              <td width="5%" align="center">:</td>
              <td><input class="input-text" name="nobukti" type="text" value="<? if(isEdit()) echo $rows_jurnal['NO_BUKTI'] ?>"></td>
            </tr>
            <tr>
              <td>Tanggal</td>
              <td align="center">:</td>
              <td><input class="input-text" name="tanggal" type="datepicker" value="<? if(isEdit()) echo cDate($rows_jurnal['TANGGAL_TRANS']) ?>" /></td>
            </tr>
            <tr>
              <td>No. Reff</td>
              <td align="center">:</td>
              <td><input class="input-text" name="noreff" type="text" value="<? if(isEdit()) echo $rows_jurnal['NO_REFF'] ?>" /></td>
            </tr>
            <tr>
              <td width="25%">Perk. Debet</td>
              <td width="5%" align="center">:</td>
              <td><select name="perkdebet" class="select-text select-medium">
                    <option value="">Pilih..</option>
                  <? 	  
                  $qry_detail = '';
                  $qry_detail = "select * from ak_detail_perk;";
                  $rs_detail = mysql_query($qry_detail);
                  while($rows_detail=mysql_fetch_array($rs_detail)) {
                  ?>
                    <option value="<? echo $rows_detail['ID_DETAIL']?>" <? if(isEdit()) if($rows_detail['ID_DETAIL']==$rows_jurnal['PERK_DEBET']) echo 'selected'; ?>><? echo $rows_detail['KODE_DETAIL']; ?> - [<? echo $rows_detail['NAMA_DETAIL']; ?>]</option>
                  <? } ?>
      			</select>
              </td>
            </tr>
            <tr>
              <td>Uraian Debet</td>
              <td align="center">:</td>
              <td><textarea class="input-text" name="uraiandebet" type="text"><? if(isEdit()) echo $rows_jurnal['URAIAN_DEBET'] ?></textarea></td>
            </tr>
            <tr>
              <td width="25%">Perk. Kredit</td>
              <td width="5%" align="center">:</td>
              <td><select name="perkkredit" class="select-text select-medium">
                    <option value="">Pilih..</option>
                  <? 	  
                  $qry_detail = '';
                  $qry_detail = "select * from ak_detail_perk;";
                  $rs_detail = mysql_query($qry_detail);
                  while($rows_detail=mysql_fetch_array($rs_detail)) {
                  ?>
                    <option value="<? echo $rows_detail['ID_DETAIL']?>" <? if(isEdit()) if($rows_detail['ID_DETAIL']==$rows_jurnal['PERK_KREDIT']) echo 'selected'; ?>><? echo $rows_detail['KODE_DETAIL']; ?> - [<? echo $rows_detail['NAMA_DETAIL']; ?>]</option>
                  <? } ?>
      			</select>
              </td>
            </tr>
            <tr>
              <td>Uraian Kredit</td>
              <td align="center">:</td>
              <td><textarea class="input-text" name="uraiankredit" type="text"><? if(isEdit()) echo $rows_jurnal['URAIAN_KREDIT'] ?></textarea></td>
            </tr>
            <tr>
              <td>Jumlah</td>
              <td align="center">:</td>
              <td><input class="input-text currency padmin" name="jumlah" type="text" value="<? if(isEdit()) echo cFormat($rows_jurnal['DEBET'],false); ?>" /></td>
            </tr>
            </table>
<!--            <input type="hidden" name="trans" value="<? //echo $trans ?>" />		
				<input type="hidden" name="nobukti" value="<? //echo $nextKode ?>" />		-->
            <input type="hidden" name="gid" value="<? if(isEdit()) echo $_GET['gid'] ?>" />
            <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
            </form>
            <? // if(isEdit()) echo $_GET['gid'] ?><? //if(isAdd()) echo $id ?>
        </div>
        <div class="popup-footer">
      		<div class="popup-cancel">Batal</div>
      		<div mode="6" link="library/submenu/akunting/jurnal" class="popup-button" get="">Simpan</div>
      	</div>
    </div>
<?
}
?>

<? 
//<!-- FORM TIPE MODE 2 = CONFIRM DELETE/KONFIRMASI HAPUS, TIPE MODE 4 = CONFIRM DELETE SELECTED/KONFIRMASI HAPUS YANG DIPILIH -->
if(isConfirmDelete()) 
{ 
	if(isConfirmDelete()) {
		$rs_jurnal = mysql_query("select * from ak_jurnal where id = '".$_GET['gid']."'");
		$rows_jurnal=mysql_fetch_array($rs_jurnal);
	}
?>
	<div class="popup-shadow" style="width: 500px;">
    	<div class="popup-header">
         <span>Konfirmasi Hapus</span>
         <div class="popup-close">X</div>
      	</div>
        <div class="popup-body">
        <table>
        <tr>
        	<td class="center">
            <? if(isConfirmDelete()) {?>
                <strong>Peringatan</strong>: <br /> 
                Data <b>Detail Jurnal</b> akan ikut terhapus, jika ada data yang terhubung!.
                <br /><br />
                Apakah anda yakin menghapus <br /><b style="text-decoration: underline;"><? echo $rows_jurnal['NO_BUKTI'] ?></b>?
      		<? }?>
            </td>
        </tr>
        </table>
        </div>
        <div class="popup-footer">
        <div class="popup-cancel"><? if($_GET['gid']!='') echo 'Batal'; else echo 'Tutup' ?></div>
        <? if(isConfirmDelete()) 
		{ ?>
      		<div mode="3" link="modul/akunting/jurnal?<? echo $_GET['gid'] ?>" class="popup-button">Hapus</div>
        <? 
		}?>
        </div>
        </div>
    </div>
<?
}
?>

<?
if(isDelete()) 
{ 
	mysql_query("DELETE from ak_detail_jurnal where JURNAL_ID =".$_GET['gid']);
	mysql_query("DELETE from ak_jurnal where ID =".$_GET['gid']);
} 
?>

<?
//<!-- TIPE MODE 6 = SAVE/MENYIMPAN -->
if(isSave()) 
{
	$error = array();
	if(!$_POST['tanggal']) $error[] = 'tanggal:Silahkan Masukkan Tanggal.';
	if(!$_POST['nobukti']) $error[] = 'nobukti:Silahkan Masukkan No. Bukti.';
	if(!$_POST['noreff']) $error[] = 'noreff:Silahkan Masukkan No. Reff.';
	if(!$_POST['perkdebet']) $error[] = 'perkdebet:Silahkan Masukkan Perk. Debet.';
	if(!$_POST['uraiandebet']) $error[] = 'uraiandebet:Silahkan Masukkan Uraian Debet';
	if(!$_POST['perkkredit']) $error[] = 'perkkredit:Silahkan Masukkan Perk. Kredit.';
	if(!$_POST['uraiankredit']) $error[] = 'uraiankredit:Silahkan Masukkan Uraian Kredit.';
	if(!$_POST['jumlah']) $error[] = 'jumlah:Silahkan Masukkan Jumlah.';
	
	if(count($error)>0) 
	{
		echo generateError($error);
	} 
	else 
	{
		$today=gmdate("Y-m-d");
		$_POST['jumlah'] = str_replace(',','',$_POST['jumlah']);
		
		if($_POST['mod']=='0')
		{
			mysql_query("INSERT INTO ak_jurnal (TANGGAL_TRANS,NO_BUKTI,NO_REFF,PERK_DEBET,URAIAN_DEBET,DEBET,PERK_KREDIT,URAIAN_KREDIT,KREDIT,TANGGAL_INPUT,UNIT_KODE) VALUES (".isNull($_POST['tanggal'],'DATE')." , '".$_POST['nobukti']."' , '".$_POST['noreff']."' , '".$_POST['perkdebet']."' , '".$_POST['uraiandebet']."' , '".$_POST['jumlah']."' , '".$_POST['perkkredit']."' ,  '".$_POST['uraiankredit']."' , '".$_POST['jumlah']."' , 			'".$today."' ,
			'".$_SESSION['galaxy_unit']."') ");
		}
		
		if($_POST['mod']=='1') 
		{	
		mysql_query("UPDATE ak_jurnal SET 
		TANGGAL_TRANS = ".isNull($_POST['tanggal'],'DATE').",
		NO_BUKTI = '".$_POST['nobukti']."',
		NO_REFF = '".$_POST['noreff']."',
		PERK_DEBET = '".$_POST['perkdebet']."' ,
		URAIAN_DEBET = '".$_POST['uraiandebet']."' ,
		DEBET = '".$_POST['jumlah']."' ,
		PERK_KREDIT = '".$_POST['perkkredit']."' ,
		URAIAN_KREDIT = '".$_POST['uraiankredit']."' ,
		KREDIT = '".$_POST['jumlah']."' 
		WHERE ID ='".$_POST['gid']."';");
		}
	}
}
 
?>