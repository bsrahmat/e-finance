<?php
	require_once '../../library/connectionmysql.php';
	Connected();
	
	$perm = array();
	$perm = getPermissions('23');
	if($perm[-1]=='1') { require_once '../../library/error-popup.php'; die; }
			
?>
<?
//<!-- FORM TIPE MODE 0 = TAMBAH/ADD, TIPE MODE 1 = UBAH/EDIT -->
 if(isAdd()) {
	 $rs_wends = mysql_query("SELECT * FROM wends  WHERE wends.id = '".$_GET['gid']."'");
	$rows_wends=mysql_fetch_array($rs_wends);
 ?>
 
   <div class="popup-shadow" style="width: 600px;">
      <div class="popup-header">
         <span>Close Penyelesaian Kerja</span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <form action="modul/akunting/update-penyelesaian-kerja.php" method="post">
      <table>
      <tr>
      <td class="center">Transaksi dengan No Penyelesaiaan Kerja : <b style="text-decoration: underline;"><? echo $rows_wends['wenom'] ?></b> Akan di Tutup?</td>
      </tr>
      
      </table>
      <input type="hidden" name="gid" value="<? echo $_GET['gid'] ?>" />
      <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
      
      </form>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel">Batal</div>
      	<div mode="6" link="library/submenu/akunting/update-penyelesaian-kerja" class="popup-button" get="">Simpan</div>
      </div>
   </div>

<? }  ?>
<?
//<!-- FORM TIPE MODE 0 = TAMBAH/ADD, TIPE MODE 1 = UBAH/EDIT -->
 
 if(isEdit()) {
	 $rs_wends = mysql_query("SELECT * FROM wends LEFT JOIN worders ON (wends.worder_id = worders.id) WHERE wends.id = '".$_GET['gid']."'");
	$rows_wends=mysql_fetch_array($rs_wends);
	$rs_units = mysql_query("select * from units where id = '".$rows_wends['unitid']."'");
	 $rows_units=mysql_fetch_array($rs_units);
	 $rgnom = IDTransLPB($rows_units['code']);
	 
 ?>
 
   <div class="popup-shadow" style="width: 600px;">
      <div class="popup-header">
         <span>ACC_EDIT PENYELESAIAN KERJA (AKUNTING)</span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <form action="modul/akunting/update-penyelesaian-kerja.php" method="post">
      <table>
      <tr>
      <td width="27%">No. Penyelesaian Kerja</td>
      <td width="5%" align="center">:</td>
      <td><input class="input-text" name="prnom-disable" type="text" value="<? echo $rows_wends['wenom'] ?>"  disabled="disabled"></td>
      </tr>
      <tr>
      <td>No. Order Kerja</td>
      <td align="center">:</td>
      <td><input class="input-text" name="prnom-disable" type="text" value="<? echo $rows_wends['wonom'] ?>"  disabled="disabled"></td>
      </tr>
      
      <tr>
      <td>Tanggal</td>
      <td align="center">:</td>
      <td><input class="input-text input-small" disabled="disabled" name="rgdate" value="<?  echo cDate($rows_wends['wedate']) ?>" /></td>
      </tr>
      <tr>
      <td>Keterangan</td>
      <td align="center">:</td>
      <td><textarea rows="3" class="input-text" name="description" type="text" disabled="disabled"><? echo $rows_wends['description'] ?></textarea></td>
      </tr>
      
      <tr>
      <td>No. Faktur</td>
      <td align="center">:</td>
      <td><input class="input-text" name="fakturnom" value="<? echo $rows_wends['fakturnom'] ?>"/></td>
      </tr>
      <tr>
      </table>
      
      <input type="hidden" name="gid" value="<? echo $_GET['gid'] ?>" />
      <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
      
      </form>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel">Batal</div>
      	<div mode="6" link="library/submenu/akunting/detail/update-penyelesaian-kerja" class="popup-button" get="<? echo $_GET['gid'] ?>">Simpan</div>
      </div>
   </div>

<? }  ?>

<?
//<!-- TIPE MODE 6 = SAVE/MENYIMPAN -->
 if(isSave()) {
	if($_POST['mod']=='0') {
		/*
		$rs_wedetails = mysql_query("select * from wedetails where wend_id = '".$_POST['gid']."'");
		while($rows_wedetails=mysql_fetch_array($rs_wedetails)) {
			mysql_query("INSERT INTO stockitems (stockdate, warehouse_id, item_id, transtype_id, nobukti1, qty, tot, trrgdetail_id, nobukti2, unit_id, price) VALUES ('".date('Y-m-d')."', '".$_POST['warehouse_id']."', '".$rows_wedetails['item_id']."', '2',  '".$_POST['rgnom']."', '".$rows_wedetails['qty']."', '".$rows_wedetails['hpptot']."', '".$rows_wedetails['id']."', '".$_POST['fakturnom']."', '".$_POST['unitid']."',  '".$rows_wedetails['hpp']."')");
		}
		*/
		mysql_query("UPDATE wends SET postby = '".$_SESSION['galaxy_kode']."', postdate = '".date('Y-m-d')."', isposted = '1' WHERE id ='".$_POST['gid']."';");
		
		$today=date('Y-m-d');
		$qry_supplier="select worders.supplier_id, wends.unitid from wends LEFT JOIN worders ON (wends.worder_id=worders.id) where wends.id ='".$_POST['gid']."' ";
		$row_supplier=mysql_fetch_array(mysql_query($qry_supplier));
		$qry_jumlah="select sum(debt) as debt from  wedetails where wend_id='".$_POST['gid']."' ";
		$row_jumlah=mysql_fetch_array(mysql_query($qry_jumlah));
		/*
		mysql_query("insert into ak_kasbank (JNS_TRANS, TANGGAL, TGL_INPUT, USER_ID, UNIT_KODE) VALUES (
		'OKJ' ,
		'".$today."' ,
		'".$today."' ,
		'".$_SESSION['galaxy_kode']."' ,
		'".$row_supplier['unitid']."' ) ");
		
		$qry_detail="select max(ID) as max from ak_kasbank ";
		$row_detail=mysql_fetch_array(mysql_query($qry_detail));
		mysql_query("insert into ak_detail_kasbank (KASBANK_ID,PERK_LAWAN,DEBET,TGL_INPUT,USER_ID,UNIT_KODE) VALUES (
		'".$row_detail['max']."' ,
		'75' ,
		'".$row_jumlah['debt']."' ,
		'".$today."' ,
		'".$_SESSION['galaxy_kode']."' ,
		'".$row_supplier['unitid']."' )");
		*/
		
		if($row_jumlah['debt'] > 0) {
			$KodeKasBank = KodeKasBank(); 
			mysql_query("insert into ak_kasbanks (ID, JNS_TRANS, TANGGAL, NO_BUKTI, NO_REFF, PERK_KASBANK, URAIAN_DEBET, DEBET, PERK_KREDIT, URAIAN_KREDIT,  KREDIT, TERIMA_DARI, UNIT_KODE) VALUES ('".$KodeKasBank."', 'HTG', '".$today."', '', '', '149', '', '".$row_jumlah['debt']."', '75', '', '".$row_jadi['debt']."', '', '".$row_supplier['unitid']."') ");
			mysql_query("INSERT INTO ak_htg (SUPPLIER_ID, WEND_ID, KASBANK_ID, DEBET, TANGGAL, UNIT_ID) VALUES ('".$row_supplier['supplier_id']."', '".$_POST['gid']."', '".$KodeKasBank."', '".$row_jumlah['debt']."',  '".$today."', '".$row_supplier['unitid']."')");
		}
		
		//mysql_query("insert into ak_htg (SUPPLIER_ID, WEND_ID, KASBANK_ID, DEBET, TANGGAL, UNIT_ID, transtype_id) VALUES ('".$row_supplier['supplier_id']."', '".$_POST['gid']."', '".$row_detail['max']."' , '".$row_jumlah['debt']."', '".$today."' ,  '".$row_supplier['unitid']."', '8')");
	}
	if($_POST['mod']=='1') {	
		mysql_query("UPDATE wends SET fakturnom = '".$_POST['fakturnom']."' WHERE id ='".$_POST['gid']."';");
	}
 }
 
?>


