<?php
	require_once '../../library/connectionmysql.php';
	Connected();
	
	$perm = array();
	$perm = getPermissions('43');

	if($perm[-1]=='1') { require_once '../../library/error-popup.php'; die; }
	if(isAdd()) { 
		if($perm[0]=='1') { require_once '../../library/error-popup.php'; die; }
	}if(isEdit()) { 
		if($perm[1]=='1') { require_once '../../library/error-popup.php'; die; }
	}if(isConfirmDelete() || isConfirmDeleteSelected()) { 
		if($perm[2]=='1') { require_once '../../library/error-popup.php'; die; }
	}
	
	$cek='';
	if(isEdit())  
	{
		$rs_kasbank = mysql_query("select * from ak_kasbanks where id = '".$_GET['gid']."'");
		$rows_kasbank=mysql_fetch_array($rs_kasbank);
		$cek=$rows_kasbank['JNS_TRANS'];
	}
	
?>

<?
if(KasMasuk() || KasKeluar() || isEdit()) {
	$id = 'ID';
	$table = 'ak_kasbank';
	$id = Kode($id,$table);
	
	$qry_unit="select * from units where id='".$_SESSION['galaxy_unit']."'";
	$rs_unit=mysql_query($qry_unit);
	$row_unit=mysql_fetch_array($rs_unit);
	$temp1=$row_unit['code'];
	
	$th=gmdate("Y");
	
	if(KasMasuk()) { $cd='BKM'; $trans='KM'; }
	if(KasKeluar()) { $cd='BKK'; $trans='KK'; }
	
	if(!isEdit())
	{
	$kode=$cd."/".$trans."/".$temp1."/".$th."/";
	$query = "SELECT max(NO_BUKTI) AS last FROM ak_kasbank WHERE NO_BUKTI LIKE '$kode%'";
	$hasil = mysql_query($query);
	$data  = mysql_fetch_array($hasil);	
	$lastNoTransaksi = $data['last'];
	$dt=explode('/',$lastNoTransaksi);
	if($lastNoTransaksi=='' || $dt[3]!=$th)
	{
		$dta=1;
	}
	else
	{
		$dta= $dt[4] + 1;
	}
	
	$nextKode = $kode.sprintf('%05s', $dta);
	}
?>
	<div class="popup-shadow" style="width: 600px;">
    	<div class="popup-header">
             <span>
			 <? 
			 	if(KasMasuk()) echo 'Kas masuk'; 
				if(KasKeluar()) echo 'Kas Keluar'; 
			 ?>
             </span>
             <div class="popup-close">X</div>
      	</div>
        <div class="popup-body">
        	<form action="modul/akunting/kasbank.php" method="post">
            <table>
            <tr>
              <td width="25%">No. Bukti</td>
              <td width="5%" align="center">:</td>
              <td><input class="input-text" name="nobukti_D" type="text" value="<? if(isEdit()) echo $rows_kasbank['NO_BUKTI'] ?><? if(KasMasuk() || KasKeluar() || BankMasuk() || BankKeluar()) echo $nextKode ?>"  disabled="disabled"></td>
            </tr>
            <tr>
              <td>Tanggal</td>
              <td align="center">:</td>
              <td><input class="input-text" name="tanggal" type="datepicker-range" value="<? if(isEdit()) echo cDate($rows_kasbank['TANGGAL']) ?>" /></td>
            </tr>
            <tr>
              <td>No. Reff</td>
              <td align="center">:</td>
              <td><input class="input-text" name="noreff" type="text" value="<? if(isEdit()) echo $rows_kasbank['NO_REFF'] ?>" /></td>
            </tr>
            <tr>
            <tr>
          	  <td>Perk. Kas/bank</td>
              <td align="center">:</td>
              <td>
              	<select name="perkkasbank" class="select-text select-medium">
                    <option value="">Pilih..</option>
                  <? 	  
                  $qry_detail = '';
                  $qry_detail = "select * from ak_detail_perk where KODE_DETAIL like '1101%' or KODE_DETAIL like '1102%';";
                  $rs_detail = mysql_query($qry_detail);
//				  $perk=$rows_kasbank['PERK_KASBANK'];
                  while($rows_detail=mysql_fetch_array($rs_detail)) {
                  ?>
                    <option value="<? echo $rows_detail['ID_DETAIL']?>" <? if(isEdit()) if($rows_detail['ID_DETAIL']==$rows_kasbank['PERK_KASBANK']) echo 'selected'; ?>><? echo $rows_detail['KODE_DETAIL']; ?> - [<? echo $rows_detail['NAMA_DETAIL']; ?>]</option>
                  <? } ?>
      			</select>
              </td>
          	</tr>
            <tr>
              <td>Diterima dr/Dibayar ke</td>
              <td align="center">:</td>
              <td><input class="input-text" name="terima" type="text" value="<? if(isEdit()) echo $rows_kasbank['TERIMA_DARI'] ?>" /></td>
            </tr>
            <tr>
              <td>Uraian Kas</td>
              <td align="center">:</td>
              <td><input class="input-text" name="ket" type="text" value="<? if(isEdit()) echo $rows_kasbank['URAIAN_DEBET'] ?>" /></td>
            </tr>
            <tr>
              <td width="25%">Perk. Lawan</td>
              <td width="5%" align="center">:</td>
              <td><select name="lawan" class="select-text select-medium">
                    <option value="">Pilih..</option>
                  <? 	  
                  $qry_detail = '';
                  $qry_detail = "select * from ak_detail_perk;";
                  $rs_detail = mysql_query($qry_detail);
                  while($rows_detail=mysql_fetch_array($rs_detail)) {
                  ?>
                    <option value="<? echo $rows_detail['ID_DETAIL']?>" <? if(isEdit()) if($rows_detail['ID_DETAIL']==$rows_kasbank['PERK_KREDIT']) echo 'selected'; ?>><? echo $rows_detail['KODE_DETAIL']; ?> - [<? echo $rows_detail['NAMA_DETAIL']; ?>]</option>
                  <? } ?>
      			</select>
              </td>
            </tr>
            <tr>
              <td>Uraian Lawan</td>
              <td align="center">:</td>
              <td><input class="input-text" name="uraian" type="text" value="<? if(isEdit()) echo $rows_kasbank['URAIAN_KREDIT'] ?>" /></td>
              </tr>
            <tr>
              <td>Jumlah</td>
              <td align="center">:</td>
              <td><input class="input-text currency padmin" name="jumlah" type="text" value="<? if(isEdit()) echo cFormat($rows_kasbank['DEBET'],false); ?>" /></td>
            </tr>
           	
            </table>
            
            <input type="hidden" name="trans" value="<? if(isEdit()) { echo $rows_kasbank['JNS_TRANS']; }else { echo $trans; }?>" />
            <input type="hidden" name="gid" value="<? if(isEdit()) echo $_GET['gid'] ?>" />
            <input type="hidden" name="nobukti" value="<? echo $nextKode ?>" />
            <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
            </form>
        </div>
        <div class="popup-footer">
      		<div class="popup-cancel">Batal</div>
      		<div mode="6" link="library/submenu/akunting/kasbank" class="popup-button" get="">Simpan</div>
      	</div>
    </div>
<?
}
?>

<? 
//<!-- FORM TIPE MODE 2 = CONFIRM DELETE/KONFIRMASI HAPUS, TIPE MODE 4 = CONFIRM DELETE SELECTED/KONFIRMASI HAPUS YANG DIPILIH -->
if(isConfirmDelete()) 
{ 
	if(isConfirmDelete()) {
		$rs_kasbank = mysql_query("select * from ak_kasbank where id = '".$_GET['gid']."'");
		$rows_kasbank=mysql_fetch_array($rs_kasbank);
	}
?>
	<div class="popup-shadow" style="width: 500px;">
    	<div class="popup-header">
         <span>Konfirmasi Hapus</span>
         <div class="popup-close">X</div>
      	</div>
        <div class="popup-body">
        <table>
        <tr>
        	<td class="center">
            <? if(isConfirmDelete()) {?>
                <strong>Peringatan</strong>: <br /> 
                Data <b>Detail Kas/Bank</b> akan ikut terhapus, jika ada data yang terhubung!.
                <br /><br />
                Apakah anda yakin menghapus <br /><b style="text-decoration: underline;"><? echo $rows_kasbank['NO_BUKTI'] ?></b>?
      		<? }?>
            </td>
        </tr>
        </table>
        </div>
        <div class="popup-footer">
        <div class="popup-cancel"><? if($_GET['gid']!='') echo 'Batal'; else echo 'Tutup' ?></div>
        <? if(isConfirmDelete()) 
		{ ?>
      		<div mode="3" link="modul/akunting/kasbank?<? echo $_GET['gid'] ?>" class="popup-button">Hapus</div>
        <? 
		}?>
        </div>
        </div>
    </div>
<?
}
?>

<?
if(isDelete()) 
{ 
	
	mysql_query("DELETE from ak_kasbanks where ID =".$_GET['gid']);
} 
?>

<?
//<!-- TIPE MODE 6 = SAVE/MENYIMPAN -->
if(isSave()) 
{
	$date_now = date("Y-m-d");
	$tgl=explode('-',$date_now);
	$tgl2=date("d F Y", mktime(0,0,0,date($tgl[1]),date($tgl[2])+1,date($tgl[0]))); 
	$bulan=array(1=>'January', 2=>'February', 3=>'March', 4=>'April', 5=>'May', 6=>'June', 7=>'July', 8=>'August', 9=>'September', 10=>'October', 11=>'November', 12=>'December');
	$t2=explode(' ',$tgl2);
	for ($i=1; $i <= 12; $i++)
	{
		if($bulan[$i]==$t2[1]) { $bln="0".$i; }
	}
	$date2=$t2[2].$bln.$t2[0];
	$date1=date("Ymd");
	$tmp = explode('/',$_POST['tanggal']);
	if(strlen($tmp[0])<=1) $tmp[0] = '0'.$tmp[0];
	if(strlen($tmp[1])<=1) $tmp[1] = '0'.$tmp[1];
	$cek = $tmp[2].$tmp[1].$tmp[0];
	
	$error = array();
	
	if(!$_POST['tanggal']) $error[] = 'tanggal:Silahkan Masukkan Tanggal.';
	if($_POST['mod']!='1') {
	if ($cek > $date2 || $cek < $date1)
	{
		$error[] = 'tanggal:Silahkan Masukkan Tanggal Max Sekarang+1.';
	}
	}
	if(!$_POST['noreff']) $error[] = 'noreff:Silahkan Masukkan noreff.';
	if(!$_POST['perkkasbank']) $error[] = 'perkkasbank:Silahkan Perk Kasbank.';
	if(!$_POST['terima']) $error[] = 'terima:Silahkan Masukkan Tanggal.';
	if(!$_POST['ket']) $error[] = 'ket:Silahkan Masukkan Keterangan.';
	if(!$_POST['lawan']) $error[] = 'lawan:Silahkan Masukkan Perkiraan lawan.';
	if(!$_POST['uraian']) $error[] = 'uraian:Silahkan Masukkan Uraian.';
	if(!$_POST['jumlah']) $error[] = 'jumlah:Silahkan Masukkan Jumlah.';
	
	if(count($error)>0) 
	{
		echo generateError($error);
	} 
	else 
	{
		$tgl='';
		if(!$_POST['tglbg']) $_POST['tglbg']='00/00/00';
		
		$tgl2=explode('/',$_POST['tglbg']);
		$tgl=$tgl2[2].'-'.$tgl2[1].'-'.$tgl2[0];

		if($_POST['mod']=='10') {
			$KodeKasBank = KodeKasBank(); 
			$today=date("Y-m-d");
			mysql_query("INSERT INTO ak_kasbanks (ID, JNS_TRANS, TANGGAL, NO_BUKTI, NO_REFF, PERK_KASBANK, URAIAN_DEBET, DEBET, PERK_KREDIT, URAIAN_KREDIT, KREDIT, TERIMA_DARI, UNIT_KODE, NO_BG, TGL_BG) VALUES ('".$KodeKasBank."','".$_POST['trans']."', ".isNull($_POST['tanggal'],'DATE').", '".$_POST['nobukti']."', '".$_POST['noreff']."', '".$_POST['perkkasbank']."', '".$_POST['ket']."' , ".isNull($_POST['jumlah'],'CUR').", '".$_POST['lawan']."', '".$_POST['uraian']."' ,  ".isNull($_POST['jumlah'],'CUR').", '".$_POST['terima']."' ,'".$_SESSION['galaxy_unit']."' , '".$_POST['nobg']."' , '".$tgl."')");

		}
		if($_POST['mod']=='11') {
			$KodeKasBank = KodeKasBank(); 
			$today=date("Y-m-d");
			mysql_query("INSERT INTO ak_kasbanks (ID, JNS_TRANS, TANGGAL, NO_BUKTI, NO_REFF, PERK_KASBANK, URAIAN_DEBET, DEBET, PERK_KREDIT, URAIAN_KREDIT, KREDIT, TERIMA_DARI, UNIT_KODE, NO_BG, TGL_BG) VALUES ('".$KodeKasBank."','".$_POST['trans']."', ".isNull($_POST['tanggal'],'DATE').", '".$_POST['nobukti']."', '".$_POST['noreff']."', '".$_POST['lawan']."', '".$_POST['uraian']."' , ".isNull($_POST['jumlah'],'CUR').", '".$_POST['perkkasbank']."', '".$_POST['ket']."' ,  ".isNull($_POST['jumlah'],'CUR').", '".$_POST['terima']."' ,'".$_SESSION['galaxy_unit']."' , '".$_POST['nobg']."' , '".$tgl."')");

		}
		if($_POST['mod']=='1') {
			
				mysql_query("UPDATE ak_kasbanks SET  TANGGAL = ".isNull($_POST['tanggal'],'DATE').", NO_REFF = '".$_POST['noreff']."', PERK_KASBANK = '".$_POST['perkkasbank']."', URAIAN_DEBET = '".$_POST['ket']."', DEBET = ".isNull($_POST['jumlah'],'CUR').", PERK_KREDIT = '".$_POST['lawan']."', URAIAN_KREDIT = '".$_POST['uraian']."', KREDIT = ".isNull($_POST['jumlah'],'CUR').", TERIMA_DARI = '".$_POST['terima']."' WHERE ID ='".$_POST['gid']."';");
			
		}
	}
}
 
?>