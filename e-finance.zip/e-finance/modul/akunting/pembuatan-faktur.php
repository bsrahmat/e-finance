<?php
	require_once '../../library/connectionmysql.php';
	Connected();
	
	$perm = array();
	$perm = getPermissions('25');
	if($perm[-1]=='1') { require_once '../../library/error-popup.php'; die; }
	
?>

<?
//<!-- FORM TIPE MODE 0 = TAMBAH/ADD, TIPE MODE 1 = UBAH/EDIT -->
 if(isAdd()) {
	 $rs_fakturs = mysql_query("SELECT fakturs.id, fakturs.isclosed, fakturs.sj_id, fakturs.fakdate, fakturs.faknom, fakturs.unitid, fakturs.tempodate, fakturs.ispost, fakturs.post, sjs.id, sjs.spb_id, sjs.sjdate, sjs.sjnom, sjs.unitid, sjs.isclosed, sjs.istaken, sjs.warehouse_id, sjs.jtdate FROM fakturs LEFT JOIN sjs ON (fakturs.sj_id = sjs.id) WHERE fakturs.id = '".$_GET['gid']."'");
	$rows_fakturs=mysql_fetch_array($rs_fakturs);
 ?>
 
   <div class="popup-shadow" style="width: 600px;">
      <div class="popup-header">
         <span>Notification</span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <form action="modul/akunting/pembuatan-faktur.php" method="post">
      <table>
      <tr>
      <td class="center">Transaksi dengan No Faktur : <b style="text-decoration: underline;"><? echo $rows_fakturs['faknom'] ?></b> Akan di Tutup?</td>
      </tr>
      
      </table>
      <input type="hidden" name="fakdate" value="<? echo $rows_fakturs[3] ?>" />
      <input type="hidden" name="gid" value="<? echo $_GET['gid'] ?>" />
      <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
      <input type="hidden" name="sj_id" value="<? echo $rows_fakturs['sj_id'] ?>" />
      
      <input type="hidden" name="faknom" value="<? echo $rows_fakturs['faknom'] ?>" />
      <input type="hidden" name="warehouse_id" value="<? echo $rows_fakturs['warehouse_id'] ?>" />
      <input type="hidden" name="sjnom" value="<? echo $rows_fakturs['sjnom'] ?>" />
      <input type="hidden" name="unitid" value="<? echo $rows_fakturs['unitid'] ?>" />
      <input type="hidden" name="tempodate" value="<? echo $rows_fakturs['tempodate'] ?>" />
      
      </form>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel">Batal</div>
      	<div mode="6" link="library/submenu/akunting/pembuatan-faktur" class="popup-button" get="">Simpan</div>
      </div>
   </div>

<? }  ?>


<?
//<!-- FORM TIPE MODE 0 = TAMBAH/ADD, TIPE MODE 1 = UBAH/EDIT -->
 if(isEdit()) {
	 $rs_fakturs = mysql_query("SELECT fakturs.id, fakturs.isclosed, fakturs.sj_id, fakturs.fakdate, fakturs.faknom, fakturs.unitid, fakturs.tempodate, fakturs.ispost, fakturs.post, sjs.id, sjs.spb_id, sjs.sjdate, sjs.sjnom, sjs.unitid, sjs.isclosed, sjs.istaken, sjs.warehouse_id, sjs.jtdate FROM fakturs LEFT JOIN sjs ON (fakturs.sj_id = sjs.id) WHERE fakturs.id = '".$_GET['gid']."'");
	$rows_fakturs=mysql_fetch_array($rs_fakturs);
	$rows_customers=mysql_fetch_array(mysql_query("select spbs.id, spbs.customer_id, spbs.spbnom, spbs.sale_id, customers.id, customers.name, sales.id, sales.name from spbs LEFT JOIN  customers ON (spbs.customer_id =  customers.id) LEFT JOIN sales ON (spbs.sale_id = sales.id) WHERE spbs.id = '".$rows_fakturs['spb_id']."';"));
	$rs_units = mysql_query("select * from units where id = '".$rows_fakturs['unitid']."'");
	 $rows_units=mysql_fetch_array($rs_units);
	 $faknom = IDTransFak($rows_units['code'], $rows_fakturs['unitid']);
	 
 ?>
 
   <div class="popup-shadow" style="width: 600px;">
      <div class="popup-header">
         <span>Edit Faktur</span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <form action="modul/akunting/pembuatan-faktur.php" method="post">
      <table>
      <tr>
      <td width="27%">No. Faktur</td>
      <td width="5%" align="center">:</td>
      <td><input class="input-text" name="faknom-disable" type="text" value="<? if($rows_fakturs[1]== '2' || $rows_fakturs[1]== '') {echo $faknom;}else{echo $rows_fakturs['faknom'];} ?>" readonly="readonly"></td>
      </tr>
      <tr>
      <td>No. SJ</td>
      <td align="center">:</td>
      <td><input class="input-text" name="prnom-disable" type="text" value="<? echo $rows_fakturs['sjnom'] ?>"  readonly="readonly"></td>
      </tr>
      <tr>
      <td>No. SPB</td>
      <td align="center">:</td>
      <td><input class="input-text" name="prnom-disable" type="text" value="<? echo $rows_customers['spbnom'] ?>"  readonly="readonly"></td>
      </tr>
      <tr>
      <td>Tanggal SJ</td>
      <td align="center">:</td>
      <td><input class="input-text input-small" readonly="readonly" name="rgdate" value="<?  echo cDate2($rows_fakturs['sjdate']) ?>" /></td>
      </tr>
      <tr>
      <td>Tanggal Faktur</td>
      <td align="center">:</td>
      <td><input class="input-text" name="fakdate" type="datepicker" value="<? if($rows_fakturs[1]== '2' || $rows_fakturs[1]== '') {echo cDate(date('Y-m-d'));}else{echo cDate($rows_fakturs['fakdate']);} ?>" /></td>
      </tr>
      <tr>
      <td>Tanggal Jatuh Tempo</td>
      <td align="center">:</td>
      <td><input class="input-text" name="tempodate" type="datepicker" value="<? echo cDate($rows_fakturs[6]) ?>" /></td>
      </tr>
      <tr>
      <td>Customers</td>
      <td align="center">:</td>
      <td><input class="input-text" name="recipient" value="<? echo $rows_customers[5] ?>" readonly="readonly"/></td>
      </tr>
      <tr>
      <td>Sales</td>
      <td align="center">:</td>
      <td><input class="input-text" name="recipient" value="<? echo $rows_customers[7] ?>" readonly="readonly"/></td>
      </tr>
      
      </table>
      <input type="hidden" name="faknom" value="<? if($rows_fakturs[1]== '2' || $rows_fakturs[1]== '') {echo $faknom;}else{echo $rows_fakturs['faknom'];} ?>" />
      <input type="hidden" name="gid" value="<? echo $_GET['gid'] ?>" />
      <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
      
      <input type="hidden" name="sjsj" value="<? echo $rows_fakturs[2] ?>" />
            
      </form>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel">Batal</div>
      	<div mode="6" link="library/submenu/akunting/detail/pembuatan-faktur" class="popup-button" get="<? echo $_GET['gid'] ?>">Simpan</div>
      </div>
   </div>

<? }  ?>

<?
//<!-- TIPE MODE 6 = SAVE/MENYIMPAN -->
 if(isSave()) {
$error = array();
if($_POST['mod']=='1') {	
if(!$_POST['fakdate']) $error[] = 'fakdate:Silahkan Masukkan Tanggal Faktur.';
if(!$_POST['tempodate']) $error[] = 'tempodate:Silahkan Masukkan Tanggal Jatuh Tempo.';

}
if(count($error)>0) {
	echo generateError($error);
	
} else {	 
	if($_POST['mod']=='0') {
		
		$rs_fakdetails = mysql_query("select * from fakdetails where faktur_id = '".$_POST['gid']."'");
		while($rows_fakdetails=mysql_fetch_array($rs_fakdetails)) {
			mysql_query("UPDATE items SET stock = stock-'".$rows_fakdetails['qty']."' WHERE id ='".$rows_fakdetails['item_id']."';");
			$rows_items=mysql_fetch_array(mysql_query("select * from items where unit_id = '".$_POST['unitid']."' AND id = '".$rows_fakdetails['item_id']."'"));
			
			mysql_query("INSERT INTO stockitems (stockdate, warehouse_id, item_id, transtype_id, nobukti1, qty, tot, fakdetail_id, nobukti2, unit_id, price) VALUES ('".date('Y-m-d')."', '".$_POST['warehouse_id']."', '".$rows_fakdetails['item_id']."', '3',  '".$_POST['faknom']."', '".$rows_fakdetails['qty']."', '".$rows_fakdetails['qty']*$rows_items['saleprice']."', '".$rows_fakdetails['id']."', '".$_POST['sjnom']."', '".$_POST['unitid']."',  '".$rows_items['saleprice']."')");
			
			
		}		
		mysql_query("UPDATE fakturs SET ispost = '1', isclosed = '0' WHERE id ='".$_POST['gid']."';");
		
		
		$today=$_POST['fakdate'];
		$qry_jumlah="select  sjdetails.price,  sjdetails.disc,  sjdetails.ppnperitem, sjdetails.qty, fakturs.unitid, spbs.customer_id, sjs.id, sjs.jtdate from fakturs  LEFT JOIN sjs ON (fakturs.sj_id = sjs.id) LEFT JOIN sjdetails ON(sjs.id = sjdetails.sj_id) LEFT JOIN spbs ON (sjs.spb_id= spbs.id) where fakturs.id='".$_POST['gid']."' ";
		$row_jumlah=mysql_fetch_array(mysql_query($qry_jumlah));
		$jumlah=($row_jumlah['price']-$row_jumlah['disc']+$row_jumlah['ppnperitem'])*$row_jumlah['qty'];
		
		
		$qry_jadi="select fakdetails.qty, fakdetails.price, fakdetails.disc, fakdetails.ppnperitem  from  fakdetails JOIN items ON (fakdetails.item_id = items.id) where items.icategory_id = '1' AND fakdetails.faktur_id='".$_POST['gid']."' ";
		$rs_jadi = mysql_query($qry_jadi);
		$row_jaditotal = 0;
		while($row_jadi=mysql_fetch_array($rs_jadi)) {
			$row_jadiaja = ($row_jadi[1]-$row_jadi[2]+$row_jadi[3])*$row_jadi[0];
			$row_jaditotal = $row_jaditotal + $row_jadiaja;
		}
		
		$qry_baku="select fakdetails.qty, fakdetails.price, fakdetails.disc, fakdetails.ppnperitem  from  fakdetails JOIN items ON (fakdetails.item_id = items.id) where items.icategory_id = '3' AND fakdetails.faktur_id='".$_POST['gid']."' ";
		//$row_baku=mysql_fetch_array(mysql_query($qry_baku));
		$rs_baku = mysql_query($qry_baku);
		$row_bakutotal = 0;
		while($row_baku=mysql_fetch_array($rs_baku)) {
			$row_bakuaja = ($row_baku[1]-$row_baku[2]+$row_baku[3])*$row_baku[0];
			$row_bakutotal = $row_bakutotal + $row_bakuaja;
		}
		
		if($row_jaditotal > 0) {
			$KodeKasBank = KodeKasBank(); 
			mysql_query("insert into ak_kasbanks (ID, JNS_TRANS, TANGGAL, NO_BUKTI, NO_REFF, PERK_KASBANK, URAIAN_DEBET, DEBET, PERK_KREDIT, URAIAN_KREDIT,  KREDIT, TERIMA_DARI, UNIT_KODE) VALUES ('".$KodeKasBank."', 'PTG', '".$_POST['fakdate']."', '', '', '17', '', '".$row_jaditotal."', '61', '', '".$row_jaditotal."', '', '".$_POST['unitid']."') ");
			mysql_query("INSERT INTO ak_piut (CUSTOMER_ID, SJ_ID, KASBANK_ID, DEBET, TANGGAL, JTH_TEMPO, UNIT_ID) VALUES ('".$row_jumlah['customer_id']."', '".$_POST['sj_id']."', '".$KodeKasBank."' , '".$row_jaditotal."', '".$_POST['fakdate']."',  '".$_POST['tempodate']."' ,  '".$_POST['unitid']."')");
		}
		
		if($row_bakutotal > 0) {
			$KodeKasBank = KodeKasBank(); 
			mysql_query("insert into ak_kasbanks (ID, JNS_TRANS, TANGGAL, NO_BUKTI, NO_REFF, PERK_KASBANK, URAIAN_DEBET, DEBET, PERK_KREDIT, URAIAN_KREDIT,  KREDIT, TERIMA_DARI, UNIT_KODE) VALUES ('".$KodeKasBank."', 'PTG', '".$_POST['fakdate']."', '', '', '17', '', '".$row_bakutotal."', '58', '', '".$row_bakutotal."', '', '".$_POST['unitid']."') ");
			mysql_query("INSERT INTO ak_piut (CUSTOMER_ID, SJ_ID, KASBANK_ID, DEBET, TANGGAL, JTH_TEMPO, UNIT_ID) VALUES ('".$row_jumlah['customer_id']."', '".$_POST['sj_id']."', '".$KodeKasBank."' , '".$row_bakutotal."', '".$_POST['fakdate']."',  '".$_POST['tempodate']."' ,  '".$_POST['unitid']."')");
		}
		
		
		/*
		mysql_query("insert into ak_kasbank (ID, JNS_TRANS, TANGGAL, TGL_INPUT, USER_ID, UNIT_KODE) VALUES (
		'".$KodeKasBank."',
		'PTG' ,
		'".$_POST['fakdate']."',
		'".$_POST['fakdate']."',
		'".$_SESSION['galaxy_kode']."' ,
		'".$row_jumlah['unitid']."' ) ");
		
		$qry_detail="select max(ID) as max from ak_kasbank ";
		$row_detail=mysql_fetch_array(mysql_query($qry_detail));
		mysql_query("insert into ak_detail_kasbank (KASBANK_ID,PERK_LAWAN,KREDIT,TGL_INPUT,USER_ID,UNIT_KODE) VALUES (
		'".$KodeKasBank."' ,
		'17' ,
		'".$jumlah."' ,
		'".$_POST['fakdate']."',
		'".$_SESSION['galaxy_kode']."' ,
		'".$row_jumlah['unitid']."' )");
		
		mysql_query("insert into ak_piut (CUSTOMER_ID, SJ_ID, KASBANK_ID, KREDIT, TANGGAL, JTH_TEMPO, UNIT_ID) VALUES (
		'".$row_jumlah['customer_id']."',
		'".$row_jumlah['id']."',
		'".$KodeKasBank."' ,
		'".$jumlah."',
		'".$_POST['fakdate']."',
		'".$row_jumlah['jtdate']."' ,
		'".$row_jumlah['unitid']."')"); */
	}
	if($_POST['mod']=='1') {	
		mysql_query("UPDATE fakturs SET fakdate = ".isNull($_POST['fakdate'],'DATE').", tempodate = ".isNull($_POST['tempodate'],'DATE')." , isclosed = '1', faknom = '".$_POST['faknom']."'  WHERE id ='".$_POST['gid']."';");
		
		mysql_query("UPDATE ak_piut SET TANGGAL = ".isNull($_POST['fakdate'],'DATE').", JTH_TEMPO = ".isNull($_POST['tempodate'],'DATE')." WHERE SJ_ID ='".$_POST['sjsj']."';");
	}
 }
 }
?>


