<?php
require_once '../../library/connectionmysql.php';
Connected();
	$perm = array();
	$perm = getPermissions('51');

	if($perm[-1]=='1') { require_once '../../library/error-popup.php'; die; }
	if(isAdd()) { 
		if($perm[0]=='1') { require_once '../../library/error-popup.php'; die; }
	}if(isEdit()) { 
		if($perm[1]=='1') { require_once '../../library/error-popup.php'; die; }
	}if(isConfirmDelete() || isConfirmDeleteSelected()) { 
		if($perm[2]=='1') { require_once '../../library/error-popup.php'; die; }
	}
?>
<?
if(isAdd())
{
	$today=date("Y-m-d");
?>
<div class="popup-shadow" style="width: 600px;">
	<div class="popup-header">
         <span>Neraca</span>
         <div class="popup-close">X</div>
    </div>
    <div class="popup-body">
    <form action="modul/akunting/kartu-piutang.php" method="post">
	<table>
    	<tr>
            <td>Per Tanggal</td>
            <td align="center">:</td>
            <td><input class="input-text" name="tanggal" type="datepicker" value="<? echo cDate($today)?>" /></td>
        </tr>
    </table>
    </form>
    </div>
    <div class="popup-footer">
	<div class="popup-cancel">Batal</div>
 <!--        <div target="<? //echo md5('cetak-KrtHtg') ?>" type="pdf" link="modul/laporan/report?<? //echo $rows_Supplier[0] ?>" class="pdf-button" >Cetak Kas/Bank</div>	-->
       <div mode="6" link="library/submenu/akunting/dt-pembelian" class="popup-button" get="<? echo $rows_Supplier['id'] ?>">Cetak Kartu Hutang</div>
   </div>
</div>
<?
}
?>