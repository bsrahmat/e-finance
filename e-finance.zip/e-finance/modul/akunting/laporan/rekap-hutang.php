<?php

require_once '../../../library/connectionmysql.php';
Connected();
if($_SESSION['galaxy_posisi']=='none' || !isset($_SESSION['galaxy_posisi'])) { header("Location: ../../index.php"); die; }
if($_SESSION['galaxy_unit']=='none' || !isset($_SESSION['galaxy_unit'])) { header("Location: ../../index.php"); die; }
$perm = array();
$perm = getPermissions('51');
if($perm[-1]=='1') { require_once '../../library/error-popup.php'; die; }
$error = array();
if(!$_POST['unit']) $error[] = 'unit:Silahkan masukkan Unit.';
if(!$_POST['tgl-awal']) $error[] = 'tgl-awal:Silahkan masukkan Tanggal Awal.';
if(!$_POST['tgl-akhir']) $error[] = 'tgl-akhir:Silahkan Pilih Tanggal Akhir.';

if(count($error)>0) {
	//tampilkan pesan error, jika ada error.. :D
	echo generateError($error).'|*|';	
	
	
} else {
	$unit= $_POST['unit'];
$tgl_awal = cDateR($_POST['tgl-awal']);
$tgl_akhir = cDateR($_POST['tgl-akhir']);
$qry_htg = "select distinct(SUPPLIER_ID) from ak_htg where TANGGAL between '".$tgl_awal."' and '".$tgl_akhir."' and UNIT_ID='".$unit."' order by SUPPLIER_ID DESC";
$rs_htg = mysql_query($qry_htg);

$rows_units=mysql_fetch_array(mysql_query("select * from units where id = '".$unit."';"));
if($rows_units['logo'] == '') 
{
	$rows_units['logo'] = 'none.jpg';
} 

header("Content-type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=Rekap-Hutang-".$rows_units['code']."-".date('m-Y').".xls");
?>

<table class="ctable-skpd" style="width: 100%;">
	<tr class="isi">
		<td style="width: 100%; text-align:center; font-size: 18px;" colspan="5"><a href="modul/laporan/capture.php?target=<? echo md5('rekap-hutang') ?>&unit=<? echo $_POST['unit']?>&tgl_awal=<? echo $_POST['tgl-awal']?>&tgl_akhir=<? echo $_POST['tgl-akhir']?>" target="_blank" title="Cetak PDF" class="cCetakpdf"></a></td>
	</tr>
    
    <tr class="isi">
		<td style="width: 100%; text-align:center; font-size: 18px;" colspan="5">REKAP HUTANG</td>
	</tr>
    <tr class="isi">
    <?
		$qry_Supplier = "select * from suppliers where id='".$_GET['gid']."';";
		$rows_Supplier=mysql_fetch_array(mysql_query($qry_Supplier));
    ?>
		<td style="width: 100%; text-align:center;  font-size: 14px;" colspan="5">Dari Tanggal: <? echo cDate2($tgl_awal) ?> Sampai: <? echo cDate2($tgl_akhir) ?></td>
	</tr>
       
</table>

        	<table border="0.3" cellspacing="0" style="width: 100%; border-color:#903; border:thin;">
            	<tr style="text-align:center; font-size:12px; background:#CCC;">
                    <td style="width: 5%; height:15px;">No</td>
                    <td style="width: 35%;">Supplier</td>
                    <td style="width: 20%;">Utang Dgng</td>
                    <td style="width: 20%;">Pelunasan</td>
                    <td style="width: 20%;">Sisa</td>
               	</tr>
                <?php
				$no= 1;
				while($rows_htg=mysql_fetch_array($rs_htg)) 
				{
					$qry_supplier="select name from suppliers where id='".$rows_htg['SUPPLIER_ID']."' ";
					$row_supplier=mysql_fetch_array(mysql_query($qry_supplier));
					
					$qry_debet="select sum(DEBET) as dbt, sum(KREDIT) as krd from ak_htg where SUPPLIER_ID='".$rows_htg['SUPPLIER_ID']."' and  TANGGAL between '".$tgl_awal."' and '".$tgl_akhir."' and UNIT_ID='".$unit."' ";
					$row_debet=mysql_fetch_array(mysql_query($qry_debet));
					
					$sisa=$row_debet['dbt']-$row_debet['krd'];
				?>
					<tr class="isi">
						<td align="center"><? echo $no?></td>
                        <td><? echo $row_supplier['name'] ?></td>
						<td align="right"><? echo cFormat($row_debet['dbt'],false) ?></td>
						<td align="right"><? echo cFormat($row_debet['krd'],false) ?></td>
						<td align="right"><? echo cFormat($sisa,false) ?></td>
					</tr>
                <?
					$no++;
				}
				?>
        	</table>
<? } ?>