<?php

require_once '../../../library/connectionmysql.php';
Connected();
if($_SESSION['galaxy_posisi']=='none' || !isset($_SESSION['galaxy_posisi'])) { header("Location: ../../index.php"); die; }
if($_SESSION['galaxy_unit']=='none' || !isset($_SESSION['galaxy_unit'])) { header("Location: ../../index.php"); die; }
$perm = array();
$perm = getPermissions('51');
if($perm[-1]=='1') { require_once '../../library/error-popup.php'; die; }
$error = array();
if(!$_POST['unit']) $error[] = 'unit:Silahkan masukkan Unit.';
if(!$_POST['customer']) $error[] = 'customer:Silahkan Pilih Customer.';
if(!$_POST['tgl-awal']) $error[] = 'tgl-awal:Silahkan masukkan Tanggal Awal.';
if(!$_POST['tgl-akhir']) $error[] = 'tgl-akhir:Silahkan Pilih Tanggal Akhir.';

if(count($error)>0) {
	//tampilkan pesan error, jika ada error.. :D
	echo generateError($error).'|*|';	
	
	
} else {
$unit=$_POST['unit'];
$customer=$_POST['customer'];
$tgl_awal=cDateR($_POST['tgl-awal']);
$tgl_akhir=cDateR($_POST['tgl-akhir']);
$tempo=$_POST['jthtempo'];

$t=explode('-',$tgl_awal);

$tgl= date("d F Y", mktime(0,0,0,date($t[1]),date($t[2])-1,date($t[0]))); 
$bulan=array(1=>'January', 2=>'February', 3=>'March', 4=>'April', 5=>'May', 6=>'June', 7=>'July', 8=>'August', 9=>'September', 10=>'October', 11=>'November', 12=>'December');
$t2=explode(' ',$tgl);
for ($i=1; $i <= 12; $i++)
{
	if($bulan[$i]==$t2[1]) { $bln="0".$i; }
}
$saldo_tanggal2=$t2[2].'-'.$bln.'-'.$t2[0];
$saldo_tanggal='2011-6-30';


if($_POST['jthtempo'])
{
	$tgl="JTH_TEMPO between '".$tgl_awal."'	and '".$tgl_akhir."' ";
	$tgl_saldo="JTH_TEMPO between '".$saldo_tanggal."'	and '".$saldo_tanggal2."'";
}
else
{
	$tgl="TANGGAL between '".$tgl_awal."' and '".$tgl_akhir."' ";
	$tgl_saldo="TANGGAL between '".$saldo_tanggal."' and '".$saldo_tanggal2."'";
}

$rows_units=mysql_fetch_array(mysql_query("select * from units where id = '".$unit."';"));
if($rows_units['logo'] == '') 
{
	$rows_units['logo'] = 'none.jpg';
}
header("Content-type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=Kartu-Piutang-".$rows_units['code']."-".date('m-Y').".xls");
?>

 
 
 <table class="ctable-skpd" style="width: 100%;">
		<tr class="isi">
		<td style="width: 100%; text-align:center; font-size: 18px;" colspan="8"><a href="modul/laporan/capture.php?target=<? echo md5('kartu-piutang') ?>&unit=<? echo $_POST['unit']?>&jthtempo=<? echo $_POST['jthtempo']?>&customer=<? echo $_POST['customer']?>&tgl_awal=<? echo $_POST['tgl-awal']?>&tgl_akhir=<? echo $_POST['tgl-akhir']?>" target="_blank" title="Cetak PDF" class="cCetakpdf"></a></td>
		</tr>
        <tr class="isi" colspan="8">
			<td style="width: 100%; color: #444444; text-align:right; border-bottom:thin;" colspan="2"></td>
        </tr>
</table>

<table class="ctable-skpd" style="width: 100%;">
    <tr class="isi">
		<td style="width: 100%; text-align:center; font-size: 18px;"  colspan="8">KARTU PIUTANG</td>
	</tr>
    <tr class="isi">
    <?
		$qry_customer = "select * from customers where id='".$customer."';";
		$rows_customer=mysql_fetch_array(mysql_query($qry_customer));
    ?>
		<td style="width: 100%; text-align:center;  font-size: 14px;" colspan="8">CUSTOMER : <? echo $rows_customer['name'] ?></td>
	</tr>
    <tr class="isi">
		<td style="width: 100%; text-align:center;  font-size: 14px;" colspan="8">Periode : <? echo cDate2($tgl_awal) ?> s/d <? echo cDate2($tgl_akhir) ?></td>
	</tr>  
</table>

        	<table class="ctable-skpd" border="0.3" cellspacing="0" style="width: 100%; border-color:#903; border:thin;">
            	<tr style="background: #efefef;font-weight: bold; text-align:center;">
                    <td style="width: 4%; height:15px;">No</td>
                    <td style="width: 9%;">Tanggal</td>
                    <td style="width: 17%;">No. SJ</td>
                    <td style="width: 17%;">No. Retur</td>
                    <td style="width: 17%;">No. Kasbank</td>
                    <td style="width: 12%;">Debet</td>
                    <td style="width: 12%;">Kredit</td>
                    <td style="width: 12%;">Saldo</td>
               	</tr>
                <?
				$saldo_debet='0';
				$saldo_kredit='0';
                $qry_saldo="SELECT * FROM ak_piut WHERE UNIT_ID='".$unit."' and CUSTOMER_ID = '".$customer."' and ".$tgl_saldo;
				$rs_saldo=mysql_query($qry_saldo);
				while($rows_saldo=mysql_fetch_array($rs_saldo)) 
				{
					$saldo_debet=$saldo_debet+$rows_saldo['DEBET'];
					$saldo_kredit=$saldo_kredit+$rows_saldo['KREDIT'];
				}
				$total_saldo=$saldo_kredit-$saldo_debet;
				?>
                <tr class="isi">
                    <td></td>
                    <td><? echo cDate2($saldo_tanggal2) ?></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td align="right"><? echo cFormat($total_saldo,false) ?></td>
               	</tr>
                <?php
				$no= 1;
				$qry_sj = "SELECT * FROM ak_piut WHERE ak_piut.UNIT_ID='".$unit."' and ak_piut.CUSTOMER_ID = '".$customer."' and ".$tgl;
				$rs_sj = mysql_query($qry_sj);
				while($rows_sj=mysql_fetch_array($rs_sj)) 
				{
				?>
					<tr class="isi">
						<td align="center"><? echo $no?></td>
						<td><? echo cDate2($rows_sj['TANGGAL']) ?></td>
                        <?
                        $qry_sjs="select sjnom from sjs where id='".$rows_sj['SJ_ID']."' ";
						$row_sjs=mysql_fetch_array(mysql_query($qry_sjs));
						?>
						<td><? echo $row_sjs['sjnom'] ?></td>
                        <?
                        $qry_retur="select retnom from sreturs where id='".$rows_sj['SRETUR_ID']."' ";
						$row_retur=mysql_fetch_array(mysql_query($qry_retur));
						?>
						<td><? echo $row_retur['retnom'] ?></td>
                        <?
                        $qry_kasbank="select NO_BUKTI from ak_kasbank where ID='".$rows_sj['KASBANK_ID']."' ";
						$row_kasbank=mysql_fetch_array(mysql_query($qry_kasbank));
						?>
                        <td><? echo $row_kasbank['NO_BUKTI'] ?></td>
						<td align="right"><? echo cFormat($rows_sj['DEBET'],false) ?></td>
						<td align="right"><? echo cFormat($rows_sj['KREDIT'],false) ?></td>
                        <?
                        $total_saldo=$total_saldo+$rows_sj['KREDIT']-$rows_sj['DEBET'];
						?>
                        <td align="right"><? echo cFormat($total_saldo,false) ?></td>
					</tr>
                <?
					$no++;
				}
				?>
        	</table>
        
    
 
<? } ?>
      
   