<?php

require_once '../../../library/connectionmysql.php';
Connected();
if($_SESSION['galaxy_posisi']=='none' || !isset($_SESSION['galaxy_posisi'])) { header("Location: ../../index.php"); die; }
if($_SESSION['galaxy_unit']=='none' || !isset($_SESSION['galaxy_unit'])) { header("Location: ../../index.php"); die; }
$perm = array();
$perm = getPermissions('51');
if($perm[-1]=='1') { require_once '../../library/error-popup.php'; die; }
$error = array();
if(!$_POST['unit']) $error[] = 'unit:Silahkan masukkan Unit.';
if(!$_POST['tgl-akhir']) $error[] = 'tgl-akhir:Silahkan masukkan per tanggal.';

if(count($error)>0) {
	//tampilkan pesan error, jika ada error.. :D
	echo generateError($error).'|*|';	
} else {

$unit=$_POST['unit'];
$tgl_trans_akhir= cDateR($_POST['tgl-akhir']);

$tgl=explode('-',$tgl_trans_akhir);
$tgl_trans_awal=$tgl['0'].'-'.$tgl['1'].'-1';

$tgl2=date("d F Y", mktime(0,0,0,date($tgl[1]),date('1')-1,date($tgl[0]))); 
$bulan=array(1=>'January', 2=>'February', 3=>'March', 4=>'April', 5=>'May', 6=>'June', 7=>'July', 8=>'August', 9=>'September', 10=>'October', 11=>'November', 12=>'December');
$t2=explode(' ',$tgl2);
for ($i=1; $i <= 12; $i++)
{
	if($bulan[$i]==$t2[1]) { $bln=$i; }
}
$tgl_sld_awal = 1990-01-01;
$tgl_sld_akhir=$t2[2].'-'.$bln.'-'.$t2[0];


$rows_units=mysql_fetch_array(mysql_query("select * from units where id = '".$unit."';"));
header("Content-type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=Neraca-".$rows_units['code']."-".date('m-Y').".xls");
?>

<table class="ctable-skpd" style="width: 100%;">
    <tr class="isi">
		<td style="width: 100%; text-align:center; font-size: 18px;" colspan="6">NERACA</td>
	</tr>
    <tr class="isi">
		<td style="width: 100%; text-align:center;  font-size: 14px;" colspan="6">Per : <? echo cDate2($tgl_trans_akhir) ?></td>
	</tr>

<tr class="isi">
    <td align="center" colspan="3" rowspan="2">Keterangan</td>
    <td align="center" style="width:2%;" rowspan="2">Lamp</td>
    <td align="center" style="width:30%;"><? echo cDate2($tgl_sld_akhir) ?></td>
    <td align="center" style="width:30%; "><? echo cDate2($tgl_trans_akhir) ?></td>
</tr>
<tr class="isi">
    <td align="center" style="width:15%; ">Rp</td>
    <td align="center" style="width:15%; ">Rp</td>
	
</tr>

<?
$qry_kategori="select * from ak_kategori_perk WHERE ID_KATEGORI != '4' ";
$rs_kategori=mysql_query($qry_kategori);
while($rows_kategori=mysql_fetch_array($rs_kategori)) {
	$total_kategori1='0';
	$total_kategori2='0';
?>
    <tr class="isi">
 		<td colspan="3" class="ltext"><b><? echo $rows_kategori['NAMA_KATEGORI']; ?></b></td>
        <td></td>
        <td align="center" style="width:15%; "></td>
    	<td align="center" style="width:15%; "></td>
    </tr>
   
    <?
	$qry_group="select * from ak_group_perk where ID_KATEGORI_GROUP='". $rows_kategori['ID_KATEGORI']."' ";
	$rs_group=mysql_query($qry_group);
	while($rows_group=mysql_fetch_array($rs_group)){
	?>
	<tr class="isi">
    	<td style="width:2%;"></td>
		<td colspan="2" class="ltext"><? echo $rows_group['NAMA_GROUP']; ?></td>
        <td></td>
		<td align="center" style="width:15%; "></td>
		<td align="center" style="width:15%; "></td>
	</tr>
        <?
		$qry_subgroup="select * from ak_subgroup_perk where ID_GROUP_SUBGROUP='". $rows_group['KODE_GROUP']."' ";
		$rs_subgroup=mysql_query($qry_subgroup);
		while($rows_subgroup=mysql_fetch_array($rs_subgroup)){
		?>
		
        <tr class="isi">
        	<td style="width:4%;" colspan="2"></td>
        	<td style="width:40%;" class="ltext"  ><? echo $rows_subgroup['NAMA_SUBGROUP']; ?></td>
            <td></td>
            <td></td>
            <td></td>
       </tr>
            <?
			$qry_perk="select * from ak_detail_perk where ID_SUBGROUP_DETAIL='".$rows_subgroup['KODE_SUBGROUP']."'";
			$rs_perk=mysql_query($qry_perk);
			while($rows_perk=mysql_fetch_array($rs_perk)){
				$cek=0;
				$saldo1='0';
				$saldo2='0';
				$total1='0';
				$total2='0';
				$qry_saldo="select * from ak_saldo_awal where ID_DETAIL='".$rows_perk['ID_DETAIL']."' and ID_UNIT='".$unit."'";
				$row_saldo=mysql_fetch_array(mysql_query($qry_saldo));
				if($row_saldo['JUMLAH']) 
				{ 
					if($rows_kategori['ID_KATEGORI']==1) { $saldo1=$row_saldo['JUMLAH']; }
					if($rows_kategori['ID_KATEGORI']==2 || $rows_kategori['ID_KATEGORI']==3) { $saldo2=$row_saldo['JUMLAH']; }
				}
				
				$qry_saldokasdebet="select SUM(DEBET) AS DEBET from ak_kasbanks where TANGGAL between '1990-01-01' and '".$tgl_sld_akhir."' and UNIT_KODE='".$unit."' AND PERK_KASBANK='".$rows_perk['ID_DETAIL']."'";
				$rs_saldokasdebet=mysql_query($qry_saldokasdebet);
				$rows_saldokasdebet=mysql_fetch_array($rs_saldokasdebet);
				if($rows_saldokasdebet['DEBET']) 
				{ 
					if($rows_kategori['ID_KATEGORI']==1) { $saldo1=$saldo1 + $rows_saldokasdebet['DEBET']; }
					if($rows_kategori['ID_KATEGORI']==2 || $rows_kategori['ID_KATEGORI']==3) { $saldo2=$saldo2 - $rows_saldokasdebet['DEBET']; }
				}
				
				$qry_saldokaskredit="select SUM(KREDIT) AS KREDIT from ak_kasbanks where TANGGAL between '1990-01-01' and '".$tgl_sld_akhir."' and UNIT_KODE='".$unit."' AND PERK_KREDIT='".$rows_perk['ID_DETAIL']."'";
				$rs_saldokaskredit=mysql_query($qry_saldokaskredit);
				$rows_saldokaskredit=mysql_fetch_array($rs_saldokaskredit);
				if($rows_saldokaskredit['KREDIT']) 
				{ 
					if($rows_kategori['ID_KATEGORI']==1) { $saldo1=$saldo1 - $rows_saldokaskredit['KREDIT']; }
					if($rows_kategori['ID_KATEGORI']==2 || $rows_kategori['ID_KATEGORI']==3) { $saldo2=$saldo2 + $rows_saldokaskredit['KREDIT']; }
				}
				
				$qry_jurnaldebet="select SUM(DEBET) AS DEBET from ak_jurnal where TANGGAL_TRANS between '1990-01-01' and '".$tgl_sld_akhir."' and UNIT_KODE='".$unit."' AND PERK_DEBET='".$rows_perk['ID_DETAIL']."'";
				$rs_jurnaldebet=mysql_query($qry_jurnaldebet);
				$rows_jurnaldebet=mysql_fetch_array($rs_jurnaldebet);
				if($rows_jurnaldebet['DEBET']) 
				{ 
					if($rows_kategori['ID_KATEGORI']==1) { $saldo1=$saldo1 + $rows_jurnaldebet['DEBET']; }
					if($rows_kategori['ID_KATEGORI']==2 || $rows_kategori['ID_KATEGORI']==3) { $saldo2=$saldo2 - $rows_jurnaldebet['DEBET']; }
				}
				//$dbtjurnal=$saldo1+$rows_jurnaldebet['DEBET'];
				
				$qry_jurnalkredit="select SUM(KREDIT) AS KREDIT from ak_jurnal where TANGGAL_TRANS between '1990-01-01' and '".$tgl_sld_akhir."' and UNIT_KODE='".$unit."' AND PERK_KREDIT='".$rows_perk['ID_DETAIL']."'";
				$rs_jurnalkredit=mysql_query($qry_jurnalkredit);
				$rows_jurnalkredit=mysql_fetch_array($rs_jurnalkredit);
				//$krdjurnal=$saldo1+$rows_jurnalkredit['KREDIT'];
				if($rows_jurnalkredit['KREDIT']) 
				{ 
					if($rows_kategori['ID_KATEGORI']==1) { $saldo1=$saldo1 - $rows_jurnalkredit['KREDIT']; }
					if($rows_kategori['ID_KATEGORI']==2 || $rows_kategori['ID_KATEGORI']==3) { $saldo2=$saldo2 + $rows_jurnalkredit['KREDIT']; }
				}
				/////////
				$qry_saldokas2debet="select SUM(DEBET) AS DEBET from ak_kasbanks where TANGGAL between '".$tgl_trans_awal."' and '".$tgl_trans_akhir."' and UNIT_KODE='".$unit."' AND PERK_KASBANK='".$rows_perk['ID_DETAIL']."'";
				$rs_saldokas2debet=mysql_query($qry_saldokas2debet);
				$rows_saldokas2debet=mysql_fetch_array($rs_saldokas2debet);
				$mutasidebet = $rows_saldokas2debet['DEBET'];
				
				$qry_saldokas2kredit="select SUM(KREDIT) AS KREDIT from ak_kasbanks where TANGGAL between '".$tgl_trans_awal."' and '".$tgl_trans_akhir."' and UNIT_KODE='".$unit."' AND PERK_KREDIT='".$rows_perk['ID_DETAIL']."'";
				$rs_saldokas2kredit=mysql_query($qry_saldokas2kredit);
				$rows_saldokas2kredit=mysql_fetch_array($rs_saldokas2kredit);
				
				$mutasikredit = $rows_saldokas2kredit['KREDIT'];
				
				$qry_jurnal2debet="select SUM(DEBET) AS DEBET from ak_jurnal where TANGGAL_TRANS between '".$tgl_trans_awal."' and '".$tgl_trans_akhir."' and UNIT_KODE='".$unit."' AND PERK_DEBET='".$rows_perk['ID_DETAIL']."'";
				$rs_jurnal2debet=mysql_query($qry_jurnal2debet);
				$rows_jurnal2debet=mysql_fetch_array($rs_jurnal2debet);
				$dbtjurnal=$rows_jurnal2debet['DEBET'];
				
				$qry_jurnal2kredit="select SUM(KREDIT) AS KREDIT from ak_jurnal where TANGGAL_TRANS between '".$tgl_trans_awal."' and '".$tgl_trans_akhir."' and UNIT_KODE='".$unit."' AND PERK_KREDIT='".$rows_perk['ID_DETAIL']."'";
				$rs_jurnal2kredit=mysql_query($qry_jurnal2kredit);
				$rows_jurnal2kredit=mysql_fetch_array($rs_jurnal2kredit);
				$krdjurnal=$rows_jurnal2kredit['KREDIT'];
				
				$total1 = $saldo1 - $saldo2 + $mutasidebet - $mutasikredit + $dbtjurnal - $krdjurnal;
				
				$totalsa = explode('-',$total1);	
				//$total2 = $saldo1 + $saldo2 - $mutasidebet + $mutasikredit - $dbtjurnal + $krdjurnal;	
				
				//if($rows_kategori['ID_KATEGORI']==1) { $saldo1=$saldo1 - $rows_jurnalkredit['KREDIT']; }
				//if($rows_kategori['ID_KATEGORI']==2 || $rows_kategori['ID_KATEGORI']==3) { $saldo2=$saldo2 + $rows_jurnalkredit['KREDIT']; }		
			
			$neraca1 = $neraca1 + $saldo1 ;
			$neraca2 = $neraca2 + $total1 ;
			?>
            <tr class="isi">
        	<td style="width:4%;" colspan="2"></td>
        	<td style="width:40%;" class="ltext"  >- <? echo $rows_perk['NAMA_DETAIL']; ?></td>
            <td></td>
            <td align="right" style="width:28%; "><? echo cFormat($saldo1,false) ; ?></td>
            <td align="right" style="width:28%; "><? echo cFormat($total1,false) ; ?></td>
       		</tr>
			
            <?
			}
			?>
        <?
			$total_group1=$total_group1+$saldo1;
			$total_group2=$total_group2+$total1;
		}
		?>
       
    <?
		$total_kategori1=$total_kategori1+$total_group1;
		$total_kategori2=$total_kategori2+$total_group2;
    }
		
    ?>
            		
                
    
<?
}
?>
</table>
<?
}
?>
