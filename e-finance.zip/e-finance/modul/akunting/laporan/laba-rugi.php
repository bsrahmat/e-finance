<?php

require_once '../../../library/connectionmysql.php';
Connected();
if($_SESSION['galaxy_posisi']=='none' || !isset($_SESSION['galaxy_posisi'])) { header("Location: ../../index.php"); die; }
if($_SESSION['galaxy_unit']=='none' || !isset($_SESSION['galaxy_unit'])) { header("Location: ../../index.php"); die; }
$perm = array();
$perm = getPermissions('63');
if($perm[-1]=='1') { require_once '../../library/error-popup.php'; die; }
$error = array();
if(!$_POST['unit']) $error[] = 'unit:Silahkan masukkan Unit.';
if(!$_POST['tgl-akhir']) $error[] = 'tgl-akhir:Silahkan masukkan per tanggal.';

if(count($error)>0) {
	//tampilkan pesan error, jika ada error.. :D
	echo generateError($error).'|*|';	
} else {

$unit=$_POST['unit'];
$tgl_akhir=  cDateR($_POST['tgl-akhir']);

$tgl=explode('-',$tgl_akhir);
$tgl_awal=$tgl['0'].'-'.$tgl['1'].'-1';

$tgl2=date("d F Y", mktime(0,0,0,date($tgl[1]),date('1')-1,date($tgl[0]))); 
$bulan=array(1=>'January', 2=>'February', 3=>'March', 4=>'April', 5=>'May', 6=>'June', 7=>'July', 8=>'August', 9=>'September', 10=>'October', 11=>'November', 12=>'December');
$t2=explode(' ',$tgl2);
for ($i=1; $i <= 12; $i++)
{
	if($bulan[$i]==$t2[1]) { $bln=$i; }
}
$tgl_sld_akhir=$t2[2].'-'.$bln.'-'.$t2[0];

$tgl_saldo_awal=$t2[2].'-'.$bln.'-1';

$tglre=explode('-',$tgl_sld_akhir);

$tgl2re=date("d F Y", mktime(0,0,0,date($tglre[1]),date('1')-1,date($tglre[0]))); 
$bulanre=array(1=>'January', 2=>'February', 3=>'March', 4=>'April', 5=>'May', 6=>'June', 7=>'July', 8=>'August', 9=>'September', 10=>'October', 11=>'November', 12=>'December');
$tre=explode(' ',$tgl2re);
for ($i=1; $i <= 12; $i++)
{
	if($bulanre[$i]==$tre[1]) { $blnre=$i; }
}
$tgl_resaldo_akhir=$tre[2].'-'.$blnre.'-'.$tre[0];
$tgl_resaldo_awal='2011-1-1';







$rows_units=mysql_fetch_array(mysql_query("select * from units where id = '".$unit."';"));
if($rows_units['logo'] == '') 
{
	$rows_units['logo'] = 'none.jpg';
}
header("Content-type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=Neraca-".$rows_units['code']."-".date('m-Y').".xls");

?>

<table class="ctable-skpd" style="width: 100%;">
   <tr class="isi">
		<td style="width: 100%; text-align:center; font-size: 18px;" colspan="10">RUGI LABA</td>
	</tr>
    <tr class="isi">
		<td style="width: 100%; text-align:center;  font-size: 14px;" colspan="10">Periode : <? echo cDate2($tgl_akhir) ?></td>
	</tr>
    <tr class="isi">
		<td colspan="4" rowspan="2" style="width:40%">Deskripsi</td>
		<td style="width: 20%;" colspan="2">Bulan Lalu</td>
		<td style="width: 20%;" colspan="2">Priode <? echo cDate2($tgl_akhir)?></td>
        <td style="width: 20%;" colspan="2">Bulan Ini</td>
		
	</tr>
    <tr class="isi">
		<td style="width: 13%;">Rp</td>
		<td style="width: 7%;">%</td>
        <td style="width: 13%;">Rp</td>
		<td style="width: 7%;">%</td>
        <td style="width: 13%;">Rp</td>
		<td style="width: 7%;">%</td>
	</tr>
    
    <tr class="isi">
    	<td colspan="4" class="ltext">Pendapatan/ Revenue</td>
		<td></td>
		<td></td>
        <td></td>
		<td></td>
        <td></td>
		<td></td>
	</tr>
    
    <tr class="isi">
    	<td></td>
    	<td style="width: 38%; height:15px;" colspan="3" class="ltext"><b>Penjualan</b></td>
		<td></td>
		<td></td>
        <td></td>
		<td></td>
        <td></td>
		<td></td>
	</tr>
    <?
	
	
	
	$rows_penjualan_pertama = mysql_fetch_array(mysql_query("select SUM(qty*(price+ppnperitem)) as penjualan, SUM(disc) as disc from fakdetails JOIN fakturs ON(fakdetails.faktur_id = fakturs.id) WHERE fakturs.unitid = '".$_POST['unit']."' AND fakturs.isclosed = '0' AND fakturs.fakdate between '".$tgl_resaldo_awal."' and '".$tgl_sld_akhir."'")) ;
	$rows_penjualan_kedua = mysql_fetch_array(mysql_query("select SUM(qty*(price+ppnperitem)) as penjualan, SUM(disc) as disc from fakdetails JOIN fakturs ON(fakdetails.faktur_id = fakturs.id) WHERE fakturs.unitid = '".$_POST['unit']."' AND fakturs.isclosed = '0' AND fakturs.fakdate between '".$tgl_awal."' and '".$tgl_akhir."'")) ;
	
	$rows_retur_tiga = mysql_fetch_array(mysql_query("select SUM(qty*price) as retur from sretdetails JOIN sreturs ON(sretdetails.sretur_id = sreturs.id) WHERE sreturs.unitid = '".$_POST['unit']."' AND sreturs.isclosed = '0' AND sreturs.retdate between '".$tgl_resaldo_awal."' and '".$tgl_sld_akhir."'")) ;
	
	$rows_retur_empat = mysql_fetch_array(mysql_query("select SUM(qty*price) as retur from sretdetails JOIN sreturs ON(sretdetails.sretur_id = sreturs.id) WHERE sreturs.unitid = '".$_POST['unit']."' AND sreturs.isclosed = '0' AND sreturs.retdate between '".$tgl_awal."' and '".$tgl_akhir."'")) ;
	
	$net1 = $rows_penjualan_pertama['penjualan'] - $rows_penjualan_pertama['disc'] - $rows_retur_tiga['retur'] ;
	$net3 = $rows_penjualan_kedua['penjualan'] - $rows_penjualan_kedua['disc'] - $rows_retur_empat['retur'] ;
	$net5 = $net1 + $net3 ;
	
	$rows_saldo = mysql_fetch_array(mysql_query("select SUM(tot) as saldo from stockitems WHERE transtype_id = '1' AND unit_id = '".$_POST['unit']."' AND stockdate  between '".$tgl_resaldo_awal."' and '".$tgl_resaldo_akhir."'")) ;
	$rows_beli = mysql_fetch_array(mysql_query("select SUM(tot) as beli from stockitems WHERE (transtype_id = '2' OR transtype_id = '5') AND unit_id = '".$_POST['unit']."' AND stockdate  between '".$tgl_resaldo_awal."' and '".$tgl_resaldo_akhir."'")) ;
	$rows_jual = mysql_fetch_array(mysql_query("select SUM(tot) as jual from stockitems WHERE (transtype_id = '3' OR transtype_id = '4') AND unit_id = '".$_POST['unit']."' AND stockdate  between '".$tgl_resaldo_awal."' and '".$tgl_resaldo_akhir."'")) ;
	$saldo_awal_barang = $rows_saldo['saldo'] + $rows_beli['beli'] - $rows_jual['jual'];
	
	$rows_pembelian_pertama = mysql_fetch_array(mysql_query("select SUM(debt) as pembelian from trrgdetails JOIN  trrgoods ON(trrgdetails.trrgood_id =  trrgoods.id) WHERE  trrgoods.unitid = '".$_POST['unit']."' AND trrgoods.isclosed = '1' AND trrgoods.rgdate between '".$tgl_saldo_awal."' and '".$tgl_sld_akhir."'")) ;
	$rows_pembelian_kedua = mysql_fetch_array(mysql_query("select SUM(qty*(price+ppnperitem)) as penjualan, SUM(disc) as disc from fakdetails JOIN fakturs ON(fakdetails.faktur_id = fakturs.id) WHERE fakturs.unitid = '".$_POST['unit']."' AND fakturs.isclosed = '0' AND fakturs.fakdate between '".$tgl_saldo_awal."' and '".$tgl_sld_akhir."'")) ;
	$rows_pembelian_ketiga = mysql_fetch_array(mysql_query("select SUM(qty*price) as retur from sretdetails JOIN sreturs ON(sretdetails.sretur_id = sreturs.id) WHERE sreturs.unitid = '".$_POST['unit']."' AND sreturs.isclosed = '0' AND sreturs.retdate between '".$tgl_saldo_awal."' and '".$tgl_sld_akhir."'")) ;
	$rows_pembelian_empat = mysql_fetch_array(mysql_query("select SUM(qty*price) as retur from bretdetails JOIN breturs ON(bretdetails.bretur_id = breturs.id) WHERE breturs.unitid = '".$_POST['unit']."' AND breturs.isclosed = '0' AND breturs.retdate between '".$tgl_saldo_awal."' and '".$tgl_sld_akhir."'")) ;
	
	$saldo_akhir_barang = $saldo_awal_barang + $rows_pembelian_pertama['pembelian'] - $rows_pembelian_kedua['penjualan'] - $rows_pembelian_kedua['disc'] + $rows_pembelian_empat['retur'] - $rows_pembelian_ketiga['retur'];
	
	
	
	
	$rows_pembelian_pertama2 = mysql_fetch_array(mysql_query("select SUM(debt) as pembelian from trrgdetails JOIN  trrgoods ON(trrgdetails.trrgood_id =  trrgoods.id) WHERE  trrgoods.unitid = '".$_POST['unit']."' AND trrgoods.isclosed = '1' AND trrgoods.rgdate between '".$tgl_awal."' and '".$tgl_akhir."'")) ;
	$rows_pembelian_kedua2 = mysql_fetch_array(mysql_query("select SUM(qty*(price+ppnperitem)) as penjualan, SUM(disc) as disc from fakdetails JOIN fakturs ON(fakdetails.faktur_id = fakturs.id) WHERE fakturs.unitid = '".$_POST['unit']."' AND fakturs.isclosed = '0' AND fakturs.fakdate between '".$tgl_awal."' and '".$tgl_akhir."'")) ;
	$rows_pembelian_ketiga2 = mysql_fetch_array(mysql_query("select SUM(qty*price) as retur from sretdetails JOIN sreturs ON(sretdetails.sretur_id = sreturs.id) WHERE sreturs.unitid = '".$_POST['unit']."' AND sreturs.isclosed = '0' AND sreturs.retdate between '".$tgl_awal."' and '".$tgl_akhir."'")) ;
	$rows_pembelian_empat2 = mysql_fetch_array(mysql_query("select SUM(qty*price) as retur from bretdetails JOIN breturs ON(bretdetails.bretur_id = breturs.id) WHERE breturs.unitid = '".$_POST['unit']."' AND breturs.isclosed = '0' AND breturs.retdate between '".$tgl_awal."' and '".$tgl_akhir."'")) ;
	
	$saldo_akhir_barang2 = $saldo_akhir_barang + $rows_pembelian_pertama2['pembelian'] - $rows_pembelian_kedua2['penjualan'] - $rows_pembelian_kedua2['disc'] + $rows_pembelian_empat2['retur'] - $rows_pembelian_ketiga2['retur'];
	
	$persen1 = $rows_penjualan_pertama['penjualan'] / $net1 * 100;
	$persen2 = -$rows_penjualan_pertama['disc'] / $net1 * 100;
	$persen3 = -$rows_retur_tiga['retur'] / $net1 * 100;
	$persen4 = $net1 / $net1 * 100;
	
	$persen5 = $rows_penjualan_kedua['penjualan'] / $net3 * 100;
	$persen6 = -$rows_penjualan_kedua['disc'] / $net3 * 100;
	$persen7 = -$rows_retur_empat['retur'] / $net3 * 100;
	$persen8 = $net3 / $net3 * 100;
	
	$persen9 = ($rows_penjualan_pertama['penjualan'] + $rows_penjualan_kedua['penjualan']) / $net5 * 100;
	$persen10 = (-($rows_penjualan_pertama['disc'] + $rows_penjualan_kedua['disc'])) / $net5 * 100;
	$persen11 = (-($rows_retur_tiga['retur'] + $rows_retur_empat['retur'])) / $net5 * 100;
	$persen12 = $net5 / $net5 * 100;
	
	
	$persen13 = $saldo_awal_barang / $net1 * 100;
	$persen14 = $rows_pembelian_pertama['pembelian'] / $net1 * 100;
	$persen15 = ($saldo_awal_barang+$rows_pembelian_pertama['pembelian']) / $net1 * 100;
	
	$persen16 = $saldo_akhir_barang / $net3 * 100;
	$persen17 = $rows_pembelian_pertama2['pembelian'] / $net3 * 100;
	$persen18 = ($saldo_akhir_barang+$rows_pembelian_pertama2['pembelian']) / $net3 * 100;
	
	$persen19 = $saldo_awal_barang / $net5 * 100;
	$persen20 = ($rows_pembelian_pertama['pembelian'] + $rows_pembelian_pertama2['pembelian']) / $net5 * 100;
	$persen21 = ($saldo_awal_barang+$rows_pembelian_pertama['pembelian'] + $rows_pembelian_pertama2['pembelian']) / $net5 * 100;
	
	$persen22 = -$saldo_akhir_barang / $net1 * 100;
	$persen23 = -$saldo_akhir_barang2 / $net3 * 100;
	$persen24 = -$saldo_akhir_barang2 / $net5 * 100;
	
	$persen25 = ($saldo_awal_barang+$rows_pembelian_pertama['pembelian']-$saldo_akhir_barang) / $net1 * 100;
	$persen26 = ($saldo_akhir_barang+$rows_pembelian_pertama2['pembelian']-$saldo_akhir_barang2) / $net3 * 100;
	$persen27 = ($saldo_awal_barang+$rows_pembelian_pertama['pembelian'] + $rows_pembelian_pertama2['pembelian'] -$saldo_akhir_barang2) / $net5 * 100;
	
	$persen28 = ($net1 -($saldo_awal_barang+$rows_pembelian_pertama['pembelian']-$saldo_akhir_barang)) / $net1 * 100;
	$persen29 = ($net3 -($saldo_akhir_barang+$rows_pembelian_pertama2['pembelian']-$saldo_akhir_barang2)) / $net3 * 100;
	$persen30 = ($net5 -($saldo_awal_barang+$rows_pembelian_pertama['pembelian'] + $rows_pembelian_pertama2['pembelian'] -$saldo_akhir_barang2)) / $net5 * 100;
	
	?>
    <tr class="isi">
    	<td></td>
        <td></td>
    	<td colspan="2" class="ltext">Penjualan</td>
		<td class="rtext"><? echo cFormat($rows_penjualan_pertama['penjualan'],false) ; ?></td>
		<td class="rtext"><? echo cPercent($persen1,false) ; ?></td>
        <td class="rtext"><? echo cFormat($rows_penjualan_kedua['penjualan'],false) ; ?></td>
        <td class="rtext"><? echo cPercent($persen5,false) ; ?></td>
        <td class="rtext"><? echo cFormat($rows_penjualan_pertama['penjualan'] + $rows_penjualan_kedua['penjualan'],false) ; ?></td>
        <td class="rtext"><? echo cPercent($persen9,false) ; ?></td>
	</tr>
    <tr class="isi">
    	<td></td>
        <td></td>
    	<td colspan="2" class="ltext">Potongan penjualan</td>
		<td class="rtext"><? echo cFormat(-$rows_penjualan_pertama['disc'],false) ; ?></td>
		<td class="rtext"><? echo cPercent($persen2,false) ; ?></td>
        <td class="rtext"><? echo cFormat(-$rows_penjualan_kedua['disc'],false) ; ?></td>
        <td class="rtext"><? echo cPercent($persen6,false) ; ?></td>
        <td class="rtext"><? echo cFormat(-($rows_penjualan_pertama['disc'] + $rows_penjualan_kedua['disc']),false) ; ?></td>
        <td class="rtext"><? echo cPercent($persen10,false) ; ?></td>
	</tr>
    <tr class="isi">
    	<td></td>
        <td></td>
    	<td colspan="2" class="ltext">Retur penjualan</td>
		<td class="rtext"><? echo cFormat(-$rows_retur_tiga['retur'],false) ; ?></td>
		<td class="rtext"><? echo cPercent($persen3,false) ; ?></td>
        <td class="rtext"><? echo cFormat(-$rows_retur_empat['retur'],false) ; ?></td>
		<td class="rtext"><? echo cPercent($persen7,false) ; ?></td>
        <td class="rtext"><? echo cFormat(-($rows_retur_tiga['retur'] + $rows_retur_empat['retur']),false) ; ?></td>
		<td class="rtext"><? echo cPercent($persen11,false) ; ?></td>
	</tr>
    <tr class="isi">
    	<td colspan="4"><b>Net Sales</b></td>
		<td class="rtext"><? echo cFormat($net1,false) ; ?></td>
		<td class="rtext"><? echo cPercent($persen4,false) ; ?></td>
        <td class="rtext"><? echo cFormat($net3,false) ; ?></td>
		<td class="rtext"><? echo cPercent($persen8,false) ; ?></td>
        <td class="rtext"><? echo cFormat($net5,false) ; ?></td>
		<td class="rtext"><? echo cPercent($persen12,false) ; ?></td>
	</tr>
   
   
   <tr class="isi">
    	<td></td>
    	<td style="width: 38%; height:15px;" colspan="3" class="ltext"><b>Harga Pokok Penjualan</b></td>
		<td></td>
		<td></td>
        <td></td>
		<td></td>
        <td></td>
		<td></td>
	</tr>
    <tr class="isi">
    	<td></td>
        <td></td>
    	<td colspan="2" class="ltext">Persediaan Awal Barang Dagang</td>
		<td class="rtext"><? echo cFormat($saldo_awal_barang,false) ; ?></td>
		<td class="rtext"><? echo cPercent($persen13,false) ; ?></td>
        <td class="rtext"><? echo cFormat($saldo_akhir_barang,false) ; ?></td>
		<td class="rtext"><? echo cPercent($persen16,false) ; ?></td>
        <td class="rtext"><? echo cFormat($saldo_awal_barang,false) ; ?></td>
		<td class="rtext"><? echo cPercent($persen19,false) ; ?></td>
	</tr>
    <tr class="isi">
    	<td></td>
        <td></td>
    	<td colspan="2" class="ltext">Pembelian Barang (Potongan pembelian)
</td>
		<td class="rtext"><? echo cFormat($rows_pembelian_pertama['pembelian'],false) ; ?></td>
		<td class="rtext"><? echo cPercent($persen14,false) ; ?></td>
        <td class="rtext"><? echo cFormat($rows_pembelian_pertama2['pembelian'],false) ; ?></td>
		<td class="rtext"><? echo cPercent($persen17,false) ; ?></td>
        <td class="rtext"><? echo cFormat($rows_pembelian_pertama['pembelian'] + $rows_pembelian_pertama2['pembelian'],false) ; ?></td>
		<td class="rtext"><? echo cPercent($persen20,false) ; ?></td>
	</tr>
    
    <tr class="isi">
    	<td colspan="4" class="ltext"><b>Barang Teresedia Dijual</b></td>
		<td class="rtext"><? echo cFormat($saldo_awal_barang+$rows_pembelian_pertama['pembelian'],false) ; ?></td>
		<td class="rtext"><? echo cPercent($persen15,false) ; ?></td>
        <td class="rtext"><? echo cFormat($saldo_akhir_barang+$rows_pembelian_pertama2['pembelian'],false) ; ?></td>
		<td class="rtext"><? echo cPercent($persen18,false) ; ?></td>
        <td class="rtext"><? echo cFormat($saldo_awal_barang+$rows_pembelian_pertama['pembelian'] + $rows_pembelian_pertama2['pembelian'],false) ; ?></td>
		<td class="rtext"><? echo cPercent($persen21,false) ; ?></td>
	</tr>
    <tr class="isi">
    	<td></td>
        <td></td>
    	<td colspan="2" class="ltext">Persediaan Akhir Barang Dagang</td>
		<td class="rtext"><? echo cFormat(-$saldo_akhir_barang,false) ; ?></td>
		<td class="rtext"><? echo cPercent($persen22,false) ; ?></td>
        <td class="rtext"><? echo cFormat(-$saldo_akhir_barang2,false) ; ?></td>
		<td class="rtext"><? echo cPercent($persen23,false) ; ?></td>
        <td class="rtext"><? echo cFormat(-$saldo_akhir_barang2,false) ; ?></td>
		<td class="rtext"><? echo cPercent($persen24,false) ; ?></td>
	</tr>
    <tr class="isi">
    	<td colspan="4" class="ltext"><b>Harga Pokok Penjualan</b></td>
		<td class="rtext"><? echo cFormat($saldo_awal_barang+$rows_pembelian_pertama['pembelian']-$saldo_akhir_barang,false) ; ?></td>
		<td class="rtext"><? echo cPercent($persen25,false) ; ?></td>
        <td class="rtext"><? echo cFormat($saldo_akhir_barang+$rows_pembelian_pertama2['pembelian']-$saldo_akhir_barang2,false) ; ?></td>
		<td class="rtext"><? echo cPercent($persen26,false) ; ?></td>
        <td class="rtext"><? echo cFormat($saldo_awal_barang+$rows_pembelian_pertama['pembelian'] + $rows_pembelian_pertama2['pembelian'] -$saldo_akhir_barang2,false) ; ?></td>
		<td class="rtext"><? echo cPercent($persen27,false) ; ?></td>
	</tr>
    <tr class="isi">
    	<td style="height:15px;" colspan="4" class="ltext"><b>Total Gross Margin</b></td>
		<td class="rtext"><? echo cFormat($net1 -($saldo_awal_barang+$rows_pembelian_pertama['pembelian']-$saldo_akhir_barang),false) ; ?></td>
		<td class="rtext"><? echo cPercent($persen28,false) ; ?></td>
        <td class="rtext"><? echo cFormat($net3 -($saldo_akhir_barang+$rows_pembelian_pertama2['pembelian']-$saldo_akhir_barang2),false) ; ?></td>
		<td class="rtext"><? echo cPercent($persen29,false) ; ?></td>
        <td class="rtext"><? echo cFormat($net5 -($saldo_awal_barang+$rows_pembelian_pertama['pembelian'] + $rows_pembelian_pertama2['pembelian'] -$saldo_akhir_barang2),false) ; ?></td>
		<td class="rtext"><? echo cPercent($persen30,false) ; ?></td>
	</tr>
    
    
<?
$qry_kategori="select * from ak_kategori_perk WHERE ID_KATEGORI = '5'";
$rs_kategori=mysql_query($qry_kategori);
while($rows_kategori=mysql_fetch_array($rs_kategori))
{
	$total_kategori='0';
?>
	<tr class="isi">
    	<td colspan="4" class="ltext"><b><? echo $rows_kategori['NAMA_KATEGORI']; ?></b></td>
		<td></td>
		<td></td>
        <td></td>
		<td></td>
        <td></td>
		<td></td>
	</tr>
        
    <?
	$qry_group="select * from ak_group_perk where ID_KATEGORI_GROUP='". $rows_kategori['ID_KATEGORI']."' ";
	$rs_group=mysql_query($qry_group);
	while($rows_group=mysql_fetch_array($rs_group)){
	?>
    	<tr class="isi">
    	<td></td>
    	<td style="width: 38%; height:15px;" colspan="3" class="ltext"><b><? echo $rows_group['NAMA_GROUP']; ?></b></td>
		<td></td>
		<td></td>
        <td></td>
		<td></td>
        <td></td>
		<td></td>
	</tr>
    
        <?
		$qry_subgroup="select * from ak_subgroup_perk where ID_GROUP_SUBGROUP='".$rows_group['KODE_GROUP']."' ";
		$rs_subgroup=mysql_query($qry_subgroup);
		while($rows_subgroup=mysql_fetch_array($rs_subgroup)){
			$rows_satu = mysql_fetch_array(mysql_query("select SUM(KREDIT) AS jakredit from ak_kasbanks join ak_detail_perk ON (ak_kasbanks.PERK_KASBANK = ak_detail_perk.ID_DETAIL) WHERE  ak_detail_perk.ID_SUBGROUP_DETAIL = '".$rows_subgroup['KODE_SUBGROUP']."' AND ak_kasbanks.UNIT_KODE = '".$unit."' AND ak_kasbanks.TANGGAL between '".$tgl_resaldo_awal."' and '".$tgl_sld_akhir."'"));
			$rows_satujur = mysql_fetch_array(mysql_query("select SUM(KREDIT) AS jakredit from ak_jurnal join ak_detail_perk ON (ak_jurnal.PERK_KREDIT = ak_detail_perk.ID_DETAIL) WHERE  ak_detail_perk.ID_SUBGROUP_DETAIL = '".$rows_subgroup['KODE_SUBGROUP']."' AND ak_jurnal.UNIT_KODE = '".$unit."' AND ak_jurnal.TANGGAL_TRANS between '".$tgl_resaldo_awal."' and '".$tgl_sld_akhir."'"));
			
			$rows_dua = mysql_fetch_array(mysql_query("select SUM(KREDIT) AS jakredit from ak_kasbanks join ak_detail_perk ON (ak_kasbanks.PERK_KASBANK = ak_detail_perk.ID_DETAIL) WHERE  ak_detail_perk.ID_SUBGROUP_DETAIL = '".$rows_subgroup['KODE_SUBGROUP']."' AND ak_kasbanks.UNIT_KODE = '".$unit."' AND ak_kasbanks.TANGGAL between '".$tgl_awal."' and '".$tgl_akhir."'"));
			$rows_duajur = mysql_fetch_array(mysql_query("select SUM(KREDIT) AS jakredit from ak_jurnal join ak_detail_perk ON (ak_jurnal.PERK_KREDIT = ak_detail_perk.ID_DETAIL) WHERE  ak_detail_perk.ID_SUBGROUP_DETAIL = '".$rows_subgroup['KODE_SUBGROUP']."' AND ak_jurnal.UNIT_KODE = '".$unit."' AND ak_jurnal.TANGGAL_TRANS between '".$tgl_awal."' and '".$tgl_akhir."'"));
			
		$persen34 = ($rows_satu['jakredit']+$rows_satujur['jakredit']) / $net1 * 100;
		$persen35 = ($rows_dua['jakredit']+$rows_duajur['jakredit']) / $net3 * 100;
		$persen36 = ($rows_satu['jakredit']+$rows_satujur['jakredit']+$rows_dua['jakredit']+$rows_duajur['jakredit']) / $net5 * 100;
		
		?>
		<tr class="isi">
        <td colspan="2" class="rtext">-</td>
        <td colspan="2" class="ltext"><? echo $rows_subgroup['NAMA_SUBGROUP']; ?></td>
        <td class="rtext"><? echo cFormat($rows_satu['jakredit']+$rows_satujur['jakredit'],false) ; ?></td>
        <td class="rtext"><? echo cPercent($persen34,false) ; ?></td>
        <td class="rtext"><? echo cFormat($rows_dua['jakredit']+$rows_duajur['jakredit'],false) ; ?></td>
        <td class="rtext"><? echo cPercent($persen35,false) ; ?></td>
        <td class="rtext"><? echo cFormat($rows_satu['jakredit']+$rows_satujur['jakredit']+$rows_dua['jakredit']+$rows_duajur['jakredit'],false) ; ?></td>
        <td class="rtext"><? echo cPercent($persen36,false) ; ?></td>
        </tr>
        <? }
		$rows_tot_satu = mysql_fetch_array(mysql_query("select SUM(KREDIT) AS jakredit from ak_kasbanks join ak_detail_perk ON (ak_kasbanks.PERK_KASBANK = ak_detail_perk.ID_DETAIL) JOIN ak_subgroup_perk ON  (ak_detail_perk.ID_SUBGROUP_DETAIL = ak_subgroup_perk.KODE_SUBGROUP) WHERE  ak_subgroup_perk.ID_GROUP_SUBGROUP = '".$rows_group['KODE_GROUP']."' AND ak_kasbanks.UNIT_KODE = '".$unit."' AND ak_kasbanks.TANGGAL between '".$tgl_resaldo_awal."' and '".$tgl_sld_akhir."'"));
		
		$rows_tot_satujur = mysql_fetch_array(mysql_query("select SUM(KREDIT) AS jakredit from ak_jurnal join ak_detail_perk ON (ak_jurnal.PERK_KREDIT = ak_detail_perk.ID_DETAIL) JOIN ak_subgroup_perk ON  (ak_detail_perk.ID_SUBGROUP_DETAIL = ak_subgroup_perk.KODE_SUBGROUP) WHERE  ak_subgroup_perk.ID_GROUP_SUBGROUP = '".$rows_group['KODE_GROUP']."' AND ak_jurnal.UNIT_KODE = '".$unit."' AND ak_jurnal.TANGGAL_TRANS between '".$tgl_resaldo_awal."' and '".$tgl_sld_akhir."'"));
			
		$rows_tot_dua = mysql_fetch_array(mysql_query("select SUM(KREDIT) AS jakredit from ak_kasbanks join ak_detail_perk ON (ak_kasbanks.PERK_KASBANK = ak_detail_perk.ID_DETAIL) JOIN ak_subgroup_perk ON  (ak_detail_perk.ID_SUBGROUP_DETAIL = ak_subgroup_perk.KODE_SUBGROUP) WHERE  ak_subgroup_perk.ID_GROUP_SUBGROUP = '".$rows_group['KODE_GROUP']."' AND ak_kasbanks.UNIT_KODE = '".$unit."' AND ak_kasbanks.TANGGAL between '".$tgl_awal."' and '".$tgl_akhir."'"));
		$rows_tot_duajur = mysql_fetch_array(mysql_query("select SUM(KREDIT) AS jakredit from ak_jurnal join ak_detail_perk ON (ak_jurnal.PERK_KREDIT = ak_detail_perk.ID_DETAIL) JOIN ak_subgroup_perk ON  (ak_detail_perk.ID_SUBGROUP_DETAIL = ak_subgroup_perk.KODE_SUBGROUP) WHERE  ak_subgroup_perk.ID_GROUP_SUBGROUP = '".$rows_group['KODE_GROUP']."' AND ak_jurnal.UNIT_KODE = '".$unit."' AND ak_jurnal.TANGGAL_TRANS between '".$tgl_awal."' and '".$tgl_akhir."'"));
		
		$persen31 = ($rows_tot_satu['jakredit']+$rows_tot_satujur['jakredit']) / $net1 * 100;
		$persen32 = ($rows_tot_dua['jakredit']+$rows_tot_duajur['jakredit']) / $net3 * 100;
		$persen33 = ($rows_tot_satu['jakredit']+$rows_tot_satujur['jakredit']+$rows_tot_dua['jakredit']+$rows_tot_duajur['jakredit']) / $net5 * 100;
		
		$data1 = $rows_tot_satu['jakredit']+$rows_tot_satujur['jakredit'];
		$data2 = $rows_tot_dua['jakredit']+$rows_tot_duajur['jakredit'];
		$data3 = $rows_tot_satu['jakredit']+$rows_tot_satujur['jakredit']+$rows_tot_dua['jakredit']+$rows_tot_duajur['jakredit'];
		?>
        
        
    <tr class="isi">
    	<td></td>
    	<td colspan="3" class="ltext"><b>Total <? echo $rows_group['NAMA_GROUP']; ?></b></td>
		<td class="rtext"><? echo cFormat($rows_tot_satu['jakredit']+$rows_tot_satujur['jakredit'],false) ; ?></td>
		<td class="rtext"><? echo cPercent($persen31,false) ; ?></td>
        <td class="rtext"><? echo cFormat($rows_tot_dua['jakredit']+$rows_tot_duajur['jakredit'],false) ; ?></td>
		<td class="rtext"><? echo cPercent($persen32,false) ; ?></td>
        <td class="rtext"><? echo cFormat($rows_tot_satu['jakredit']+$rows_tot_satujur['jakredit']+$rows_tot_dua['jakredit']+$rows_tot_duajur['jakredit'],false) ; ?></td>
		<td class="rtext"><? echo cPercent($persen33,false) ; ?></td>
	</tr>
    <? 
	$total_data1 = $total_data1 + $data1;
	$total_data2 = $total_data2 + $data2;
	$total_data3 = $total_data3 + $data3;
	}
	
	$persen37 = $total_data1 / $net1 * 100;
	$persen38 = $total_data2 / $net3 * 100;
	$persen39 = $total_data3 / $net5 * 100;
	
	$lr1 = $net1 -($saldo_awal_barang+$rows_pembelian_pertama['pembelian']-$saldo_akhir_barang) - $total_data1;
	$lr2 = $net3 -($saldo_akhir_barang+$rows_pembelian_pertama2['pembelian']-$saldo_akhir_barang2) - $total_data2;
	$lr3 = $net5 -($saldo_awal_barang+$rows_pembelian_pertama['pembelian'] + $rows_pembelian_pertama2['pembelian'] -$saldo_akhir_barang2) - $total_data3;
	
	$persen40 = $lr1 / $net1 * 100;
	$persen41 = $lr2 / $net3 * 100;
	$persen42 = $lr3 / $net5 * 100;

    ?>
    <tr class="isi">
    	<td colspan="4"><b>Total Biaya Operasional</b></td>
		<td class="rtext"><? echo cFormat($total_data1,false) ; ?></td>
		<td class="rtext"><? echo cPercent($persen37,false) ; ?></td>
        <td class="rtext"><? echo cFormat($total_data2,false) ; ?></td>
		<td class="rtext"><? echo cPercent($persen38,false) ; ?></td>
        <td class="rtext"><? echo cFormat($total_data3,false) ; ?></td>
		<td class="rtext"><? echo cPercent($persen39,false) ; ?></td>
	</tr>
    <tr class="isi">
    	<td colspan="4"><b>Laba (Rugi) Operasional</b></td>
		<td class="rtext"><? echo cFormat($lr1,false) ; ?></td>
		<td class="rtext"><? echo cPercent($persen40,false) ; ?></td>
        <td class="rtext"><? echo cFormat($lr2,false) ; ?></td>
		<td class="rtext"><? echo cPercent($persen41,false) ; ?></td>
        <td class="rtext"><? echo cFormat($lr3,false) ; ?></td>
		<td class="rtext"><? echo cPercent($persen42,false) ; ?></td>
	</tr>
<?
}
?>
<?
$qry_kategori="select * from ak_kategori_perk WHERE ID_KATEGORI = '6'";
$rs_kategori=mysql_query($qry_kategori);
while($rowss_kategori=mysql_fetch_array($rs_kategori))
{
	$total_kategori='0';
?>
	<tr class="isi">
    	<td colspan="4" class="ltext"><b><? echo $rowss_kategori['NAMA_KATEGORI']; ?></b></td>
		<td></td>
		<td></td>
        <td></td>
		<td></td>
        <td></td>
		<td></td>
	</tr>
    <?
	$qry_group="select * from ak_group_perk where ID_KATEGORI_GROUP='". $rowss_kategori['ID_KATEGORI']."' ";
	$rs_group=mysql_query($qry_group);
	while($rowss_group=mysql_fetch_array($rs_group)){
	?>
    	<tr class="isi">
    	<td></td>
    	<td style="width: 38%; height:15px;" colspan="3" class="ltext"><b><? echo $rowss_group['NAMA_GROUP']; ?></b></td>
		<td></td>
		<td></td>
        <td></td>
		<td></td>
        <td></td>
		<td></td>
	</tr>
    
        <?
		$qry_subgroup="select * from ak_subgroup_perk where ID_GROUP_SUBGROUP='".$rowss_group['KODE_GROUP']."' ";
		$rs_subgroup=mysql_query($qry_subgroup);
		while($rowss_subgroup=mysql_fetch_array($rs_subgroup)){
			$rowss_satu = mysql_fetch_array(mysql_query("select SUM(KREDIT) AS jakredit from ak_kasbanks join ak_detail_perk ON (ak_kasbanks.PERK_KASBANK = ak_detail_perk.ID_DETAIL) WHERE  ak_detail_perk.ID_SUBGROUP_DETAIL = '".$rowss_subgroup['KODE_SUBGROUP']."' AND ak_kasbanks.UNIT_KODE = '".$unit."' AND ak_kasbanks.TANGGAL between '".$tgl_resaldo_awal."' and '".$tgl_sld_akhir."'"));
			$rowss_satujur = mysql_fetch_array(mysql_query("select SUM(KREDIT) AS jakredit from ak_jurnal join ak_detail_perk ON (ak_jurnal.PERK_KREDIT = ak_detail_perk.ID_DETAIL) WHERE  ak_detail_perk.ID_SUBGROUP_DETAIL = '".$rowss_subgroup['KODE_SUBGROUP']."' AND ak_jurnal.UNIT_KODE = '".$unit."' AND ak_jurnal.TANGGAL_TRANS between '".$tgl_resaldo_awal."' and '".$tgl_sld_akhir."'"));
			
			$rowss_dua = mysql_fetch_array(mysql_query("select SUM(KREDIT) AS jakredit from ak_kasbanks join ak_detail_perk ON (ak_kasbanks.PERK_KASBANK = ak_detail_perk.ID_DETAIL) WHERE  ak_detail_perk.ID_SUBGROUP_DETAIL = '".$rowss_subgroup['KODE_SUBGROUP']."' AND ak_kasbanks.UNIT_KODE = '".$unit."' AND ak_kasbanks.TANGGAL between '".$tgl_awal."' and '".$tgl_akhir."'"));
			$rowss_duajur = mysql_fetch_array(mysql_query("select SUM(KREDIT) AS jakredit from ak_jurnal join ak_detail_perk ON (ak_jurnal.PERK_KREDIT = ak_detail_perk.ID_DETAIL) WHERE  ak_detail_perk.ID_SUBGROUP_DETAIL = '".$rowss_subgroup['KODE_SUBGROUP']."' AND ak_jurnal.UNIT_KODE = '".$unit."' AND ak_jurnal.TANGGAL_TRANS between '".$tgl_awal."' and '".$tgl_akhir."'"));
			
		$persen43 = ($rowss_satu['jakredit']+$rowss_satujur['jakredit']) / $net1 * 100;
		$persen44 = ($rowss_dua['jakredit']+$rowss_duajur['jakredit']) / $net3 * 100;
		$persen45 = ($rowss_satu['jakredit']+$rowss_satujur['jakredit']+$rowss_dua['jakredit']+$rowss_duajur['jakredit']) / $net5 * 100;
		
		?>
        <? if($rowss_subgroup['ID_GROUP_SUBGROUP'] == '61') { ?>
		<tr class="isi">
        <td colspan="2" class="rtext">-</td>
        <td colspan="2" class="ltext"><? echo $rowss_subgroup['NAMA_SUBGROUP']; ?></td>
        <td class="rtext"><? echo cFormat($rowss_satu['jakredit']+$rowss_satujur['jakredit'],false) ; ?></td>
        <td class="rtext"><? echo cPercent($persen43,false) ; ?></td>
        <td class="rtext"><? echo cFormat($rowss_dua['jakredit']+$rowss_duajur['jakredit'],false) ; ?></td>
        <td class="rtext"><? echo cPercent($persen44,false) ; ?></td>
        <td class="rtext"><? echo cFormat($rowss_satu['jakredit']+$rowss_satujur['jakredit']+$rowss_dua['jakredit']+$rowss_duajur['jakredit'],false) ; ?></td>
        <td class="rtext"><? echo cPercent($persen45,false) ; ?></td>
        </tr>
        <? } ?>
        <? if($rowss_subgroup['ID_GROUP_SUBGROUP'] == '62') { ?>
		<tr class="isi">
        <td colspan="2" class="rtext">-</td>
        <td colspan="2" class="ltext"><? echo $rowss_subgroup['NAMA_SUBGROUP']; ?></td>
        <td class="rtext"><? echo cFormat(-($rowss_satu['jakredit']+$rowss_satujur['jakredit']),false) ; ?></td>
        <td class="rtext"><? echo cPercent(-($persen43),false) ; ?></td>
        <td class="rtext"><? echo cFormat(-($rowss_dua['jakredit']+$rowss_duajur['jakredit']),false) ; ?></td>
        <td class="rtext"><? echo cPercent(-($persen44),false) ; ?></td>
        <td class="rtext"><? echo cFormat(-($rowss_satu['jakredit']+$rowss_satujur['jakredit']+$rowss_dua['jakredit']+$rowss_duajur['jakredit']),false) ; ?></td>
        <td class="rtext"><? echo cPercent(-($persen45),false) ; ?></td>
        </tr>
        <? } 
        
        
		
		}
		$rowss_tot_satu = mysql_fetch_array(mysql_query("select SUM(KREDIT) AS jakredit from ak_kasbanks join ak_detail_perk ON (ak_kasbanks.PERK_KASBANK = ak_detail_perk.ID_DETAIL) JOIN ak_subgroup_perk ON  (ak_detail_perk.ID_SUBGROUP_DETAIL = ak_subgroup_perk.KODE_SUBGROUP) WHERE  ak_subgroup_perk.ID_GROUP_SUBGROUP = '".$rowss_group['KODE_GROUP']."' AND ak_kasbanks.UNIT_KODE = '".$unit."' AND ak_kasbanks.TANGGAL between '".$tgl_resaldo_awal."' and '".$tgl_sld_akhir."'"));
		
		$rowss_tot_satujur = mysql_fetch_array(mysql_query("select SUM(KREDIT) AS jakredit from ak_jurnal join ak_detail_perk ON (ak_jurnal.PERK_KREDIT = ak_detail_perk.ID_DETAIL) JOIN ak_subgroup_perk ON  (ak_detail_perk.ID_SUBGROUP_DETAIL = ak_subgroup_perk.KODE_SUBGROUP) WHERE  ak_subgroup_perk.ID_GROUP_SUBGROUP = '".$rowss_group['KODE_GROUP']."' AND ak_jurnal.UNIT_KODE = '".$unit."' AND ak_jurnal.TANGGAL_TRANS between '".$tgl_resaldo_awal."' and '".$tgl_sld_akhir."'"));
			
		$rowss_tot_dua = mysql_fetch_array(mysql_query("select SUM(KREDIT) AS jakredit from ak_kasbanks join ak_detail_perk ON (ak_kasbanks.PERK_KASBANK = ak_detail_perk.ID_DETAIL) JOIN ak_subgroup_perk ON  (ak_detail_perk.ID_SUBGROUP_DETAIL = ak_subgroup_perk.KODE_SUBGROUP) WHERE  ak_subgroup_perk.ID_GROUP_SUBGROUP = '".$rowss_group['KODE_GROUP']."' AND ak_kasbanks.UNIT_KODE = '".$unit."' AND ak_kasbanks.TANGGAL between '".$tgl_awal."' and '".$tgl_akhir."'"));
		$rowss_tot_duajur = mysql_fetch_array(mysql_query("select SUM(KREDIT) AS jakredit from ak_jurnal join ak_detail_perk ON (ak_jurnal.PERK_KREDIT = ak_detail_perk.ID_DETAIL) JOIN ak_subgroup_perk ON  (ak_detail_perk.ID_SUBGROUP_DETAIL = ak_subgroup_perk.KODE_SUBGROUP) WHERE  ak_subgroup_perk.ID_GROUP_SUBGROUP = '".$rowss_group['KODE_GROUP']."' AND ak_jurnal.UNIT_KODE = '".$unit."' AND ak_jurnal.TANGGAL_TRANS between '".$tgl_awal."' and '".$tgl_akhir."'"));
		
		$persen46 = ($rowss_tot_satu['jakredit']+$rowss_tot_satujur['jakredit']) / $net1 * 100;
		$persen47 = ($rowss_tot_dua['jakredit']+$rowss_tot_duajur['jakredit']) / $net3 * 100;
		$persen48 = ($rowss_tot_satu['jakredit']+$rowss_tot_satujur['jakredit']+$rowss_tot_dua['jakredit']+$rowss_tot_duajur['jakredit']) / $net5 * 100;
		
		$datas1 = $rowss_tot_satu['jakredit']+$rowss_tot_satujur['jakredit'];
		$datas2 = $rowss_tot_dua['jakredit']+$rowss_tot_duajur['jakredit'];
		$datas3 = $rowss_tot_satu['jakredit']+$rowss_tot_satujur['jakredit']+$rowss_tot_dua['jakredit']+$rowss_tot_duajur['jakredit'];
		?>
        
       <? if($rowss_group['KODE_GROUP'] == '61') { ?> 
    <tr class="isi">
    	<td></td>
    	<td colspan="3" class="ltext"><b>Total <? echo $rowss_group['NAMA_GROUP']; ?></b></td>
		<td class="rtext"><? echo cFormat($rowss_tot_satu['jakredit']+$rowss_tot_satujur['jakredit'],false) ; ?></td>
		<td class="rtext"><? echo cPercent($persen46,false) ; ?></td>
        <td class="rtext"><? echo cFormat($rowss_tot_dua['jakredit']+$rowss_tot_duajur['jakredit'],false) ; ?></td>
		<td class="rtext"><? echo cPercent($persen47,false) ; ?></td>
        <td class="rtext"><? echo cFormat($rowss_tot_satu['jakredit']+$rowss_tot_satujur['jakredit']+$rowss_tot_dua['jakredit']+$rowss_tot_duajur['jakredit'],false) ; ?></td>
		<td class="rtext"><? echo cPercent($persen48,false) ; ?></td>
	</tr>
    	<? 
		$total_datas1 = $total_datas1 + $datas1;
		$total_datas2 = $total_datas2 + $datas2;
		$total_datas3 = $total_datas3 + $datas3;
		
		} ?>
        <? if($rowss_group['KODE_GROUP'] == '62') { ?>
        <tr class="isi">
    	<td></td>
    	<td colspan="3" class="ltext"><b>Total <? echo $rowss_group['NAMA_GROUP']; ?></b></td>
		<td class="rtext"><? echo cFormat(-($rowss_tot_satu['jakredit']+$rowss_tot_satujur['jakredit']),false) ; ?></td>
		<td class="rtext"><? echo cPercent(-$persen46,false) ; ?></td>
        <td class="rtext"><? echo cFormat(-($rowss_tot_dua['jakredit']+$rowss_tot_duajur['jakredit']),false) ; ?></td>
		<td class="rtext"><? echo cPercent(-$persen47,false) ; ?></td>
        <td class="rtext"><? echo cFormat(-($rowss_tot_satu['jakredit']+$rowss_tot_satujur['jakredit']+$rowss_tot_dua['jakredit']+$rowss_tot_duajur['jakredit']),false) ; ?></td>
		<td class="rtext"><? echo cPercent(-$persen48,false) ; ?></td>
	</tr>
    	<? 
		$total_datas1 = $total_datas1 - $datas1;
		$total_datas2 = $total_datas2 - $datas2;
		$total_datas3 = $total_datas3 - $datas3;
		} ?>
    <? 
	}
	
	$persen48 = $total_datas1 / $net1 * 100;
	$persen49 = $total_datas2 / $net3 * 100;
	$persen50 = $total_datas3 / $net5 * 100;
	
	$lrs1 = $lr1 - $total_datas1;
	$lrs2 = $lr2 - $total_datas2;
	$lrs3 = $lr3 - $total_datas3;
	
	$persen40 = $lr1 / $net1 * 100;
	$persen41 = $lr2 / $net3 * 100;
	$persen42 = $lr3 / $net5 * 100;

    ?>
    <tr class="isi">
    	<td colspan="4"><b>TOTAL PENDAPATAN (BEBAN) LAIN</b></td>
		<td class="rtext"><? echo cFormat($total_datas1,false) ; ?></td>
		<td class="rtext"><? echo cPercent($persen48,false) ; ?></td>
        <td class="rtext"><? echo cFormat($total_datas2,false) ; ?></td>
		<td class="rtext"><? echo cPercent($persen49,false) ; ?></td>
        <td class="rtext"><? echo cFormat($total_datas3,false) ; ?></td>
		<td class="rtext"><? echo cPercent($persen50,false) ; ?></td>
	</tr>
    <tr class="isi">
    	<td colspan="4"><b>LABA BERSIH SEBELUM PAJAK</b></td>
		<td class="rtext"><? echo cFormat($lr1,false) ; ?></td>
		<td class="rtext"><? echo cPercent($persen40,false) ; ?></td>
        <td class="rtext"><? echo cFormat($lr2,false) ; ?></td>
		<td class="rtext"><? echo cPercent($persen41,false) ; ?></td>
        <td class="rtext"><? echo cFormat($lr3,false) ; ?></td>
		<td class="rtext"><? echo cPercent($persen42,false) ; ?></td>
	</tr>
<?
}
?>
</table>
<?
}
?>
