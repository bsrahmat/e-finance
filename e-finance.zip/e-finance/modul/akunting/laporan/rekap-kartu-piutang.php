<?php

require_once '../../../library/connectionmysql.php';
Connected();
if($_SESSION['galaxy_posisi']=='none' || !isset($_SESSION['galaxy_posisi'])) { header("Location: ../../index.php"); die; }
if($_SESSION['galaxy_unit']=='none' || !isset($_SESSION['galaxy_unit'])) { header("Location: ../../index.php"); die; }
$perm = array();
$perm = getPermissions('51');
if($perm[-1]=='1') { require_once '../../library/error-popup.php'; die; }
$error = array();
if(!$_POST['unit']) $error[] = 'unit:Silahkan Pilih Unit.';
if(!$_POST['tgl-awal']) $error[] = 'tgl-awal:Silahkan masukkan Tanggal Awal.';
if(!$_POST['tgl-akhir']) $error[] = 'tgl-akhir:Silahkan Pilih Tanggal Akhir.';

if(count($error)>0) {
	//tampilkan pesan error, jika ada error.. :D
	echo generateError($error).'|*|';	
	
	
} else {
$unit=$_POST['unit'];
$tgl_awal = cDateR($_POST['tgl-awal']);
$tgl_akhir = cDateR($_POST['tgl-akhir']);
$qry_cus= "select distinct(CUSTOMER_ID) from ak_piut where TANGGAL between '".$tgl_awal."' and '".$tgl_akhir."' and UNIT_ID='".$unit."' order by CUSTOMER_ID DESC";
$rs_cus = mysql_query($qry_cus);

$rows_units=mysql_fetch_array(mysql_query("select * from units where id = '".$unit."';"));
if($rows_units['logo'] == '') 
{
	$rows_units['logo'] = 'none.jpg';
}
header("Content-type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=Rekap-Piutang-".$rows_units['code']."-".date('m-Y').".xls");
?>

<table class="ctable-skpd" style="width: 100%;">
	<tr class="isi">
		<td style="width: 100%; text-align:center; font-size: 18px;" colspan="5"><a href="modul/laporan/capture.php?target=<? echo md5('rekap-piutang') ?>&unit=<? echo $_POST['unit']?>&tgl_awal=<? echo $_POST['tgl-awal']?>&tgl_akhir=<? echo $_POST['tgl-akhir']?>" target="_blank" title="Cetak PDF" class="cCetakpdf"></a></td>
	</tr>
	<tr class="isi">
		<td style="width: 100%; text-align:center; font-size: 18px;" colspan="5">REKAP KARTU PIUTANG</td>
	</tr>
    <tr class="isi">
		<td style="width: 100%; text-align:center;  font-size: 14px;" colspan="5">Periode : <? echo cDate2($tgl_awal) ?> s/d <? echo cDate2($tgl_akhir) ?></td>
	</tr>
       
</table>
<table class="ctable-skpd" border="0.3" cellspacing="0" style="width: 100%; border-color:#903; border:thin;">
            	<tr style="background: #efefef;font-weight: bold; text-align:center;">
                    <td style="width: 5%; height:15px;">No</td>
                    <td style="width: 35%;">Customer</td>
                    <td style="width: 20%;">Debet</td>
                    <td style="width: 20%;">Kredit</td>
                    <td style="width: 20%;">Sisa</td>
               	</tr>
                <?php
				$no= 1;
				while($rows_cus=mysql_fetch_array($rs_cus)) 
				{
					$qry_customer="select name from customers where id='".$rows_cus['CUSTOMER_ID']."' ";
					$row_customer=mysql_fetch_array(mysql_query($qry_customer));
					
					$qry_piut="select sum(DEBET) as dbt, sum(KREDIT) as krd from ak_piut where CUSTOMER_ID='".$rows_cus['CUSTOMER_ID']."' and  TANGGAL between '".$tgl_awal."' and '".$tgl_akhir."' and UNIT_ID='".$unit."' ";
					$row_piut=mysql_fetch_array(mysql_query($qry_piut));
					
					$sisa=$row_piut['krd']-$row_piut['dbt'];
				?>
					<tr class="isi">
						<td align="center"><? echo $no?></td>
                        <td class="ltext"><? echo $row_customer['name'] ?></td>
						<td align="right"><? echo cFormat($row_piut['dbt'],false) ?></td>
                        <td align="right"><? echo cFormat($row_piut['krd'],false) ?></td>
						<td align="right"><? echo cFormat($sisa,false) ?></td>
					</tr>
                <?
					$no++;
				}
				?>
        	</table>
        
<? } ?>
      
   