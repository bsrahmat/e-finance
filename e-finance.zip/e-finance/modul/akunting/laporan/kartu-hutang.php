<?php

require_once '../../../library/connectionmysql.php';
Connected();
if($_SESSION['galaxy_posisi']=='none' || !isset($_SESSION['galaxy_posisi'])) { header("Location: ../../index.php"); die; }
if($_SESSION['galaxy_unit']=='none' || !isset($_SESSION['galaxy_unit'])) { header("Location: ../../index.php"); die; }
$perm = array();
$perm = getPermissions('51');
if($perm[-1]=='1') { require_once '../../library/error-popup.php'; die; }
$error = array();
if(!$_POST['unit']) $error[] = 'unit:Silahkan masukkan Unit.';
if(!$_POST['supplier']) $error[] = 'supplier:Silahkan Pilih Supplier.';
if(!$_POST['tgl-awal']) $error[] = 'tgl-awal:Silahkan masukkan tanggal Awal.';
if(!$_POST['tgl-akhir']) $error[] = 'tgl-akhir:Silahkan masukkan tanggal akhir.';

if(count($error)>0) {
	//tampilkan pesan error, jika ada error.. :D
	echo generateError($error).'|*|';	
	
	
} else {
	
	$unit= $_POST['unit'];
	$supplier= $_POST['supplier'];
	$tgl_awal = cDateR($_POST['tgl-awal']);
	$tgl_akhir = cDateR($_POST['tgl-akhir']);

$t=explode('-',$tgl_awal);

$tgl= date("d F Y", mktime(0,0,0,date($t[1]),date($t[2])-1,date($t[0]))); 
$bulan=array(1=>'January', 2=>'February', 3=>'March', 4=>'April', 5=>'May', 6=>'June', 7=>'July', 8=>'August', 9=>'September', 10=>'October', 11=>'November', 12=>'December');
$t2=explode(' ',$tgl);
for ($i=1; $i <= 12; $i++)
{
	if($bulan[$i]==$t2[1]) { $bln="0".$i; }
}
$saldo_tanggal2=$t2[2].'-'.$bln.'-'.$t2[0];
$saldo_tanggal='2011-6-30';



$tgl="TANGGAL between '".$tgl_awal."' and '".$tgl_akhir."' ";
$tgl_saldo="TANGGAL between '".$saldo_tanggal."' and '".$saldo_tanggal2."'";



$rows_units=mysql_fetch_array(mysql_query("select * from units where id = '".$unit."';"));
if($rows_units['logo'] == '') 
{
	$rows_units['logo'] = 'none.jpg';
} 
header("Content-type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=Kartu-Hutang-".$rows_units['code']."-".date('m-Y').".xls");
?>

<table class="ctable-skpd" style="width: 100%;">
	<tr class="isi">
		<td style="width: 100%; text-align:center; font-size: 18px;" colspan="8"><a href="modul/laporan/capture.php?target=<? echo md5('kartu-hutang') ?>&unit=<? echo $_POST['unit']?>&supplier=<? echo $_POST['supplier']?>&tgl_awal=<? echo $_POST['tgl-awal']?>&tgl_akhir=<? echo $_POST['tgl-akhir']?>" target="_blank" title="Cetak PDF" class="cCetakpdf"></a></td>
	</tr>
    <tr class="isi">
		<td style="width: 100%; text-align:center; font-size: 18px;" colspan="8">KARTU HUTANG</td>
	</tr>
    <tr class="isi">
    <?
		$qry_Supplier = "select * from suppliers where id='".$supplier."';";
		$rows_Supplier=mysql_fetch_array(mysql_query($qry_Supplier));
    ?>
		<td style="width: 100%; text-align:center;  font-size: 14px;" colspan="8">SUPPLIER : <? echo $rows_Supplier['name'] ?></td>
	</tr>
    <tr class="isi">
		<td style="width: 100%; text-align:center;  font-size: 14px;" colspan="8">Periode : <? echo cDate2($tgl_awal) ?> s/d <? echo cDate2($tgl_akhir) ?></td>
	</tr>  
       
</table>

        	<table class="ctable-skpd" border="0.3" cellspacing="0" style="width: 100%; border-color:#903; border:thin;">
            	<tr style="background: #efefef;font-weight: bold; text-align:center;">
                    <td style="width: 4%; height:15px;">No</td>
                    <td style="width: 8%;">Tanggal</td>
                    <td style="width: 17%;">No. LPB</td>
                    <td style="width: 17%;">No. Retur</td>
                    <td style="width: 18%;">No. PK</td>
                    <td style="width: 12%;">Debet</td>
                    <td style="width: 12%;">Kredit</td>
                    <td style="width: 12%;">Saldo</td>
               	</tr>
                <?
				$saldo_debet='0';
				$saldo_kredit='0';
                $qry_saldo="SELECT * FROM ak_htg WHERE UNIT_ID='".$unit."' and SUPPLIER_ID = '".$supplier."' and ".$tgl_saldo."order by ID ASC";
				$rs_saldo=mysql_query($qry_saldo);
				while($rows_saldo=mysql_fetch_array($rs_saldo)) 
				{
					$saldo_debet=$saldo_debet+$rows_saldo['DEBET'];
					$saldo_kredit=$saldo_kredit+$rows_saldo['KREDIT'];
				}
				$total_saldo=$saldo_kredit-$saldo_debet;
				?>
                <tr  class="isi">
                    <td></td>
                    <td><? echo cDate2($saldo_tanggal2) ?></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td align="right"><? echo cFormat($total_saldo,false) ?></td>
               	</tr>
                <?php
				$no= 1;
				$total_saldo='0';
				$qry_trrgoods="select * from ak_htg where UNIT_ID='".$unit."' and SUPPLIER_ID='".$supplier."' and ".$tgl."order by ID ASC";
				$rs_trrgoods = mysql_query($qry_trrgoods);
				while($rows_trrgoods=mysql_fetch_array($rs_trrgoods)) 
				{
	                $qry_rg="select rgnom from trrgoods where id='".$rows_trrgoods['TRRGOOD_ID']."'";
					$row_rg=mysql_fetch_array(mysql_query($qry_rg));
					
					$qry_retur="select retnom from breturs where id='".$rows_trrgoods['BRETUR_ID']."'";
					$row_retur=mysql_fetch_array(mysql_query($qry_retur));
					
					$qry_kasbank="select NO_BUKTI from ak_kasbank where ID='".$rows_trrgoods['KASBANK_ID']."' ";
					$row_kasbank=mysql_fetch_array(mysql_query($qry_kasbank));
					
					$qry_wd="select wends.wenom, worders.wonom from wends LEFT JOIN worders ON (wends.worder_id=worders.id) where wends.id='".$rows_trrgoods['WEND_ID']."' ";
					$row_wd=mysql_fetch_array(mysql_query($qry_wd));
					
					$total_saldo=$total_saldo+$rows_trrgoods['DEBET']-$rows_trrgoods['KREDIT'];
				?>
					<tr class="isi">
						<td align="center"><? echo $no?></td>
						<td><? echo cDate2($rows_trrgoods['TANGGAL']) ?></td>
						<td><? echo $row_rg['rgnom'] ?></td>
						<td><? echo $row_retur['retnom'] ?></td>
						<td><? echo $row_wd['wenom'] ?></td>
						<td align="right"><? echo cFormat($rows_trrgoods['DEBET'],false) ?></td>
                        <td align="right"><? echo cFormat($rows_trrgoods['KREDIT'],false) ?></td>
						<td align="right"><? echo cFormat($total_saldo,false) ?></td>
					</tr>
                <?
					$no++;
				}
				?>
        	</table>
        
 
<? } ?>
      
   