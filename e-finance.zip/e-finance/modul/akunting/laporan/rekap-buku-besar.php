<?php
require_once '../../../library/connectionmysql.php';
Connected();
if($_SESSION['galaxy_posisi']=='none' || !isset($_SESSION['galaxy_posisi'])) { header("Location: ../../index.php"); die; }
if($_SESSION['galaxy_unit']=='none' || !isset($_SESSION['galaxy_unit'])) { header("Location: ../../index.php"); die; }
$perm = array();
$perm = getPermissions('51');
if($perm[-1]=='1') { require_once '../../library/error-popup.php'; die; }
$error = array();
if(!$_POST['unit']) $error[] = 'unit:Silahkan masukkan Unit.';
if(!$_POST['tgl-awal']) $error[] = 'tgl-awal:Silahkan masukkan tanggal Awal.';
if(!$_POST['tgl-akhir']) $error[] = 'tgl-akhir:Silahkan masukkan tanggal akhir.';

if(count($error)>0) {
	//tampilkan pesan error, jika ada error.. :D
	echo generateError($error).'|*|';	
	
	
} else {

$unit=$_POST['unit'];
$tgl_awal= cDateR($_POST['tgl-awal']);
$tgl_akhir=  cDateR($_POST['tgl-akhir']);


$t=explode('-',$tgl_awal);

$tgl= date("d F Y", mktime(0,0,0,date($t[1]),date($t[2])-1,date($t[0]))); 
$bulan=array(1=>'January', 2=>'February', 3=>'March', 4=>'April', 5=>'May', 6=>'June', 7=>'July', 8=>'August', 9=>'September', 10=>'October', 11=>'November', 12=>'December');
$t2=explode(' ',$tgl);
for ($i=1; $i <= 12; $i++)
{
	if($bulan[$i]==$t2[1]) { $bln="0".$i; }
}
$tgl_awal2=$t2[2].'-'.$bln.'-'.$t2[0];


$rows_units=mysql_fetch_array(mysql_query("select * from units where id = '".$unit."';"));
if($rows_units['logo'] == '') 
{
	$rows_units['logo'] = 'none.jpg';
}
header("Content-type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=Rekap-Buku-Besar-".$rows_units['code']."-".date('m-Y').".xls");
?>



<table class="ctable-skpd" style="width: 100%;">
    <tr class="isi">
		<td style="width: 100%; text-align:center; font-size: 18px;" colspan="6"><a href="modul/laporan/capture.php?target=<? echo md5('rekap-buku-besar') ?>&unit=<? echo $_POST['unit']?>&tgl_awal=<? echo $_POST['tgl-awal']?>&tgl_akhir=<? echo $_POST['tgl-akhir']?>" target="_blank" title="Cetak PDF" class="cCetakpdf"></a></td>
	</tr>
    <tr class="isi">
		<td style="width: 100%; text-align:center; font-size: 18px;" colspan="6">REKAP BUKU BESAR</td>
	</tr>
    <tr class="isi">
		<td style="width: 100%; text-align:center;  font-size: 14px;" colspan="6">Periode : <? echo cDate2($tgl_awal) ?> s/d <? echo cDate2($tgl_akhir) ?></td>
	</tr>
</table>


<table class="ctable-skpd" border="0.3" cellspacing="0" style="width: 100%; border-color:#903; border:thin;">
            	<tr style="text-align:center; font-size:12px; background:#CCC;">
                    <td align="left" style="width: 12%;">Kd. Perk.</td>
                    <td align="left" style="width: 32%;">Nama Perk.</td>
                    <td align="right" style="width: 14%;">Sld. Awal</td>
                    <td align="right" style="width: 14%;">Debet</td>
                    <td align="right" style="width: 14%;">Kredit</td>
                    <td align="right" style="width: 14%;">Sld. Akhir</td>
               	</tr>
              
       

<?php
$total_sld_awal='0';
$total_dbt='0';
$total_krd='0';
$total_sld_akhir='0';

$qry_perk="select * from ak_detail_perk ";
$rs_perk=mysql_query($qry_perk);
while($rows_perk=mysql_fetch_array($rs_perk)) 
{
	$saldo_awal=0;
	$cek3=0;
	$qry_saldo="select * from ak_saldo_awal where ID_UNIT= '".$unit."' and ID_DETAIL='".$rows_perk['ID_DETAIL']."'";
	$rs_saldo=mysql_query($qry_saldo);
	while($rows_saldo=mysql_fetch_array($rs_saldo)) 
	{
		$saldo_awal=$rows_saldo['JUMLAH'];
		$cek3++;
	}
	$qry_saldo_awal="select * from ak_kasbank where UNIT_KODE= '".$unit."' and PERK_KASBANK='".$rows_perk['ID_DETAIL']."' and TANGGAL between '2011-6-30' and '".$tgl_awal2."' ";
	$rs_saldo_awal=mysql_query($qry_saldo_awal);
	while($rows_saldo_awal=mysql_fetch_array($rs_saldo_awal)) 
	{
		$qry_detail_saldo="select * from ak_detail_kasbank where UNIT_KODE= '".$unit."' and KASBANK_ID='".$rows_saldo_awal['ID']."'";
		$rs_detail_saldo=mysql_query($qry_detail_saldo);
		while($rows_detail_saldo=mysql_fetch_array($rs_detail_saldo)) 
		{
			$saldo_awal=$saldo_awal+$rows_detail_saldo['DEBET']-$rows_detail_saldo['KREDIT'];
			$cek3++;
		}
	}
	$qry_saldo_awal2="select * from  ak_detail_kasbank where PERK_LAWAN = '".$rows_perk['ID_DETAIL']."' and UNIT_KODE= '".$unit."' ;";
	$rs_saldo_awal2=mysql_query($qry_saldo_awal2);
	while($rows_saldo_awal2=mysql_fetch_array($rs_saldo_awal2))
	{
		$qry_saldo3="select * from ak_kasbank where ID='".$rows_saldo_awal2['KASBANK_ID']."' and TANGGAL between '2011-06-30' and '".$tgl_awal2."' and UNIT_KODE= '".$unit."' ";
		$rs_saldo3 = mysql_query($qry_saldo3);
		while($rows_saldo3=mysql_fetch_array($rs_saldo3)) 
		{
			$saldo_awal=$saldo_awal-$rows_saldo_awal2['DEBET']+$rows_saldo_awal2['KREDIT'];
			$cek3++;
		}
	}
		

	$dbt='0';
	$krd='0';
	$saldo_akhir='0';
		
	$cek1=0;
	$qry_kasbank="select * from ak_kasbank where UNIT_KODE= '".$unit."' and PERK_KASBANK='".$rows_perk['ID_DETAIL']."' and TANGGAL between '".$tgl_awal."' and '".$tgl_akhir."' ";
	$rs_kasbank=mysql_query($qry_kasbank);
	while($rows_kasbank=mysql_fetch_array($rs_kasbank)) 
	{
		$qry_detail="select * from ak_detail_kasbank where UNIT_KODE= '".$unit."' and KASBANK_ID='".$rows_kasbank['ID']."'";
		$rs_detail=mysql_query($qry_detail);
		while($rows_detail=mysql_fetch_array($rs_detail)) 
		{
			$dbt=$dbt+$rows_detail['DEBET'];
			$krd=$krd+$rows_detail['KREDIT'];
		}
		$saldo_akhir=$saldo_awal+$dbt-$krd;
		$cek1++;
	}
		
	$cek2=0;
	$qry_detailB = "select * from  ak_detail_kasbank where PERK_LAWAN = '".$rows_perk['ID_DETAIL']."' and UNIT_KODE= '".$unit."' ;";
	$rs_detailB = mysql_query($qry_detailB);
	while($rows_detailB=mysql_fetch_array($rs_detailB))
	{
		$qry_bbB="select * from ak_kasbank where ID='".$rows_detailB['KASBANK_ID']."' and TANGGAL between '".$tgl_awal."' and '".$tgl_akhir."' and UNIT_KODE= '".$unit."' ";
		$rs_bbB = mysql_query($qry_bbB);
		while($rows_bbB=mysql_fetch_array($rs_bbB)) 
		{
			$dbt=$dbt+$rows_detailB['KREDIT'];
			$krd=$krd+$rows_detailB['DEBET'];
			
			$cek2++;
		}
		$saldo_akhir=$saldo_awal+$dbt-$krd;
		
	}
	if($cek1==0 && $cek2==0)
	{
		$saldo_akhir=$saldo_awal;
	}
	if($cek1!=0 || $cek2!=0 || $cek3!=0)
	{
	?>
	
	
		<tr class="isi">
		<?
		$qry_nm="select * from ak_detail_perk where ID_DETAIL='".$rows_perk['ID_DETAIL']."'";
		$rows_nm=mysql_fetch_array(mysql_query($qry_nm));
		?>
		<td align="left" style="width: 12%;"><? echo $rows_nm['KODE_DETAIL']?></td>
		<td align="left" style="width: 32%;"><? echo $rows_nm['NAMA_DETAIL']?></td>
		<td align="right" style="width: 14%;"><? echo cFormat($saldo_awal,false) ?></td>
		<td align="right" style="width: 14%;"><? echo cFormat($dbt,false) ?></td>
		<td align="right" style="width: 14%;"><? echo cFormat($krd,false) ?></td>
		<td align="right" style="width: 14%;"><? echo cFormat($saldo_akhir,false) ?></td>
		</tr>

	  
<?
	}
	$total_sld_awal=$total_sld_awal+$saldo_awal;
	$total_dbt=$total_dbt+$dbt; 
	$total_krd=$total_krd+$krd;
	$total_sld_akhir=$total_sld_akhir+$saldo_akhir;
}
		
?>					
        <tr class="isi">
            <td style="width: 12%;"></td>
            <td align="center" style="width: 32%;">Total</td>
            <td align="right" style="width: 14%;"><? echo cFormat($total_sld_awal,false) ?></td>
            <td align="right" style="width: 14%;"><? echo cFormat($total_dbt,false) ?></td>
            <td align="right" style="width: 14%;"><? echo cFormat($total_krd,false) ?></td>
            <td align="right" style="width: 14%;"><? echo cFormat($total_sld_akhir,false) ?></td>
        </tr>
      </table>
	
<?
}
?>		    