<?php
	require_once '../../library/connectionmysql.php';
	Connected();
	
	$perm = array();
	$perm = getPermissions('22');
	if($perm[-1]=='1') { require_once '../../library/error-popup.php'; die; }
			
?>

<?
 if(isAdd()) {
	 $rs_trrgoods = mysql_query("SELECT * FROM trrgoods  WHERE trrgoods.id = '".$_GET['gid']."'");
	$rows_trrgoods=mysql_fetch_array($rs_trrgoods);
 ?>
 
   <div class="popup-shadow" style="width: 600px;">
      <div class="popup-header">
         <span>Close LPB</span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <form action="modul/akunting/update-lpb.php" method="post">
      <table>
      <tr>
      <td class="center">Transaksi dengan No LPB : <b style="text-decoration: underline;"><? echo $rows_trrgoods['rgnom'] ?></b> Akan di Tutup?</td>
      </tr>
      
      </table>
      <input type="hidden" name="gid" value="<? echo $_GET['gid'] ?>" />
      <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
      <input type="hidden" name="trporder_id" value="<? echo $rows_trrgoods['trporder_id'] ?>" />
      <input type="hidden" name="rgnom" value="<? echo $rows_trrgoods['rgnom'] ?>" />
      <input type="hidden" name="warehouse_id" value="<? echo $rows_trrgoods['warehouse_id'] ?>" />
      <input type="hidden" name="fakturnom" value="<? echo $rows_trrgoods['fakturnom'] ?>" />
      <input type="hidden" name="unitid" value="<? echo $rows_trrgoods['unitid'] ?>" />
      
      </form>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel">Batal</div>
      	<div mode="6" link="library/submenu/akunting/update-lpb" class="popup-button" get="">Simpan</div>
      </div>
   </div>

<? }  ?>


<?
//<!-- FORM TIPE MODE 0 = TAMBAH/ADD, TIPE MODE 1 = UBAH/EDIT -->
 if(isEdit()) {
	 $rs_trrgoods = mysql_query("SELECT * FROM trrgoods LEFT JOIN trporders ON (trrgoods.trporder_id = trporders.id) LEFT JOIN suppliers ON (trporders.supplier_id = suppliers.id)  WHERE trrgoods.id = '".$_GET['gid']."'");
	$rows_trrgoods=mysql_fetch_array($rs_trrgoods);
	$rs_units = mysql_query("select * from units where id = '".$_SESSION['galaxy_unit']."'");
	 $rows_units=mysql_fetch_array($rs_units);
	 $rgnom = IDTransLPB($rows_units['code']);
	 
 ?>
 
   <div class="popup-shadow" style="width: 600px;">
      <div class="popup-header">
         <span>ACC_Edit Laporan Penerimaan Barang (Bag. Purchasing)</span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <form action="modul/akunting/update-lpb.php" method="post">
      <table>
      <tr>
      <td width="27%">No. LPB</td>
      <td width="5%" align="center">:</td>
      <td><input class="input-text" name="prnom-disable" type="text" value="<? echo $rows_trrgoods['rgnom'] ?>"  disabled="disabled"></td>
      </tr>
      <tr>
      <td>No. PO</td>
      <td align="center">:</td>
      <td><input class="input-text" name="prnom-disable" type="text" value="<? echo $rows_trrgoods['ponom'] ?>"  disabled="disabled"></td>
      </tr>
      
      <tr>
      <td>Tanggal</td>
      <td align="center">:</td>
      <td><input class="input-text input-small" disabled="disabled" name="rgdate" value="<?  echo cDate($rows_trrgoods['rgdate']) ?>" /></td>
      </tr>
      <tr>
      <td>Keterangan</td>
      <td align="center">:</td>
      <td><textarea rows="3" class="input-text" name="description" type="text" disabled="disabled"><? echo $rows_trrgoods['description'] ?></textarea></td>
      </tr>
      <tr>
      <td>Gudang Penerima</td>
      <td align="center">:</td>
      <td><select name="warehouse_id" class="select-text select-small" disabled="disabled">
      	<option value="">Pilih..</option>
      <?
	  $qry_warehouses = "select * from units_warehouses JOIN warehouses ON (units_warehouses.warehouse_id = warehouses.id ) WHERE units_warehouses.unit_id = '".$_SESSION['galaxy_unit']."' order by warehouses.id;";
	  $rs_warehouses = mysql_query($qry_warehouses);
	  while($rows_warehouses=mysql_fetch_array($rs_warehouses)) {
	  ?>
        <option value="<? echo $rows_warehouses[3]?>" <? if(isEdit()) if($rows_warehouses[3]==$rows_trrgoods['warehouse_id']) echo 'selected'; ?>><? echo $rows_warehouses[5]; ?></option>
      <? } ?>
      </select></td>
      </tr>
      <tr>
      <td>Penerima</td>
      <td align="center">:</td>
      <td><input class="input-text" name="recipient" value="<? echo $rows_trrgoods['recipient'] ?>" disabled="disabled"/></td>
      </tr>
      <tr>
      <td></td>
      <td align="center"></td>
      <td><label style="float: left; width: 180px; height: 20px; color: black;"><input style="float: left; margin-right: 4px;" type="checkbox" name="prsign" value="1" <? if(isEdit()) if($rows_trrgoods['prsign']=='1') echo 'checked'; ?> disabled="disabled"/>Cocok</label> </td>
      </tr>
      <tr>
      <td>No. Faktur</td>
      <td align="center">:</td>
      <td><input class="input-text" name="fakturnom" value="<? if($rows_trrgoods[3]=='') {echo $rows_trrgoods[15]; } else{ echo $rows_trrgoods[3];} ?>"/></td>
      </tr>
      <tr>
      </table>
      <input type="hidden" name="rgnom" value="<? if($rows_trrgoods[13]=='2' || $rows_trrgoods[13]=='') echo $rgnom ?><? if($rows_trrgoods[13]!='2' || $rows_trrgoods[13]!='2') echo $rows_trrgoods['rgnom'] ?>" />
      <input type="hidden" name="gid" value="<? echo $_GET['gid'] ?>" />
      <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
      <input type="hidden" name="trprequest_id" value="<? echo $rows_trrgoods['trprequest_id'] ?>" />
      
      </form>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel">Batal</div>
      	<div mode="6" link="library/submenu/akunting/detail/update-lpb" class="popup-button" get="<? echo $_GET['gid'] ?>">Simpan</div>
      </div>
   </div>

<? }  ?>

<?
//<!-- TIPE MODE 6 = SAVE/MENYIMPAN -->
 if(isSave()) {
	if($_POST['mod']=='0') {
		
		
		$rs_trrgdetails = mysql_query("select * from trrgdetails where trrgood_id = '".$_POST['gid']."'");
		$buyprice= 0;
		while($rows_trrgdetails=mysql_fetch_array($rs_trrgdetails)) {
			//$buyprice = $rows_trrgdetails['hpp']+$rows_trrgdetails['ppnperitem'];
			$buyprice = $rows_trrgdetails['hpp'];
			$rows_items=mysql_fetch_array(mysql_query("select * from items where unit_id = '".$_POST['unitid']."' AND id = '".$rows_trrgdetails['item_id']."'"));
			if($rows_items['buyprice'] != '0.00') {
				$buybuybuy = ($buyprice + $rows_items['saleprice']) /2 ;
			}else {
				$buybuybuy = $buyprice ;
			}
			
			mysql_query("UPDATE items SET stock = stock+'".$rows_trrgdetails['qty']."', buyprice = '".$buyprice."', saleprice = '".$buybuybuy."' WHERE id ='".$rows_trrgdetails['item_id']."';");
			
			mysql_query("INSERT INTO stockitems (stockdate, warehouse_id, item_id, transtype_id, nobukti1, qty, tot, trrgdetail_id, nobukti2, unit_id, price) VALUES ('".date('Y-m-d')."', '".$_POST['warehouse_id']."', '".$rows_trrgdetails['item_id']."', '2',  '".$_POST['rgnom']."', '".$rows_trrgdetails['qty']."', '".$rows_trrgdetails['hpptot']."', '".$rows_trrgdetails['id']."', '".$_POST['fakturnom']."', '".$_POST['unitid']."',  '".$rows_trrgdetails['hpp']."')");
		}	
			
		mysql_query("UPDATE trrgoods SET postby = '".$_SESSION['galaxy_kode']."', postdate = '".date('Y-m-d')."', isposted = '1' WHERE id ='".$_POST['gid']."';");
		
		$today=date('Y-m-d');
		$qry_jadi="select sum(debt) as jml from  trrgdetails JOIN items ON (trrgdetails.item_id = items.id) where items.icategory_id = '1' AND trrgdetails.trrgood_id='".$_POST['gid']."' ";
		$row_jadi=mysql_fetch_array(mysql_query($qry_jadi));
		
		$qry_baku="select sum(debt) as jml from  trrgdetails JOIN items ON (trrgdetails.item_id = items.id) where items.icategory_id = '3' AND trrgdetails.trrgood_id='".$_POST['gid']."'";
		$row_baku=mysql_fetch_array(mysql_query($qry_baku));
		
		$qry_supplier="select trporders.supplier_id, trporders.unitid from trrgoods LEFT JOIN trporders ON (trrgoods.trporder_id = trporders.id) where trrgoods.id = '".$_POST['gid']."' ";
		$row_supplier=mysql_fetch_array(mysql_query($qry_supplier));
		
		if($row_jadi['jml'] > 0) {
			$KodeKasBank = KodeKasBank(); 
		
			mysql_query("insert into ak_kasbanks (ID, JNS_TRANS, TANGGAL, NO_BUKTI, NO_REFF, PERK_KASBANK, URAIAN_DEBET, DEBET, PERK_KREDIT, URAIAN_KREDIT,  KREDIT, TERIMA_DARI, UNIT_KODE) VALUES ('".$KodeKasBank."', 'HTG', '".$today."', '', '', '61', '', '".$row_jadi['jml']."', '75', '', '".$row_jadi['jml']."', '', '".$row_supplier['unitid']."') ");
			mysql_query("INSERT INTO ak_htg (SUPPLIER_ID, TRRGOOD_ID, KASBANK_ID, DEBET, TANGGAL, UNIT_ID) VALUES ('".$row_supplier['supplier_id']."', '".$_POST['gid']."', '".$KodeKasBank."', '".$row_jadi['jml']."',  '".$today."', '".$row_supplier['unitid']."')");
		}
		
		if($row_baku['jml'] > 0) {
			$KodeKasBank = KodeKasBank(); 
			mysql_query("insert into ak_kasbanks (ID, JNS_TRANS, TANGGAL, NO_BUKTI, NO_REFF, PERK_KASBANK, URAIAN_DEBET, DEBET, PERK_KREDIT, URAIAN_KREDIT,  KREDIT, TERIMA_DARI, UNIT_KODE) VALUES ('".$KodeKasBank."', 'HTG', '".$today."', '', '', '58', '', '".$row_baku['jml']."', '75', '', '".$row_baku['jml']."', '', '".$row_supplier['unitid']."') ");
			mysql_query("INSERT INTO ak_htg (SUPPLIER_ID, TRRGOOD_ID, KASBANK_ID, DEBET, TANGGAL, UNIT_ID) VALUES ('".$row_supplier['supplier_id']."', '".$_POST['gid']."', '".$KodeKasBank."', '".$row_baku['jml']."',  '".$today."', '".$row_supplier['unitid']."')");
		}
		
		/*
		mysql_query("insert into ak_kasbank (ID, PERK_KASBANK, JNS_TRANS, TANGGAL, TGL_INPUT, USER_ID, UNIT_KODE) VALUES (
		'".$KodeKasBank."' ,
		'61', 
		'HTG' ,
		'".$today."' ,
		'".$today."' ,
		'".$_SESSION['galaxy_kode']."' ,
		'".$row_supplier['unitid']."' ) ");
											 
		$qry_detail="select max(ID) as max from ak_kasbank ";
		$row_detail=mysql_fetch_array(mysql_query($qry_detail));
		
		mysql_query("insert into ak_detail_kasbank (KASBANK_ID,PERK_LAWAN,DEBET,TGL_INPUT,USER_ID,UNIT_KODE) VALUES (
		'".$KodeKasBank."'  ,
		'75' ,
		'".$row_jumlah['jml']."' ,
		'".$today."' ,
		'".$_SESSION['galaxy_kode']."' ,
		'".$row_supplier['unitid']."' )");
		*/
		
		
		
	}
	if($_POST['mod']=='1') {	
		mysql_query("UPDATE trrgoods SET fakturnom = '".$_POST['fakturnom']."' WHERE id ='".$_POST['gid']."';");
	}
 }
 
?>


