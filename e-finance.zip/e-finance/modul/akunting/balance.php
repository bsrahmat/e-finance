<?php
	require_once '../../library/connectionmysql.php';
	Connected();
	/*
	$perm = array();
	$perm = getPermissions('36');

	if($perm[-1]=='1') { require_once '../../library/error-popup.php'; die; }
	*/
	if(isEdit())  
	{
		$rs_blc = mysql_query("select sum(debet) as debet, sum(kredit) as kredit from ak_detail_jurnal where JURNAL_ID = '".$_GET['gid']."'");
		$rows_blc=mysql_fetch_array($rs_blc);
		
		$blc='';
		if($rows_blc['debet']==$rows_blc['kredit']) { $blc='1'; }
		else { $blc='0'; }
	}
	
?>

<?
if(isAdd() || isEdit() )
{
	$id = 'ID';
	$table = 'ak_jurnal';
	$id = Kode($id,$table);
	

?>
	<div class="popup-shadow" style="width: 600px;">
    	<div class="popup-header">
             <span>Cek Balance</span>
             <div class="popup-close">X</div>
      	</div>
        <div class="popup-body">
        	<form action="modul/akunting/balance.php" method="post">
            <table>
            <tr>
			<td class="center">
				<? if($blc==0) {?>
                    Data belum Balance <br /><b><strong>Mohon Dicek Lagi</strong></b>
                 <? }else {?>
                    Data Telah Balance <br /><b><strong>Dan Akan Tersimpan</strong></b>
                 <? } ?>
            </td>

            </tr>
                        
            </table>
            <input type="hidden" name="gid" value="<? echo $_GET['gid'] ?>" />
            <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
            <input type="hidden" name="isbalace" value="<? if($blc==1){echo'0';}else {echo'1';} ?>" />
            </form>
        </div>
        <div class="popup-footer">
      		<? if($blc==0) { ?>
      			<div class="popup-cancel">Cek Ulang</div>
    	    <? } else {?>
      		<div mode="6" link="library/submenu/akunting/jurnal" class="popup-button" get="">Simpan</div>
            <? } ?>
      	</div>
    </div>
<?
}

?>

<?
if(isSave()) 
{
	$error = array();
		
	if(count($error)>0) 
	{
		echo generateError($error);
	} 
	else 
	{
		
		
		if($_POST['mod']=='1') 
		{	
		mysql_query("UPDATE ak_jurnal SET isbalace = '".$_POST['isbalace']."' WHERE ID ='".$_POST['gid']."';");
		}
	}
}
 
?>