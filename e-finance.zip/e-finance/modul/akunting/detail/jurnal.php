<?php
	require_once '../../../library/connectionmysql.php';
	Connected();
	
	if(isEdit())  {
		$rs_edit = mysql_query("select * from ak_detail_jurnal where ID = '".$_GET['sub']."'");
		$rows_edit=mysql_fetch_array($rs_edit);
	}
?>

<?
//<!-- FORM TIPE MODE 0 = TAMBAH/ADD, TIPE MODE 1 = UBAH/EDIT -->
if(isAdd() || isEdit()) 
{
?>
	<div class="popup-shadow" style="width: 600px;">
    	<div class="popup-header">
             <span><? if(isAdd()) echo 'Tambah Data'; else echo 'Edit Data'; ?></span>
             <div class="popup-close">X</div>
      	</div>
        <div class="popup-body">
        <form action="modul/akunting/detail/jurnal.php" method="post">
        	<table>
            <tr>
              <td width="25%">Kd. Perk</td>
              <td width="5%" align="center">:</td>
              <td><select name="perkkasbank" class="select-text select-medium">
                    <option value="">Pilih..</option>
                  <? 	  
                  $qry_detail = '';
                  $qry_detail = "select * from ak_detail_perk;";
                  $rs_detail = mysql_query($qry_detail);
                  while($rows_detail=mysql_fetch_array($rs_detail)) {
                  ?>
                    <option value="<? echo $rows_detail['ID_DETAIL']?>" <? if(isEdit()) if($rows_detail['ID_DETAIL']==$rows_edit['PERK']) echo 'selected'; ?>><? echo $rows_detail['KODE_DETAIL']; ?> - [<? echo $rows_detail['NAMA_DETAIL']; ?>]</option>
                  <? } ?>
      			</select>
              </td>
            </tr>
            <tr>
              <td>Uraian</td>
              <td align="center">:</td>
              <td><input class="input-text" name="uraian" type="text" value="<? if(isEdit()) echo $rows_edit['URAIAN'] ?>" /></td>
              </tr>
            <tr>
              <td>Eq Debit</td>
              <td align="center">:</td>
              <td><input class="input-text currency padmin" name="debet" type="text" value="<? if(isEdit()) echo cFormat($rows_edit['DEBET'],false); ?>" /></td>
            </tr>
            <tr>
              <td>Eq Credit</td>
              <td align="center">:</td>
              <td><input class="input-text currency padmin" name="kredit" type="text" value="<? if(isEdit()) echo cFormat($rows_edit['KREDIT'],false); ?>" /></td>
            </tr>
            </table>
            <input type="hidden" name="gid" value="<? echo $_GET['gid'] ?>" />
            <input type="hidden" name="gid2" value="<? echo $_GET['sub'] ?>" />
            <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
            
        </form>
        </div>
    <div class="popup-footer">
    	<div class="popup-cancel">Batal</div>
      	<div mode="6" link="library/submenu/akunting/detail/jurnal" class="popup-button" get="<? echo $_GET['gid'] ?>">Simpan</div>
    </div>
   </div>
<?
}
?>

<?
//<!-- FORM TIPE MODE 2 = CONFIRM DELETE/KONFIRMASI HAPUS, TIPE MODE 4 = CONFIRM DELETE SELECTED/KONFIRMASI HAPUS YANG DIPILIH -->
if(isConfirmDelete()) 
{ 
	if(isConfirmDelete()) 
	{
		$rs_detail = mysql_query("select * from ak_detail_jurnal where ID = '".$_GET['gid']."'");
		$rows_detail=mysql_fetch_array($rs_detail);
	}
?>
	<div class="popup-shadow" style="width: 500px;">
		<div class="popup-header">
         <span>Konfirmasi Hapus</span>
         <div class="popup-close">X</div>
    	</div>
        <div class="popup-body">
        <table>
        <tr>
      		<td class="center">
            <? 
			if(isConfirmDelete()) 
			{
			?>
      			Apakah anda yakin menghapus <br /><b style="text-decoration: underline;"><? echo $rows_detail['URAIAN'] ?></b>?
  		    <? 
			}?>
            </td>
        </tr>
        </table>
        </div>
        <div class="popup-footer">
        	<div class="popup-cancel"><? if($_GET['gid']!='') echo 'Batal'; else echo 'Tutup' ?></div>
            <? 
			if(isConfirmDelete()) 
			{ ?>
      			<div mode="3" link="modul/akunting/detail/jurnal?<? echo $_GET['gid'] ?>" class="popup-button">Hapus</div>
    	    <? 
			}?>
        </div>
    </div>
<?
}
?>

<?
if(isDelete()) 
{
	$rs_detail = mysql_query("select * from ak_detail_jurnal where ID = '".$_GET['gid']."'");
	$rows_detail=mysql_fetch_array($rs_detail);
	
	$_POST['gid'] = $rows_detail['JURNAL_ID'];
	
	mysql_query("DELETE from ak_detail_jurnal where id ='".$_GET['gid']."'");
	
	$rs_blc = mysql_query("select sum(debet) as debet, sum(kredit) as kredit from ak_detail_jurnal where JURNAL_ID = '".$_POST['gid']."'");
			$rows_blc=mysql_fetch_array($rs_blc);
			
			$blc='';
			if($rows_blc['debet']==$rows_blc['kredit']) {
				mysql_query("UPDATE ak_jurnal SET isbalace = '0' WHERE ID ='".$_POST['gid']."';");
			}
			else {
				mysql_query("UPDATE ak_jurnal SET isbalace = '1' WHERE ID ='".$_POST['gid']."';");
			}
	
	
	
} ?>

<?
//<!-- TIPE MODE 6 = SAVE/MENYIMPAN -->
if(isSave()) 
{ 
	$error = array();
		if(!$_POST['perkkasbank']) $error[] = 'perkkasbank:Silahkan Masukkan Perkiraan.';
		if(!$_POST['uraian']) $error[] = 'uraian:Silahkan Masukkan Uraian.';
	
	if(count($error)>0) 
	{
		echo generateError($error);
	} 
	else 
	{
		if(!$_POST['debet']) $_POST['debet']=0;
		if(!$_POST['kredit']) $_POST['kredit']=0;
		$_POST['debet'] = str_replace(',','',$_POST['debet']);
		$_POST['kredit'] = str_replace(',','',$_POST['kredit']);
			
		if($_POST['mod']=='0') 
		{
			mysql_query("INSERT INTO ak_detail_jurnal VALUES (
			'' ,
			'".$_POST['gid']."' ,
			'".$_POST['perkkasbank']."' ,
			'".$_POST['uraian']."' ,
			'".$_POST['debet']."' ,
			'".$_POST['kredit']."' )");	
			
			
			$rs_blc = mysql_query("select sum(debet) as debet, sum(kredit) as kredit from ak_detail_jurnal where JURNAL_ID = '".$_POST['gid']."'");
			$rows_blc=mysql_fetch_array($rs_blc);
			
			$blc='';
			if($rows_blc['debet']==$rows_blc['kredit']) {
				mysql_query("UPDATE ak_jurnal SET isbalace = '0' WHERE ID ='".$_POST['gid']."';");
			}
			else {
				mysql_query("UPDATE ak_jurnal SET isbalace = '1' WHERE ID ='".$_POST['gid']."';");
			}
		}
		
		if($_POST['mod']=='1') 
		{
			mysql_query("UPDATE ak_detail_jurnal SET 
			PERK = '".$_POST['perkkasbank']."', 
			URAIAN = '".$_POST['uraian']."' ,
			DEBET = '".$_POST['debet']."' ,
			KREDIT = '".$_POST['kredit']."'  
			WHERE ID ='".$_POST['gid2']."';");
			
			$rs_blc = mysql_query("select sum(debet) as debet, sum(kredit) as kredit from ak_detail_jurnal where JURNAL_ID = '".$_POST['gid']."'");
			$rows_blc=mysql_fetch_array($rs_blc);
			
			$blc='';
			if($rows_blc['debet']==$rows_blc['kredit']) {
				mysql_query("UPDATE ak_jurnal SET isbalace = '0' WHERE ID ='".$_POST['gid']."';");
			}
			else {
				mysql_query("UPDATE ak_jurnal SET isbalace = '1' WHERE ID ='".$_POST['gid']."';");
			}
		}
		
	}

}
?>

