<?php
	require_once '../../../library/connectionmysql.php';
	Connected();
	
	if(isEdit())  {
		$rs_edit = mysql_query("select * from ak_detail_kasbank where ID = '".$_GET['sub']."'");
		$rows_edit=mysql_fetch_array($rs_edit);
	}
?>

<?
//<!-- FORM TIPE MODE 0 = TAMBAH/ADD, TIPE MODE 1 = UBAH/EDIT -->
if(isAdd() || isEdit()) 
{
?>
	<div class="popup-shadow" style="width: 600px;">
    	<div class="popup-header">
             <span><? if(isAdd()) echo 'Tambah Data'; else echo 'Edit Data'; ?></span>
             <div class="popup-close">X</div>
      	</div>
        <div class="popup-body">
        <form action="modul/akunting/detail/bank.php" method="post">
        	<table>
            <tr>
              <td width="25%">Perk. Lawan</td>
              <td width="5%" align="center">:</td>
              <td><select name="perkkasbank" class="select-text select-medium">
                    <option value="">Pilih..</option>
                  <? 	  
                  $qry_detail = '';
                  $qry_detail = "select * from ak_detail_perk;";
                  $rs_detail = mysql_query($qry_detail);
                  while($rows_detail=mysql_fetch_array($rs_detail)) {
                  ?>
                    <option value="<? echo $rows_detail['ID_DETAIL']?>" <? if(isEdit()) if($rows_detail['ID_DETAIL']==$rows_edit['PERK_LAWAN']) echo 'selected'; ?>><? echo $rows_detail['KODE_DETAIL']; ?> - [<? echo $rows_detail['NAMA_DETAIL']; ?>]</option>
                  <? } ?>
      			</select>
              </td>
            </tr>
            <tr>
              <td>Uraian</td>
              <td align="center">:</td>
              <td><input class="input-text" name="uraian" type="text" value="<? if(isEdit()) echo $rows_edit['URAIAN'] ?>" /></td>
              </tr>
            <tr>
              <td>Jumlah</td>
              <td align="center">:</td>
              <td><input class="input-text currency padmin" name="jumlah" type="text" value="<? 
			  if(isEdit()) 
			  {
				  if($rows_edit['DEBET']!='0.00')
				  {
					  echo cFormat($rows_edit['DEBET'],false);
				  }
				  else
				  {
					  echo cFormat($rows_edit['KREDIT'],false);
				  }
				   
			  }
			  ?>" /></td>
            </tr>
            </table>
            <input type="hidden" name="gid" value="<? echo $_GET['gid'] ?>" />
            <input type="hidden" name="gid2" value="<? echo $_GET['sub'] ?>" />
            <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
            <?
			$qry_cek= '';
			$qry_cek = "select * from ak_kasbank where id = '".$_GET['gid']."';";
			$rs_cek = mysql_query($qry_cek);
			$rows_cek = mysql_fetch_array($rs_cek);
			?>
            <input type="hidden" name="kode" value="<? echo $rows_cek['JNS_TRANS'] ?>" />
        </form>
        </div>
    <div class="popup-footer">
    	<div class="popup-cancel">Batal</div>
      	<div mode="6" link="library/submenu/akunting/detail/bank" class="popup-button" get="<? echo $_GET['gid'] ?>">Simpan</div>
    </div>
   </div>
<?
}
?>

<?
//<!-- FORM TIPE MODE 2 = CONFIRM DELETE/KONFIRMASI HAPUS, TIPE MODE 4 = CONFIRM DELETE SELECTED/KONFIRMASI HAPUS YANG DIPILIH -->
if(isConfirmDelete()) 
{ 
	if(isConfirmDelete()) 
	{
		$rs_detail = mysql_query("select * from ak_detail_kasbank where ID = '".$_GET['gid']."'");
		$rows_detail=mysql_fetch_array($rs_detail);
	}
?>
	<div class="popup-shadow" style="width: 500px;">
		<div class="popup-header">
         <span>Konfirmasi Hapus</span>
         <div class="popup-close">X</div>
    	</div>
        <div class="popup-body">
        <table>
        <tr>
      		<td class="center">
            <? 
			if(isConfirmDelete()) 
			{
			?>
      			Apakah anda yakin menghapus <br /><b style="text-decoration: underline;"><? echo $rows_detail['URAIAN'] ?></b>?
  		    <? 
			}?>
            </td>
        </tr>
        </table>
        </div>
        <div class="popup-footer">
        	<div class="popup-cancel"><? if($_GET['gid']!='') echo 'Batal'; else echo 'Tutup' ?></div>
            <? 
			if(isConfirmDelete()) 
			{ ?>
      			<div mode="3" link="modul/akunting/detail/bank?<? echo $_GET['gid'] ?>" class="popup-button">Hapus</div>
    	    <? 
			}?>
        </div>
    </div>
<?
}
?>

<?
if(isDelete()) 
{
	mysql_query("DELETE from ak_detail_kasbank where id ='".$_GET['gid']."'");
} ?>

<?
//<!-- TIPE MODE 6 = SAVE/MENYIMPAN -->
if(isSave()) 
{ 
	$error = array();
	
	if(!$_POST['perkkasbank']) $error[] = 'perkkasbank:Silahkan Masukkan Perkiraan.';
	if(!$_POST['uraian']) $error[] = 'uraian:Silahkan Masukkan Uraian.';
	if(!$_POST['jumlah']) $error[] = 'jumlah:Silahkan Masukkan Jumlah.';
	
	if(count($error)>0) 
	{
		echo generateError($error);
	} 
	else 
	{
		$dbt='';
		$krd='';
		$today=gmdate("Y-m-d");
		if(strcmp($_POST['kode'],'KM')==0 || strcmp($_POST['kode'],'BM')==0)
		{
			$_POST['jumlah'] = str_replace(',','',$_POST['jumlah']);
			$dbt= $_POST['jumlah']; 
		}
		if(strcmp($_POST['kode'],'KK')==0 || strcmp($_POST['kode'],'BK')==0)
		{
			$_POST['jumlah'] = str_replace(',','',$_POST['jumlah']);
			$krd= $_POST['jumlah']; 
		}
		
		if($_POST['mod']=='0') 
		{
			mysql_query("INSERT INTO ak_detail_kasbank VALUES (
			'' ,
			'".$_POST['gid']."' ,
			'".$_POST['perkkasbank']."' ,
			'".$_POST['uraian']."' ,
			'".$dbt."' ,
			'".$krd."' ,
			'".$today."' ,
			'".$_SESSION['galaxy_kode']."' ,
			'".$_SESSION['galaxy_unit']."' )");	
		}
		
		if($_POST['mod']=='1') 
		{
			mysql_query("UPDATE ak_detail_kasbank SET 
			PERK_LAWAN = '".$_POST['perkkasbank']."', 
			URAIAN = '".$_POST['uraian']."' ,
			DEBET = '".$dbt."' ,
			KREDIT = '".$krd."' , 
			TGL_INPUT = '".$today."' ,
			USER_ID = '".$_SESSION['galaxy_kode']."'
			WHERE ID ='".$_POST['gid2']."';");
		}
	}

}
?>