<?php
	require_once '../../../library/connectionmysql.php';
	Connected();
	
	$perm = array();
	$perm = getPermissions('23');

	if($perm[-1]=='1') { require_once '../../library/error-popup.php'; die; }
	

if(isEdit()) {
	$rs_wedetails = mysql_query("select * from wedetails LEFT JOIN items ON ( wedetails.item_id = items.id) where wedetails.id = '".$_GET['sub']."'");
	$rows_wedetails=mysql_fetch_array($rs_wedetails);
 ?>
<script language="JavaScript">
<!-- Begin
function Sumary(form) {
	
	var hpp = $("input[name^='hpp']").val().replace(',','');
	var ppnperitem = $("input[name^='ppnperitem']").val().replace(',','');
	
	//salemindisc = saleprice - disc;
	//tsalemindisc = (saleprice * qty) - (qty * disc);
	ppnperitems = 10/100 * hpp; 
	
	$("input[name^='ppnperitem']").val($.fn.addCommas(ppnperitems,''));
	
}
// End -->
</script>
   <div class="popup-shadow" style="width: 650px;">
      <div class="popup-header">
         <span>Edit Trpodetail</span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <form action="modul/akunting/detail/update-penyelesaian-kerja.php" method="post">
      <table>
      <tr>
      <td width="25%">Nama Barang</td>
      <td width="5%" align="center">:</td>
      <td><input class="input-text" name="name-disable" type="text" value="<? echo $rows_wedetails['name'] ?>"  disabled="disabled"/></td>
      </tr>
      
      <tr>
      <td>Harga Pokok</td>
      <td align="center">:</td>
      <td><input class="input-text currency" name="hpp" type="text" value="<? echo cFormat($rows_wedetails['hpp'], false) ?>" onkeyup="Sumary(this.form)"/></td>
      </tr>
      
      <tr>
      <td>PPn Per Barang</td>
      <td align="center">:</td>
      <td><input class="input-text currency" name="ppnperitem" type="text" value="<? echo cFormat($rows_wedetails['ppnperitem'], false) ?>" /></td>
      </tr>
      
      
      
      </table>
      
      <input type="text" name="item_id" value="<? echo $rows_wedetails['item_id'] ?>" />
      <input type="text" name="sub" value="<? echo $_GET['sub'] ?>" />
      <input type="text" name="gid" value="<? echo $_GET['gid'] ?>" />
      <input type="text" name="mod" value="<? echo $_GET['mod'] ?>" />
      </form>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel">Batal</div>
      	<div mode="6" link="library/submenu/akunting/detail/update-penyelesaian-kerja" class="popup-button" get="<? echo $_GET['gid'] ?>">Simpan</div>
      </div>
   </div>

<? }  
//<!-- END FORM -->

//<!-- =========================================================================================================================== -->
?>

<? 
//<!-- FORM TIPE MODE 2 = CONFIRM DELETE/KONFIRMASI HAPUS, TIPE MODE 4 = CONFIRM DELETE SELECTED/KONFIRMASI HAPUS YANG DIPILIH -->
if(isConfirmDelete()) { ?>
<?
	if(isConfirmDelete()) {
		$rs_wedetails = mysql_query("select * from wedetails JOIN items ON ( wedetails.item_id = items.id) where wedetails.id = '".$_GET['sub']."'");
		$rows_wedetails=mysql_fetch_array($rs_wedetails);
	}
?>
   <div class="popup-shadow" style="width: 500px;">
      <div class="popup-header">
         <span>Konfirmasi Hapus</span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <form action="modul/akunting/detail/update-penyelesaian-kerja.php" method="post">
      <table>
      <tr>
      <td class="center">
      <? if(isConfirmDelete()) {?>
      		Apakah anda yakin menghapus <br /><b style="text-decoration: underline;"><? echo $rows_wedetails['name'] ?></b>?
      <? }?>
      
      
      </td>
      </tr>
      </table>
          
      
      <input type="hidden" name="sub" value="<? echo $_GET['sub'] ?>" />
      <input type="hidden" name="trpodetail_id" value="<? echo $rows_wedetails['trpodetail_id'] ?>" />
      <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
      </form>
      </div>
      <div class="popup-footer">
        <div class="popup-cancel">Batal</div>
      	<div mode="6" link="library/submenu/akunting/detail/update-penyelesaian-kerja" class="popup-button" get="<? echo $_GET['gid'] ?>">Hapus</div>
      	
      </div>
      
   </div>

<? } 



 if(isSave()) {
	$error = array();
if($_POST['mod']=='1') {
	/*
	$qty = str_replace(',','',$_POST['qty']);
	$qty2 = str_replace(',','',$_POST['qty2']);
	if($qty > $qty2) $error[] = 'qty:Jumlah Tidak Boleh Lebih Besar Dari .'.cFormat($qty2,false);
	*/
}
		

if(count($error)>0) {
	echo generateError($error);
	
} else {  
		
	if($_POST['mod']=='1') {
		$hpp = str_replace(',','',$_POST['hpp']);
		$ppnperitem = str_replace(',','',$_POST['ppnperitem']);
		$hpptot =  $hpp + $ppnperitem;
			
		mysql_query("UPDATE wedetails SET hpp = ".isNull($_POST['hpp'],'CUR').", hpptot = ".isNull($_POST['hpp'],'CUR')." , ppn = ".isNull($_POST['ppnperitem'],'CUR')." , debt = '".$hpptot."' WHERE id ='".$_POST['sub']."';");
		
	}
	if($_POST['mod']=='2') {
		mysql_query("UPDATE  trpodetails SET trpostatus = '1' WHERE id ='".$_POST['trpodetail_id']."';");
		mysql_query("DELETE from wedetails where id ='".$_POST['sub']."'");
		
	}
}


 }
//<!-- END TIPE MODE 6 --> 
?>

