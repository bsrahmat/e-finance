<?php
	require_once '../../../library/connectionmysql.php';
	Connected();
	
	$perm = array();
	$perm = getPermissions('54');

	if($perm[-1]=='1') { require_once '../../library/error-popup.php'; die; }
	if(isAdd()) { 
		if($perm[0]=='1') { require_once '../../library/error-popup.php'; die; }
	}if(isEdit()) { 
		if($perm[1]=='1') { require_once '../../library/error-popup.php'; die; }
	}if(isConfirmDelete() || isConfirmDeleteSelected()) { 
		if($perm[2]=='1') { require_once '../../library/error-popup.php'; die; }
	}
	
?>

<?
if(KasKeluar() || BankKeluar())
{
	$qry_total="SELECT * FROM ak_htg_awal JOIN ak_htg ON (ak_htg_awal.id = ak_htg.hutang_awal_id) JOIN  suppliers ON (ak_htg.SUPPLIER_ID = suppliers.id) JOIN units ON (ak_htg.UNIT_ID = units.id) WHERE ak_htg_awal.id = '".$_GET['gid']."';";
	$row_total=mysql_fetch_array(mysql_query($qry_total));
	
	$qry_code="select * from  trrgoods where id='".$_GET['gid']."'";
	$row_code=mysql_fetch_array(mysql_query($qry_code));
	
	$id = 'ID';
	$table = 'ak_kasbank';
	$id = Kode($id,$table);
	
	
	
	$qry_unit="select * from units where id='".$row_total[4]."'";
	$rs_unit=mysql_query($qry_unit);
	$row_unit=mysql_fetch_array($rs_unit);
	$temp1=$row_unit['code'];
	
	$th=gmdate("Y");
	$cd='HTG';
	
	if(KasKeluar()) { $trans='KHB'; }
	if(BankKeluar()) { $trans='BHB'; }
	
	$kode=$cd."/".$trans."/".$temp1."/".$th."/";
	$query = "SELECT max(NO_BUKTI) AS last FROM ak_kasbank WHERE NO_BUKTI LIKE '$kode%'";
	$hasil = mysql_query($query);
	$data  = mysql_fetch_array($hasil);	
	$lastNoTransaksi = $data['last'];
	$dt=explode('/',$lastNoTransaksi);
	if($lastNoTransaksi=='' || $dt[3]!=$th)
	{
		$dta=1;
	}
	else
	{
		$dta= $dt[4] + 1;
	}
	
	$nextKode = $kode.sprintf('%05s', $dta);
?>
	<div class="popup-shadow" style="width: 600px;">
    	<div class="popup-header">
             <span>
			 <? 
				if(KasKeluar()) echo 'Kas Keluar'; 
				if(BankKeluar()) echo 'Bank Keluar';
			 ?>
             </span>
             <div class="popup-close">X</div>
      	</div>
        <div class="popup-body">
        	<form action="modul/akunting/detail/utang-awal.php" method="post">
            <table>
            <tr>
              <td width="25%">No. Bukti</td>
              <td width="5%" align="center">:</td>
              <td><input class="input-text" name="nobukti_D" type="text" value="<? echo $nextKode ?>"  disabled="disabled"></td>
            </tr>
            <tr>
              <td>Tanggal</td>
              <td align="center">:</td>
              <td><input class="input-text" name="tanggal" type="datepicker" value="" /></td>
            </tr>
            <tr>
              <td>No. Reff</td>
              <td align="center">:</td>
              <td><input class="input-text" name="noreff" type="text" value="" /></td>
            </tr>
            <tr>
            <tr>
          	  <td>Perk. Kas/bank</td>
              <td align="center">:</td>
              <td>
              	<select name="perkkasbank" class="select-text select-medium">
                    <option value="">Pilih..</option>
                  <? 	  
                  $qry_detail = '';
                  if(KasKeluar())
				  {
                  	$qry_detail = "select * from ak_detail_perk where KODE_DETAIL like '1101%' or KODE_DETAIL like '1102%';";
				  }
				  if(BankKeluar())
				  {
					 $qry_detail = "select * from ak_detail_perk where KODE_DETAIL like '1103%';";
				  }
                  $rs_detail = mysql_query($qry_detail);
                  while($rows_detail=mysql_fetch_array($rs_detail)) {
                  ?>
                    <option value="<? echo $rows_detail['ID_DETAIL']?>" ><? echo $rows_detail['KODE_DETAIL']; ?> - [<? echo $rows_detail['NAMA_DETAIL']; ?>]</option>
                  <? } ?>
      			</select>
              </td>
          	</tr>
            <tr>
              <td>Diterima dr/Dibayar ke</td>
              <td align="center">:</td>
              <td><input class="input-text" name="terima" type="text" value="" /></td>
            </tr>
            <tr>
              <td>Keterangan</td>
              <td align="center">:</td>
              <td><input class="input-text" name="ket" type="text" value="" /></td>
            </tr>
           	<?
			if(BankKeluar() )
			{
			?>
                <tr>
                  <td>No. BG</td>
                  <td align="center">:</td>
                  <td><input class="input-text" name="nobg" type="text" value="" /></td>
                </tr>
                <tr>
                <td>Tgl. BG</td>
                  <td align="center">:</td>
                  <td><input class="input-text" name="tglbg" type="datepicker" value="" /></td>
                </tr>
            <?
			}
			else
			{
			?>
            	<input class="input-text" name="nobg" type="hidden" value="" />
                <input class="input-text" name="tglbg" type="hidden" value="00/00/0000" />
            <?
			}
			?>
            <tr>
              <td width="25%">Perk. Lawan</td>
              <td width="5%" align="center">:</td>
              <td><select name="perklawan" class="select-text select-medium">
                    <option value="">Pilih..</option>
                  <? 	  
                  $qry_detail = '';
                  $qry_detail = "select * from ak_detail_perk where KODE_DETAIL = '2101' or KODE_DETAIL = '2102' or KODE_DETAIL = '2103';";
                  $rs_detail = mysql_query($qry_detail);
                  while($rows_detail=mysql_fetch_array($rs_detail)) {
                  ?>
                    <option value="<? echo $rows_detail['ID_DETAIL']?>" ><? echo $rows_detail['KODE_DETAIL']; ?> - [<? echo $rows_detail['NAMA_DETAIL']; ?>]</option>
                  <? } ?>
      			</select>
              </td>
            </tr>
            <tr>
              <td>Uraian</td>
              <td align="center">:</td>
              <td><input class="input-text" name="uraian" type="text" value="" /></td>
              </tr>
              <?
			  	$total=$row_total[12];
			  	$qry_sisa="select sum(ak_htg.KREDIT) as sisa FROM ak_htg_awal JOIN ak_htg ON (ak_htg_awal.id = ak_htg.hutang_awal_id)  WHERE ak_htg_awal.id = '".$_GET['gid']."';";
				$row_sisa=mysql_fetch_array(mysql_query($qry_sisa));
				$kurang=$total-$row_sisa['sisa'];
			  ?>
            <tr>
              <td>Jumlah</td>
              <td align="center">:</td>
              <td><input class="input-text currency padmin" name="jumlah" type="text" value="<? echo cFormat($kurang,false);?>" />
              </td>
            </tr>
            </table>
            <input type="hidden" name="total" value="<? echo $kurang ?>" />
            <input type="hidden" name="trans" value="<? echo $trans ?>" />
            <input type="hidden" name="gid" value="<? echo $_GET['gid'] ?>" />
            <input type="hidden" name="nobukti" value="<? echo $nextKode ?>" />
            <input type="hidden" name="supplier" value="<? echo $row_total[1] ?>" />
            <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
            <input type="hidden" name="unitid" value="<? echo $row_unit['id'] ?>" />
            </form>
        </div>
        <div class="popup-footer">
      		<div class="popup-cancel">Batal</div>
      		<div mode="6" link="library/submenu/akunting/utang-awal" class="popup-button" get="<? echo $id ?>">Simpan</div>
      	</div>
    </div>
<?
}
?>


<?
//<!-- TIPE MODE 6 = SAVE/MENYIMPAN -->
if(isSave()) 
{
	$error = array();
	if(!$_POST['tanggal']) $error[] = 'tanggal:Silahkan Masukkan Tanggal.';
	if(!$_POST['noreff']) $error[] = 'noreff:Silahkan Masukkan noreff.';
	if(!$_POST['perkkasbank']) $error[] = 'perkkasbank:Silahkan Masukkan Perk Kasbank.';
	if(!$_POST['terima']) $error[] = 'terima:Silahkan Masukkan Diterima dr/Dibayar ke.';
	if(!$_POST['ket']) $error[] = 'ket:Silahkan Masukkan Keterangan.';
	
	if(!$_POST['perklawan']) $error[] = 'perklawan:Silahkan Masukkan Perk Lawan.';
	if(!$_POST['uraian']) $error[] = 'uraian:Silahkan Masukkan Uraian.';
	$_POST['jumlah'] = str_replace(',','',$_POST['jumlah']);
	if($_POST['jumlah'] > $_POST['total']) $error[] = 'jumlah:Jumlah terlalu Besar.';
	
	if(count($error)>0) 
	{
		echo generateError($error);
	} 
	else 
	{
		$tgl='';
		if(!$_POST['tglbg']) $_POST['tglbg']='00/00/00';
		
		$tgl2=explode('/',$_POST['tglbg']);
		$tgl=$tgl2[2].'-'.$tgl2[1].'-'.$tgl2[0];

		if($_POST['mod']=='11' || $_POST['mod']=='13')
		{
			$today=gmdate("Y-m-d");
			$kodeKasBank = KodeKasBank();
			mysql_query("INSERT INTO ak_kasbank VALUES (
			'".$kodeKasBank."' ,
			'".$_POST['trans']."' ,
			".isNull($_POST['tanggal'],'DATE')." ,
			'".$_POST['nobukti']."' ,
			'".$_POST['noreff']."' ,
			'".$_POST['perkkasbank']."' ,
			'".$_POST['terima']."' ,
			'".$_POST['ket']."' ,
			'".$today."' ,
			'".$_SESSION['galaxy_kode']."' ,
			'".$_POST['unitid']."' ,
			'".$_POST['nobg']."' , 
			'".$tgl."')");

			mysql_query("INSERT INTO ak_detail_kasbank VALUES (
			'' ,
			'".$kodeKasBank."' ,
			'".$_POST['perklawan']."' ,
			'".$_POST['uraian']."' ,
			'' ,
			'".$_POST['jumlah']."' ,
			'".$today."' ,
			'".$_SESSION['galaxy_kode']."' ,
			'".$_SESSION['galaxy_unit']."' )");

			$row_supplier=mysql_fetch_array(mysql_query($qry_supplier));
			mysql_query("INSERT INTO ak_htg (SUPPLIER_ID,hutang_awal_id,KASBANK_ID,KREDIT,TANGGAL, UNIT_ID) VALUES (
			'".$_POST['supplier']."' ,
			'".$_POST['gid']."' ,
			'".$kodeKasBank."' ,
			'".$_POST['jumlah']."' ,
			".isNull($_POST['tanggal'],'DATE')." ,
			'".$_POST['unitid']."' )");
			
			$qry_total="SELECT * FROM ak_htg_awal JOIN ak_htg ON (ak_htg_awal.id = ak_htg.hutang_awal_id) JOIN  suppliers ON (ak_htg.SUPPLIER_ID = suppliers.id) JOIN units ON (ak_htg.UNIT_ID = units.id) WHERE ak_htg_awal.id = '".$_POST['gid']."';";
			$row_total=mysql_fetch_array(mysql_query($qry_total));
			$qry_jml_hutang="select sum(ak_htg.KREDIT) as sisa FROM ak_htg_awal JOIN ak_htg ON (ak_htg_awal.id = ak_htg.hutang_awal_id)  WHERE ak_htg_awal.id = '".$_POST['gid']."';";
			$row_jml_hutang=mysql_fetch_array(mysql_query($qry_jml_hutang));
			
			if($_POST['jumlah']==$_POST['total']){
				mysql_query("UPDATE ak_htg_awal SET status_utang = '1' WHERE id ='".$_POST['gid']."';");
			} else {
				mysql_query("UPDATE ak_htg_awal SET status_utang = '2' WHERE id ='".$_POST['gid']."';");
			}
		}
	}
}
 
?>