<?php
	require_once '../../library/connectionmysql.php';
	Connected();

	
		
	if(isEdit())  {
		$rs_saldo = mysql_query("select * from ak_saldo_awal where ID = '".$_GET['gid']."'");
		$rows_saldo=mysql_fetch_array($rs_saldo);
	}
//<!-- =========================================================================================================================== -->
?>

<?
//<!-- FORM TIPE MODE 0 = TAMBAH/ADD, TIPE MODE 1 = UBAH/EDIT -->
 if(isAdd() || isEdit()) { ?>
 
   <div class="popup-shadow" style="width: 600px;">
      <div class="popup-header">
         <span><? if(isAdd()) echo 'Tambah Data'; else echo 'Edit Data'; ?></span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <form action="modul/akunting/saldo.php" method="post">
      <table>
      
      <tr>
      <td width="25%">Kd. Perk</td>
      <td width="5%" align="center">:</td>
      <?
	  if(isAdd())
	  {
	  ?>
      <td><select name="perk" class="select-text select-medium">
        <option value="">Pilih..</option>
        <? 	  
		  $qry_detail = '';
		  $qry_detail = "select * from ak_detail_perk;";
		  $rs_detail = mysql_query($qry_detail);
		  while($rows_detail=mysql_fetch_array($rs_detail)) {
			?>
			<option value="<? echo $rows_detail['ID_DETAIL']?>" <? if(isEdit()) if($rows_detail['ID_DETAIL']==$rows_saldo['ID_DETAIL']) echo 'selected'; ?>><? echo $rows_detail['KODE_DETAIL']; ?> - [<? echo $rows_detail['NAMA_DETAIL']; ?>]</option>
			<? } ?>
      </select></td>
      <?
      }
	  if(isEdit())
	  {
		  $qry_nm="select * from ak_detail_perk where ID_DETAIL='".$rows_saldo['ID_DETAIL']."' ";
		  $row_nm=mysql_fetch_array(mysql_query($qry_nm));
	  ?>
      <td><input class="input-text" name="perk" type="text" value="<? echo $row_nm['KODE_DETAIL']; ?>-[<? echo $row_nm['NAMA_DETAIL']?>]" disabled="disabled" /></td>
      <?
	  }
	  ?>
      </tr>
      <tr>
      <td>Tanggal</td>
      <td align="center">:</td>
      <td><input class="input-text" name="tanggal" type="datepicker" value="<? if(isEdit()) echo cDate($rows_saldo['TANGGAL']) ?>" /></td>
      </tr>
      <tr>
      <td>Saldo</td>
      <td align="center">:</td>
      <td><input class="input-text currency padmin" name="saldo" type="text" value="<? if(isEdit()) echo cFormat($rows_saldo['JUMLAH'],false); ?>" /></td>
      </tr>
      
      </table>
      <? if(isEdit())  {?>
      <input type="hidden" name="gid" value="<? echo $_GET['gid'] ?>" />
      
      <? }?>
      <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
      </form>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel">Batal</div>
      	<div mode="6" link="library/submenu/akunting/saldo" get="" class="popup-button">Simpan</div>
      </div>
   </div>

<? }  
//<!-- END FORM -->

//<!-- =========================================================================================================================== -->
?>

<? 
//<!-- FORM TIPE MODE 2 = CONFIRM DELETE/KONFIRMASI HAPUS, TIPE MODE 4 = CONFIRM DELETE SELECTED/KONFIRMASI HAPUS YANG DIPILIH -->
if(isConfirmDelete() || isConfirmDeleteSelected()) { ?>
<?
	if(isConfirmDelete()) {
		$rs_delete = mysql_query("select * from ak_saldo_awal where ID = '".$_GET['gid']."'");
		$rows_delete=mysql_fetch_array($rs_delete);
		$qry_perk="select * from ak_detail_perk where ID_DETAIL='".$rows_delete['ID_DETAIL']."' ";
		$row_perk=mysql_fetch_array(mysql_query($qry_perk));
	}
?>
   <div class="popup-shadow" style="width: 500px;">
      <div class="popup-header">
         <span>Konfirmasi Hapus</span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <table>
      <tr>
      <td class="center">
      <? if(isConfirmDelete()) {?>
      		<strong>Peringatan</strong>: <br /> 
      		Data <b>Saldo Awal</b> akan ikut terhapus!.
      		<br /><br />
      		Apakah anda yakin menghapus <br /><b style="text-decoration: underline;"><? echo $row_perk['KODE_DETAIL']; ?> -[ <? echo $row_perk['NAMA_DETAIL'] ?> ] </b>?
      <? }?>
      </td>
      </tr>
      </table>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel"><? if($_GET['gid']!='') echo 'Batal'; else echo 'Tutup' ?></div>
        <? if(isConfirmDelete()) { ?>
      		<div mode="3" link="modul/akunting/saldo?<? echo $_GET['gid'] ?>" class="popup-button">Hapus</div>
        <? }?>
      	<? if(isConfirmDeleteSelected()) {
			if($_GET['gid']!='') {
				if(count($value)>0)
		?>
      		<div mode="5" link="modul/akunting/saldo?<? echo htmlspecialchars($_GET['gid']) ?>" class="popup-button">Hapus</div>
        <? } } ?>
      </div>
      
   </div>

<? } 

?>

<?
 if(isDelete()) {
	 
	mysql_query("DELETE from ak_saldo_awal where ID =".$_GET['gid']);
	
 } ?>
 
<?
//<!-- END TIPE MODE 3 -->


//<!-- =========================================================================================================================== -->
?>

<?
//<!-- TIPE MODE 6 = SAVE/MENYIMPAN -->
 if(isSave()) { 

$error = array();


if(!$_POST['tanggal']) $error[] = 'tanggal:Silahkan Masukkan Tanggal.';
if(!$_POST['saldo']) $error[] = 'saldo:Silahkan Masukkan Saldo.';


//Ngecek apa ada nama kabupaten yg sama...
$rs_check = mysql_query("select * from ak_saldo_awal where ID_DETAIL = '".$_POST['perk']."' ");
$rows_check = mysql_num_rows($rs_check);

//jika nambah data baru..
if($_POST['mod']=='0')
	if(!$_POST['perk']) $error[] = 'perk:Silahkan Masukkan Perkiraan.';
	if($rows_check>0) $error[] = 'perk:Perkiraan Sudah Ada Silahkan Masukkan Yang lain.';


if(count($error)>0) {
	echo generateError($error);
	
} else {
	$_POST['saldo'] = str_replace(',','',$_POST['saldo']);
	$tgl2=explode('/',$_POST['tanggal']);
	$tgl=$tgl2[2].'-'.$tgl2[1].'-'.$tgl2[0];
	
	if($_POST['mod']=='0') {
			
		mysql_query("INSERT INTO ak_saldo_awal VALUES (
		'', 
		'".$_POST['perk']."', 
		'".$_SESSION['galaxy_unit']."' , 
		'".$_POST['saldo']."', 
		'".$tgl."' )");
		
	}
	
	if($_POST['mod']=='1') {	
		mysql_query("UPDATE ak_saldo_awal SET 
		TANGGAL = '".$tgl."', 
		JUMLAH = '".$_POST['saldo']."'
		WHERE ID ='".$_POST['gid']."' ;");
		
	}
		
}

} 
//<!-- END TIPE MODE 6 --> 
?>

