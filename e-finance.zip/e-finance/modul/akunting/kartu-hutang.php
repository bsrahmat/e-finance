<?php
require_once '../../library/connectionmysql.php';
Connected();
	$perm = array();
	$perm = getPermissions('51');

	if($perm[-1]=='1') { require_once '../../library/error-popup.php'; die; }
?>
<?
if(isAdd())
{
?>
<div class="popup-shadow" style="width: 600px;">
	<div class="popup-header">
         <span>Kartu Hutang</span>
         <div class="popup-close">X</div>
    </div>
    <div class="popup-body">
        <form action="modul/laporan/report3.php" target="_blank" method="post">
          <table>
            <tr>
          	  <td width="25%">Supplier</td>
              <td width="1%"align="center">:</td>
              <td>
              	<select name="supplier" class="select-text select-small">
                    <option value="">Pilih..</option>
                  <? 	  
                  $qry_Supplier = "select * from suppliers;";
                  $rs_Supplier = mysql_query($qry_Supplier);
//				  $perk=$rows_kasbank['PERK_KASBANK'];
                  while($rows_Supplier=mysql_fetch_array($rs_Supplier)) {
                  ?>
                    <option value="<? echo $rows_Supplier['id']?>"><? echo $rows_Supplier['name']; ?> </option>
                  <? } ?>
      			</select>
              </td>
          	</tr>
        </table>
        <input name="target" value="<? echo md5('cetak-KrtHtg') ?>" type="text"/>
        </form>
    </div>
    <div class="popup-footer">
    	<div class="popup-cancel">Batal</div>
 <!--        <div target="<? //echo md5('cetak-KrtHtg') ?>" type="pdf" link="modul/laporan/report?<? //echo $rows_Supplier[0] ?>" class="pdf-button" >Cetak Kas/Bank</div>	-->
       <div mode="9" link="library/submenu/akunting/dt-pembelian" class="popup-button" get="<? echo $rows_Supplier['id'] ?>">Cetak Kartu Hutang</div>
     </div>
</div>
<?
}
?>

<?
if(isSave()) 
{
	$error = array();
	if(!$_POST['supplier']) $error[] = 'supplier:Silahkan Masukkan Supplier.';
	
	
	if(count($error)>0) {
	//tampilkan pesan error, jika ada error.. :D
	echo generateError($error);
	
} else {
	
	
}
	
}
?>