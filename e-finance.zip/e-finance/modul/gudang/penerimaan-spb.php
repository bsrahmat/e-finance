<?php
	require_once '../../library/connectionmysql.php';
	Connected();
	
	$perm = array();
	$perm = getPermissions('12');

	if($perm[-1]=='1') { require_once '../../library/error-popup.php'; die; }		
	if(isAdd())  {
		$rs_trprequests = mysql_query("select * FROM spbs LEFT JOIN customers ON (spbs.customer_id = customers.id) LEFT JOIN sales ON (spbs.sale_id = sales.id) LEFT JOIN units ON (spbs.unit_id = units.id) where spbs.id = '".$_GET['gid']."'");
		$rows_trprequests=mysql_fetch_array($rs_trprequests);
	}
//<!-- =========================================================================================================================== -->
?>

<?
//<!-- FORM TIPE MODE 0 = TAMBAH/ADD, TIPE MODE 1 = UBAH/EDIT -->
 if(isAdd()) {
	
 ?>
 
   <div class="popup-shadow" style="width: 600px;">
      <div class="popup-header">
         <span><? if(isAdd()) echo 'Penerimaan SPB'; else echo 'Penolakan Permintaan Pembelian'; ?></span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <form action="modul/gudang/penerimaan-spb.php" method="post">
      <table>
      <tr>
      <td class="center">
      <? if(isAdd()) {?>
      		Diterima SPB <br /><b style="text-decoration: underline;"><? echo $rows_trprequests['spbnom'] ?></b>?
      <? }?>
            
      
      <input type="hidden" name="gid" value="<? echo $_GET['gid'] ?>" />
      <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
      </form>
      </td>
      </tr>
      </table>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel">Cencel</div>
      	<div mode="6" link="library/submenu/gudang/penerimaan-spb" get="" class="popup-button">Ok</div>
        
      </div>
   </div>

<? }  
if(isSave()) { 
	if($_POST['mod']=='0') {
		mysql_query("UPDATE spbs SET istake = '1' WHERE id ='".$_POST['gid']."';");
		mysql_query("INSERT INTO sjs (spb_id, unitid) VALUES ('".$_POST['gid']."', '".$_SESSION['galaxy_unit']."')");
	}
	
} 
//<!-- END TIPE MODE 6 --> 
?>

