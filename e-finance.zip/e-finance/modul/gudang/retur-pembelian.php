<?php
	require_once '../../library/connectionmysql.php';
	Connected();
	
	$perm = array();
	$perm = getPermissions('11');
	if($perm[-1]=='1') { require_once '../../library/error-popup.php'; die; }
	
	if(isEdit()) {
		$rs_breturs = mysql_query("SELECT * FROM breturs  WHERE id = '".$_GET['gid']."'");
		$rows_breturs=mysql_fetch_array($rs_breturs);
	}
	if(isAdd()) {
		 $rs_units = mysql_query("select * from units where id = '".$_SESSION['galaxy_unit']."'");
		 $rows_units=mysql_fetch_array($rs_units);
		 $retnom = IDTransRet($rows_units['code']);
		 $id = 'id';
		 $table = 'breturs';
		 $id = Kode($id,$table);
	}
		
?>

<?
//<!-- FORM TIPE MODE 0 = TAMBAH/ADD, TIPE MODE 1 = UBAH/EDIT -->
 if(isAdd() || isEdit()) {
 ?>
 
   <div class="popup-shadow" style="width: 600px;">
      <div class="popup-header">
         <span><? if(isAdd()) {echo 'Tambah Retur Pembelian'; } if(isEdit()) {echo 'Edit Retur Pembelian'; }  ?></span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <form action="modul/gudang/retur-pembelian.php" method="post">
      <table>
      <tr>
      <td width="27%">No. Retur</td>
      <td width="5%" align="center">:</td>
      <td><input class="input-text" name="prnom-disable" type="text" value="<? if(isEdit()) echo $rows_breturs['retnom'] ?><? if(isAdd()) echo $retnom ?>" readonly="readonly"></td>
      </tr>
      <tr>
      <td>No. LPB</td>
      <td align="center">:</td>
      <td><select name="trrgood_id" class="select-text select-small" <? if(isEdit()) { echo 'disabled="disabled"'; } ?>>
      	<option value="">Pilih..</option>
      <? 	  
	  $qry_trrgoods = '';
	  if($_SESSION['galaxy_type']=='0')	{
		  $qry_trrgoods = "select * from trrgoods WHERE unitid != '10' AND isposted = '1' AND is_bayar != '2' order by id;";
	  }
	  else{
	  	$qry_trrgoods = "select * from trrgoods WHERE unitid = '".$_SESSION['galaxy_unit']."'  AND isposted = '1' AND is_bayar != '2' order by id;";
	  } 
	  $rs_trrgoods = mysql_query($qry_trrgoods);
	  while($rows_trrgoods=mysql_fetch_array($rs_trrgoods)) {
		  
	  ?>
        <option value="<? echo $rows_trrgoods['id']?>" <? if(isEdit()) if($rows_trrgoods['id']==$rows_breturs['trrgood_id']) echo 'selected'; ?>><? echo $rows_trrgoods['rgnom']; ?></option>
      <? } ?>
      </select></td>
      </tr>
      <tr>
      <td>Tanggal</td>
      <td align="center">:</td>
      <td><input class="input-text" name="retdate" type="datepicker" value="<? if(isEdit()) echo cDate($rows_breturs['retdate']) ?><? if(isAdd()) echo cDate(date('Y-m-d')) ?>" /></td>
      </tr>
      </table>
      <input type="hidden" name="retnom" value="<? if(isEdit()) echo $rows_breturs['retnom'] ?><? if(isAdd()) echo $retnom ?>" />
      <input type="hidden" name="gid" value="<? if(isEdit()) echo $_GET['gid'] ?><? if(isAdd()) echo $id ?>" />
      <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
      
      </form>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel">Batal</div>
      	<div mode="6" link="library/submenu/gudang/detail/retur-pembelian" class="popup-button" get="<? if(isEdit()) echo $_GET['gid'] ?><? if(isAdd()) echo $id ?>">Simpan</div>
      </div>
   </div>

<? }  ?>

<? 
if(isConfirmDelete()) {
	$rs_breturs = mysql_query("select * from breturs where id = '".$_GET['gid']."'");
	$rows_breturs=mysql_fetch_array($rs_breturs);
?>
   <div class="popup-shadow" style="width: 500px;">
      <div class="popup-header">
         <span>Notifikasi Hapus</span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <form action="modul/gudang/retur-pembelian.php" method="post">
      <table>
      <tr>
      <td class="center">
  
      		<strong>Peringatan</strong>: <br /> 
      		Data <b>Retur Pembelianr</b> akan ikut terhapus, jika ada data yang terhubung!.
      		<br /><br />
      		Apakah anda yakin menghapus Kode : <b style="text-decoration: underline;"><? echo $rows_breturs['retnom'] ?></b>?
      <input type="hidden" name="gid" value="<? echo $_GET['gid'] ?>" />
      <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
     
      </td>
      </tr>
      </table>
      </form>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel"><? if($_GET['gid']!='') echo 'Batal'; else echo 'Tutup' ?></div>
        <div mode="6" link="library/submenu/gudang/retur-pembelian" class="popup-button" get="">Hapus</div>
      </div>
      
   </div>

<? } 
?>

<? 
if(isApply()) {
	$rs_breturs = mysql_query("select * from breturs where id = '".$_GET['gid']."'");
	$rows_breturs=mysql_fetch_array($rs_breturs);
?>
   <div class="popup-shadow" style="width: 500px;">
      <div class="popup-header">
         <span>Notifikasi Close</span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <form action="modul/gudang/retur-pembelian.php" method="post">
      <table>
      <tr>
      <td class="center">
  
      		<strong>Peringatan</strong>: <br /> 
      		Data <b>Retur Pembelianr</b> Akan Di ajukan Ke Kepala Pembelian!.
      		<br /><br />
      		Dengan No Retur : <b style="text-decoration: underline;"><? echo $rows_breturs['retnom'] ?></b>?
      <input type="hidden" name="gid" value="<? echo $_GET['gid'] ?>" />
      <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
     
      </td>
      </tr>
      </table>
      </form>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel"><? if($_GET['gid']!='') echo 'Batal'; else echo 'Tutup' ?></div>
        <div mode="6" link="library/submenu/gudang/retur-pembelian" class="popup-button" get="">Proses</div>
      </div>
      
   </div>

<? } 
?>


<?
//<!-- TIPE MODE 6 = SAVE/MENYIMPAN -->
 if(isSave()) {
	$error = array();
if($_POST['mod']=='1' || $_POST['mod'] == '0') {
if(!$_POST['retdate']) $error[] = 'retdate:Silahkan masukkan Tanggal Retur.';
}
if($_POST['mod']=='0') {
if(!$_POST['trrgood_id']) $error[] = 'trrgood_id:Silahkan Pilih No LPB.';

}		



if(count($error)>0) {
	echo generateError($error);
	
} else { 
	 
	if($_POST['mod']=='0') {
	mysql_query("INSERT INTO breturs (id, trrgood_id, retdate, retnom, unitid, isclosed) VALUES ('".$_POST['gid']."', '".$_POST['trrgood_id']."', ".isNull($_POST['retdate'],'DATE').", '".$_POST['retnom']."', '".$_SESSION['galaxy_unit']."', '0')");

	}
	if($_POST['mod']=='1') {	
		mysql_query("UPDATE breturs SET retdate = ".isNull($_POST['retdate'],'DATE')." WHERE id ='".$_POST['gid']."';");
	}
	if($_POST['mod']=='2') {	
		mysql_query("DELETE from breturs where id =".$_POST['gid']);
		$qry_bretdetails = "select * from bretdetails JOIN items ON ( bretdetails.item_id = items.id) where bretdetails.bretur_id = '".$_POST['gid']."';";
		$rs_bretdetails = mysql_query($qry_bretdetails);
		while($rows_bretdetailss=mysql_fetch_array($rs_bretdetails)) {
			mysql_query("UPDATE trrgdetails SET trrgstatus = '1' WHERE id ='".$rows_bretdetailss['trrgdetails_id']."';");
			mysql_query("DELETE from bretdetails where bretur_id =".$_POST['gid']);
		}
	}
	if($_POST['mod']=='7') {	
		mysql_query("UPDATE breturs SET isok = '1' WHERE id ='".$_POST['gid']."';");
	}
 }
 }
?>

