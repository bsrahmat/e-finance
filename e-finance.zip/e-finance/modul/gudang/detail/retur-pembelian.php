<?php
	require_once '../../../library/connectionmysql.php';
	Connected();
	$perm = array();
	$perm = getPermissions('11');
	if($perm[-1]=='1') { require_once '../../library/error-popup.php'; die; }		
	if(isAdd())  {
		$rs_breturs = mysql_query("SELECT * FROM breturs WHERE id = '".$_GET['gid']."';");
		$rows_breturs=mysql_fetch_array($rs_breturs);
		$rs_trrgdetails = mysql_query("select * from trrgdetails JOIN items ON ( trrgdetails.item_id = items.id) where trrgdetails.id = '".$_GET['sub']."'");
		$rows_trrgdetails=mysql_fetch_array($rs_trrgdetails);
		
		$rs_total = mysql_query("select SUM(bretdetails.qty) as total from bretdetails JOIN breturs ON (bretdetails.bretur_id = breturs.id) JOIN trrgdetails ON (trrgdetails.trrgood_id = breturs.trrgood_id AND bretdetails.trrgdetails_id = trrgdetails.id) where breturs.trrgood_id = '".$rows_breturs['trrgood_id']."' AND breturs.isacc != '0' AND bretdetails.trrgdetails_id = '".$_GET['sub']."'");
		$rows_total=mysql_fetch_array($rs_total);
		
		$total = $rows_trrgdetails['qty'] - $rows_total[0];
		
	}
 if(isAdd()) {
 ?>

   <div class="popup-shadow" style="width: 500px;">
      <div class="popup-header">
         <span>Notifikasi</span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <form action="modul/gudang/detail/retur-pembelian.php" method="post">
      <table>
      <tr>
      <td class="center">Tambahkan Ke Daftar Retur : <b style="text-decoration: underline;"><? echo $rows_breturs['retnom'] ?></b><br /><? echo $rows_trrgdetails['name'] ?><input type="hidden" name="qty" value="<? echo $total ?>" /></td>
      </tr>
      </table>
      
      <input type="hidden" name="item_id" value="<? echo $rows_trrgdetails['item_id'] ?>" />
      <input type="hidden" name="trrgood_id" value="<? echo $_GET['gid'] ?>" />
      
      <input type="hidden" name="price" value="<? echo $rows_trrgdetails['hpp'] ?>" />
      <input type="hidden" name="ppnperitem" value="<? echo $rows_trrgdetails['ppnperitem'] ?>" />
      
      <input type="hidden" name="sub" value="<? echo $_GET['sub'] ?>" />
      <input type="hidden" name="gid" value="<? echo $_GET['gid'] ?>" />
      <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
      </form>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel">Batal</div>
      	<div mode="6" link="library/submenu/gudang/detail/retur-pembelian" class="popup-button" get="<? echo $_GET['gid'] ?>">Tambahkan</div>
      </div>
   </div>

<? } 

if(isEdit()) {
	$rs_trporders = mysql_query("select * from bretdetails JOIN items ON (bretdetails.item_id = items.id) where bretdetails.id = '".$_GET['sub']."'");
	$rows_trporders=mysql_fetch_array($rs_trporders);
 ?>

   <div class="popup-shadow" style="width: 650px;">
      <div class="popup-header">
         <span>Edit Trpodetail</span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <form action="modul/gudang/detail/retur-pembelian.php" method="post">
      <table>
      <tr>
      <td width="25%">Nama Barang</td>
      <td width="5%" align="center">:</td>
      <td><input class="input-text" name="name-disable" type="text" value="<? echo $rows_trporders['name'] ?>"  disabled="disabled"></td>
      </tr>
      <tr>
      <td>Jumlah</td>
      <td align="center">:</td>
      <td><input class="input-text currency" name="qty" type="text" value="<? echo cFormat($rows_trporders[3], false) ?>"></td>
      </tr>
      <tr>
      <td>Keterangan</td>
      <td align="center">:</td>
      <td><textarea rows="3" class="input-text" name="description" type="text"><? echo $rows_trporders['description'] ?></textarea></td>
      </tr>
      
      
      </table>
      <input type="hidden" name="qty2" value="<? echo cFormat($rows_trporders[3], false) ?>" />
      <input type="hidden" name="ppnperitem" value="<? echo $rows_trporders['ppnperitem'] ?>" />
      <input type="hidden" name="item_id" value="<? echo $rows_trporders['item_id'] ?>" />
      
      
      
      <input type="hidden" name="sub" value="<? echo $_GET['sub'] ?>" />
      <input type="hidden" name="gid" value="<? echo $_GET['gid'] ?>" />
      <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
      </form>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel">Batal</div>
      	<div mode="6" link="library/submenu/gudang/detail/retur-pembelian" class="popup-button" get="<? echo $_GET['gid'] ?>">Simpan</div>
      </div>
   </div>

<? }  
//<!-- END FORM -->

//<!-- =========================================================================================================================== -->
?>

<? 
//<!-- FORM TIPE MODE 2 = CONFIRM DELETE/KONFIRMASI HAPUS, TIPE MODE 4 = CONFIRM DELETE SELECTED/KONFIRMASI HAPUS YANG DIPILIH -->
if(isConfirmDelete()) { ?>
<?
	if(isConfirmDelete()) {
		$rs_trporders = mysql_query("select * from bretdetails JOIN items ON ( bretdetails.item_id = items.id) where bretdetails.id = '".$_GET['sub']."'");
		$rows_trporders=mysql_fetch_array($rs_trporders);
	}
?>
   <div class="popup-shadow" style="width: 500px;">
      <div class="popup-header">
         <span>Konfirmasi Hapus</span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <form action="modul/gudang/detail/retur-pembelian.php" method="post">
      <table>
      <tr>
      <td class="center">
      <? if(isConfirmDelete()) {?>
      		Apakah anda yakin menghapus <br /><b style="text-decoration: underline;"><? echo $rows_trporders['name'] ?></b>?
      <? }?>
      
      
      </td>
      </tr>
      </table>
          
      
      <input type="hidden" name="sub" value="<? echo $_GET['sub'] ?>" />
      <input type="hidden" name="trrgdetails_id" value="<? echo $rows_trporders['trrgdetails_id'] ?>" />
      <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
      </form>
      </div>
      <div class="popup-footer">
        <div class="popup-cancel">Batal</div>
      	<div mode="6" link="library/submenu/gudang/detail/retur-pembelian" class="popup-button" get="<? echo $_GET['gid'] ?>">Hapus</div>
      	
      </div>
      
   </div>

<? } 



 if(isSave()) {
$error = array();
if($_POST['mod']=='0') {
	$qty = str_replace(',','',$_POST['qty']);
	$qty2 = str_replace(',','',$_POST['qty2']);
	if(!$_POST['qty']) $error[] = 'qty:Jumlah Yang diretur sudah Melebihi target Pembelian';
}

if($_POST['mod']=='1') {
	$qty = str_replace(',','',$_POST['qty']);
	$qty2 = str_replace(',','',$_POST['qty2']);
	if($qty > $qty2) $error[] = 'qty:Jumlah Tidak Boleh Lebih Besar Dari .'.cFormat($qty2,false);
}
		

if(count($error)>0) {
	echo generateError($error);
	
} else {  
	if($_POST['mod']=='0') {
		mysql_query("INSERT INTO bretdetails (bretur_id, item_id, qty, price , ppnperitem, trrgdetails_id) VALUES ('".$_POST['gid']."', '".$_POST['item_id']."', '".$_POST['qty']."', '".$_POST['price']."', '".$_POST['ppnperitem']."', '".$_POST['sub']."')");
		mysql_query("UPDATE trrgdetails SET trrgstatus = '0' WHERE id ='".$_POST['sub']."';");
	}
	
	if($_POST['mod']=='1') {	
		mysql_query("UPDATE bretdetails SET qty = ".isNull($_POST['qty'],'CUR').", description = '".$_POST['description']."' WHERE id ='".$_POST['sub']."';");
	}
	if($_POST['mod']=='2') {
		mysql_query("UPDATE  trrgdetails SET trrgstatus = '1' WHERE id ='".$_POST['trrgdetails_id']."';");
		mysql_query("DELETE from bretdetails where id ='".$_POST['sub']."'");
		
	}
}


 }
//<!-- END TIPE MODE 6 --> 
?>

