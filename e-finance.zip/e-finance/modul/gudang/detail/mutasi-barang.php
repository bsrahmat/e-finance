<?php
	require_once '../../../library/connectionmysql.php';
	Connected();
			
	if(isEdit())  {
		$rs_mvdetails = mysql_query("select * from mvdetails JOIN items ON (mvdetails.item_id = items.id) where mvdetails.id = '".$_GET['sub']."'");
		$rows_mvdetails=mysql_fetch_array($rs_mvdetails);
	}
$perm = array();
$perm = getPermissions('15');
if($perm[-1]=='1') { require_once '../../library/error-popup.php'; die; }
?>

<?
//<!-- FORM TIPE MODE 0 = TAMBAH/ADD, TIPE MODE 1 = UBAH/EDIT -->
 if(isAdd() || isEdit()) {
	 $rs_moveitems = mysql_query("select * from moveitems where id = '".$_GET['gid']."'");
	 $rows_moveitems=mysql_fetch_array($rs_moveitems);
	 
	 
	 
	 
	 
	 //$id = UnitIDs(id,mvdetails);
	 //$prnom = IDTrans();
 ?>
<style>
.ui-autocomplete-loading { background: white url('images/load.gif') right center no-repeat; }
</style>
   <div class="popup-shadow" style="width: 600px;">
      <div class="popup-header">
         <span><? if(isAdd()) echo 'Tambah Data'; else echo 'Edit Data'; ?></span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <form action="modul/gudang/detail/mutasi-barang.php" method="post">
      <table>
      <tr>
      <td width="25%">Nama Barang</td>
      <td width="5%"  align="center">:</td>
      <td><input class="input-text" name="nama_barang" type="text" value="<? if(isEdit()) echo $rows_mvdetails['name'] ?>" /></td>
      </tr>
      <tr>
      <td>Jumlah</td>
      <td align="center">:</td>
      <td><input class="input-text currency padmin" name="qty" type="text" value="<? if(isEdit()) echo cFormat($rows_mvdetails['qty'],false) ?>" /></td>
      </tr>
      
      </table>
      <? if(isEdit())  {?>
      <input type="hidden" name="gid2" value="<? echo $_GET['sub'] ?>" />
      <input type="hidden" name="kode" value="<? echo $rows_mvdetails['item_id'] ?>" />
      <? }?>
      <input type="hidden" name="item_id" value="<? if(isEdit()) echo $rows_mvdetails['item_id'] ?>" />
      <input type="hidden" name="gid" value="<? echo $_GET['gid'] ?>" />
      <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
      
      <input type="hidden" name="unit_id" value="<? echo $rows_moveitems['unit_id'] ?>" />
      <input type="hidden" name="warehouse1_id" value="<? echo $rows_moveitems['warehouse1_id'] ?>" />
      </form>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel">Batal</div>
      	<div mode="6" link="library/submenu/gudang/detail/mutasi-barang" class="popup-button" get="<? echo $_GET['gid'] ?>">Simpan</div>
      </div>
   </div>

<? }  
//<!-- END FORM -->

//<!-- =========================================================================================================================== -->
?>

<? 
//<!-- FORM TIPE MODE 2 = CONFIRM DELETE/KONFIRMASI HAPUS, TIPE MODE 4 = CONFIRM DELETE SELECTED/KONFIRMASI HAPUS YANG DIPILIH -->
if(isConfirmDelete() || isConfirmDeleteSelected()) { ?>
<?
	if(isConfirmDelete()) {
		$rs_mvdetails = mysql_query("select * from mvdetails JOIN items ON (mvdetails.item_id = items.id) where mvdetails.id = '".$_GET['gid']."'");
		$rows_mvdetails=mysql_fetch_array($rs_mvdetails);
	}
?>
   <div class="popup-shadow" style="width: 500px;">
      <div class="popup-header">
         <span>Konfirmasi Hapus</span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <table>
      <tr>
      <td class="center">
      <? if(isConfirmDelete()) {?>
      		Apakah anda yakin menghapus <br /><b style="text-decoration: underline;"><? echo $rows_mvdetails['name'] ?></b>?
      <? }?>
      
      <? if(isConfirmDeleteSelected()) {?>
      		<? if($_GET['gid']!='') { 
				$value = array();
				$value = generateArray($_GET['gid']); 
			?>
            	<strong>Peringatan: </strong><br /> Data <b>Satuan Barang</b> akan ikut terhapus, jika ada data yang terhubung!.
      		<br /><br />
                Sebanyak <b style="text-decoration: underline;"><? echo count($value) ?> item</b> yang akan dihapus!.<br />
                Apakah anda yakin untuk menghapusnya?
            <? } else { ?>
            	Tidak ada item yang akan dihapus.<br />Silahkan anda memilih check box untuk dicentang.
            <? } ?>
      <? }?>
      </td>
      </tr>
      </table>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel"><? if($_GET['gid']!='') echo 'Batal'; else echo 'Tutup' ?></div>
        <? if(isConfirmDelete()) { ?>
      		<div mode="3" link="modul/gudang/detail/mutasi-barang?<? echo $_GET['gid'] ?>" class="popup-button">Hapus</div>
        <? }?>
      	<? if(isConfirmDeleteSelected()) {
			if($_GET['gid']!='') {
				if(count($value)>0)
		?>
      		<div mode="5" link="modul/gudang/mutasi-barang?<? echo htmlspecialchars($_GET['gid']) ?>" class="popup-button">Hapus</div>
        <? } } ?>
      </div>
      
   </div>

<? } 

?>

<?
 if(isDelete()) {
	 
	//mysql_query("DELETE from mvdetails where moveitem_id =".$_GET['gid']);
	mysql_query("DELETE from mvdetails where id ='".$_GET['gid']."'");
	
 } ?>
 
<?
//<!-- END TIPE MODE 3 -->

//<!-- =========================================================================================================================== -->

//<!-- TIPE MODE 5 = DELETE SELECTED/HAPUS YANG DIPILIH -->
?>

<? if(isDeleteSelected()) { 
	
	$value = array();
	$value = generateArray($_GET['gid']); 

	// Taruh query ke database untuk menghapus disini...
	// Contoh :
	for($i=0;$i<count($value);$i++) {
		mysql_query("DELETE from mvdetails where moveitem_id = '".$value[$i]."'");
	 	mysql_query("DELETE from mvdetails where id = '".$value[$i]."'");
	}
	
 } 
//<!-- END TIPE MODE 5 -->

//<!-- =========================================================================================================================== -->
?>

<?
//<!-- TIPE MODE 6 = SAVE/MENYIMPAN -->
 if(isSave()) { 

$error = array();


if(!$_POST['item_id']) $error[] = 'nama_barang:Silahkan Masukkan Nama Barang.';
if(!$_POST['qty']) $error[] = 'qty:Silahkan Masukkan Jumlah Barang.';

//$tmp = explode('/',$_POST['item_id']);

$rs_check = mysql_query("select * from mvdetails where moveitem_id = '".$_POST['gid']."' AND item_id = UPPER('".$_POST['item_id']."')");
$rows_check = mysql_num_rows($rs_check);

if($_POST['mod']=='0')
	if($rows_check>0) $error[] = 'nama_barang:Maaf Barang Sudah Masuk Dalam List.';

if($_POST['mod']=='1') 
	if($_POST['kode']!=strtoupper($_POST['item_id']))
		if($rows_check>0) $error[] = 'nama_barang:Maaf Barang Sudah Masuk Dalam List.';
		
			$rows_awal=mysql_fetch_array(mysql_query("select SUM(qty) AS awal from stockitems where transtype_id ='1' AND warehouse_id = '".$_POST['warehouse1_id']."' AND unit_id = '".$_POST['unit_id']."' and item_id = '".$_POST['item_id']."'"));
			$rows_pembelian=mysql_fetch_array(mysql_query("select SUM(qty) AS pembelian from stockitems where transtype_id ='2' AND warehouse_id = '".$_POST['warehouse1_id']."' AND unit_id = '".$_POST['unit_id']."' and item_id = '".$_POST['item_id']."'"));		
			$rows_penjualan=mysql_fetch_array(mysql_query("select SUM(qty) AS penjualan from stockitems where transtype_id ='3'  AND warehouse_id = '".$_POST['warehouse1_id']."' AND unit_id = '".$_POST['unit_id']."' and item_id = '".$_POST['item_id']."'"));
			$rows_retur_beli=mysql_fetch_array(mysql_query("select SUM(qty) AS retur_beli from stockitems where transtype_id ='4' AND warehouse_id = '".$_POST['warehouse1_id']."' AND unit_id = '".$_POST['unit_id']."' and item_id = '".$_POST['item_id']."'"));
			$rows_retur_jual=mysql_fetch_array(mysql_query("select SUM(qty) AS retur_jual from stockitems where transtype_id ='5' AND warehouse_id = '".$_POST['warehouse1_id']."' AND unit_id = '".$_POST['unit_id']."' and item_id = '".$_POST['item_id']."'"));
			$rows_mvmasuk=mysql_fetch_array(mysql_query("select SUM(qty) AS mvmasuk from stockitems where transtype_id ='6' AND warehouse_id = '".$_POST['warehouse1_id']."' AND unit_id = '".$_POST['unit_id']."' and item_id = '".$_POST['item_id']."'"));
			$rows_mvkeluar=mysql_fetch_array(mysql_query("select SUM(qty) AS mvkeluar from stockitems where transtype_id ='7' AND warehouse_id = '".$_POST['warehouse1_id']."' AND unit_id = '".$_POST['unit_id']."' and item_id = '".$_POST['item_id']."'"));
			
			$debet = $rows_pembelian['pembelian'] + $rows_retur_jual['retur_jual'] + $rows_mvmasuk['mvmasuk'] ;
			$kridit = $rows_penjualan['penjualan'] + $rows_retur_beli['retur_beli'] + $rows_mvkeluar['mvkeluar'] ;
			$akhir = $rows_awal['awal'] + ($debet - $kridit);	
			
			if($akhir == 0) $error[] = 'nama_barang:Maaf Jumlah Barang Dalam gudang Kosong.';
			$qty = str_replace(',','',$_POST['qty']);
			if($qty > $akhir) $error[] = 'qty:Maaf Jumlah Barang Terlalu Besar.';
				

		

if(count($error)>0) {
	echo generateError($error);
	
} else {
	
	if($_POST['mod']=='0') {
		mysql_query("INSERT INTO mvdetails (moveitem_id, item_id, qty) VALUES ('".$_POST['gid']."', '".$_POST['item_id']."', ".isNull($_POST['qty'],'CUR').")");
		
	}
	
	if($_POST['mod']=='1') {	
		mysql_query("UPDATE mvdetails SET item_id = '".$_POST['item_id']."', qty = ".isNull($_POST['qty'],'CUR')." WHERE id ='".$_POST['gid2']."';");
	}
}

} 
//<!-- END TIPE MODE 6 --> 
?>

