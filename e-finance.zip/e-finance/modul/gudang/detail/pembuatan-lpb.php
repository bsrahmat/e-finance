<?php
	require_once '../../../library/connectionmysql.php';
	Connected();
	
$perm = array();
$perm = getPermissions('10');

if(file_exists('../../error-menu.php')) if($perm[-1]=='1') { require_once '../../error-menu.php'; die; }
		
	if(isAdd())  {
		$rs_trpodetails = mysql_query("select * from trpodetails JOIN items ON ( trpodetails.item_id = items.id) where trpodetails.id = '".$_GET['sub']."'");
		$rows_trpodetails=mysql_fetch_array($rs_trpodetails);
		
		$rs_trrgoods = mysql_query("SELECT * FROM trrgoods LEFT JOIN trporders ON (trrgoods.trporder_id = trporders.id) LEFT JOIN suppliers ON (trporders.supplier_id = suppliers.id) WHERE trrgoods.id = '".$_GET['gid']."';");
		$rows_trporders=mysql_fetch_array($rs_trrgoods);
		
	}
	
//<!-- =========================================================================================================================== -->
?>

<?
//<!-- FORM TIPE MODE 0 = TAMBAH/ADD, TIPE MODE 1 = UBAH/EDIT -->
 if(isAdd()) {
	 //$id = UnitIDs(id,trporders);
	 //$prnom = IDTrans();
 ?>

   <div class="popup-shadow" style="width: 500px;">
      <div class="popup-header">
         <span>Tambah LPB</span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <form action="modul/gudang/detail/pembuatan-lpb.php" method="post">
      <table>
      <tr>
      <td class="center">Tambahkan Ke LPB : <b style="text-decoration: underline;"><? echo $rows_trporders['rgnom'] ?></b><br /><? echo $rows_trpodetails['name'] ?></td>
      </tr>
      </table>
      
      <input type="hidden" name="item_id" value="<? echo $rows_trpodetails['item_id'] ?>" />
      <input type="hidden" name="trrgood_id" value="<? echo $_GET['gid'] ?>" />
      <input type="hidden" name="qty" value="<? echo $rows_trpodetails['qty'] ?>" />
      <input type="hidden" name="rest" value="<? echo $rows_trpodetails['rest'] ?>" />
      <input type="hidden" name="hpp" value="<? echo $rows_trpodetails['price'] ?>" />
      <input type="hidden" name="tax" value="<? echo $rows_trpodetails['tax'] ?>" />
      
      <input type="hidden" name="sub" value="<? echo $_GET['sub'] ?>" />
      <input type="hidden" name="gid" value="<? echo $_GET['gid'] ?>" />
      <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
      </form>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel">Batal</div>
      	<div mode="6" link="library/submenu/gudang/detail/pembuatan-lpb" class="popup-button" get="<? echo $_GET['gid'] ?>">Tambahkan</div>
      </div>
   </div>

<? } 

if(isEdit()) {
	$rs_trporders = mysql_query("select * from trrgdetails LEFT JOIN items ON ( trrgdetails.item_id = items.id) LEFT JOIN trpodetails ON (trrgdetails.trpodetail_id = trpodetails.id) where trrgdetails.id = '".$_GET['sub']."'");
	$rows_trporders=mysql_fetch_array($rs_trporders);
 ?>

   <div class="popup-shadow" style="width: 650px;">
      <div class="popup-header">
         <span>Edit Trpodetail</span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <form action="modul/gudang/detail/pembuatan-lpb.php" method="post">
      <table>
      <tr>
      <td width="25%">Nama Barang</td>
      <td width="5%" align="center">:</td>
      <td><input class="input-text" name="name-disable" type="text" value="<? echo $rows_trporders['name'] ?>"  disabled="disabled"></td>
      </tr>
      <tr>
      <td>Jumlah</td>
      <td align="center">:</td>
      <td><input class="input-text currency" name="qty" type="text" value="<? echo cFormat($rows_trporders[3], false) ?>"></td>
      </tr>
      <tr>
      <td>Pcs Per Satuan (Qty*Pcs)</td>
      <td align="center">:</td>
      <td><input class="input-text currency padmin" name="pcs-qty" type="text" value="<? echo cFormat($rows_trporders[3]*$rows_trporders['pcs'], false) ?>" disabled="disabled"></td>
      </tr>
      
      
      </table>
      <input type="hidden" name="qty2" value="<? echo cFormat($rows_trporders['rest'], false) ?>" />
      <input type="hidden" name="ppnperitem" value="<? echo $rows_trporders['ppnperitem'] ?>" />
      <input type="hidden" name="item_id" value="<? echo $rows_trporders['item_id'] ?>" />
      <input type="hidden" name="hpp" value="<? echo $rows_trporders['hpp'] ?>" />
      
      
      
      <input type="hidden" name="sub" value="<? echo $_GET['sub'] ?>" />
      <input type="hidden" name="gid" value="<? echo $_GET['gid'] ?>" />
      <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
      </form>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel">Batal</div>
      	<div mode="6" link="library/submenu/gudang/detail/pembuatan-lpb" class="popup-button" get="<? echo $_GET['gid'] ?>">Simpan</div>
      </div>
   </div>

<? }  
//<!-- END FORM -->

//<!-- =========================================================================================================================== -->
?>

<? 
//<!-- FORM TIPE MODE 2 = CONFIRM DELETE/KONFIRMASI HAPUS, TIPE MODE 4 = CONFIRM DELETE SELECTED/KONFIRMASI HAPUS YANG DIPILIH -->
if(isConfirmDelete()) { ?>
<?
	if(isConfirmDelete()) {
		$rs_trporders = mysql_query("select * from trrgdetails JOIN items ON ( trrgdetails.item_id = items.id) where trrgdetails.id = '".$_GET['sub']."'");
		$rows_trporders=mysql_fetch_array($rs_trporders);
	}
?>
   <div class="popup-shadow" style="width: 500px;">
      <div class="popup-header">
         <span>Konfirmasi Hapus</span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <form action="modul/gudang/detail/pembuatan-lpb.php" method="post">
      <table>
      <tr>
      <td class="center">
      <? if(isConfirmDelete()) {?>
      		Apakah anda yakin menghapus <br /><b style="text-decoration: underline;"><? echo $rows_trporders['name'] ?></b>?
      <? }?>
      
      
      </td>
      </tr>
      </table>
          
      
      <input type="hidden" name="sub" value="<? echo $_GET['sub'] ?>" />
      <input type="hidden" name="trpodetail_id" value="<? echo $rows_trporders['trpodetail_id'] ?>" />
      <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
      </form>
      </div>
      <div class="popup-footer">
        <div class="popup-cancel">Batal</div>
      	<div mode="6" link="library/submenu/gudang/detail/pembuatan-lpb" class="popup-button" get="<? echo $_GET['gid'] ?>">Hapus</div>
      	
      </div>
      
   </div>

<? } 



 if(isSave()) {
$error = array();
if($_POST['mod']=='1') {
	$qty = str_replace(',','',$_POST['qty']);
	$qty2 = str_replace(',','',$_POST['qty2']);
	if($qty > $qty2) $error[] = 'qty:Jumlah Tidak Boleh Lebih Besar Dari .'.cFormat($qty2,false);
}
		

if(count($error)>0) {
	echo generateError($error);
	
} else {  
	if($_POST['mod']=='0') {
		
		$debt = ($_POST['rest']*$_POST['hpp']) + ($_POST['tax']*$_POST['rest']);
		mysql_query("INSERT INTO trrgdetails (item_id, trrgood_id, qty, hpp, hpptot, debt, trpodetail_id, ppn, ppnperitem) VALUES ('".$_POST['item_id']."', '".$_POST['trrgood_id']."', '".$_POST['rest']."', '".$_POST['hpp']."', '".$_POST['rest']*$_POST['hpp']."', '".$debt."', '".$_POST['sub']."', '".$_POST['tax']*$_POST['rest']."', '".$_POST['tax']."')");
		mysql_query("UPDATE trpodetails SET trpostatus = '0' WHERE id ='".$_POST['sub']."';");
		
	}
	
	if($_POST['mod']=='1') {
		$debt = ($qty*$_POST['hpp']) + ($_POST['ppnperitem']*$qty);	
		mysql_query("UPDATE trrgdetails SET qty = ".isNull($_POST['qty'],'CUR').", ppn = '".$_POST['ppnperitem']*$qty."', hpptot = '".$qty*$_POST['hpp']."', debt = '".$debt."' WHERE id ='".$_POST['sub']."';");
		
		mysql_query("UPDATE items SET isupdate = '0' WHERE id ='".$_POST['item_id']."';");
	}
	if($_POST['mod']=='2') {
		mysql_query("UPDATE  trpodetails SET trpostatus = '1' WHERE id ='".$_POST['trpodetail_id']."';");
		mysql_query("DELETE from trrgdetails where id ='".$_POST['sub']."'");
		
	}
}


 }
//<!-- END TIPE MODE 6 --> 
?>

