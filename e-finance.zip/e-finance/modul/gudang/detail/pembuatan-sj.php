<?php
	require_once '../../../library/connectionmysql.php';
	Connected();
	$perm = array();
	$perm = getPermissions('13');

	if($perm[-1]=='1') { require_once '../../library/error-popup.php'; die; }
			
	if(isAdd())  {
		$rs_sjdetails = mysql_query("select * from spbdetails JOIN items ON ( spbdetails.item_id = items.id) where spbdetails.id = '".$_GET['sub']."'");
		$rows_sjdetails=mysql_fetch_array($rs_sjdetails);
		
		$rs_sjs = mysql_query("SELECT * FROM sjs LEFT JOIN spbs ON (sjs.spb_id = spbs.id) WHERE sjs.id = '".$_GET['gid']."';");
		$rows_spbs=mysql_fetch_array($rs_sjs);
		
	}
	
//<!-- =========================================================================================================================== -->
?>

<?
//<!-- FORM TIPE MODE 0 = TAMBAH/ADD, TIPE MODE 1 = UBAH/EDIT -->
 if(isAdd()) {
	 //$id = UnitIDs(id,spbs);
	 //$prnom = IDTrans();
 ?>

   <div class="popup-shadow" style="width: 500px;">
      <div class="popup-header">
         <span>Notifikasi</span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <form action="modul/gudang/detail/pembuatan-sj.php" method="post">
      <table>
      <tr>
      <td class="center">Tambahkan Ke SJ : <b style="text-decoration: underline;"><? echo $rows_spbs['sjnom'] ?></b><br /><? echo $rows_sjdetails['name'] ?>
      <input type="hidden" name="notif" /></td>
      </tr>
      </table>
      <input type="hidden" name="item_id" value="<? echo $rows_sjdetails['item_id'] ?>" />
      <input type="hidden" name="sj_id" value="<? echo $_GET['gid'] ?>" />
      <input type="hidden" name="qty" value="<? echo $rows_sjdetails['qty'] ?>" />
      <input type="hidden" name="rest" value="<? echo $rows_sjdetails['rest'] ?>" />
      <input type="hidden" name="price" value="<? echo $rows_sjdetails['price'] ?>" />
      <input type="hidden" name="stock" value="<? echo $rows_sjdetails['stock'] ?>" />
      <input type="hidden" name="disc" value="<? echo $rows_sjdetails['disc'] ?>" />
      <input type="hidden" name="ppnperitem" value="<? echo $rows_sjdetails['ppnperitem'] ?>" />
      
      
      <input type="hidden" name="sub" value="<? echo $_GET['sub'] ?>" />
      <input type="hidden" name="gid" value="<? echo $_GET['gid'] ?>" />
      <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
      </form>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel">Batal</div>
      	<div mode="6" link="library/submenu/gudang/detail/pembuatan-sj" class="popup-button" get="<? echo $_GET['gid'] ?>">Tambahkan</div>
      </div>
   </div>

<? } 

if(isEdit()) {
	$rs_spbs = mysql_query("select * from sjdetails LEFT JOIN items ON ( sjdetails.item_id = items.id) LEFT JOIN spbdetails ON (sjdetails.spbdetails_id = spbdetails.id) where sjdetails.id = '".$_GET['sub']."'");
	$rows_spbs=mysql_fetch_array($rs_spbs);
 ?>

   <div class="popup-shadow" style="width: 650px;">
      <div class="popup-header">
         <span>Edit Trpodetail</span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <form action="modul/gudang/detail/pembuatan-sj.php" method="post">
      <table>
      <tr>
      <td width="25%">Nama Barang</td>
      <td width="5%" align="center">:</td>
      <td><input class="input-text" name="name-disable" type="text" value="<? echo $rows_spbs['name'] ?>"  disabled="disabled"></td>
      </tr>
      <tr>
      <td>Jumlah</td>
      <td align="center">:</td>
      <td><input class="input-text currency" name="qty" type="text" value="<? echo cFormat($rows_spbs[3], false) ?>"></td>
      </tr>
      <tr>
      <td>Keterangan</td>
      <td align="center">:</td>
      <td><textarea rows="3" class="input-text" name="description" type="text"><? echo $rows_spbs['description'] ?></textarea></td>
      </tr>
      
      
      </table>
      <input type="hidden" name="qty2" value="<? echo cFormat($rows_spbs[27], false) ?>" />
      <input type="hidden" name="item_id" value="<? echo $rows_spbs['item_id'] ?>" />
      
      
      
      <input type="hidden" name="sub" value="<? echo $_GET['sub'] ?>" />
      <input type="hidden" name="gid" value="<? echo $_GET['gid'] ?>" />
      <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
      </form>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel">Batal</div>
      	<div mode="6" link="library/submenu/gudang/detail/pembuatan-sj" class="popup-button" get="<? echo $_GET['gid'] ?>">Simpan</div>
      </div>
   </div>

<? }  
//<!-- END FORM -->

//<!-- =========================================================================================================================== -->
?>

<? 
//<!-- FORM TIPE MODE 2 = CONFIRM DELETE/KONFIRMASI HAPUS, TIPE MODE 4 = CONFIRM DELETE SELECTED/KONFIRMASI HAPUS YANG DIPILIH -->
if(isConfirmDelete()) { ?>
<?
	if(isConfirmDelete()) {
		$rs_spbs = mysql_query("select * from sjdetails JOIN items ON ( sjdetails.item_id = items.id) where sjdetails.id = '".$_GET['sub']."'");
		$rows_spbs=mysql_fetch_array($rs_spbs);
	}
?>
   <div class="popup-shadow" style="width: 500px;">
      <div class="popup-header">
         <span>Konfirmasi Hapus</span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <form action="modul/gudang/detail/pembuatan-sj.php" method="post">
      <table>
      <tr>
      <td class="center">
      <? if(isConfirmDelete()) {?>
      		Apakah anda yakin menghapus <br /><b style="text-decoration: underline;"><? echo $rows_spbs['name'] ?></b>?
      <? }?>
      
      
      </td>
      </tr>
      </table>
          
      
      <input type="hidden" name="sub" value="<? echo $_GET['sub'] ?>" />
      <input type="hidden" name="spbdetails_id" value="<? echo $rows_spbs['spbdetails_id'] ?>" />
      <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
      </form>
      </div>
      <div class="popup-footer">
        <div class="popup-cancel">Batal</div>
      	<div mode="6" link="library/submenu/gudang/detail/pembuatan-sj" class="popup-button" get="<? echo $_GET['gid'] ?>">Hapus</div>
      	
      </div>
      
   </div>

<? } 



 if(isSave()) {
$error = array();
if($_POST['mod']=='1') {
	$qty = str_replace(',','',$_POST['qty']);
	$qty2 = str_replace(',','',$_POST['qty2']);
	if($qty > $qty2) $error[] = 'qty:Jumlah Tidak Boleh Lebih Besar Dari .'.cFormat($qty2,false);
}

if($_POST['mod']=='0') {
	
	if($_POST['qty'] > $_POST['stock']) $error[] = 'notif:Maaf Tidak Bisa Menambahkan Ke SJ,<br /> <b>Stock Kurang</b>';
}
		

if(count($error)>0) {
	echo generateError($error);
	
} else {  
	if($_POST['mod']=='0') {
		mysql_query("INSERT INTO sjdetails (sj_id, item_id, qty, rest , price, disc, ppnperitem, spbdetails_id) VALUES ('".$_POST['sj_id']."', '".$_POST['item_id']."', '".$_POST['rest']."', '".$_POST['rest']."', '".$_POST['price']."', '".$_POST['disc']."','".$_POST['ppnperitem']."','".$_POST['sub']."')");
		mysql_query("UPDATE spbdetails SET spbstatus = '0' WHERE id ='".$_POST['sub']."';");
		
	}
	
	if($_POST['mod']=='1') {	
		mysql_query("UPDATE sjdetails SET qty = ".isNull($_POST['qty'],'CUR').", description = '".$_POST['description']."' WHERE id ='".$_POST['sub']."';");
		
	}
	if($_POST['mod']=='2') {
		mysql_query("UPDATE  spbdetails SET spbstatus = '1' WHERE id ='".$_POST['spbdetails_id']."';");
		mysql_query("DELETE from sjdetails where id ='".$_POST['sub']."'");
		
	}
}


 }
//<!-- END TIPE MODE 6 --> 
?>

