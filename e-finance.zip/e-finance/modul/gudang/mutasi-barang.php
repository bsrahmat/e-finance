<?php
	require_once '../../library/connectionmysql.php';
	Connected();
	
	$perm = array();
	$perm = getPermissions('15');

	if($perm[-1]=='1') { require_once '../../library/error-popup.php'; die; }
			
	if(isEdit())  {
		$rs_moveitems = mysql_query("SELECT Moveitem.id, Moveitem.mvdate, Moveitem.mvnom, Moveitem.warehouse1_id, Moveitem.warehouse2_id, Moveitem.unit_id, Moveitem.description, Moveitem.isclose, Moveitem.id, Warehouse1.id, Warehouse1.code, Warehouse1.name, Warehouse1.location, Warehouse1.whhead, Warehouse2.id, Warehouse2.code, Warehouse2.name, Warehouse2.location, Warehouse2.whhead, Unit.id, Unit.gmanager_id, Unit.name, Unit.code, Unit.address, Unit.phone, Unit.fax, Unit.headsale_id, Unit.rek, Unit.rekname, Unit.pusat, Unit.ismanu FROM moveitems AS Moveitem LEFT JOIN warehouses AS Warehouse1 ON (Moveitem.warehouse1_id = Warehouse1.id) LEFT JOIN warehouses AS Warehouse2 ON (Moveitem.warehouse2_id = Warehouse2.id) LEFT JOIN units AS Unit ON (Moveitem.unit_id = Unit.id) where Moveitem.id = '".$_GET['gid']."'");
		$rows_moveitems=mysql_fetch_array($rs_moveitems);
	}
//<!-- =========================================================================================================================== -->
?>
<?
//<!-- FORM TIPE MODE 0 = TAMBAH/ADD, TIPE MODE 1 = UBAH/EDIT -->
 if(isCencel()) {
	 $rs_moveitems = mysql_query("SELECT Moveitem.id, Moveitem.mvdate, Moveitem.mvnom, Moveitem.warehouse1_id, Moveitem.warehouse2_id, Moveitem.unit_id, Moveitem.description, Moveitem.isclose, Moveitem.id, Warehouse1.id, Warehouse1.code, Warehouse1.name, Warehouse1.location, Warehouse1.whhead, Warehouse2.id, Warehouse2.code, Warehouse2.name, Warehouse2.location, Warehouse2.whhead, Unit.id, Unit.gmanager_id, Unit.name, Unit.code, Unit.address, Unit.phone, Unit.fax, Unit.headsale_id, Unit.rek, Unit.rekname, Unit.pusat, Unit.ismanu FROM moveitems AS Moveitem LEFT JOIN warehouses AS Warehouse1 ON (Moveitem.warehouse1_id = Warehouse1.id) LEFT JOIN warehouses AS Warehouse2 ON (Moveitem.warehouse2_id = Warehouse2.id) LEFT JOIN units AS Unit ON (Moveitem.unit_id = Unit.id) where Moveitem.id = '".$_GET['gid']."'");
	$rows_moveitems=mysql_fetch_array($rs_moveitems);
 ?>
 
   <div class="popup-shadow" style="width: 600px;">
      <div class="popup-header">
         <span>Close Mutasi</span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <form action="modul/gudang/mutasi-barang.php" method="post">
      <table>
      <tr>
      <td class="center">Apakah Anda Mau Menutup Mutasi : <b style="text-decoration: underline;"><? echo $rows_moveitems['mvnom'] ?></b> ?</td>
      </tr>
      
      </table>
      <input type="hidden" name="warehouse1_id" value="<? echo $rows_moveitems['warehouse1_id'] ?>" />
      <input type="hidden" name="warehouse2_id" value="<? echo $rows_moveitems['warehouse2_id'] ?>" />
      <input type="hidden" name="gid" value="<? echo $_GET['gid'] ?>" />
      <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
      <input type="hidden" name="unit_id" value="<? echo $rows_moveitems['unit_id'] ?>" />
      <input type="hidden" name="mvnom" value="<? echo $rows_moveitems['mvnom'] ?>" />
      
      </form>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel">Batal</div>
      	<div mode="6" link="library/submenu/gudang/mutasi-barang" class="popup-button" get="">Simpan</div>
      </div>
   </div>

<? }  ?>
<?
//<!-- FORM TIPE MODE 0 = TAMBAH/ADD, TIPE MODE 1 = UBAH/EDIT -->
 if(isAdd() || isEdit()) {
	$rs_units = mysql_query("select * from units where id = '".$_SESSION['galaxy_unit']."'");
	$rows_units=mysql_fetch_array($rs_units);
	$id = 'id';
	$table = 'moveitems';
	$field = 'mvnom';
	$kode = 'MV';
	$id = Kode($id,$table);
	$mvnom = IDTrans($table,$field,$kode,$rows_units['id'],$rows_units['code']);
 ?>
 
   <div class="popup-shadow" style="width: 600px;">
      <div class="popup-header">
         <span><? if(isAdd()) echo 'Tambah Data'; else echo 'Edit Data'; ?></span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <form action="modul/gudang/mutasi-barang.php" method="post">
      <table>
      <tr>
      <td width="25%">No. Mutasi</td>
      <td width="5%" align="center">:</td>
      <td><input class="input-text" name="mvnom-disable" type="text" value="<? if(isEdit()) echo $rows_moveitems['mvnom'] ?><? if(isAdd()) echo $mvnom ?>"  disabled="disabled"></td>
      </tr>
      <tr>
      <td>Tanggal</td>
      <td align="center">:</td>
      <td><input class="input-text" name="mvdate" type="datepicker" value="<? if(isEdit()) echo cDate($rows_moveitems['mvdate']) ?><? if(isAdd()) echo cDate(date('Y-m-d')) ?>" /></td>
      </tr>
      
      <tr>
      <td>Dari Gudang</td>
      <td align="center">:</td>
      <td><select name="warehouse1_id" class="select-text select-small" <? if(isEdit())  {?>disabled="disabled" <? }?>>
      	<option value="">Pilih..</option>
      <? 	  
	 
	  $qry_warehouse1 = "select * from warehouses LEFT JOIN units_warehouses  ON (units_warehouses.warehouse_id =warehouses.id) WHERE units_warehouses.unit_id = '".$_SESSION['galaxy_unit']."' order by warehouses.id;";	  
	  $rs_warehouse1 = mysql_query($qry_warehouse1);
	  while($rows_warehouse1=mysql_fetch_array($rs_warehouse1)) {
	  ?>
        <option value="<? echo $rows_warehouse1[0]?>" <? if(isEdit()) if($rows_warehouse1[0]==$rows_moveitems['warehouse1_id']) echo 'selected'; ?>><? echo $rows_warehouse1['name']; ?></option>
      <? } ?>
      </select></td>
      </tr>
      <tr>
      <td>Ke Gudang</td>
      <td align="center">:</td>
      <td><select name="warehouse2_id" class="select-text select-small" <? if(isEdit())  {?>disabled="disabled" <? }?>>
      	<option value="">Pilih..</option>
      <? 	  
	 
	  $qry_warehouse2 = "select * from warehouses LEFT JOIN units_warehouses  ON (units_warehouses.warehouse_id =warehouses.id) WHERE units_warehouses.unit_id = '".$_SESSION['galaxy_unit']."' order by warehouses.id;";	  
	  $rs_warehouse2 = mysql_query($qry_warehouse2);
	  while($rows_warehouse2=mysql_fetch_array($rs_warehouse2)) {
	  ?>
        <option value="<? echo $rows_warehouse2[0]?>" <? if(isEdit()) if($rows_warehouse2[0]==$rows_moveitems['warehouse2_id']) echo 'selected'; ?>><? echo $rows_warehouse2['name']; ?></option>
      <? } ?>
      </select></td>
      </tr>
      <tr>
      <td>Keterangan</td>
      <td align="center">:</td>
      <td><textarea rows="4" class="input-text" name="description" type="text"><? if(isEdit()) echo $rows_moveitems['description'] ?></textarea></td>
      </tr>
      </table>
      <? if(isEdit())  {?>
      
      <input type="hidden" name="kode" value="<? echo strtoupper($rows_moveitems['code']) ?>" />
      <input type="hidden" name="unit_id" value="<? echo $rows_moveitems['unit_id'] ?>" />
      
      
      <? }?>
      <input type="hidden" name="gid" value="<? if(isEdit()) echo $_GET['gid'] ?><? if(isAdd()) echo $id ?>" />
      <input type="hidden" name="mvnom" value="<? if(isEdit()) echo $rows_moveitems['mvnom'] ?><? if(isAdd()) echo $mvnom ?>" />
      <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
      </form>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel">Batal</div>
      	<div mode="6" link="library/submenu/gudang/detail/mutasi-barang" class="popup-button" get="<? if(isEdit()) echo $_GET['gid'] ?><? if(isAdd()) echo $id ?>">Simpan</div>
      </div>
   </div>

<? }  
//<!-- END FORM -->

//<!-- =========================================================================================================================== -->
?>

<? 
//<!-- FORM TIPE MODE 2 = CONFIRM DELETE/KONFIRMASI HAPUS, TIPE MODE 4 = CONFIRM DELETE SELECTED/KONFIRMASI HAPUS YANG DIPILIH -->
if(isConfirmDelete() || isConfirmDeleteSelected()) { ?>
<?
	if(isConfirmDelete()) {
		$rs_moveitems = mysql_query("select * from moveitems where id = '".$_GET['gid']."'");
		$rows_moveitems=mysql_fetch_array($rs_moveitems);
	}
?>
   <div class="popup-shadow" style="width: 500px;">
      <div class="popup-header">
         <span>Konfirmasi Hapus</span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <table>
      <tr>
      <td class="center">
      <? if(isConfirmDelete()) {?>
      		<strong>Peringatan</strong>: <br /> 
      		Data <b>Permintaan Pembelian</b> akan ikut terhapus, jika ada data yang terhubung!.
      		<br /><br />
      		Apakah anda yakin menghapus <br /><b style="text-decoration: underline;"><? echo $rows_moveitems['mvnom'] ?></b>?
      <? }?>
      
      <? if(isConfirmDeleteSelected()) {?>
      		<? if($_GET['gid']!='') { 
				$value = array();
				$value = generateArray($_GET['gid']); 
			?>
            	<strong>Peringatan: </strong><br /> Data <b>Satuan Barang</b> akan ikut terhapus, jika ada data yang terhubung!.
      		<br /><br />
                Sebanyak <b style="text-decoration: underline;"><? echo count($value) ?> item</b> yang akan dihapus!.<br />
                Apakah anda yakin untuk menghapusnya?
            <? } else { ?>
            	Tidak ada item yang akan dihapus.<br />Silahkan anda memilih check box untuk dicentang.
            <? } ?>
      <? }?>
      </td>
      </tr>
      </table>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel"><? if($_GET['gid']!='') echo 'Batal'; else echo 'Tutup' ?></div>
        <? if(isConfirmDelete()) { ?>
      		<div mode="3" link="modul/gudang/mutasi-barang?<? echo $_GET['gid'] ?>" class="popup-button">Hapus</div>
        <? }?>
      	<? if(isConfirmDeleteSelected()) {
			if($_GET['gid']!='') {
				if(count($value)>0)
		?>
      		<div mode="5" link="modul/gudang/mutasi-barang?<? echo htmlspecialchars($_GET['gid']) ?>" class="popup-button">Hapus</div>
        <? } } ?>
      </div>
      
   </div>

<? } 

?>

<?
 if(isDelete()) {
	 
	mysql_query("DELETE from trprdetails where trprequest_id =".$_GET['gid']);
	mysql_query("DELETE from moveitems where id =".$_GET['gid']);
	
 } ?>
 
<?
//<!-- END TIPE MODE 3 -->

//<!-- =========================================================================================================================== -->

//<!-- TIPE MODE 5 = DELETE SELECTED/HAPUS YANG DIPILIH -->
?>

<? if(isDeleteSelected()) { 
	
	$value = array();
	$value = generateArray($_GET['gid']); 

	// Taruh query ke database untuk menghapus disini...
	// Contoh :
	for($i=0;$i<count($value);$i++) {
		mysql_query("DELETE from trprdetails where trprequest_id = '".$value[$i]."'");
	 	mysql_query("DELETE from moveitems where id = '".$value[$i]."'");
	}
	
 } 
//<!-- END TIPE MODE 5 -->

//<!-- =========================================================================================================================== -->
?>

<?
//<!-- TIPE MODE 6 = SAVE/MENYIMPAN -->
 if(isSave()) { 

$error = array();
if($_POST['mod']=='0' || $_POST['mod']=='1') {
if(!$_POST['mvdate']) $error[] = 'mvdate:Silahkan Masukkan Tanggal Mutasi.';

if($_POST['mod']=='0') {
if(!$_POST['warehouse1_id']) $error[] = 'warehouse1_id:Silahkan Pilih Gudang.';
if(!$_POST['warehouse2_id']) $error[] = 'warehouse2_id:Silahkan Pilih Gudang Tujuan.';
}

}

if(count($error)>0) {
	echo generateError($error);
	
} else {
	
	if($_POST['mod']=='0') {
		mysql_query("INSERT INTO moveitems (id, mvdate, mvnom, warehouse1_id, warehouse2_id, unit_id, description) VALUES ('".$_POST['gid']."', ".isNull($_POST['mvdate'],'DATE').",  '".$_POST['mvnom']."',  '".$_POST['warehouse1_id']."',  '".$_POST['warehouse2_id']."', '".$_SESSION['galaxy_unit']."',  '".$_POST['description']."')");
	}
	
	if($_POST['mod']=='1') {	
		mysql_query("UPDATE moveitems SET mvdate = ".isNull($_POST['mvdate'],'DATE').", description	 = '".$_POST['description']."' WHERE id ='".$_POST['gid']."';");
	}
	if($_POST['mod']=='8') {	
		mysql_query("UPDATE moveitems SET isclose = '1' WHERE id ='".$_POST['gid']."';");
		$qry_mvdetails = "SELECT * FROM mvdetails where moveitem_id = '".$_POST['gid']."';";
		$rs_mvdetails = mysql_query($qry_mvdetails);
		while($rows_mvdetails=mysql_fetch_array($rs_mvdetails)) {
			mysql_query("INSERT INTO stockitems (stockdate, warehouse_id, item_id, transtype_id, nobukti1, qty, unit_id, moveitem_id) VALUES ('".date('Y-m-d')."', '".$_POST['warehouse1_id']."', '".$rows_mvdetails['item_id']."', '7',  '".$_POST['mvnom']."', '".$rows_mvdetails['qty']."',  '".$_POST['unit_id']."',  '".$_POST['gid']."')");
			mysql_query("INSERT INTO stockitems (stockdate, warehouse_id, item_id, transtype_id, nobukti1, qty, unit_id, moveitem_id) VALUES ('".date('Y-m-d')."', '".$_POST['warehouse2_id']."', '".$rows_mvdetails['item_id']."', '6',  '".$_POST['mvnom']."', '".$rows_mvdetails['qty']."',  '".$_POST['unit_id']."',  '".$_POST['gid']."')");
			
		}
	}
}

} 
//<!-- END TIPE MODE 6 --> 
?>

