<?php
	require_once '../../library/connectionmysql.php';
	Connected();
	
	$perm = array();
	$perm = getPermissions('9');

	if($perm[-1]=='1') { require_once '../../library/error-popup.php'; die; }
			
	if(isEdit())  {
		$rs_trprequests = mysql_query("select * from trprequests where id = '".$_GET['gid']."'");
		$rows_trprequests=mysql_fetch_array($rs_trprequests);
	}
//<!-- =========================================================================================================================== -->
?>

<?
//<!-- FORM TIPE MODE 0 = TAMBAH/ADD, TIPE MODE 1 = UBAH/EDIT -->
 if(isAdd() || isEdit()) {
	$rs_units = mysql_query("select * from units where id = '".$_SESSION['galaxy_unit']."'");
	$rows_units=mysql_fetch_array($rs_units);
	$id = 'id';
	$table = 'trprequests';
	$field = 'prnom';
	$kode = 'PR';
	$id = Kode($id,$table);
	$prnom = IDTrans($table,$field,$kode,$rows_units['id'],$rows_units['code']);
 ?>
 
   <div class="popup-shadow" style="width: 600px;">
      <div class="popup-header">
         <span><? if(isAdd()) echo 'Tambah Data'; else echo 'Edit Data'; ?></span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <form action="modul/gudang/pembuatan-pb.php" method="post">
      <table>
      <tr>
      <td width="25%">No. Permintaan</td>
      <td width="5%" align="center">:</td>
      <td><input class="input-text" name="prnom-disable" type="text" value="<? if(isEdit()) echo $rows_trprequests['prnom'] ?><? if(isAdd()) echo $prnom ?>"  disabled="disabled"></td>
      </tr>
      <tr>
      <td>Tanggal</td>
      <td align="center">:</td>
      <td><input class="input-text" name="prdate" type="datepicker" value="<? if(isEdit()) echo cDate($rows_trprequests['prdate']) ?><? if(isAdd()) echo cDate(date('Y-m-d')) ?>" /></td>
      </tr>
      
      <tr>
      <td>Nama Peminta</td>
      <td align="center">:</td>
      <td><input class="input-text" name="prname" type="text" value="<? if(isEdit()) echo $rows_trprequests['prname'] ?>" /></td>
      </tr>
      
      </table>
      <? if(isEdit())  {?>
      
      <input type="hidden" name="kode" value="<? echo strtoupper($rows_trprequests['code']) ?>" />
      <input type="hidden" name="unit_id" value="<? echo $rows_trprequests['unit_id'] ?>" />
      
      
      <? }?>
      <input type="hidden" name="gid" value="<? if(isEdit()) echo $_GET['gid'] ?><? if(isAdd()) echo $id ?>" />
      <input type="hidden" name="prnom" value="<? if(isEdit()) echo $rows_trprequests['prnom'] ?><? if(isAdd()) echo $prnom ?>" />
      <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
      </form>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel">Batal</div>
      	<div mode="6" link="library/submenu/gudang/detail/pembuatan-pb" class="popup-button" get="<? if(isEdit()) echo $_GET['gid'] ?><? if(isAdd()) echo $id ?>">Simpan</div>
      </div>
   </div>

<? }  
//<!-- END FORM -->

//<!-- =========================================================================================================================== -->
?>

<? 
//<!-- FORM TIPE MODE 2 = CONFIRM DELETE/KONFIRMASI HAPUS, TIPE MODE 4 = CONFIRM DELETE SELECTED/KONFIRMASI HAPUS YANG DIPILIH -->
if(isConfirmDelete() || isConfirmDeleteSelected()) { ?>
<?
	if(isConfirmDelete()) {
		$rs_trprequests = mysql_query("select * from trprequests where id = '".$_GET['gid']."'");
		$rows_trprequests=mysql_fetch_array($rs_trprequests);
	}
?>
   <div class="popup-shadow" style="width: 500px;">
      <div class="popup-header">
         <span>Konfirmasi Hapus</span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <table>
      <tr>
      <td class="center">
      <? if(isConfirmDelete()) {?>
      		<strong>Peringatan</strong>: <br /> 
      		Data <b>Permintaan Pembelian</b> akan ikut terhapus, jika ada data yang terhubung!.
      		<br /><br />
      		Apakah anda yakin menghapus <br /><b style="text-decoration: underline;"><? echo $rows_trprequests['prnom'] ?></b>?
      <? }?>
      
      <? if(isConfirmDeleteSelected()) {?>
      		<? if($_GET['gid']!='') { 
				$value = array();
				$value = generateArray($_GET['gid']); 
			?>
            	<strong>Peringatan: </strong><br /> Data <b>Satuan Barang</b> akan ikut terhapus, jika ada data yang terhubung!.
      		<br /><br />
                Sebanyak <b style="text-decoration: underline;"><? echo count($value) ?> item</b> yang akan dihapus!.<br />
                Apakah anda yakin untuk menghapusnya?
            <? } else { ?>
            	Tidak ada item yang akan dihapus.<br />Silahkan anda memilih check box untuk dicentang.
            <? } ?>
      <? }?>
      </td>
      </tr>
      </table>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel"><? if($_GET['gid']!='') echo 'Batal'; else echo 'Tutup' ?></div>
        <? if(isConfirmDelete()) { ?>
      		<div mode="3" link="modul/gudang/pembuatan-pb?<? echo $_GET['gid'] ?>" class="popup-button">Hapus</div>
        <? }?>
      	<? if(isConfirmDeleteSelected()) {
			if($_GET['gid']!='') {
				if(count($value)>0)
		?>
      		<div mode="5" link="modul/gudang/pembuatan-pb?<? echo htmlspecialchars($_GET['gid']) ?>" class="popup-button">Hapus</div>
        <? } } ?>
      </div>
      
   </div>

<? } 

?>

<?
 if(isDelete()) {
	 
	mysql_query("DELETE from trprdetails where trprequest_id =".$_GET['gid']);
	mysql_query("DELETE from trprequests where id =".$_GET['gid']);
	
 } ?>
 
<?
//<!-- END TIPE MODE 3 -->

//<!-- =========================================================================================================================== -->

//<!-- TIPE MODE 5 = DELETE SELECTED/HAPUS YANG DIPILIH -->
?>

<? if(isDeleteSelected()) { 
	
	$value = array();
	$value = generateArray($_GET['gid']); 

	// Taruh query ke database untuk menghapus disini...
	// Contoh :
	for($i=0;$i<count($value);$i++) {
		mysql_query("DELETE from trprdetails where trprequest_id = '".$value[$i]."'");
	 	mysql_query("DELETE from trprequests where id = '".$value[$i]."'");
	}
	
 } 
//<!-- END TIPE MODE 5 -->

//<!-- =========================================================================================================================== -->
?>

<?
//<!-- TIPE MODE 6 = SAVE/MENYIMPAN -->
 if(isSave()) { 

$error = array();
if(!$_POST['prdate']) $error[] = 'prdate:Silahkan Masukkan Tanggal Kebutuhan.';
if(!$_POST['prname']) $error[] = 'prname:Silahkan Masukkan Kode Unit.';

if(count($error)>0) {
	echo generateError($error);
	
} else {
	
	if($_POST['mod']=='0') {
		mysql_query("INSERT INTO trprequests (id, unit_id, prdate, prname, prnom) VALUES ('".$_POST['gid']."', '".$_SESSION['galaxy_unit']."', ".isNull($_POST['prdate'],'DATE').", '".$_POST['prname']."', '".$_POST['prnom']."')");
		
	}
	
	if($_POST['mod']=='1') {	
		mysql_query("UPDATE trprequests SET prdate = ".isNull($_POST['prdate'],'DATE').", prname = '".$_POST['prname']."' WHERE id ='".$_POST['gid']."';");
		
		
		
	}
	
	
		
}

} 
//<!-- END TIPE MODE 6 --> 
?>

