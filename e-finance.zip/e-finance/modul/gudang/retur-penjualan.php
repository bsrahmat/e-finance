<?php
	require_once '../../library/connectionmysql.php';
	Connected();
	
	$perm = array();
	$perm = getPermissions('14');
	if($perm[-1]=='1') { require_once '../../library/error-popup.php'; die; }
	
	if(isEdit()) {
		$rs_sreturs = mysql_query("SELECT * FROM sreturs  WHERE id = '".$_GET['gid']."'");
		$rows_sreturs=mysql_fetch_array($rs_sreturs);
	}
	if(isAdd()) {
		 $rs_units = mysql_query("select * from units where id = '".$_SESSION['galaxy_unit']."'");
		 $rows_units=mysql_fetch_array($rs_units);
		 $retnom = IDTransRet2($rows_units['code']);
		 $id = 'id';
		 $table = 'sreturs';
		 $id = Kode($id,$table);
	}
		
?>

<?
//<!-- FORM TIPE MODE 0 = TAMBAH/ADD, TIPE MODE 1 = UBAH/EDIT -->
 if(isAdd() || isEdit()) {
 ?>
 
   <div class="popup-shadow" style="width: 600px;">
      <div class="popup-header">
         <span><? if(isAdd()) {echo 'Tambah Retur Penjualan'; } if(isEdit()) {echo 'Edit Retur Penjualan'; }  ?></span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <form action="modul/gudang/retur-penjualan.php" method="post">
      <table>
      <tr>
      <td width="27%">No. Retur</td>
      <td width="5%" align="center">:</td>
      <td><input class="input-text" name="prnom-disable" type="text" value="<? if(isEdit()) echo $rows_sreturs['retnom'] ?><? if(isAdd()) echo $retnom ?>" readonly="readonly"></td>
      </tr>
      <tr>
      <td>No. Faktur</td>
      <td align="center">:</td>
      <td><select name="faktur_id" class="select-text select-small" <? if(isEdit()) { echo 'disabled="disabled"'; } ?>>
      	<option value="">Pilih..</option>
      <? 	  
	  $qry_fakturs = '';
	  if($_SESSION['galaxy_type']=='0')	{
		  $qry_fakturs = "select * from fakturs WHERE unitid != '10' AND ispost = '1' order by id;";
	  }
	  else{
	  	$qry_fakturs = "select * from fakturs WHERE unitid = '".$_SESSION['galaxy_unit']."'  AND ispost = '1' order by id;";
	  } 
	  $rs_fakturs = mysql_query($qry_fakturs);
	  while($rows_fakturs=mysql_fetch_array($rs_fakturs)) {
	  ?>
        <option value="<? echo $rows_fakturs['id']?>" <? if(isEdit()) if($rows_fakturs['id']==$rows_sreturs['faktur_id']) echo 'selected'; ?>><? echo $rows_fakturs['faknom']; ?></option>
      <? } ?>
      </select></td>
      </tr>
      <tr>
      <td>Tanggal</td>
      <td align="center">:</td>
      <td><input class="input-text" name="retdate" type="datepicker" value="<? if(isEdit()) echo cDate($rows_sreturs['retdate']) ?><? if(isAdd()) echo cDate(date('Y-m-d')) ?>" /></td>
      </tr>
      </table>
      <input type="hidden" name="retnom" value="<? if(isEdit()) echo $rows_sreturs['retnom'] ?><? if(isAdd()) echo $retnom ?>" />
      <input type="hidden" name="gid" value="<? if(isEdit()) echo $_GET['gid'] ?><? if(isAdd()) echo $id ?>" />
      <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
      
      </form>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel">Batal</div>
      	<div mode="6" link="library/submenu/gudang/detail/retur-penjualan" class="popup-button" get="<? if(isEdit()) echo $_GET['gid'] ?><? if(isAdd()) echo $id ?>">Simpan</div>
      </div>
   </div>

<? }  ?>

<? 
if(isConfirmDelete()) {
	$rs_sreturs = mysql_query("select * from sreturs where id = '".$_GET['gid']."'");
	$rows_sreturs=mysql_fetch_array($rs_sreturs);
?>
   <div class="popup-shadow" style="width: 500px;">
      <div class="popup-header">
         <span>Notifikasi Hapus</span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <form action="modul/gudang/retur-penjualan.php" method="post">
      <table>
      <tr>
      <td class="center">
  
      		<strong>Peringatan</strong>: <br /> 
      		Data <b>Retur Penjualan</b> akan ikut terhapus, jika ada data yang terhubung!.
      		<br /><br />
      		Apakah anda yakin menghapus Kode : <b style="text-decoration: underline;"><? echo $rows_sreturs['retnom'] ?></b>?
      <input type="hidden" name="gid" value="<? echo $_GET['gid'] ?>" />
      <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
     
      </td>
      </tr>
      </table>
      </form>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel"><? if($_GET['gid']!='') echo 'Batal'; else echo 'Tutup' ?></div>
        <div mode="6" link="library/submenu/gudang/retur-penjualan" class="popup-button" get="">Hapus</div>
      </div>
      
   </div>

<? } 
?>

<? 
if(isApply()) {
	$rs_sreturs = mysql_query("select * from sreturs where id = '".$_GET['gid']."'");
	$rows_sreturs=mysql_fetch_array($rs_sreturs);
?>
   <div class="popup-shadow" style="width: 500px;">
      <div class="popup-header">
         <span>Notifikasi Close</span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <form action="modul/gudang/retur-penjualan.php" method="post">
      <table>
      <tr>
      <td class="center">
  
      		<strong>Peringatan</strong>: <br /> 
      		Data <b>Retur Penjualan</b> Akan Di ajukan Ke Kepala Pembelian!.
      		<br /><br />
      		Dengan No Retur : <b style="text-decoration: underline;"><? echo $rows_sreturs['retnom'] ?></b>?
      <input type="hidden" name="gid" value="<? echo $_GET['gid'] ?>" />
      <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
     
      </td>
      </tr>
      </table>
      </form>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel"><? if($_GET['gid']!='') echo 'Batal'; else echo 'Tutup' ?></div>
        <div mode="6" link="library/submenu/gudang/retur-penjualan" class="popup-button" get="">Proses</div>
      </div>
      
   </div>

<? } 
?>


<?
//<!-- TIPE MODE 6 = SAVE/MENYIMPAN -->
 if(isSave()) {
	$error = array();
if($_POST['mod']=='1' || $_POST['mod'] == '0') {
if(!$_POST['retdate']) $error[] = 'retdate:Silahkan masukkan Tanggal Retur.';
}
if($_POST['mod']=='0') {
if(!$_POST['faktur_id']) $error[] = 'faktur_id:Silahkan Pilih No Fakturs.';
}		

if(count($error)>0) {
	echo generateError($error);
	
} else { 
	 
	if($_POST['mod']=='0') {
	mysql_query("INSERT INTO sreturs (id, faktur_id, retdate, retnom, unitid, isclosed) VALUES ('".$_POST['gid']."', '".$_POST['faktur_id']."', ".isNull($_POST['retdate'],'DATE').", '".$_POST['retnom']."', '".$_SESSION['galaxy_unit']."', '0')");
	}
	if($_POST['mod']=='1') {	
		mysql_query("UPDATE sreturs SET retdate = ".isNull($_POST['retdate'],'DATE')." WHERE id ='".$_POST['gid']."';");
	}
	if($_POST['mod']=='2') {	
		mysql_query("DELETE from sreturs where id =".$_POST['gid']);
		$qry_sretdetails = "select * from sretdetails JOIN items ON ( sretdetails.item_id = items.id) where sretdetails.sretur_id = '".$_POST['gid']."';";
		$rs_sretdetails = mysql_query($qry_sretdetails);
		while($rows_sretdetails=mysql_fetch_array($rs_sretdetails)) {
			mysql_query("UPDATE fakdetails SET fakstatus = '1' WHERE id ='".$rows_sretdetails['fakdetails_id']."';");
			mysql_query("DELETE from sretdetails where sretur_id =".$_POST['gid']);
		}
	}
	if($_POST['mod']=='7') {	
		mysql_query("UPDATE sreturs SET isok = '1' WHERE id ='".$_POST['gid']."';");
	}
 }
 }
?>

