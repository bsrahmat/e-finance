<?php
	require_once '../../library/connectionmysql.php';
	Connected();
	
	$perm = array();
	$perm = getPermissions('13');

	if($perm[-1]=='1') { require_once '../../library/error-popup.php'; die; }
		
	if(isEdit() || isAdd())  {
		$rs_sjs = mysql_query("SELECT sjs.id, sjs.spb_id, sjs.sjdate, sjs.sjnom, sjs.unitid, sjs.isclosed, sjs.istaken, sjs.warehouse_id, sjs.jtdate, spbs.id, spbs.spbdate, spbs.spbnom, spbs.customer_id, spbs.sale_id, spbs.description, spbs.unit_id, spbs.isclosed, spbs.istake, spbs.tempodate FROM sjs LEFT JOIN spbs ON (sjs.spb_id = spbs.id) where sjs.id = '".$_GET['gid']."'");
		$rows_sjs=mysql_fetch_array($rs_sjs);
		$rows_customer=mysql_fetch_array(mysql_query("select * from customers where id = '".$rows_sjs['customer_id']."';"));
		$rows_sales=mysql_fetch_array(mysql_query("select * from sales where id = '".$rows_sjs['sale_id']."';"));
	}
//<!-- =========================================================================================================================== -->
?>
<?
//<!-- FORM TIPE MODE 0 = TAMBAH/ADD, TIPE MODE 1 = UBAH/EDIT -->
 if(isEdit()) {
	 $rs_units = mysql_query("select * from units where id = '".$_SESSION['galaxy_unit']."'");
	$rows_units=mysql_fetch_array($rs_units);
	$id = 'id';
	$table = 'sjs';
	$id = Kode($id,$table);
	$sjnom = IDTransSJ($rows_units['code']);
?>
 
   <div class="popup-shadow" style="width: 600px;">
      <div class="popup-header">
         <span>Edit SJ</span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <form action="modul/gudang/pembuatan-sj.php" method="post">
      <table>
      <tr>
      <td width="25%">No. SJ</td>
      <td width="5%" align="center">:</td>
      <td><input class="input-text input-small" name="prnom-disable" type="text" value="<? if($rows_sjs[5]== '2' || $rows_sjs[5]== '') {echo $sjnom;}else{echo $rows_sjs['sjnom'];} ?>" readonly="readonly"></td>
      </tr>
      <tr>
      <td width="25%">No. SPB</td>
      <td width="5%" align="center">:</td>
      <td><input class="input-text input-small" name="prnom-disable" type="text" value="<? echo $rows_sjs['spbnom']; ?>"  readonly="readonly"></td>
      </tr>
      <tr>
      <td>Tanggal Sj</td>
      <td align="center">:</td>
      <td><input class="input-text" name="sjdate" type="datepicker" value="<? if($rows_sjs[5]!= '2' || $rows_sjs[5]!= '') {echo cDate(date('Y-m-d'));}else{echo cDate($rows_sjs['sjdate']);} ?>" /></td>
      </tr>
      <tr>
      <td>Tanggal Jatuh Tempo</td>
      <td align="center">:</td>
      <td><input class="input-text" name="jtdate" type="datepicker" value="<? if($rows_sjs[5]!= '2' || $rows_sjs[5]!= '') {echo cDate(date('Y-m-d'));}else{echo cDate($rows_sjs['jtdate']);} ?>" /></td>
      </tr>
      <tr>
      <td>Customer</td>
      <td align="center">:</td>
      <td><input class="input-text" name="nama-cus" type="text" value="<? if(isEdit()) echo $rows_customer['name'] ?>" readonly="readonly"/></td>
      </tr>
      <tr>
      <td>Sales</td>
      <td align="center">:</td>
      <td><input class="input-text" name="nama-sale" type="text" value="<? if(isEdit()) echo $rows_sales['name'] ?>" readonly="readonly"/></td>
      </tr>
      <tr>
      <td>Gudang Pengirim</td>
      <td align="center">:</td>
      <td><select name="warehouse_id" class="select-text select-medium">
      	<option value="">Pilih..</option>
      <? 	  
	  $qry_warehouses = "select * from warehouses JOIN units_warehouses ON (units_warehouses.warehouse_id = warehouses.id) WHERE units_warehouses.unit_id = '".$_SESSION['galaxy_unit']."' order by units_warehouses.id;";
	  $rs_warehouses = mysql_query($qry_warehouses);
	  while($rows_warehouses=mysql_fetch_array($rs_warehouses)) {
	  ?>
        <option value="<? echo $rows_warehouses[0]?>" <? if(isEdit()) if($rows_warehouses[0]==$rows_sjs['warehouse_id']) echo 'selected'; ?>><? echo $rows_warehouses['name']; ?></option>
      <? } ?>
      </select></td>
      </tr>
      
      </table>
      
      <input type="hidden" name="unit_id" value="<? echo $rows_sjs['unit_id'] ?>" />
      
      <input type="hidden" name="gid" value="<? echo $_GET['gid'] ?>" />
      <input type="hidden" name="sjnom" value="<? if($rows_sjs[5]== '2' || $rows_sjs[5]== '') {echo $sjnom;}else{echo $rows_sjs['sjnom'];} ?>" />
      <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
      </form>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel">Batal</div>
      	<div mode="6" link="library/submenu/gudang/detail/pembuatan-sj" class="popup-button" get="<? echo $_GET['gid']; ?>">Simpan</div>
      </div>
   </div>

<? } ?>  

<?
//<!-- FORM TIPE MODE 0 = TAMBAH/ADD, TIPE MODE 1 = UBAH/EDIT -->
 if(isAdd()) {
	
 ?>
 
   <div class="popup-shadow" style="width: 600px;">
      <div class="popup-header">
         <span>Penerimaan SJ</span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <form action="modul/gudang/pembuatan-sj.php" method="post">
      <table>
      
      <tr>
      <td class="center">Sudah Di Terima Dengan No SJ : <? echo $rows_sjs['sjnom'] ?></td>
      </tr>
            
      </table>
      <input type="hidden" name="tempodate" value="<? echo $rows_sjs['jtdate'] ?>" />
      <input type="hidden" name="gid" value="<? echo $_GET['gid'] ?>" />
      <input type="hidden" name="isclosed" value="<? echo $rows_sjs[5] ?>" />
      <input type="hidden" name="istaken" value="<? echo $rows_sjs[6] ?>" />
      <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
      </form>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel">Batal</div>
      	<div mode="6" link="library/submenu/gudang/pembuatan-sj" class="popup-button" get="">Simpan</div>
      </div>
   </div>

<? }  
//<!-- END FORM -->

//<!-- =========================================================================================================================== -->
?>

<? 
//<!-- FORM TIPE MODE 2 = CONFIRM DELETE/KONFIRMASI HAPUS, TIPE MODE 4 = CONFIRM DELETE SELECTED/KONFIRMASI HAPUS YANG DIPILIH -->
if(isConfirmDelete() || isConfirmDeleteSelected()) { ?>
<?
	if(isConfirmDelete()) {
		$rs_sjs = mysql_query("select * from sjs where id = '".$_GET['gid']."'");
		$rows_sjs=mysql_fetch_array($rs_sjs);
	}
?>
   <div class="popup-shadow" style="width: 500px;">
      <div class="popup-header">
         <span>Konfirmasi Hapus</span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <table>
      <tr>
      <td class="center">
      <? if(isConfirmDelete()) {?>
      		<strong>Peringatan</strong>: <br /> 
      		Data <b>Permintaan Pembelian</b> akan ikut terhapus, jika ada data yang terhubung!.
      		<br /><br />
      		Apakah anda yakin menghapus <br /><b style="text-decoration: underline;"><? echo $rows_sjs['prnom'] ?></b>?
      <? }?>
      
      <? if(isConfirmDeleteSelected()) {?>
      		<? if($_GET['gid']!='') { 
				$value = array();
				$value = generateArray($_GET['gid']); 
			?>
            	<strong>Peringatan: </strong><br /> Data <b>Satuan Barang</b> akan ikut terhapus, jika ada data yang terhubung!.
      		<br /><br />
                Sebanyak <b style="text-decoration: underline;"><? echo count($value) ?> item</b> yang akan dihapus!.<br />
                Apakah anda yakin untuk menghapusnya?
            <? } else { ?>
            	Tidak ada item yang akan dihapus.<br />Silahkan anda memilih check box untuk dicentang.
            <? } ?>
      <? }?>
      </td>
      </tr>
      </table>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel"><? if($_GET['gid']!='') echo 'Batal'; else echo 'Tutup' ?></div>
        <? if(isConfirmDelete()) { ?>
      		<div mode="3" link="modul/gudang/pembuatan-sj?<? echo $_GET['gid'] ?>" class="popup-button">Hapus</div>
        <? }?>
      	<? if(isConfirmDeleteSelected()) {
			if($_GET['gid']!='') {
				if(count($value)>0)
		?>
      		<div mode="5" link="modul/gudang/pembuatan-sj?<? echo htmlspecialchars($_GET['gid']) ?>" class="popup-button">Hapus</div>
        <? } } ?>
      </div>
      
   </div>

<? } 

?>

<?
 if(isDelete()) {
	 
	mysql_query("DELETE from trprdetails where trprequest_id =".$_GET['gid']);
	mysql_query("DELETE from sjs where id =".$_GET['gid']);
	
 } ?>
 
<?
//<!-- END TIPE MODE 3 -->

//<!-- =========================================================================================================================== -->

//<!-- TIPE MODE 5 = DELETE SELECTED/HAPUS YANG DIPILIH -->
?>

<? if(isDeleteSelected()) { 
	
	$value = array();
	$value = generateArray($_GET['gid']); 

	// Taruh query ke database untuk menghapus disini...
	// Contoh :
	for($i=0;$i<count($value);$i++) {
		mysql_query("DELETE from trprdetails where trprequest_id = '".$value[$i]."'");
	 	mysql_query("DELETE from sjs where id = '".$value[$i]."'");
	}
	
 } 
//<!-- END TIPE MODE 5 -->

//<!-- =========================================================================================================================== -->
?>

<?
//<!-- TIPE MODE 6 = SAVE/MENYIMPAN -->
 if(isSave()) { 

$error = array();
if($_POST['mod']=='1') {	
if(!$_POST['sjdate']) $error[] = 'sjdate:Silahkan Masukkan Tanggal SJ.';
if(!$_POST['jtdate']) $error[] = 'jtdate:Silahkan Masukkan Tanggal Jatuh Tempo.';
if(!$_POST['warehouse_id']) $error[] = 'warehouse_id:Silahkan Pilih Gudang Penerima.';
}
if(count($error)>0) {
	echo generateError($error);
	
} else {
	
	if($_POST['mod']=='0') {
		if($_POST['isclosed']=='1') {
			mysql_query("UPDATE  sjs SET istaken = '1' WHERE id ='".$_POST['gid']."';");
			$id = 'id';
			$table = ' fakturs';
			$id_faktur = Kode($id,$table);
			mysql_query("INSERT INTO fakturs (id, sj_id, unitid, tempodate, ispost) VALUES ('".$id_faktur."' ,'".$_POST['gid']."', '".$_SESSION['galaxy_unit']."', '".$_POST['tempodate']."', '0')");
		
			$qry_sjdetail = "SELECT * FROM sjdetails where sj_id = '".$_POST['gid']."';";
			$rs_sjdetail = mysql_query($qry_sjdetail);
			while($rows_sjdetail=mysql_fetch_array($rs_sjdetail)) {
				mysql_query("INSERT INTO fakdetails (faktur_id, item_id, qty, price, disc, ppnperitem, description) VALUES ('".$id_faktur."' ,'".$rows_sjdetail['item_id']."', '".$rows_sjdetail['qty']."', '".$rows_sjdetail['price']."', '".$rows_sjdetail['disc']."', '".$rows_sjdetail['ppnperitem']."', '".$rows_sjdetail['description']."')");
			}
		
		}else{
		mysql_query("UPDATE  sjs SET isclosed = '0' WHERE id ='".$_POST['gid']."';");
		}
		
	}
	
	if($_POST['mod']=='1') {	
		mysql_query("UPDATE  sjs SET sjdate = ".isNull($_POST['sjdate'],'DATE').", jtdate = ".isNull($_POST['jtdate'],'DATE').", sjnom = '".$_POST['sjnom']."', warehouse_id = '".$_POST['warehouse_id']."', isclosed = '0' WHERE id ='".$_POST['gid']."';");
		
		
		
	}
	
	
		
}

} 
//<!-- END TIPE MODE 6 --> 
?>

