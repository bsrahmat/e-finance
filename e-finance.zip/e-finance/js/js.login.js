var sIndex=0; var timeOut;
jQuery(document).ready(function() {
$("input:text:first").val('');
$("input:text:last").val('');
$('input').click(function() { 
	var self = $(this);
	
})
$("input:text:first").focus()

$("input[name='user_name']").keypress(function(e) { 
	if(e.keyCode==13) { 
		var self = $(this);
		e.preventDefault();
		if($(this).val()=='') {
			self.parent().children('p').html('Silahkan memasukkan <b class="tunder">Username</b> anda terlebih dahulu.');
			clearTimeout(timeOut)
			timeOut = setTimeout(function() {
				self.parent().children('p').html('Tekan <b class="tunder">Enter</b> untuk memasukkan password.');
			},2000);
			$("input[name='user_name']").focus()
			sIndex = 0;
		} else {
			clearTimeout(timeOut)
			self.parent().children('p').html('<b>Okay</b>');
			$("input[name='pass_word']").focus()
			$("input[name='pass_word']").parent().children('p').html('Tekan <b class="tunder">Enter</b> untuk <b class="tunder">Login</b>.');
			sIndex = 1;
		}
	}
})
$("input[name='pass_word']").keypress(function(e) { 
	if(e.keyCode==13) { 
		var self = $(this);
		e.preventDefault();
		if($(this).val()=='') {
			self.parent().children('p').html('Silahkan masukkan <b class="tunder">Password</b> anda terlebih dahulu.');
			clearTimeout(timeOut)
			timeOut = setTimeout(function() {
				self.parent().children('p').html('Tekan <b class="tunder">Enter</b> untuk <b class="tunder">Login</b>.');
			},2000);
			sIndex = 1;
		} else {
			clearTimeout(timeOut)
			self.parent().children('p').html('<b>Okay</b>');
			sIndex = 1;
			$(this).parents('form').ajaxForm(function(data) { 
				if(data!='') {
					sIndex = 0;
					$("input[name='user_name']").focus();
					$('.border, .container').css('height',270+'px');
					var dt = data.split(':');
					$("."+dt[0]).html(dt[1]).show();
				} else {
					$('.border, .container').css('height',210+'px');
					$('.error').hide();
					$('.body').hide();
					$('.main').show();
					window.location = "simonev.php"
				}
			}).submit();
		}
	}
})
$('html, body').keypress(function(e) { 
	if(e.keyCode==13) { 
		if(sIndex==0)
		$("input:text").eq(sIndex).focus()
	}
})

})